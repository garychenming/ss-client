(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

var __extends = undefined && undefined.__extends || function () {
    var extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function (d, b) {
        d.__proto__ = b;
    } || function (d, b) {
        for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
        }
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
(function iife() {
    var platformExportObj = function detectPlatformExportObj() {
        if (typeof module !== 'undefined' && module.exports) {
            return module.exports; // node
        } else if (typeof window !== 'undefined') {
            return window; // browser
        }
        throw new Error('Could not detect platform global object (no window or module.exports)');
    }();
    /* tslint:disable */
    var isBrowser = typeof window !== 'undefined';
    var b64Encode = isBrowser ? btoa : require('base-64').encode;
    var b64Decode = isBrowser ? atob : require('base-64').decode;
    var URL = isBrowser ? window.URL : require('url').URL;
    var punycode = isBrowser ? window.punycode : require('punycode');
    if (!punycode) {
        throw new Error("Could not find punycode. Did you forget to add e.g.\n  <script src=\"bower_components/punycode/punycode.min.js\"></script>?");
    }
    /* tslint:enable */
    // Custom error base class
    var ShadowsocksConfigError = /** @class */function (_super) {
        __extends(ShadowsocksConfigError, _super);
        function ShadowsocksConfigError(message) {
            var _newTarget = this.constructor;
            var _this = _super.call(this, message) || this;
            Object.setPrototypeOf(_this, _newTarget.prototype); // restore prototype chain
            _this.name = _newTarget.name;
            return _this;
        }
        return ShadowsocksConfigError;
    }(Error);
    platformExportObj.ShadowsocksConfigError = ShadowsocksConfigError;
    var InvalidConfigField = /** @class */function (_super) {
        __extends(InvalidConfigField, _super);
        function InvalidConfigField() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return InvalidConfigField;
    }(ShadowsocksConfigError);
    platformExportObj.InvalidConfigField = InvalidConfigField;
    var InvalidUri = /** @class */function (_super) {
        __extends(InvalidUri, _super);
        function InvalidUri() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return InvalidUri;
    }(ShadowsocksConfigError);
    platformExportObj.InvalidUri = InvalidUri;
    // Self-validating/normalizing config data types implement this ValidatedConfigField interface.
    // Constructors take some data, validate, normalize, and store if valid, or throw otherwise.
    var ValidatedConfigField = /** @class */function () {
        function ValidatedConfigField() {}
        return ValidatedConfigField;
    }();
    platformExportObj.ValidatedConfigField = ValidatedConfigField;
    function throwErrorForInvalidField(name, value, reason) {
        throw new InvalidConfigField("Invalid " + name + ": " + value + " " + (reason || ''));
    }
    var Host = /** @class */function (_super) {
        __extends(Host, _super);
        function Host(host) {
            var _this = _super.call(this) || this;
            if (!host) {
                throwErrorForInvalidField('host', host);
            }
            if (host instanceof Host) {
                host = host.data;
            }
            host = punycode.toASCII(host);
            _this.isIPv4 = Host.IPV4_PATTERN.test(host);
            _this.isIPv6 = _this.isIPv4 ? false : Host.IPV6_PATTERN.test(host);
            _this.isHostname = _this.isIPv4 || _this.isIPv6 ? false : Host.HOSTNAME_PATTERN.test(host);
            if (!(_this.isIPv4 || _this.isIPv6 || _this.isHostname)) {
                throwErrorForInvalidField('host', host);
            }
            _this.data = host;
            return _this;
        }
        Host.IPV4_PATTERN = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;
        Host.IPV6_PATTERN = /^(?:[A-F0-9]{1,4}:){7}[A-F0-9]{1,4}$/i;
        Host.HOSTNAME_PATTERN = /^[A-z0-9]+[A-z0-9_.-]*$/;
        return Host;
    }(ValidatedConfigField);
    platformExportObj.Host = Host;
    var Port = /** @class */function (_super) {
        __extends(Port, _super);
        function Port(port) {
            var _this = _super.call(this) || this;
            if (port instanceof Port) {
                port = port.data;
            }
            if (typeof port === 'number') {
                // Stringify in case negative or floating point -> the regex test below will catch.
                port = port.toString();
            }
            if (!Port.PATTERN.test(port)) {
                throwErrorForInvalidField('port', port);
            }
            // Could exceed the maximum port number, so convert to Number to check. Could also have leading
            // zeros. Converting to Number drops those, so we get normalization for free. :)
            port = Number(port);
            if (port > 65535) {
                throwErrorForInvalidField('port', port);
            }
            _this.data = port;
            return _this;
        }
        Port.PATTERN = /^[0-9]{1,5}$/;
        return Port;
    }(ValidatedConfigField);
    platformExportObj.Port = Port;
    // A method value must exactly match an element in the set of known ciphers.
    // ref: https://github.com/shadowsocks/shadowsocks-libev/blob/10a2d3e3/completions/bash/ss-redir#L5
    platformExportObj.METHODS = new Set(['rc4-md5', 'aes-128-gcm', 'aes-192-gcm', 'aes-256-gcm', 'aes-128-cfb', 'aes-192-cfb', 'aes-256-cfb', 'aes-128-ctr', 'aes-192-ctr', 'aes-256-ctr', 'camellia-128-cfb', 'camellia-192-cfb', 'camellia-256-cfb', 'bf-cfb', 'chacha20-ietf-poly1305', 'salsa20', 'chacha20', 'chacha20-ietf', 'xchacha20-ietf-poly1305']);
    var Method = /** @class */function (_super) {
        __extends(Method, _super);
        function Method(method) {
            var _this = _super.call(this) || this;
            if (method instanceof Method) {
                method = method.data;
            }
            if (!platformExportObj.METHODS.has(method)) {
                throwErrorForInvalidField('method', method);
            }
            _this.data = method;
            return _this;
        }
        return Method;
    }(ValidatedConfigField);
    platformExportObj.Method = Method;
    var Password = /** @class */function (_super) {
        __extends(Password, _super);
        function Password(password) {
            var _this = _super.call(this) || this;
            _this.data = password instanceof Password ? password.data : password;
            return _this;
        }
        return Password;
    }(ValidatedConfigField);
    platformExportObj.Password = Password;
    var Tag = /** @class */function (_super) {
        __extends(Tag, _super);
        function Tag(tag) {
            if (tag === void 0) {
                tag = '';
            }
            var _this = _super.call(this) || this;
            _this.data = tag instanceof Tag ? tag.data : tag;
            return _this;
        }
        return Tag;
    }(ValidatedConfigField);
    platformExportObj.Tag = Tag;
    // tslint:disable-next-line:no-any
    function makeConfig(input) {
        // Use "!" for the required fields to tell tsc that we handle undefined in the
        // ValidatedConfigFields we call; tsc can't figure that out otherwise.
        var config = {
            host: new Host(input.host),
            port: new Port(input.port),
            method: new Method(input.method),
            password: new Password(input.password),
            tag: new Tag(input.tag),
            extra: {}
        };
        // Put any remaining fields in `input` into `config.extra`.
        for (var _i = 0, _a = Object.keys(input); _i < _a.length; _i++) {
            var key = _a[_i];
            if (!/^(host|port|method|password|tag)$/.test(key)) {
                config.extra[key] = input[key] && input[key].toString();
            }
        }
        return config;
    }
    platformExportObj.makeConfig = makeConfig;
    platformExportObj.SHADOWSOCKS_URI = {
        PROTOCOL: 'ss:',
        getUriFormattedHost: function getUriFormattedHost(host) {
            return host.isIPv6 ? "[" + host.data + "]" : host.data;
        },
        getHash: function getHash(tag) {
            return tag.data ? "#" + encodeURIComponent(tag.data) : '';
        },
        validateProtocol: function validateProtocol(uri) {
            if (!uri.startsWith(platformExportObj.SHADOWSOCKS_URI.PROTOCOL)) {
                throw new InvalidUri("URI must start with \"" + platformExportObj.SHADOWSOCKS_URI.PROTOCOL + "\"");
            }
        },
        parse: function parse(uri) {
            var error;
            for (var _i = 0, _a = [platformExportObj.SIP002_URI, platformExportObj.LEGACY_BASE64_URI]; _i < _a.length; _i++) {
                var uriType = _a[_i];
                try {
                    return uriType.parse(uri);
                } catch (e) {
                    error = e;
                }
            }
            if (!(error instanceof InvalidUri)) {
                var originalErrorName = error.name || '(Unnamed Error)';
                var originalErrorMessage = error.message || '(no error message provided)';
                var originalErrorString = originalErrorName + ": " + originalErrorMessage;
                var newErrorMessage = "Invalid input: " + originalErrorString;
                error = new InvalidUri(newErrorMessage);
            }
            throw error;
        }
    };
    // Ref: https://shadowsocks.org/en/config/quick-guide.html
    platformExportObj.LEGACY_BASE64_URI = {
        parse: function parse(uri) {
            platformExportObj.SHADOWSOCKS_URI.validateProtocol(uri);
            var hashIndex = uri.indexOf('#');
            var hasTag = hashIndex !== -1;
            var b64EndIndex = hasTag ? hashIndex : uri.length;
            var tagStartIndex = hasTag ? hashIndex + 1 : uri.length;
            var tag = new Tag(decodeURIComponent(uri.substring(tagStartIndex)));
            var b64EncodedData = uri.substring('ss://'.length, b64EndIndex);
            var b64DecodedData = b64Decode(b64EncodedData);
            var atSignIndex = b64DecodedData.lastIndexOf('@');
            if (atSignIndex === -1) {
                throw new InvalidUri("Missing \"@\"");
            }
            var methodAndPassword = b64DecodedData.substring(0, atSignIndex);
            var methodEndIndex = methodAndPassword.indexOf(':');
            if (methodEndIndex === -1) {
                throw new InvalidUri("Missing password");
            }
            var methodString = methodAndPassword.substring(0, methodEndIndex);
            var method = new Method(methodString);
            var passwordStartIndex = methodEndIndex + 1;
            var passwordString = methodAndPassword.substring(passwordStartIndex);
            var password = new Password(passwordString);
            var hostStartIndex = atSignIndex + 1;
            var hostAndPort = b64DecodedData.substring(hostStartIndex);
            var hostEndIndex = hostAndPort.lastIndexOf(':');
            if (hostEndIndex === -1) {
                throw new InvalidUri("Missing port");
            }
            var uriFormattedHost = hostAndPort.substring(0, hostEndIndex);
            var host;
            try {
                host = new Host(uriFormattedHost);
            } catch (_) {
                // Could be IPv6 host formatted with surrounding brackets, so try stripping first and last
                // characters. If this throws, give up and let the exception propagate.
                host = new Host(uriFormattedHost.substring(1, uriFormattedHost.length - 1));
            }
            var portStartIndex = hostEndIndex + 1;
            var portString = hostAndPort.substring(portStartIndex);
            var port = new Port(portString);
            var extra = {}; // empty because LegacyBase64Uri can't hold extra
            return { method: method, password: password, host: host, port: port, tag: tag, extra: extra };
        },
        stringify: function stringify(config) {
            var host = config.host,
                port = config.port,
                method = config.method,
                password = config.password,
                tag = config.tag;
            var hash = platformExportObj.SHADOWSOCKS_URI.getHash(tag);
            var b64EncodedData = b64Encode(method.data + ":" + password.data + "@" + host.data + ":" + port.data);
            var dataLength = b64EncodedData.length;
            var paddingLength = 0;
            for (; b64EncodedData[dataLength - 1 - paddingLength] === '='; paddingLength++) {}
            b64EncodedData = paddingLength === 0 ? b64EncodedData : b64EncodedData.substring(0, dataLength - paddingLength);
            return "ss://" + b64EncodedData + hash;
        }
    };
    // Ref: https://shadowsocks.org/en/spec/SIP002-URI-Scheme.html
    platformExportObj.SIP002_URI = {
        parse: function parse(uri) {
            platformExportObj.SHADOWSOCKS_URI.validateProtocol(uri);
            // Can use built-in URL parser for expedience. Just have to replace "ss" with "http" to ensure
            // correct results, otherwise browsers like Safari fail to parse it.
            var inputForUrlParser = "http" + uri.substring(2);
            // The built-in URL parser throws as desired when given URIs with invalid syntax.
            var urlParserResult = new URL(inputForUrlParser);
            var uriFormattedHost = urlParserResult.hostname;
            // URI-formatted IPv6 hostnames have surrounding brackets.
            var last = uriFormattedHost.length - 1;
            var brackets = uriFormattedHost[0] === '[' && uriFormattedHost[last] === ']';
            var hostString = brackets ? uriFormattedHost.substring(1, last) : uriFormattedHost;
            var host = new Host(hostString);
            var parsedPort = urlParserResult.port;
            if (!parsedPort && uri.match(/:80($|\/)/g)) {
                // The default URL parser fails to recognize the default port (80) when the URI being parsed
                // is HTTP. Check if the port is present at the end of the string or before the parameters.
                parsedPort = 80;
            }
            var port = new Port(parsedPort);
            var tag = new Tag(decodeURIComponent(urlParserResult.hash.substring(1)));
            var b64EncodedUserInfo = urlParserResult.username.replace(/%3D/g, '=');
            // base64.decode throws as desired when given invalid base64 input.
            var b64DecodedUserInfo = b64Decode(b64EncodedUserInfo);
            var colonIdx = b64DecodedUserInfo.indexOf(':');
            if (colonIdx === -1) {
                throw new InvalidUri("Missing password");
            }
            var methodString = b64DecodedUserInfo.substring(0, colonIdx);
            var method = new Method(methodString);
            var passwordString = b64DecodedUserInfo.substring(colonIdx + 1);
            var password = new Password(passwordString);
            var queryParams = urlParserResult.search.substring(1).split('&');
            var extra = {};
            for (var _i = 0, queryParams_1 = queryParams; _i < queryParams_1.length; _i++) {
                var pair = queryParams_1[_i];
                var _a = pair.split('=', 2),
                    key = _a[0],
                    value = _a[1];
                if (!key) continue;
                extra[key] = decodeURIComponent(value || '');
            }
            return { method: method, password: password, host: host, port: port, tag: tag, extra: extra };
        },
        stringify: function stringify(config) {
            var host = config.host,
                port = config.port,
                method = config.method,
                password = config.password,
                tag = config.tag,
                extra = config.extra;
            var userInfo = b64Encode(method.data + ":" + password.data);
            var uriHost = platformExportObj.SHADOWSOCKS_URI.getUriFormattedHost(host);
            var hash = platformExportObj.SHADOWSOCKS_URI.getHash(tag);
            var queryString = '';
            for (var key in extra) {
                if (!key) continue;
                queryString += (queryString ? '&' : '?') + (key + "=" + encodeURIComponent(extra[key]));
            }
            return "ss://" + userInfo + "@" + uriHost + ":" + port.data + "/" + queryString + hash;
        }
    };
})();

},{"base-64":2,"punycode":3,"url":15}],2:[function(require,module,exports){
(function (global){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/*! http://mths.be/base64 v0.1.0 by @mathias | MIT license */
;(function (root) {

	// Detect free variables `exports`.
	var freeExports = (typeof exports === 'undefined' ? 'undefined' : _typeof(exports)) == 'object' && exports;

	// Detect free variable `module`.
	var freeModule = (typeof module === 'undefined' ? 'undefined' : _typeof(module)) == 'object' && module && module.exports == freeExports && module;

	// Detect free variable `global`, from Node.js or Browserified code, and use
	// it as `root`.
	var freeGlobal = (typeof global === 'undefined' ? 'undefined' : _typeof(global)) == 'object' && global;
	if (freeGlobal.global === freeGlobal || freeGlobal.window === freeGlobal) {
		root = freeGlobal;
	}

	/*--------------------------------------------------------------------------*/

	var InvalidCharacterError = function InvalidCharacterError(message) {
		this.message = message;
	};
	InvalidCharacterError.prototype = new Error();
	InvalidCharacterError.prototype.name = 'InvalidCharacterError';

	var error = function error(message) {
		// Note: the error messages used throughout this file match those used by
		// the native `atob`/`btoa` implementation in Chromium.
		throw new InvalidCharacterError(message);
	};

	var TABLE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
	// http://whatwg.org/html/common-microsyntaxes.html#space-character
	var REGEX_SPACE_CHARACTERS = /[\t\n\f\r ]/g;

	// `decode` is designed to be fully compatible with `atob` as described in the
	// HTML Standard. http://whatwg.org/html/webappapis.html#dom-windowbase64-atob
	// The optimized base64-decoding algorithm used is based on @atk’s excellent
	// implementation. https://gist.github.com/atk/1020396
	var decode = function decode(input) {
		input = String(input).replace(REGEX_SPACE_CHARACTERS, '');
		var length = input.length;
		if (length % 4 == 0) {
			input = input.replace(/==?$/, '');
			length = input.length;
		}
		if (length % 4 == 1 ||
		// http://whatwg.org/C#alphanumeric-ascii-characters
		/[^+a-zA-Z0-9/]/.test(input)) {
			error('Invalid character: the string to be decoded is not correctly encoded.');
		}
		var bitCounter = 0;
		var bitStorage;
		var buffer;
		var output = '';
		var position = -1;
		while (++position < length) {
			buffer = TABLE.indexOf(input.charAt(position));
			bitStorage = bitCounter % 4 ? bitStorage * 64 + buffer : buffer;
			// Unless this is the first of a group of 4 characters…
			if (bitCounter++ % 4) {
				// …convert the first 8 bits to a single ASCII character.
				output += String.fromCharCode(0xFF & bitStorage >> (-2 * bitCounter & 6));
			}
		}
		return output;
	};

	// `encode` is designed to be fully compatible with `btoa` as described in the
	// HTML Standard: http://whatwg.org/html/webappapis.html#dom-windowbase64-btoa
	var encode = function encode(input) {
		input = String(input);
		if (/[^\0-\xFF]/.test(input)) {
			// Note: no need to special-case astral symbols here, as surrogates are
			// matched, and the input is supposed to only contain ASCII anyway.
			error('The string to be encoded contains characters outside of the ' + 'Latin1 range.');
		}
		var padding = input.length % 3;
		var output = '';
		var position = -1;
		var a;
		var b;
		var c;
		var d;
		var buffer;
		// Make sure any padding is handled outside of the loop.
		var length = input.length - padding;

		while (++position < length) {
			// Read three bytes, i.e. 24 bits.
			a = input.charCodeAt(position) << 16;
			b = input.charCodeAt(++position) << 8;
			c = input.charCodeAt(++position);
			buffer = a + b + c;
			// Turn the 24 bits into four chunks of 6 bits each, and append the
			// matching character for each of them to the output.
			output += TABLE.charAt(buffer >> 18 & 0x3F) + TABLE.charAt(buffer >> 12 & 0x3F) + TABLE.charAt(buffer >> 6 & 0x3F) + TABLE.charAt(buffer & 0x3F);
		}

		if (padding == 2) {
			a = input.charCodeAt(position) << 8;
			b = input.charCodeAt(++position);
			buffer = a + b;
			output += TABLE.charAt(buffer >> 10) + TABLE.charAt(buffer >> 4 & 0x3F) + TABLE.charAt(buffer << 2 & 0x3F) + '=';
		} else if (padding == 1) {
			buffer = input.charCodeAt(position);
			output += TABLE.charAt(buffer >> 2) + TABLE.charAt(buffer << 4 & 0x3F) + '==';
		}

		return output;
	};

	var base64 = {
		'encode': encode,
		'decode': decode,
		'version': '0.1.0'
	};

	// Some AMD build optimizers, like r.js, check for specific condition patterns
	// like the following:
	if (typeof define == 'function' && _typeof(define.amd) == 'object' && define.amd) {
		define(function () {
			return base64;
		});
	} else if (freeExports && !freeExports.nodeType) {
		if (freeModule) {
			// in Node.js or RingoJS v0.8.0+
			freeModule.exports = base64;
		} else {
			// in Narwhal or RingoJS v0.7.0-
			for (var key in base64) {
				base64.hasOwnProperty(key) && (freeExports[key] = base64[key]);
			}
		}
	} else {
		// in Rhino or a web browser
		root.base64 = base64;
	}
})(undefined);

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],3:[function(require,module,exports){
(function (global){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/*! https://mths.be/punycode v1.4.1 by @mathias */
;(function (root) {

	/** Detect free variables */
	var freeExports = (typeof exports === 'undefined' ? 'undefined' : _typeof(exports)) == 'object' && exports && !exports.nodeType && exports;
	var freeModule = (typeof module === 'undefined' ? 'undefined' : _typeof(module)) == 'object' && module && !module.nodeType && module;
	var freeGlobal = (typeof global === 'undefined' ? 'undefined' : _typeof(global)) == 'object' && global;
	if (freeGlobal.global === freeGlobal || freeGlobal.window === freeGlobal || freeGlobal.self === freeGlobal) {
		root = freeGlobal;
	}

	/**
  * The `punycode` object.
  * @name punycode
  * @type Object
  */
	var punycode,


	/** Highest positive signed 32-bit float value */
	maxInt = 2147483647,
	    // aka. 0x7FFFFFFF or 2^31-1

	/** Bootstring parameters */
	base = 36,
	    tMin = 1,
	    tMax = 26,
	    skew = 38,
	    damp = 700,
	    initialBias = 72,
	    initialN = 128,
	    // 0x80
	delimiter = '-',
	    // '\x2D'

	/** Regular expressions */
	regexPunycode = /^xn--/,
	    regexNonASCII = /[^\x20-\x7E]/,
	    // unprintable ASCII chars + non-ASCII chars
	regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g,
	    // RFC 3490 separators

	/** Error messages */
	errors = {
		'overflow': 'Overflow: input needs wider integers to process',
		'not-basic': 'Illegal input >= 0x80 (not a basic code point)',
		'invalid-input': 'Invalid input'
	},


	/** Convenience shortcuts */
	baseMinusTMin = base - tMin,
	    floor = Math.floor,
	    stringFromCharCode = String.fromCharCode,


	/** Temporary variable */
	key;

	/*--------------------------------------------------------------------------*/

	/**
  * A generic error utility function.
  * @private
  * @param {String} type The error type.
  * @returns {Error} Throws a `RangeError` with the applicable error message.
  */
	function error(type) {
		throw new RangeError(errors[type]);
	}

	/**
  * A generic `Array#map` utility function.
  * @private
  * @param {Array} array The array to iterate over.
  * @param {Function} callback The function that gets called for every array
  * item.
  * @returns {Array} A new array of values returned by the callback function.
  */
	function map(array, fn) {
		var length = array.length;
		var result = [];
		while (length--) {
			result[length] = fn(array[length]);
		}
		return result;
	}

	/**
  * A simple `Array#map`-like wrapper to work with domain name strings or email
  * addresses.
  * @private
  * @param {String} domain The domain name or email address.
  * @param {Function} callback The function that gets called for every
  * character.
  * @returns {Array} A new string of characters returned by the callback
  * function.
  */
	function mapDomain(string, fn) {
		var parts = string.split('@');
		var result = '';
		if (parts.length > 1) {
			// In email addresses, only the domain name should be punycoded. Leave
			// the local part (i.e. everything up to `@`) intact.
			result = parts[0] + '@';
			string = parts[1];
		}
		// Avoid `split(regex)` for IE8 compatibility. See #17.
		string = string.replace(regexSeparators, '\x2E');
		var labels = string.split('.');
		var encoded = map(labels, fn).join('.');
		return result + encoded;
	}

	/**
  * Creates an array containing the numeric code points of each Unicode
  * character in the string. While JavaScript uses UCS-2 internally,
  * this function will convert a pair of surrogate halves (each of which
  * UCS-2 exposes as separate characters) into a single code point,
  * matching UTF-16.
  * @see `punycode.ucs2.encode`
  * @see <https://mathiasbynens.be/notes/javascript-encoding>
  * @memberOf punycode.ucs2
  * @name decode
  * @param {String} string The Unicode input string (UCS-2).
  * @returns {Array} The new array of code points.
  */
	function ucs2decode(string) {
		var output = [],
		    counter = 0,
		    length = string.length,
		    value,
		    extra;
		while (counter < length) {
			value = string.charCodeAt(counter++);
			if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
				// high surrogate, and there is a next character
				extra = string.charCodeAt(counter++);
				if ((extra & 0xFC00) == 0xDC00) {
					// low surrogate
					output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
				} else {
					// unmatched surrogate; only append this code unit, in case the next
					// code unit is the high surrogate of a surrogate pair
					output.push(value);
					counter--;
				}
			} else {
				output.push(value);
			}
		}
		return output;
	}

	/**
  * Creates a string based on an array of numeric code points.
  * @see `punycode.ucs2.decode`
  * @memberOf punycode.ucs2
  * @name encode
  * @param {Array} codePoints The array of numeric code points.
  * @returns {String} The new Unicode string (UCS-2).
  */
	function ucs2encode(array) {
		return map(array, function (value) {
			var output = '';
			if (value > 0xFFFF) {
				value -= 0x10000;
				output += stringFromCharCode(value >>> 10 & 0x3FF | 0xD800);
				value = 0xDC00 | value & 0x3FF;
			}
			output += stringFromCharCode(value);
			return output;
		}).join('');
	}

	/**
  * Converts a basic code point into a digit/integer.
  * @see `digitToBasic()`
  * @private
  * @param {Number} codePoint The basic numeric code point value.
  * @returns {Number} The numeric value of a basic code point (for use in
  * representing integers) in the range `0` to `base - 1`, or `base` if
  * the code point does not represent a value.
  */
	function basicToDigit(codePoint) {
		if (codePoint - 48 < 10) {
			return codePoint - 22;
		}
		if (codePoint - 65 < 26) {
			return codePoint - 65;
		}
		if (codePoint - 97 < 26) {
			return codePoint - 97;
		}
		return base;
	}

	/**
  * Converts a digit/integer into a basic code point.
  * @see `basicToDigit()`
  * @private
  * @param {Number} digit The numeric value of a basic code point.
  * @returns {Number} The basic code point whose value (when used for
  * representing integers) is `digit`, which needs to be in the range
  * `0` to `base - 1`. If `flag` is non-zero, the uppercase form is
  * used; else, the lowercase form is used. The behavior is undefined
  * if `flag` is non-zero and `digit` has no uppercase form.
  */
	function digitToBasic(digit, flag) {
		//  0..25 map to ASCII a..z or A..Z
		// 26..35 map to ASCII 0..9
		return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
	}

	/**
  * Bias adaptation function as per section 3.4 of RFC 3492.
  * https://tools.ietf.org/html/rfc3492#section-3.4
  * @private
  */
	function adapt(delta, numPoints, firstTime) {
		var k = 0;
		delta = firstTime ? floor(delta / damp) : delta >> 1;
		delta += floor(delta / numPoints);
		for (; /* no initialization */delta > baseMinusTMin * tMax >> 1; k += base) {
			delta = floor(delta / baseMinusTMin);
		}
		return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
	}

	/**
  * Converts a Punycode string of ASCII-only symbols to a string of Unicode
  * symbols.
  * @memberOf punycode
  * @param {String} input The Punycode string of ASCII-only symbols.
  * @returns {String} The resulting string of Unicode symbols.
  */
	function decode(input) {
		// Don't use UCS-2
		var output = [],
		    inputLength = input.length,
		    out,
		    i = 0,
		    n = initialN,
		    bias = initialBias,
		    basic,
		    j,
		    index,
		    oldi,
		    w,
		    k,
		    digit,
		    t,

		/** Cached calculation results */
		baseMinusT;

		// Handle the basic code points: let `basic` be the number of input code
		// points before the last delimiter, or `0` if there is none, then copy
		// the first basic code points to the output.

		basic = input.lastIndexOf(delimiter);
		if (basic < 0) {
			basic = 0;
		}

		for (j = 0; j < basic; ++j) {
			// if it's not a basic code point
			if (input.charCodeAt(j) >= 0x80) {
				error('not-basic');
			}
			output.push(input.charCodeAt(j));
		}

		// Main decoding loop: start just after the last delimiter if any basic code
		// points were copied; start at the beginning otherwise.

		for (index = basic > 0 ? basic + 1 : 0; index < inputLength;) /* no final expression */{

			// `index` is the index of the next character to be consumed.
			// Decode a generalized variable-length integer into `delta`,
			// which gets added to `i`. The overflow checking is easier
			// if we increase `i` as we go, then subtract off its starting
			// value at the end to obtain `delta`.
			for (oldi = i, w = 1, k = base;; /* no condition */k += base) {

				if (index >= inputLength) {
					error('invalid-input');
				}

				digit = basicToDigit(input.charCodeAt(index++));

				if (digit >= base || digit > floor((maxInt - i) / w)) {
					error('overflow');
				}

				i += digit * w;
				t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;

				if (digit < t) {
					break;
				}

				baseMinusT = base - t;
				if (w > floor(maxInt / baseMinusT)) {
					error('overflow');
				}

				w *= baseMinusT;
			}

			out = output.length + 1;
			bias = adapt(i - oldi, out, oldi == 0);

			// `i` was supposed to wrap around from `out` to `0`,
			// incrementing `n` each time, so we'll fix that now:
			if (floor(i / out) > maxInt - n) {
				error('overflow');
			}

			n += floor(i / out);
			i %= out;

			// Insert `n` at position `i` of the output
			output.splice(i++, 0, n);
		}

		return ucs2encode(output);
	}

	/**
  * Converts a string of Unicode symbols (e.g. a domain name label) to a
  * Punycode string of ASCII-only symbols.
  * @memberOf punycode
  * @param {String} input The string of Unicode symbols.
  * @returns {String} The resulting Punycode string of ASCII-only symbols.
  */
	function encode(input) {
		var n,
		    delta,
		    handledCPCount,
		    basicLength,
		    bias,
		    j,
		    m,
		    q,
		    k,
		    t,
		    currentValue,
		    output = [],

		/** `inputLength` will hold the number of code points in `input`. */
		inputLength,

		/** Cached calculation results */
		handledCPCountPlusOne,
		    baseMinusT,
		    qMinusT;

		// Convert the input in UCS-2 to Unicode
		input = ucs2decode(input);

		// Cache the length
		inputLength = input.length;

		// Initialize the state
		n = initialN;
		delta = 0;
		bias = initialBias;

		// Handle the basic code points
		for (j = 0; j < inputLength; ++j) {
			currentValue = input[j];
			if (currentValue < 0x80) {
				output.push(stringFromCharCode(currentValue));
			}
		}

		handledCPCount = basicLength = output.length;

		// `handledCPCount` is the number of code points that have been handled;
		// `basicLength` is the number of basic code points.

		// Finish the basic string - if it is not empty - with a delimiter
		if (basicLength) {
			output.push(delimiter);
		}

		// Main encoding loop:
		while (handledCPCount < inputLength) {

			// All non-basic code points < n have been handled already. Find the next
			// larger one:
			for (m = maxInt, j = 0; j < inputLength; ++j) {
				currentValue = input[j];
				if (currentValue >= n && currentValue < m) {
					m = currentValue;
				}
			}

			// Increase `delta` enough to advance the decoder's <n,i> state to <m,0>,
			// but guard against overflow
			handledCPCountPlusOne = handledCPCount + 1;
			if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
				error('overflow');
			}

			delta += (m - n) * handledCPCountPlusOne;
			n = m;

			for (j = 0; j < inputLength; ++j) {
				currentValue = input[j];

				if (currentValue < n && ++delta > maxInt) {
					error('overflow');
				}

				if (currentValue == n) {
					// Represent delta as a generalized variable-length integer
					for (q = delta, k = base;; /* no condition */k += base) {
						t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
						if (q < t) {
							break;
						}
						qMinusT = q - t;
						baseMinusT = base - t;
						output.push(stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0)));
						q = floor(qMinusT / baseMinusT);
					}

					output.push(stringFromCharCode(digitToBasic(q, 0)));
					bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
					delta = 0;
					++handledCPCount;
				}
			}

			++delta;
			++n;
		}
		return output.join('');
	}

	/**
  * Converts a Punycode string representing a domain name or an email address
  * to Unicode. Only the Punycoded parts of the input will be converted, i.e.
  * it doesn't matter if you call it on a string that has already been
  * converted to Unicode.
  * @memberOf punycode
  * @param {String} input The Punycoded domain name or email address to
  * convert to Unicode.
  * @returns {String} The Unicode representation of the given Punycode
  * string.
  */
	function toUnicode(input) {
		return mapDomain(input, function (string) {
			return regexPunycode.test(string) ? decode(string.slice(4).toLowerCase()) : string;
		});
	}

	/**
  * Converts a Unicode string representing a domain name or an email address to
  * Punycode. Only the non-ASCII parts of the domain name will be converted,
  * i.e. it doesn't matter if you call it with a domain that's already in
  * ASCII.
  * @memberOf punycode
  * @param {String} input The domain name or email address to convert, as a
  * Unicode string.
  * @returns {String} The Punycode representation of the given domain name or
  * email address.
  */
	function toASCII(input) {
		return mapDomain(input, function (string) {
			return regexNonASCII.test(string) ? 'xn--' + encode(string) : string;
		});
	}

	/*--------------------------------------------------------------------------*/

	/** Define the public API */
	punycode = {
		/**
   * A string representing the current Punycode.js version number.
   * @memberOf punycode
   * @type String
   */
		'version': '1.4.1',
		/**
   * An object of methods to convert from JavaScript's internal character
   * representation (UCS-2) to Unicode code points, and back.
   * @see <https://mathiasbynens.be/notes/javascript-encoding>
   * @memberOf punycode
   * @type Object
   */
		'ucs2': {
			'decode': ucs2decode,
			'encode': ucs2encode
		},
		'decode': decode,
		'encode': encode,
		'toASCII': toASCII,
		'toUnicode': toUnicode
	};

	/** Expose `punycode` */
	// Some AMD build optimizers, like r.js, check for specific condition patterns
	// like the following:
	if (typeof define == 'function' && _typeof(define.amd) == 'object' && define.amd) {
		define('punycode', function () {
			return punycode;
		});
	} else if (freeExports && freeModule) {
		if (module.exports == freeExports) {
			// in Node.js, io.js, or RingoJS v0.8.0+
			freeModule.exports = punycode;
		} else {
			// in Narwhal or RingoJS v0.7.0-
			for (key in punycode) {
				punycode.hasOwnProperty(key) && (freeExports[key] = punycode[key]);
			}
		}
	} else {
		// in Rhino or a web browser
		root.punycode = punycode;
	}
})(undefined);

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],4:[function(require,module,exports){
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

'use strict';

// If obj.hasOwnProperty has been overridden, then calling
// obj.hasOwnProperty(prop) will break.
// See: https://github.com/joyent/node/issues/1707

function hasOwnProperty(obj, prop) {
  return Object.prototype.hasOwnProperty.call(obj, prop);
}

module.exports = function (qs, sep, eq, options) {
  sep = sep || '&';
  eq = eq || '=';
  var obj = {};

  if (typeof qs !== 'string' || qs.length === 0) {
    return obj;
  }

  var regexp = /\+/g;
  qs = qs.split(sep);

  var maxKeys = 1000;
  if (options && typeof options.maxKeys === 'number') {
    maxKeys = options.maxKeys;
  }

  var len = qs.length;
  // maxKeys <= 0 means that we should not limit keys count
  if (maxKeys > 0 && len > maxKeys) {
    len = maxKeys;
  }

  for (var i = 0; i < len; ++i) {
    var x = qs[i].replace(regexp, '%20'),
        idx = x.indexOf(eq),
        kstr,
        vstr,
        k,
        v;

    if (idx >= 0) {
      kstr = x.substr(0, idx);
      vstr = x.substr(idx + 1);
    } else {
      kstr = x;
      vstr = '';
    }

    k = decodeURIComponent(kstr);
    v = decodeURIComponent(vstr);

    if (!hasOwnProperty(obj, k)) {
      obj[k] = v;
    } else if (isArray(obj[k])) {
      obj[k].push(v);
    } else {
      obj[k] = [obj[k], v];
    }
  }

  return obj;
};

var isArray = Array.isArray || function (xs) {
  return Object.prototype.toString.call(xs) === '[object Array]';
};

},{}],5:[function(require,module,exports){
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var stringifyPrimitive = function stringifyPrimitive(v) {
  switch (typeof v === 'undefined' ? 'undefined' : _typeof(v)) {
    case 'string':
      return v;

    case 'boolean':
      return v ? 'true' : 'false';

    case 'number':
      return isFinite(v) ? v : '';

    default:
      return '';
  }
};

module.exports = function (obj, sep, eq, name) {
  sep = sep || '&';
  eq = eq || '=';
  if (obj === null) {
    obj = undefined;
  }

  if ((typeof obj === 'undefined' ? 'undefined' : _typeof(obj)) === 'object') {
    return map(objectKeys(obj), function (k) {
      var ks = encodeURIComponent(stringifyPrimitive(k)) + eq;
      if (isArray(obj[k])) {
        return map(obj[k], function (v) {
          return ks + encodeURIComponent(stringifyPrimitive(v));
        }).join(sep);
      } else {
        return ks + encodeURIComponent(stringifyPrimitive(obj[k]));
      }
    }).join(sep);
  }

  if (!name) return '';
  return encodeURIComponent(stringifyPrimitive(name)) + eq + encodeURIComponent(stringifyPrimitive(obj));
};

var isArray = Array.isArray || function (xs) {
  return Object.prototype.toString.call(xs) === '[object Array]';
};

function map(xs, f) {
  if (xs.map) return xs.map(f);
  var res = [];
  for (var i = 0; i < xs.length; i++) {
    res.push(f(xs[i], i));
  }
  return res;
}

var objectKeys = Object.keys || function (obj) {
  var res = [];
  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) res.push(key);
  }
  return res;
};

},{}],6:[function(require,module,exports){
'use strict';

exports.decode = exports.parse = require('./decode');
exports.encode = exports.stringify = require('./encode');

},{"./decode":4,"./encode":5}],7:[function(require,module,exports){
'use strict';

function RavenConfigError(message) {
  this.name = 'RavenConfigError';
  this.message = message;
}
RavenConfigError.prototype = new Error();
RavenConfigError.prototype.constructor = RavenConfigError;

module.exports = RavenConfigError;

},{}],8:[function(require,module,exports){
'use strict';

var utils = require('./utils');

var wrapMethod = function wrapMethod(console, level, callback) {
  var originalConsoleLevel = console[level];
  var originalConsole = console;

  if (!(level in console)) {
    return;
  }

  var sentryLevel = level === 'warn' ? 'warning' : level;

  console[level] = function () {
    var args = [].slice.call(arguments);

    var msg = utils.safeJoin(args, ' ');
    var data = { level: sentryLevel, logger: 'console', extra: { arguments: args } };

    if (level === 'assert') {
      if (args[0] === false) {
        // Default browsers message
        msg = 'Assertion failed: ' + (utils.safeJoin(args.slice(1), ' ') || 'console.assert');
        data.extra.arguments = args.slice(1);
        callback && callback(msg, data);
      }
    } else {
      callback && callback(msg, data);
    }

    // this fails for some browsers. :(
    if (originalConsoleLevel) {
      // IE9 doesn't allow calling apply on console functions directly
      // See: https://stackoverflow.com/questions/5472938/does-ie9-support-console-log-and-is-it-a-real-function#answer-5473193
      Function.prototype.apply.call(originalConsoleLevel, originalConsole, args);
    }
  };
};

module.exports = {
  wrapMethod: wrapMethod
};

},{"./utils":11}],9:[function(require,module,exports){
(function (global){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/*global XDomainRequest:false */

var TraceKit = require('../vendor/TraceKit/tracekit');
var stringify = require('../vendor/json-stringify-safe/stringify');
var md5 = require('../vendor/md5/md5');
var RavenConfigError = require('./configError');

var utils = require('./utils');
var isErrorEvent = utils.isErrorEvent;
var isDOMError = utils.isDOMError;
var isDOMException = utils.isDOMException;
var isError = utils.isError;
var isObject = utils.isObject;
var isPlainObject = utils.isPlainObject;
var isUndefined = utils.isUndefined;
var isFunction = utils.isFunction;
var isString = utils.isString;
var isArray = utils.isArray;
var isEmptyObject = utils.isEmptyObject;
var each = utils.each;
var objectMerge = utils.objectMerge;
var truncate = utils.truncate;
var objectFrozen = utils.objectFrozen;
var hasKey = utils.hasKey;
var joinRegExp = utils.joinRegExp;
var urlencode = utils.urlencode;
var uuid4 = utils.uuid4;
var htmlTreeAsString = utils.htmlTreeAsString;
var isSameException = utils.isSameException;
var isSameStacktrace = utils.isSameStacktrace;
var parseUrl = utils.parseUrl;
var fill = utils.fill;
var supportsFetch = utils.supportsFetch;
var supportsReferrerPolicy = utils.supportsReferrerPolicy;
var serializeKeysForMessage = utils.serializeKeysForMessage;
var serializeException = utils.serializeException;
var sanitize = utils.sanitize;

var wrapConsoleMethod = require('./console').wrapMethod;

var dsnKeys = 'source protocol user pass host port path'.split(' '),
    dsnPattern = /^(?:(\w+):)?\/\/(?:(\w+)(:\w+)?@)?([\w\.-]+)(?::(\d+))?(\/.*)/;

function now() {
  return +new Date();
}

// This is to be defensive in environments where window does not exist (see https://github.com/getsentry/raven-js/pull/785)
var _window = typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};
var _document = _window.document;
var _navigator = _window.navigator;

function keepOriginalCallback(original, callback) {
  return isFunction(callback) ? function (data) {
    return callback(data, original);
  } : callback;
}

// First, check for JSON support
// If there is no JSON, we no-op the core features of Raven
// since JSON is required to encode the payload
function Raven() {
  this._hasJSON = !!((typeof JSON === 'undefined' ? 'undefined' : _typeof(JSON)) === 'object' && JSON.stringify);
  // Raven can run in contexts where there's no document (react-native)
  this._hasDocument = !isUndefined(_document);
  this._hasNavigator = !isUndefined(_navigator);
  this._lastCapturedException = null;
  this._lastData = null;
  this._lastEventId = null;
  this._globalServer = null;
  this._globalKey = null;
  this._globalProject = null;
  this._globalContext = {};
  this._globalOptions = {
    // SENTRY_RELEASE can be injected by https://github.com/getsentry/sentry-webpack-plugin
    release: _window.SENTRY_RELEASE && _window.SENTRY_RELEASE.id,
    logger: 'javascript',
    ignoreErrors: [],
    ignoreUrls: [],
    whitelistUrls: [],
    includePaths: [],
    headers: null,
    collectWindowErrors: true,
    captureUnhandledRejections: true,
    maxMessageLength: 0,
    // By default, truncates URL values to 250 chars
    maxUrlLength: 250,
    stackTraceLimit: 50,
    autoBreadcrumbs: true,
    instrument: true,
    sampleRate: 1,
    sanitizeKeys: []
  };
  this._fetchDefaults = {
    method: 'POST',
    // Despite all stars in the sky saying that Edge supports old draft syntax, aka 'never', 'always', 'origin' and 'default
    // https://caniuse.com/#feat=referrer-policy
    // It doesn't. And it throw exception instead of ignoring this parameter...
    // REF: https://github.com/getsentry/raven-js/issues/1233
    referrerPolicy: supportsReferrerPolicy() ? 'origin' : ''
  };
  this._ignoreOnError = 0;
  this._isRavenInstalled = false;
  this._originalErrorStackTraceLimit = Error.stackTraceLimit;
  // capture references to window.console *and* all its methods first
  // before the console plugin has a chance to monkey patch
  this._originalConsole = _window.console || {};
  this._originalConsoleMethods = {};
  this._plugins = [];
  this._startTime = now();
  this._wrappedBuiltIns = [];
  this._breadcrumbs = [];
  this._lastCapturedEvent = null;
  this._keypressTimeout;
  this._location = _window.location;
  this._lastHref = this._location && this._location.href;
  this._resetBackoff();

  // eslint-disable-next-line guard-for-in
  for (var method in this._originalConsole) {
    this._originalConsoleMethods[method] = this._originalConsole[method];
  }
}

/*
 * The core Raven singleton
 *
 * @this {Raven}
 */

Raven.prototype = {
  // Hardcode version string so that raven source can be loaded directly via
  // webpack (using a build step causes webpack #1617). Grunt verifies that
  // this value matches package.json during build.
  //   See: https://github.com/getsentry/raven-js/issues/465
  VERSION: '3.27.2',

  debug: false,

  TraceKit: TraceKit, // alias to TraceKit

  /*
     * Configure Raven with a DSN and extra options
     *
     * @param {string} dsn The public Sentry DSN
     * @param {object} options Set of global options [optional]
     * @return {Raven}
     */
  config: function config(dsn, options) {
    var self = this;

    if (self._globalServer) {
      this._logDebug('error', 'Error: Raven has already been configured');
      return self;
    }
    if (!dsn) return self;

    var globalOptions = self._globalOptions;

    // merge in options
    if (options) {
      each(options, function (key, value) {
        // tags and extra are special and need to be put into context
        if (key === 'tags' || key === 'extra' || key === 'user') {
          self._globalContext[key] = value;
        } else {
          globalOptions[key] = value;
        }
      });
    }

    self.setDSN(dsn);

    // "Script error." is hard coded into browsers for errors that it can't read.
    // this is the result of a script being pulled in from an external domain and CORS.
    globalOptions.ignoreErrors.push(/^Script error\.?$/);
    globalOptions.ignoreErrors.push(/^Javascript error: Script error\.? on line 0$/);

    // join regexp rules into one big rule
    globalOptions.ignoreErrors = joinRegExp(globalOptions.ignoreErrors);
    globalOptions.ignoreUrls = globalOptions.ignoreUrls.length ? joinRegExp(globalOptions.ignoreUrls) : false;
    globalOptions.whitelistUrls = globalOptions.whitelistUrls.length ? joinRegExp(globalOptions.whitelistUrls) : false;
    globalOptions.includePaths = joinRegExp(globalOptions.includePaths);
    globalOptions.maxBreadcrumbs = Math.max(0, Math.min(globalOptions.maxBreadcrumbs || 100, 100)); // default and hard limit is 100

    var autoBreadcrumbDefaults = {
      xhr: true,
      console: true,
      dom: true,
      location: true,
      sentry: true
    };

    var autoBreadcrumbs = globalOptions.autoBreadcrumbs;
    if ({}.toString.call(autoBreadcrumbs) === '[object Object]') {
      autoBreadcrumbs = objectMerge(autoBreadcrumbDefaults, autoBreadcrumbs);
    } else if (autoBreadcrumbs !== false) {
      autoBreadcrumbs = autoBreadcrumbDefaults;
    }
    globalOptions.autoBreadcrumbs = autoBreadcrumbs;

    var instrumentDefaults = {
      tryCatch: true
    };

    var instrument = globalOptions.instrument;
    if ({}.toString.call(instrument) === '[object Object]') {
      instrument = objectMerge(instrumentDefaults, instrument);
    } else if (instrument !== false) {
      instrument = instrumentDefaults;
    }
    globalOptions.instrument = instrument;

    TraceKit.collectWindowErrors = !!globalOptions.collectWindowErrors;

    // return for chaining
    return self;
  },

  /*
     * Installs a global window.onerror error handler
     * to capture and report uncaught exceptions.
     * At this point, install() is required to be called due
     * to the way TraceKit is set up.
     *
     * @return {Raven}
     */
  install: function install() {
    var self = this;
    if (self.isSetup() && !self._isRavenInstalled) {
      TraceKit.report.subscribe(function () {
        self._handleOnErrorStackInfo.apply(self, arguments);
      });

      if (self._globalOptions.captureUnhandledRejections) {
        self._attachPromiseRejectionHandler();
      }

      self._patchFunctionToString();

      if (self._globalOptions.instrument && self._globalOptions.instrument.tryCatch) {
        self._instrumentTryCatch();
      }

      if (self._globalOptions.autoBreadcrumbs) self._instrumentBreadcrumbs();

      // Install all of the plugins
      self._drainPlugins();

      self._isRavenInstalled = true;
    }

    Error.stackTraceLimit = self._globalOptions.stackTraceLimit;
    return this;
  },

  /*
     * Set the DSN (can be called multiple time unlike config)
     *
     * @param {string} dsn The public Sentry DSN
     */
  setDSN: function setDSN(dsn) {
    var self = this,
        uri = self._parseDSN(dsn),
        lastSlash = uri.path.lastIndexOf('/'),
        path = uri.path.substr(1, lastSlash);

    self._dsn = dsn;
    self._globalKey = uri.user;
    self._globalSecret = uri.pass && uri.pass.substr(1);
    self._globalProject = uri.path.substr(lastSlash + 1);

    self._globalServer = self._getGlobalServer(uri);

    self._globalEndpoint = self._globalServer + '/' + path + 'api/' + self._globalProject + '/store/';

    // Reset backoff state since we may be pointing at a
    // new project/server
    this._resetBackoff();
  },

  /*
     * Wrap code within a context so Raven can capture errors
     * reliably across domains that is executed immediately.
     *
     * @param {object} options A specific set of options for this context [optional]
     * @param {function} func The callback to be immediately executed within the context
     * @param {array} args An array of arguments to be called with the callback [optional]
     */
  context: function context(options, func, args) {
    if (isFunction(options)) {
      args = func || [];
      func = options;
      options = {};
    }

    return this.wrap(options, func).apply(this, args);
  },

  /*
     * Wrap code within a context and returns back a new function to be executed
     *
     * @param {object} options A specific set of options for this context [optional]
     * @param {function} func The function to be wrapped in a new context
     * @param {function} _before A function to call before the try/catch wrapper [optional, private]
     * @return {function} The newly wrapped functions with a context
     */
  wrap: function wrap(options, func, _before) {
    var self = this;
    // 1 argument has been passed, and it's not a function
    // so just return it
    if (isUndefined(func) && !isFunction(options)) {
      return options;
    }

    // options is optional
    if (isFunction(options)) {
      func = options;
      options = undefined;
    }

    // At this point, we've passed along 2 arguments, and the second one
    // is not a function either, so we'll just return the second argument.
    if (!isFunction(func)) {
      return func;
    }

    // We don't wanna wrap it twice!
    try {
      if (func.__raven__) {
        return func;
      }

      // If this has already been wrapped in the past, return that
      if (func.__raven_wrapper__) {
        return func.__raven_wrapper__;
      }
    } catch (e) {
      // Just accessing custom props in some Selenium environments
      // can cause a "Permission denied" exception (see raven-js#495).
      // Bail on wrapping and return the function as-is (defers to window.onerror).
      return func;
    }

    function wrapped() {
      var args = [],
          i = arguments.length,
          deep = !options || options && options.deep !== false;

      if (_before && isFunction(_before)) {
        _before.apply(this, arguments);
      }

      // Recursively wrap all of a function's arguments that are
      // functions themselves.
      while (i--) {
        args[i] = deep ? self.wrap(options, arguments[i]) : arguments[i];
      }try {
        // Attempt to invoke user-land function
        // NOTE: If you are a Sentry user, and you are seeing this stack frame, it
        //       means Raven caught an error invoking your application code. This is
        //       expected behavior and NOT indicative of a bug with Raven.js.
        return func.apply(this, args);
      } catch (e) {
        self._ignoreNextOnError();
        self.captureException(e, options);
        throw e;
      }
    }

    // copy over properties of the old function
    for (var property in func) {
      if (hasKey(func, property)) {
        wrapped[property] = func[property];
      }
    }
    wrapped.prototype = func.prototype;

    func.__raven_wrapper__ = wrapped;
    // Signal that this function has been wrapped/filled already
    // for both debugging and to prevent it to being wrapped/filled twice
    wrapped.__raven__ = true;
    wrapped.__orig__ = func;

    return wrapped;
  },

  /**
   * Uninstalls the global error handler.
   *
   * @return {Raven}
   */
  uninstall: function uninstall() {
    TraceKit.report.uninstall();

    this._detachPromiseRejectionHandler();
    this._unpatchFunctionToString();
    this._restoreBuiltIns();
    this._restoreConsole();

    Error.stackTraceLimit = this._originalErrorStackTraceLimit;
    this._isRavenInstalled = false;

    return this;
  },

  /**
   * Callback used for `unhandledrejection` event
   *
   * @param {PromiseRejectionEvent} event An object containing
   *   promise: the Promise that was rejected
   *   reason: the value with which the Promise was rejected
   * @return void
   */
  _promiseRejectionHandler: function _promiseRejectionHandler(event) {
    this._logDebug('debug', 'Raven caught unhandled promise rejection:', event);
    this.captureException(event.reason, {
      mechanism: {
        type: 'onunhandledrejection',
        handled: false
      }
    });
  },

  /**
   * Installs the global promise rejection handler.
   *
   * @return {raven}
   */
  _attachPromiseRejectionHandler: function _attachPromiseRejectionHandler() {
    this._promiseRejectionHandler = this._promiseRejectionHandler.bind(this);
    _window.addEventListener && _window.addEventListener('unhandledrejection', this._promiseRejectionHandler);
    return this;
  },

  /**
   * Uninstalls the global promise rejection handler.
   *
   * @return {raven}
   */
  _detachPromiseRejectionHandler: function _detachPromiseRejectionHandler() {
    _window.removeEventListener && _window.removeEventListener('unhandledrejection', this._promiseRejectionHandler);
    return this;
  },

  /**
   * Manually capture an exception and send it over to Sentry
   *
   * @param {error} ex An exception to be logged
   * @param {object} options A specific set of options for this error [optional]
   * @return {Raven}
   */
  captureException: function captureException(ex, options) {
    options = objectMerge({ trimHeadFrames: 0 }, options ? options : {});

    if (isErrorEvent(ex) && ex.error) {
      // If it is an ErrorEvent with `error` property, extract it to get actual Error
      ex = ex.error;
    } else if (isDOMError(ex) || isDOMException(ex)) {
      // If it is a DOMError or DOMException (which are legacy APIs, but still supported in some browsers)
      // then we just extract the name and message, as they don't provide anything else
      // https://developer.mozilla.org/en-US/docs/Web/API/DOMError
      // https://developer.mozilla.org/en-US/docs/Web/API/DOMException
      var name = ex.name || (isDOMError(ex) ? 'DOMError' : 'DOMException');
      var message = ex.message ? name + ': ' + ex.message : name;

      return this.captureMessage(message, objectMerge(options, {
        // neither DOMError or DOMException provide stack trace and we most likely wont get it this way as well
        // but it's barely any overhead so we may at least try
        stacktrace: true,
        trimHeadFrames: options.trimHeadFrames + 1
      }));
    } else if (isError(ex)) {
      // we have a real Error object
      ex = ex;
    } else if (isPlainObject(ex)) {
      // If it is plain Object, serialize it manually and extract options
      // This will allow us to group events based on top-level keys
      // which is much better than creating new group when any key/value change
      options = this._getCaptureExceptionOptionsFromPlainObject(options, ex);
      ex = new Error(options.message);
    } else {
      // If none of previous checks were valid, then it means that
      // it's not a DOMError/DOMException
      // it's not a plain Object
      // it's not a valid ErrorEvent (one with an error property)
      // it's not an Error
      // So bail out and capture it as a simple message:
      return this.captureMessage(ex, objectMerge(options, {
        stacktrace: true, // if we fall back to captureMessage, default to attempting a new trace
        trimHeadFrames: options.trimHeadFrames + 1
      }));
    }

    // Store the raw exception object for potential debugging and introspection
    this._lastCapturedException = ex;

    // TraceKit.report will re-raise any exception passed to it,
    // which means you have to wrap it in try/catch. Instead, we
    // can wrap it here and only re-raise if TraceKit.report
    // raises an exception different from the one we asked to
    // report on.
    try {
      var stack = TraceKit.computeStackTrace(ex);
      this._handleStackInfo(stack, options);
    } catch (ex1) {
      if (ex !== ex1) {
        throw ex1;
      }
    }

    return this;
  },

  _getCaptureExceptionOptionsFromPlainObject: function _getCaptureExceptionOptionsFromPlainObject(currentOptions, ex) {
    var exKeys = Object.keys(ex).sort();
    var options = objectMerge(currentOptions, {
      message: 'Non-Error exception captured with keys: ' + serializeKeysForMessage(exKeys),
      fingerprint: [md5(exKeys)],
      extra: currentOptions.extra || {}
    });
    options.extra.__serialized__ = serializeException(ex);

    return options;
  },

  /*
     * Manually send a message to Sentry
     *
     * @param {string} msg A plain message to be captured in Sentry
     * @param {object} options A specific set of options for this message [optional]
     * @return {Raven}
     */
  captureMessage: function captureMessage(msg, options) {
    // config() automagically converts ignoreErrors from a list to a RegExp so we need to test for an
    // early call; we'll error on the side of logging anything called before configuration since it's
    // probably something you should see:
    if (!!this._globalOptions.ignoreErrors.test && this._globalOptions.ignoreErrors.test(msg)) {
      return;
    }

    options = options || {};
    msg = msg + ''; // Make sure it's actually a string

    var data = objectMerge({
      message: msg
    }, options);

    var ex;
    // Generate a "synthetic" stack trace from this point.
    // NOTE: If you are a Sentry user, and you are seeing this stack frame, it is NOT indicative
    //       of a bug with Raven.js. Sentry generates synthetic traces either by configuration,
    //       or if it catches a thrown object without a "stack" property.
    try {
      throw new Error(msg);
    } catch (ex1) {
      ex = ex1;
    }

    // null exception name so `Error` isn't prefixed to msg
    ex.name = null;
    var stack = TraceKit.computeStackTrace(ex);

    // stack[0] is `throw new Error(msg)` call itself, we are interested in the frame that was just before that, stack[1]
    var initialCall = isArray(stack.stack) && stack.stack[1];

    // if stack[1] is `Raven.captureException`, it means that someone passed a string to it and we redirected that call
    // to be handled by `captureMessage`, thus `initialCall` is the 3rd one, not 2nd
    // initialCall => captureException(string) => captureMessage(string)
    if (initialCall && initialCall.func === 'Raven.captureException') {
      initialCall = stack.stack[2];
    }

    var fileurl = initialCall && initialCall.url || '';

    if (!!this._globalOptions.ignoreUrls.test && this._globalOptions.ignoreUrls.test(fileurl)) {
      return;
    }

    if (!!this._globalOptions.whitelistUrls.test && !this._globalOptions.whitelistUrls.test(fileurl)) {
      return;
    }

    // Always attempt to get stacktrace if message is empty.
    // It's the only way to provide any helpful information to the user.
    if (this._globalOptions.stacktrace || options.stacktrace || data.message === '') {
      // fingerprint on msg, not stack trace (legacy behavior, could be revisited)
      data.fingerprint = data.fingerprint == null ? msg : data.fingerprint;

      options = objectMerge({
        trimHeadFrames: 0
      }, options);
      // Since we know this is a synthetic trace, the top frame (this function call)
      // MUST be from Raven.js, so mark it for trimming
      // We add to the trim counter so that callers can choose to trim extra frames, such
      // as utility functions.
      options.trimHeadFrames += 1;

      var frames = this._prepareFrames(stack, options);
      data.stacktrace = {
        // Sentry expects frames oldest to newest
        frames: frames.reverse()
      };
    }

    // Make sure that fingerprint is always wrapped in an array
    if (data.fingerprint) {
      data.fingerprint = isArray(data.fingerprint) ? data.fingerprint : [data.fingerprint];
    }

    // Fire away!
    this._send(data);

    return this;
  },

  captureBreadcrumb: function captureBreadcrumb(obj) {
    var crumb = objectMerge({
      timestamp: now() / 1000
    }, obj);

    if (isFunction(this._globalOptions.breadcrumbCallback)) {
      var result = this._globalOptions.breadcrumbCallback(crumb);

      if (isObject(result) && !isEmptyObject(result)) {
        crumb = result;
      } else if (result === false) {
        return this;
      }
    }

    this._breadcrumbs.push(crumb);
    if (this._breadcrumbs.length > this._globalOptions.maxBreadcrumbs) {
      this._breadcrumbs.shift();
    }
    return this;
  },

  addPlugin: function addPlugin(plugin /*arg1, arg2, ... argN*/) {
    var pluginArgs = [].slice.call(arguments, 1);

    this._plugins.push([plugin, pluginArgs]);
    if (this._isRavenInstalled) {
      this._drainPlugins();
    }

    return this;
  },

  /*
     * Set/clear a user to be sent along with the payload.
     *
     * @param {object} user An object representing user data [optional]
     * @return {Raven}
     */
  setUserContext: function setUserContext(user) {
    // Intentionally do not merge here since that's an unexpected behavior.
    this._globalContext.user = user;

    return this;
  },

  /*
     * Merge extra attributes to be sent along with the payload.
     *
     * @param {object} extra An object representing extra data [optional]
     * @return {Raven}
     */
  setExtraContext: function setExtraContext(extra) {
    this._mergeContext('extra', extra);

    return this;
  },

  /*
     * Merge tags to be sent along with the payload.
     *
     * @param {object} tags An object representing tags [optional]
     * @return {Raven}
     */
  setTagsContext: function setTagsContext(tags) {
    this._mergeContext('tags', tags);

    return this;
  },

  /*
     * Clear all of the context.
     *
     * @return {Raven}
     */
  clearContext: function clearContext() {
    this._globalContext = {};

    return this;
  },

  /*
     * Get a copy of the current context. This cannot be mutated.
     *
     * @return {object} copy of context
     */
  getContext: function getContext() {
    // lol javascript
    return JSON.parse(stringify(this._globalContext));
  },

  /*
     * Set environment of application
     *
     * @param {string} environment Typically something like 'production'.
     * @return {Raven}
     */
  setEnvironment: function setEnvironment(environment) {
    this._globalOptions.environment = environment;

    return this;
  },

  /*
     * Set release version of application
     *
     * @param {string} release Typically something like a git SHA to identify version
     * @return {Raven}
     */
  setRelease: function setRelease(release) {
    this._globalOptions.release = release;

    return this;
  },

  /*
     * Set the dataCallback option
     *
     * @param {function} callback The callback to run which allows the
     *                            data blob to be mutated before sending
     * @return {Raven}
     */
  setDataCallback: function setDataCallback(callback) {
    var original = this._globalOptions.dataCallback;
    this._globalOptions.dataCallback = keepOriginalCallback(original, callback);
    return this;
  },

  /*
     * Set the breadcrumbCallback option
     *
     * @param {function} callback The callback to run which allows filtering
     *                            or mutating breadcrumbs
     * @return {Raven}
     */
  setBreadcrumbCallback: function setBreadcrumbCallback(callback) {
    var original = this._globalOptions.breadcrumbCallback;
    this._globalOptions.breadcrumbCallback = keepOriginalCallback(original, callback);
    return this;
  },

  /*
     * Set the shouldSendCallback option
     *
     * @param {function} callback The callback to run which allows
     *                            introspecting the blob before sending
     * @return {Raven}
     */
  setShouldSendCallback: function setShouldSendCallback(callback) {
    var original = this._globalOptions.shouldSendCallback;
    this._globalOptions.shouldSendCallback = keepOriginalCallback(original, callback);
    return this;
  },

  /**
   * Override the default HTTP transport mechanism that transmits data
   * to the Sentry server.
   *
   * @param {function} transport Function invoked instead of the default
   *                             `makeRequest` handler.
   *
   * @return {Raven}
   */
  setTransport: function setTransport(transport) {
    this._globalOptions.transport = transport;

    return this;
  },

  /*
     * Get the latest raw exception that was captured by Raven.
     *
     * @return {error}
     */
  lastException: function lastException() {
    return this._lastCapturedException;
  },

  /*
     * Get the last event id
     *
     * @return {string}
     */
  lastEventId: function lastEventId() {
    return this._lastEventId;
  },

  /*
     * Determine if Raven is setup and ready to go.
     *
     * @return {boolean}
     */
  isSetup: function isSetup() {
    if (!this._hasJSON) return false; // needs JSON support
    if (!this._globalServer) {
      if (!this.ravenNotConfiguredError) {
        this.ravenNotConfiguredError = true;
        this._logDebug('error', 'Error: Raven has not been configured.');
      }
      return false;
    }
    return true;
  },

  afterLoad: function afterLoad() {
    // TODO: remove window dependence?

    // Attempt to initialize Raven on load
    var RavenConfig = _window.RavenConfig;
    if (RavenConfig) {
      this.config(RavenConfig.dsn, RavenConfig.config).install();
    }
  },

  showReportDialog: function showReportDialog(options) {
    if (!_document // doesn't work without a document (React native)
    ) return;

    options = objectMerge({
      eventId: this.lastEventId(),
      dsn: this._dsn,
      user: this._globalContext.user || {}
    }, options);

    if (!options.eventId) {
      throw new RavenConfigError('Missing eventId');
    }

    if (!options.dsn) {
      throw new RavenConfigError('Missing DSN');
    }

    var encode = encodeURIComponent;
    var encodedOptions = [];

    for (var key in options) {
      if (key === 'user') {
        var user = options.user;
        if (user.name) encodedOptions.push('name=' + encode(user.name));
        if (user.email) encodedOptions.push('email=' + encode(user.email));
      } else {
        encodedOptions.push(encode(key) + '=' + encode(options[key]));
      }
    }
    var globalServer = this._getGlobalServer(this._parseDSN(options.dsn));

    var script = _document.createElement('script');
    script.async = true;
    script.src = globalServer + '/api/embed/error-page/?' + encodedOptions.join('&');
    (_document.head || _document.body).appendChild(script);
  },

  /**** Private functions ****/
  _ignoreNextOnError: function _ignoreNextOnError() {
    var self = this;
    this._ignoreOnError += 1;
    setTimeout(function () {
      // onerror should trigger before setTimeout
      self._ignoreOnError -= 1;
    });
  },

  _triggerEvent: function _triggerEvent(eventType, options) {
    // NOTE: `event` is a native browser thing, so let's avoid conflicting wiht it
    var evt, key;

    if (!this._hasDocument) return;

    options = options || {};

    eventType = 'raven' + eventType.substr(0, 1).toUpperCase() + eventType.substr(1);

    if (_document.createEvent) {
      evt = _document.createEvent('HTMLEvents');
      evt.initEvent(eventType, true, true);
    } else {
      evt = _document.createEventObject();
      evt.eventType = eventType;
    }

    for (key in options) {
      if (hasKey(options, key)) {
        evt[key] = options[key];
      }
    }if (_document.createEvent) {
      // IE9 if standards
      _document.dispatchEvent(evt);
    } else {
      // IE8 regardless of Quirks or Standards
      // IE9 if quirks
      try {
        _document.fireEvent('on' + evt.eventType.toLowerCase(), evt);
      } catch (e) {
        // Do nothing
      }
    }
  },

  /**
   * Wraps addEventListener to capture UI breadcrumbs
   * @param evtName the event name (e.g. "click")
   * @returns {Function}
   * @private
   */
  _breadcrumbEventHandler: function _breadcrumbEventHandler(evtName) {
    var self = this;
    return function (evt) {
      // reset keypress timeout; e.g. triggering a 'click' after
      // a 'keypress' will reset the keypress debounce so that a new
      // set of keypresses can be recorded
      self._keypressTimeout = null;

      // It's possible this handler might trigger multiple times for the same
      // event (e.g. event propagation through node ancestors). Ignore if we've
      // already captured the event.
      if (self._lastCapturedEvent === evt) return;

      self._lastCapturedEvent = evt;

      // try/catch both:
      // - accessing evt.target (see getsentry/raven-js#838, #768)
      // - `htmlTreeAsString` because it's complex, and just accessing the DOM incorrectly
      //   can throw an exception in some circumstances.
      var target;
      try {
        target = htmlTreeAsString(evt.target);
      } catch (e) {
        target = '<unknown>';
      }

      self.captureBreadcrumb({
        category: 'ui.' + evtName, // e.g. ui.click, ui.input
        message: target
      });
    };
  },

  /**
   * Wraps addEventListener to capture keypress UI events
   * @returns {Function}
   * @private
   */
  _keypressEventHandler: function _keypressEventHandler() {
    var self = this,
        debounceDuration = 1000; // milliseconds

    // TODO: if somehow user switches keypress target before
    //       debounce timeout is triggered, we will only capture
    //       a single breadcrumb from the FIRST target (acceptable?)
    return function (evt) {
      var target;
      try {
        target = evt.target;
      } catch (e) {
        // just accessing event properties can throw an exception in some rare circumstances
        // see: https://github.com/getsentry/raven-js/issues/838
        return;
      }
      var tagName = target && target.tagName;

      // only consider keypress events on actual input elements
      // this will disregard keypresses targeting body (e.g. tabbing
      // through elements, hotkeys, etc)
      if (!tagName || tagName !== 'INPUT' && tagName !== 'TEXTAREA' && !target.isContentEditable) return;

      // record first keypress in a series, but ignore subsequent
      // keypresses until debounce clears
      var timeout = self._keypressTimeout;
      if (!timeout) {
        self._breadcrumbEventHandler('input')(evt);
      }
      clearTimeout(timeout);
      self._keypressTimeout = setTimeout(function () {
        self._keypressTimeout = null;
      }, debounceDuration);
    };
  },

  /**
   * Captures a breadcrumb of type "navigation", normalizing input URLs
   * @param to the originating URL
   * @param from the target URL
   * @private
   */
  _captureUrlChange: function _captureUrlChange(from, to) {
    var parsedLoc = parseUrl(this._location.href);
    var parsedTo = parseUrl(to);
    var parsedFrom = parseUrl(from);

    // because onpopstate only tells you the "new" (to) value of location.href, and
    // not the previous (from) value, we need to track the value of the current URL
    // state ourselves
    this._lastHref = to;

    // Use only the path component of the URL if the URL matches the current
    // document (almost all the time when using pushState)
    if (parsedLoc.protocol === parsedTo.protocol && parsedLoc.host === parsedTo.host) to = parsedTo.relative;
    if (parsedLoc.protocol === parsedFrom.protocol && parsedLoc.host === parsedFrom.host) from = parsedFrom.relative;

    this.captureBreadcrumb({
      category: 'navigation',
      data: {
        to: to,
        from: from
      }
    });
  },

  _patchFunctionToString: function _patchFunctionToString() {
    var self = this;
    self._originalFunctionToString = Function.prototype.toString;
    // eslint-disable-next-line no-extend-native
    Function.prototype.toString = function () {
      if (typeof this === 'function' && this.__raven__) {
        return self._originalFunctionToString.apply(this.__orig__, arguments);
      }
      return self._originalFunctionToString.apply(this, arguments);
    };
  },

  _unpatchFunctionToString: function _unpatchFunctionToString() {
    if (this._originalFunctionToString) {
      // eslint-disable-next-line no-extend-native
      Function.prototype.toString = this._originalFunctionToString;
    }
  },

  /**
   * Wrap timer functions and event targets to catch errors and provide
   * better metadata.
   */
  _instrumentTryCatch: function _instrumentTryCatch() {
    var self = this;

    var wrappedBuiltIns = self._wrappedBuiltIns;

    function wrapTimeFn(orig) {
      return function (fn, t) {
        // preserve arity
        // Make a copy of the arguments to prevent deoptimization
        // https://github.com/petkaantonov/bluebird/wiki/Optimization-killers#32-leaking-arguments
        var args = new Array(arguments.length);
        for (var i = 0; i < args.length; ++i) {
          args[i] = arguments[i];
        }
        var originalCallback = args[0];
        if (isFunction(originalCallback)) {
          args[0] = self.wrap({
            mechanism: {
              type: 'instrument',
              data: { function: orig.name || '<anonymous>' }
            }
          }, originalCallback);
        }

        // IE < 9 doesn't support .call/.apply on setInterval/setTimeout, but it
        // also supports only two arguments and doesn't care what this is, so we
        // can just call the original function directly.
        if (orig.apply) {
          return orig.apply(this, args);
        } else {
          return orig(args[0], args[1]);
        }
      };
    }

    var autoBreadcrumbs = this._globalOptions.autoBreadcrumbs;

    function wrapEventTarget(global) {
      var proto = _window[global] && _window[global].prototype;
      if (proto && proto.hasOwnProperty && proto.hasOwnProperty('addEventListener')) {
        fill(proto, 'addEventListener', function (orig) {
          return function (evtName, fn, capture, secure) {
            // preserve arity
            try {
              if (fn && fn.handleEvent) {
                fn.handleEvent = self.wrap({
                  mechanism: {
                    type: 'instrument',
                    data: {
                      target: global,
                      function: 'handleEvent',
                      handler: fn && fn.name || '<anonymous>'
                    }
                  }
                }, fn.handleEvent);
              }
            } catch (err) {}
            // can sometimes get 'Permission denied to access property "handle Event'


            // More breadcrumb DOM capture ... done here and not in `_instrumentBreadcrumbs`
            // so that we don't have more than one wrapper function
            var before, clickHandler, keypressHandler;

            if (autoBreadcrumbs && autoBreadcrumbs.dom && (global === 'EventTarget' || global === 'Node')) {
              // NOTE: generating multiple handlers per addEventListener invocation, should
              //       revisit and verify we can just use one (almost certainly)
              clickHandler = self._breadcrumbEventHandler('click');
              keypressHandler = self._keypressEventHandler();
              before = function before(evt) {
                // need to intercept every DOM event in `before` argument, in case that
                // same wrapped method is re-used for different events (e.g. mousemove THEN click)
                // see #724
                if (!evt) return;

                var eventType;
                try {
                  eventType = evt.type;
                } catch (e) {
                  // just accessing event properties can throw an exception in some rare circumstances
                  // see: https://github.com/getsentry/raven-js/issues/838
                  return;
                }
                if (eventType === 'click') return clickHandler(evt);else if (eventType === 'keypress') return keypressHandler(evt);
              };
            }
            return orig.call(this, evtName, self.wrap({
              mechanism: {
                type: 'instrument',
                data: {
                  target: global,
                  function: 'addEventListener',
                  handler: fn && fn.name || '<anonymous>'
                }
              }
            }, fn, before), capture, secure);
          };
        }, wrappedBuiltIns);
        fill(proto, 'removeEventListener', function (orig) {
          return function (evt, fn, capture, secure) {
            try {
              fn = fn && (fn.__raven_wrapper__ ? fn.__raven_wrapper__ : fn);
            } catch (e) {
              // ignore, accessing __raven_wrapper__ will throw in some Selenium environments
            }
            return orig.call(this, evt, fn, capture, secure);
          };
        }, wrappedBuiltIns);
      }
    }

    fill(_window, 'setTimeout', wrapTimeFn, wrappedBuiltIns);
    fill(_window, 'setInterval', wrapTimeFn, wrappedBuiltIns);
    if (_window.requestAnimationFrame) {
      fill(_window, 'requestAnimationFrame', function (orig) {
        return function (cb) {
          return orig(self.wrap({
            mechanism: {
              type: 'instrument',
              data: {
                function: 'requestAnimationFrame',
                handler: orig && orig.name || '<anonymous>'
              }
            }
          }, cb));
        };
      }, wrappedBuiltIns);
    }

    // event targets borrowed from bugsnag-js:
    // https://github.com/bugsnag/bugsnag-js/blob/master/src/bugsnag.js#L666
    var eventTargets = ['EventTarget', 'Window', 'Node', 'ApplicationCache', 'AudioTrackList', 'ChannelMergerNode', 'CryptoOperation', 'EventSource', 'FileReader', 'HTMLUnknownElement', 'IDBDatabase', 'IDBRequest', 'IDBTransaction', 'KeyOperation', 'MediaController', 'MessagePort', 'ModalWindow', 'Notification', 'SVGElementInstance', 'Screen', 'TextTrack', 'TextTrackCue', 'TextTrackList', 'WebSocket', 'WebSocketWorker', 'Worker', 'XMLHttpRequest', 'XMLHttpRequestEventTarget', 'XMLHttpRequestUpload'];
    for (var i = 0; i < eventTargets.length; i++) {
      wrapEventTarget(eventTargets[i]);
    }
  },

  /**
   * Instrument browser built-ins w/ breadcrumb capturing
   *  - XMLHttpRequests
   *  - DOM interactions (click/typing)
   *  - window.location changes
   *  - console
   *
   * Can be disabled or individually configured via the `autoBreadcrumbs` config option
   */
  _instrumentBreadcrumbs: function _instrumentBreadcrumbs() {
    var self = this;
    var autoBreadcrumbs = this._globalOptions.autoBreadcrumbs;

    var wrappedBuiltIns = self._wrappedBuiltIns;

    function wrapProp(prop, xhr) {
      if (prop in xhr && isFunction(xhr[prop])) {
        fill(xhr, prop, function (orig) {
          return self.wrap({
            mechanism: {
              type: 'instrument',
              data: { function: prop, handler: orig && orig.name || '<anonymous>' }
            }
          }, orig);
        }); // intentionally don't track filled methods on XHR instances
      }
    }

    if (autoBreadcrumbs.xhr && 'XMLHttpRequest' in _window) {
      var xhrproto = _window.XMLHttpRequest && _window.XMLHttpRequest.prototype;
      fill(xhrproto, 'open', function (origOpen) {
        return function (method, url) {
          // preserve arity

          // if Sentry key appears in URL, don't capture
          if (isString(url) && url.indexOf(self._globalKey) === -1) {
            this.__raven_xhr = {
              method: method,
              url: url,
              status_code: null
            };
          }

          return origOpen.apply(this, arguments);
        };
      }, wrappedBuiltIns);

      fill(xhrproto, 'send', function (origSend) {
        return function () {
          // preserve arity
          var xhr = this;

          function onreadystatechangeHandler() {
            if (xhr.__raven_xhr && xhr.readyState === 4) {
              try {
                // touching statusCode in some platforms throws
                // an exception
                xhr.__raven_xhr.status_code = xhr.status;
              } catch (e) {
                /* do nothing */
              }

              self.captureBreadcrumb({
                type: 'http',
                category: 'xhr',
                data: xhr.__raven_xhr
              });
            }
          }

          var props = ['onload', 'onerror', 'onprogress'];
          for (var j = 0; j < props.length; j++) {
            wrapProp(props[j], xhr);
          }

          if ('onreadystatechange' in xhr && isFunction(xhr.onreadystatechange)) {
            fill(xhr, 'onreadystatechange', function (orig) {
              return self.wrap({
                mechanism: {
                  type: 'instrument',
                  data: {
                    function: 'onreadystatechange',
                    handler: orig && orig.name || '<anonymous>'
                  }
                }
              }, orig, onreadystatechangeHandler);
            } /* intentionally don't track this instrumentation */
            );
          } else {
            // if onreadystatechange wasn't actually set by the page on this xhr, we
            // are free to set our own and capture the breadcrumb
            xhr.onreadystatechange = onreadystatechangeHandler;
          }

          return origSend.apply(this, arguments);
        };
      }, wrappedBuiltIns);
    }

    if (autoBreadcrumbs.xhr && supportsFetch()) {
      fill(_window, 'fetch', function (origFetch) {
        return function () {
          // preserve arity
          // Make a copy of the arguments to prevent deoptimization
          // https://github.com/petkaantonov/bluebird/wiki/Optimization-killers#32-leaking-arguments
          var args = new Array(arguments.length);
          for (var i = 0; i < args.length; ++i) {
            args[i] = arguments[i];
          }

          var fetchInput = args[0];
          var method = 'GET';
          var url;

          if (typeof fetchInput === 'string') {
            url = fetchInput;
          } else if ('Request' in _window && fetchInput instanceof _window.Request) {
            url = fetchInput.url;
            if (fetchInput.method) {
              method = fetchInput.method;
            }
          } else {
            url = '' + fetchInput;
          }

          // if Sentry key appears in URL, don't capture, as it's our own request
          if (url.indexOf(self._globalKey) !== -1) {
            return origFetch.apply(this, args);
          }

          if (args[1] && args[1].method) {
            method = args[1].method;
          }

          var fetchData = {
            method: method,
            url: url,
            status_code: null
          };

          return origFetch.apply(this, args).then(function (response) {
            fetchData.status_code = response.status;

            self.captureBreadcrumb({
              type: 'http',
              category: 'fetch',
              data: fetchData
            });

            return response;
          })['catch'](function (err) {
            // if there is an error performing the request
            self.captureBreadcrumb({
              type: 'http',
              category: 'fetch',
              data: fetchData,
              level: 'error'
            });

            throw err;
          });
        };
      }, wrappedBuiltIns);
    }

    // Capture breadcrumbs from any click that is unhandled / bubbled up all the way
    // to the document. Do this before we instrument addEventListener.
    if (autoBreadcrumbs.dom && this._hasDocument) {
      if (_document.addEventListener) {
        _document.addEventListener('click', self._breadcrumbEventHandler('click'), false);
        _document.addEventListener('keypress', self._keypressEventHandler(), false);
      } else if (_document.attachEvent) {
        // IE8 Compatibility
        _document.attachEvent('onclick', self._breadcrumbEventHandler('click'));
        _document.attachEvent('onkeypress', self._keypressEventHandler());
      }
    }

    // record navigation (URL) changes
    // NOTE: in Chrome App environment, touching history.pushState, *even inside
    //       a try/catch block*, will cause Chrome to output an error to console.error
    // borrowed from: https://github.com/angular/angular.js/pull/13945/files
    var chrome = _window.chrome;
    var isChromePackagedApp = chrome && chrome.app && chrome.app.runtime;
    var hasPushAndReplaceState = !isChromePackagedApp && _window.history && _window.history.pushState && _window.history.replaceState;
    if (autoBreadcrumbs.location && hasPushAndReplaceState) {
      // TODO: remove onpopstate handler on uninstall()
      var oldOnPopState = _window.onpopstate;
      _window.onpopstate = function () {
        var currentHref = self._location.href;
        self._captureUrlChange(self._lastHref, currentHref);

        if (oldOnPopState) {
          return oldOnPopState.apply(this, arguments);
        }
      };

      var historyReplacementFunction = function historyReplacementFunction(origHistFunction) {
        // note history.pushState.length is 0; intentionally not declaring
        // params to preserve 0 arity
        return function () /* state, title, url */{
          var url = arguments.length > 2 ? arguments[2] : undefined;

          // url argument is optional
          if (url) {
            // coerce to string (this is what pushState does)
            self._captureUrlChange(self._lastHref, url + '');
          }

          return origHistFunction.apply(this, arguments);
        };
      };

      fill(_window.history, 'pushState', historyReplacementFunction, wrappedBuiltIns);
      fill(_window.history, 'replaceState', historyReplacementFunction, wrappedBuiltIns);
    }

    if (autoBreadcrumbs.console && 'console' in _window && console.log) {
      // console
      var consoleMethodCallback = function consoleMethodCallback(msg, data) {
        self.captureBreadcrumb({
          message: msg,
          level: data.level,
          category: 'console'
        });
      };

      each(['debug', 'info', 'warn', 'error', 'log'], function (_, level) {
        wrapConsoleMethod(console, level, consoleMethodCallback);
      });
    }
  },

  _restoreBuiltIns: function _restoreBuiltIns() {
    // restore any wrapped builtins
    var builtin;
    while (this._wrappedBuiltIns.length) {
      builtin = this._wrappedBuiltIns.shift();

      var obj = builtin[0],
          name = builtin[1],
          orig = builtin[2];

      obj[name] = orig;
    }
  },

  _restoreConsole: function _restoreConsole() {
    // eslint-disable-next-line guard-for-in
    for (var method in this._originalConsoleMethods) {
      this._originalConsole[method] = this._originalConsoleMethods[method];
    }
  },

  _drainPlugins: function _drainPlugins() {
    var self = this;

    // FIX ME TODO
    each(this._plugins, function (_, plugin) {
      var installer = plugin[0];
      var args = plugin[1];
      installer.apply(self, [self].concat(args));
    });
  },

  _parseDSN: function _parseDSN(str) {
    var m = dsnPattern.exec(str),
        dsn = {},
        i = 7;

    try {
      while (i--) {
        dsn[dsnKeys[i]] = m[i] || '';
      }
    } catch (e) {
      throw new RavenConfigError('Invalid DSN: ' + str);
    }

    if (dsn.pass && !this._globalOptions.allowSecretKey) {
      throw new RavenConfigError('Do not specify your secret key in the DSN. See: http://bit.ly/raven-secret-key');
    }

    return dsn;
  },

  _getGlobalServer: function _getGlobalServer(uri) {
    // assemble the endpoint from the uri pieces
    var globalServer = '//' + uri.host + (uri.port ? ':' + uri.port : '');

    if (uri.protocol) {
      globalServer = uri.protocol + ':' + globalServer;
    }
    return globalServer;
  },

  _handleOnErrorStackInfo: function _handleOnErrorStackInfo(stackInfo, options) {
    options = options || {};
    options.mechanism = options.mechanism || {
      type: 'onerror',
      handled: false
    };

    // if we are intentionally ignoring errors via onerror, bail out
    if (!this._ignoreOnError) {
      this._handleStackInfo(stackInfo, options);
    }
  },

  _handleStackInfo: function _handleStackInfo(stackInfo, options) {
    var frames = this._prepareFrames(stackInfo, options);

    this._triggerEvent('handle', {
      stackInfo: stackInfo,
      options: options
    });

    this._processException(stackInfo.name, stackInfo.message, stackInfo.url, stackInfo.lineno, frames, options);
  },

  _prepareFrames: function _prepareFrames(stackInfo, options) {
    var self = this;
    var frames = [];
    if (stackInfo.stack && stackInfo.stack.length) {
      each(stackInfo.stack, function (i, stack) {
        var frame = self._normalizeFrame(stack, stackInfo.url);
        if (frame) {
          frames.push(frame);
        }
      });

      // e.g. frames captured via captureMessage throw
      if (options && options.trimHeadFrames) {
        for (var j = 0; j < options.trimHeadFrames && j < frames.length; j++) {
          frames[j].in_app = false;
        }
      }
    }
    frames = frames.slice(0, this._globalOptions.stackTraceLimit);
    return frames;
  },

  _normalizeFrame: function _normalizeFrame(frame, stackInfoUrl) {
    // normalize the frames data
    var normalized = {
      filename: frame.url,
      lineno: frame.line,
      colno: frame.column,
      function: frame.func || '?'
    };

    // Case when we don't have any information about the error
    // E.g. throwing a string or raw object, instead of an `Error` in Firefox
    // Generating synthetic error doesn't add any value here
    //
    // We should probably somehow let a user know that they should fix their code
    if (!frame.url) {
      normalized.filename = stackInfoUrl; // fallback to whole stacks url from onerror handler
    }

    normalized.in_app = !( // determine if an exception came from outside of our app
    // first we check the global includePaths list.
    !!this._globalOptions.includePaths.test && !this._globalOptions.includePaths.test(normalized.filename) ||
    // Now we check for fun, if the function name is Raven or TraceKit
    /(Raven|TraceKit)\./.test(normalized['function']) ||
    // finally, we do a last ditch effort and check for raven.min.js
    /raven\.(min\.)?js$/.test(normalized.filename));

    return normalized;
  },

  _processException: function _processException(type, message, fileurl, lineno, frames, options) {
    var prefixedMessage = (type ? type + ': ' : '') + (message || '');
    if (!!this._globalOptions.ignoreErrors.test && (this._globalOptions.ignoreErrors.test(message) || this._globalOptions.ignoreErrors.test(prefixedMessage))) {
      return;
    }

    var stacktrace;

    if (frames && frames.length) {
      fileurl = frames[0].filename || fileurl;
      // Sentry expects frames oldest to newest
      // and JS sends them as newest to oldest
      frames.reverse();
      stacktrace = { frames: frames };
    } else if (fileurl) {
      stacktrace = {
        frames: [{
          filename: fileurl,
          lineno: lineno,
          in_app: true
        }]
      };
    }

    if (!!this._globalOptions.ignoreUrls.test && this._globalOptions.ignoreUrls.test(fileurl)) {
      return;
    }

    if (!!this._globalOptions.whitelistUrls.test && !this._globalOptions.whitelistUrls.test(fileurl)) {
      return;
    }

    var data = objectMerge({
      // sentry.interfaces.Exception
      exception: {
        values: [{
          type: type,
          value: message,
          stacktrace: stacktrace
        }]
      },
      transaction: fileurl
    }, options);

    var ex = data.exception.values[0];
    if (ex.type == null && ex.value === '') {
      ex.value = 'Unrecoverable error caught';
    }

    // Move mechanism from options to exception interface
    // We do this, as requiring user to pass `{exception:{mechanism:{ ... }}}` would be
    // too much
    if (!data.exception.mechanism && data.mechanism) {
      data.exception.mechanism = data.mechanism;
      delete data.mechanism;
    }

    data.exception.mechanism = objectMerge({
      type: 'generic',
      handled: true
    }, data.exception.mechanism || {});

    // Fire away!
    this._send(data);
  },

  _trimPacket: function _trimPacket(data) {
    // For now, we only want to truncate the two different messages
    // but this could/should be expanded to just trim everything
    var max = this._globalOptions.maxMessageLength;
    if (data.message) {
      data.message = truncate(data.message, max);
    }
    if (data.exception) {
      var exception = data.exception.values[0];
      exception.value = truncate(exception.value, max);
    }

    var request = data.request;
    if (request) {
      if (request.url) {
        request.url = truncate(request.url, this._globalOptions.maxUrlLength);
      }
      if (request.Referer) {
        request.Referer = truncate(request.Referer, this._globalOptions.maxUrlLength);
      }
    }

    if (data.breadcrumbs && data.breadcrumbs.values) this._trimBreadcrumbs(data.breadcrumbs);

    return data;
  },

  /**
   * Truncate breadcrumb values (right now just URLs)
   */
  _trimBreadcrumbs: function _trimBreadcrumbs(breadcrumbs) {
    // known breadcrumb properties with urls
    // TODO: also consider arbitrary prop values that start with (https?)?://
    var urlProps = ['to', 'from', 'url'],
        urlProp,
        crumb,
        data;

    for (var i = 0; i < breadcrumbs.values.length; ++i) {
      crumb = breadcrumbs.values[i];
      if (!crumb.hasOwnProperty('data') || !isObject(crumb.data) || objectFrozen(crumb.data)) continue;

      data = objectMerge({}, crumb.data);
      for (var j = 0; j < urlProps.length; ++j) {
        urlProp = urlProps[j];
        if (data.hasOwnProperty(urlProp) && data[urlProp]) {
          data[urlProp] = truncate(data[urlProp], this._globalOptions.maxUrlLength);
        }
      }
      breadcrumbs.values[i].data = data;
    }
  },

  _getHttpData: function _getHttpData() {
    if (!this._hasNavigator && !this._hasDocument) return;
    var httpData = {};

    if (this._hasNavigator && _navigator.userAgent) {
      httpData.headers = {
        'User-Agent': _navigator.userAgent
      };
    }

    // Check in `window` instead of `document`, as we may be in ServiceWorker environment
    if (_window.location && _window.location.href) {
      httpData.url = _window.location.href;
    }

    if (this._hasDocument && _document.referrer) {
      if (!httpData.headers) httpData.headers = {};
      httpData.headers.Referer = _document.referrer;
    }

    return httpData;
  },

  _resetBackoff: function _resetBackoff() {
    this._backoffDuration = 0;
    this._backoffStart = null;
  },

  _shouldBackoff: function _shouldBackoff() {
    return this._backoffDuration && now() - this._backoffStart < this._backoffDuration;
  },

  /**
   * Returns true if the in-process data payload matches the signature
   * of the previously-sent data
   *
   * NOTE: This has to be done at this level because TraceKit can generate
   *       data from window.onerror WITHOUT an exception object (IE8, IE9,
   *       other old browsers). This can take the form of an "exception"
   *       data object with a single frame (derived from the onerror args).
   */
  _isRepeatData: function _isRepeatData(current) {
    var last = this._lastData;

    if (!last || current.message !== last.message || // defined for captureMessage
    current.transaction !== last.transaction // defined for captureException/onerror
    ) return false;

    // Stacktrace interface (i.e. from captureMessage)
    if (current.stacktrace || last.stacktrace) {
      return isSameStacktrace(current.stacktrace, last.stacktrace);
    } else if (current.exception || last.exception) {
      // Exception interface (i.e. from captureException/onerror)
      return isSameException(current.exception, last.exception);
    } else if (current.fingerprint || last.fingerprint) {
      return Boolean(current.fingerprint && last.fingerprint) && JSON.stringify(current.fingerprint) === JSON.stringify(last.fingerprint);
    }

    return true;
  },

  _setBackoffState: function _setBackoffState(request) {
    // If we are already in a backoff state, don't change anything
    if (this._shouldBackoff()) {
      return;
    }

    var status = request.status;

    // 400 - project_id doesn't exist or some other fatal
    // 401 - invalid/revoked dsn
    // 429 - too many requests
    if (!(status === 400 || status === 401 || status === 429)) return;

    var retry;
    try {
      // If Retry-After is not in Access-Control-Expose-Headers, most
      // browsers will throw an exception trying to access it
      if (supportsFetch()) {
        retry = request.headers.get('Retry-After');
      } else {
        retry = request.getResponseHeader('Retry-After');
      }

      // Retry-After is returned in seconds
      retry = parseInt(retry, 10) * 1000;
    } catch (e) {
      /* eslint no-empty:0 */
    }

    this._backoffDuration = retry ? // If Sentry server returned a Retry-After value, use it
    retry : // Otherwise, double the last backoff duration (starts at 1 sec)
    this._backoffDuration * 2 || 1000;

    this._backoffStart = now();
  },

  _send: function _send(data) {
    var globalOptions = this._globalOptions;

    var baseData = {
      project: this._globalProject,
      logger: globalOptions.logger,
      platform: 'javascript'
    },
        httpData = this._getHttpData();

    if (httpData) {
      baseData.request = httpData;
    }

    // HACK: delete `trimHeadFrames` to prevent from appearing in outbound payload
    if (data.trimHeadFrames) delete data.trimHeadFrames;

    data = objectMerge(baseData, data);

    // Merge in the tags and extra separately since objectMerge doesn't handle a deep merge
    data.tags = objectMerge(objectMerge({}, this._globalContext.tags), data.tags);
    data.extra = objectMerge(objectMerge({}, this._globalContext.extra), data.extra);

    // Send along our own collected metadata with extra
    data.extra['session:duration'] = now() - this._startTime;

    if (this._breadcrumbs && this._breadcrumbs.length > 0) {
      // intentionally make shallow copy so that additions
      // to breadcrumbs aren't accidentally sent in this request
      data.breadcrumbs = {
        values: [].slice.call(this._breadcrumbs, 0)
      };
    }

    if (this._globalContext.user) {
      // sentry.interfaces.User
      data.user = this._globalContext.user;
    }

    // Include the environment if it's defined in globalOptions
    if (globalOptions.environment) data.environment = globalOptions.environment;

    // Include the release if it's defined in globalOptions
    if (globalOptions.release) data.release = globalOptions.release;

    // Include server_name if it's defined in globalOptions
    if (globalOptions.serverName) data.server_name = globalOptions.serverName;

    data = this._sanitizeData(data);

    // Cleanup empty properties before sending them to the server
    Object.keys(data).forEach(function (key) {
      if (data[key] == null || data[key] === '' || isEmptyObject(data[key])) {
        delete data[key];
      }
    });

    if (isFunction(globalOptions.dataCallback)) {
      data = globalOptions.dataCallback(data) || data;
    }

    // Why??????????
    if (!data || isEmptyObject(data)) {
      return;
    }

    // Check if the request should be filtered or not
    if (isFunction(globalOptions.shouldSendCallback) && !globalOptions.shouldSendCallback(data)) {
      return;
    }

    // Backoff state: Sentry server previously responded w/ an error (e.g. 429 - too many requests),
    // so drop requests until "cool-off" period has elapsed.
    if (this._shouldBackoff()) {
      this._logDebug('warn', 'Raven dropped error due to backoff: ', data);
      return;
    }

    if (typeof globalOptions.sampleRate === 'number') {
      if (Math.random() < globalOptions.sampleRate) {
        this._sendProcessedPayload(data);
      }
    } else {
      this._sendProcessedPayload(data);
    }
  },

  _sanitizeData: function _sanitizeData(data) {
    return sanitize(data, this._globalOptions.sanitizeKeys);
  },

  _getUuid: function _getUuid() {
    return uuid4();
  },

  _sendProcessedPayload: function _sendProcessedPayload(data, callback) {
    var self = this;
    var globalOptions = this._globalOptions;

    if (!this.isSetup()) return;

    // Try and clean up the packet before sending by truncating long values
    data = this._trimPacket(data);

    // ideally duplicate error testing should occur *before* dataCallback/shouldSendCallback,
    // but this would require copying an un-truncated copy of the data packet, which can be
    // arbitrarily deep (extra_data) -- could be worthwhile? will revisit
    if (!this._globalOptions.allowDuplicates && this._isRepeatData(data)) {
      this._logDebug('warn', 'Raven dropped repeat event: ', data);
      return;
    }

    // Send along an event_id if not explicitly passed.
    // This event_id can be used to reference the error within Sentry itself.
    // Set lastEventId after we know the error should actually be sent
    this._lastEventId = data.event_id || (data.event_id = this._getUuid());

    // Store outbound payload after trim
    this._lastData = data;

    this._logDebug('debug', 'Raven about to send:', data);

    var auth = {
      sentry_version: '7',
      sentry_client: 'raven-js/' + this.VERSION,
      sentry_key: this._globalKey
    };

    if (this._globalSecret) {
      auth.sentry_secret = this._globalSecret;
    }

    var exception = data.exception && data.exception.values[0];

    // only capture 'sentry' breadcrumb is autoBreadcrumbs is truthy
    if (this._globalOptions.autoBreadcrumbs && this._globalOptions.autoBreadcrumbs.sentry) {
      this.captureBreadcrumb({
        category: 'sentry',
        message: exception ? (exception.type ? exception.type + ': ' : '') + exception.value : data.message,
        event_id: data.event_id,
        level: data.level || 'error' // presume error unless specified
      });
    }

    var url = this._globalEndpoint;
    (globalOptions.transport || this._makeRequest).call(this, {
      url: url,
      auth: auth,
      data: data,
      options: globalOptions,
      onSuccess: function success() {
        self._resetBackoff();

        self._triggerEvent('success', {
          data: data,
          src: url
        });
        callback && callback();
      },
      onError: function failure(error) {
        self._logDebug('error', 'Raven transport failed to send: ', error);

        if (error.request) {
          self._setBackoffState(error.request);
        }

        self._triggerEvent('failure', {
          data: data,
          src: url
        });
        error = error || new Error('Raven send failed (no additional details provided)');
        callback && callback(error);
      }
    });
  },

  _makeRequest: function _makeRequest(opts) {
    // Auth is intentionally sent as part of query string (NOT as custom HTTP header) to avoid preflight CORS requests
    var url = opts.url + '?' + urlencode(opts.auth);

    var evaluatedHeaders = null;
    var evaluatedFetchParameters = {};

    if (opts.options.headers) {
      evaluatedHeaders = this._evaluateHash(opts.options.headers);
    }

    if (opts.options.fetchParameters) {
      evaluatedFetchParameters = this._evaluateHash(opts.options.fetchParameters);
    }

    if (supportsFetch()) {
      evaluatedFetchParameters.body = stringify(opts.data);

      var defaultFetchOptions = objectMerge({}, this._fetchDefaults);
      var fetchOptions = objectMerge(defaultFetchOptions, evaluatedFetchParameters);

      if (evaluatedHeaders) {
        fetchOptions.headers = evaluatedHeaders;
      }

      return _window.fetch(url, fetchOptions).then(function (response) {
        if (response.ok) {
          opts.onSuccess && opts.onSuccess();
        } else {
          var error = new Error('Sentry error code: ' + response.status);
          // It's called request only to keep compatibility with XHR interface
          // and not add more redundant checks in setBackoffState method
          error.request = response;
          opts.onError && opts.onError(error);
        }
      })['catch'](function () {
        opts.onError && opts.onError(new Error('Sentry error code: network unavailable'));
      });
    }

    var request = _window.XMLHttpRequest && new _window.XMLHttpRequest();
    if (!request) return;

    // if browser doesn't support CORS (e.g. IE7), we are out of luck
    var hasCORS = 'withCredentials' in request || typeof XDomainRequest !== 'undefined';

    if (!hasCORS) return;

    if ('withCredentials' in request) {
      request.onreadystatechange = function () {
        if (request.readyState !== 4) {
          return;
        } else if (request.status === 200) {
          opts.onSuccess && opts.onSuccess();
        } else if (opts.onError) {
          var err = new Error('Sentry error code: ' + request.status);
          err.request = request;
          opts.onError(err);
        }
      };
    } else {
      request = new XDomainRequest();
      // xdomainrequest cannot go http -> https (or vice versa),
      // so always use protocol relative
      url = url.replace(/^https?:/, '');

      // onreadystatechange not supported by XDomainRequest
      if (opts.onSuccess) {
        request.onload = opts.onSuccess;
      }
      if (opts.onError) {
        request.onerror = function () {
          var err = new Error('Sentry error code: XDomainRequest');
          err.request = request;
          opts.onError(err);
        };
      }
    }

    request.open('POST', url);

    if (evaluatedHeaders) {
      each(evaluatedHeaders, function (key, value) {
        request.setRequestHeader(key, value);
      });
    }

    request.send(stringify(opts.data));
  },

  _evaluateHash: function _evaluateHash(hash) {
    var evaluated = {};

    for (var key in hash) {
      if (hash.hasOwnProperty(key)) {
        var value = hash[key];
        evaluated[key] = typeof value === 'function' ? value() : value;
      }
    }

    return evaluated;
  },

  _logDebug: function _logDebug(level) {
    // We allow `Raven.debug` and `Raven.config(DSN, { debug: true })` to not make backward incompatible API change
    if (this._originalConsoleMethods[level] && (this.debug || this._globalOptions.debug)) {
      // In IE<10 console methods do not have their own 'apply' method
      Function.prototype.apply.call(this._originalConsoleMethods[level], this._originalConsole, [].slice.call(arguments, 1));
    }
  },

  _mergeContext: function _mergeContext(key, context) {
    if (isUndefined(context)) {
      delete this._globalContext[key];
    } else {
      this._globalContext[key] = objectMerge(this._globalContext[key] || {}, context);
    }
  }
};

// Deprecations
Raven.prototype.setUser = Raven.prototype.setUserContext;
Raven.prototype.setReleaseContext = Raven.prototype.setRelease;

module.exports = Raven;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"../vendor/TraceKit/tracekit":12,"../vendor/json-stringify-safe/stringify":13,"../vendor/md5/md5":14,"./configError":7,"./console":8,"./utils":11}],10:[function(require,module,exports){
(function (global){
'use strict';

/**
 * Enforces a single instance of the Raven client, and the
 * main entry point for Raven. If you are a consumer of the
 * Raven library, you SHOULD load this file (vs raven.js).
 **/

var RavenConstructor = require('./raven');

// This is to be defensive in environments where window does not exist (see https://github.com/getsentry/raven-js/pull/785)
var _window = typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};
var _Raven = _window.Raven;

var Raven = new RavenConstructor();

/*
 * Allow multiple versions of Raven to be installed.
 * Strip Raven from the global context and returns the instance.
 *
 * @return {Raven}
 */
Raven.noConflict = function () {
  _window.Raven = _Raven;
  return Raven;
};

Raven.afterLoad();

module.exports = Raven;

/**
 * DISCLAIMER:
 *
 * Expose `Client` constructor for cases where user want to track multiple "sub-applications" in one larger app.
 * It's not meant to be used by a wide audience, so pleaaase make sure that you know what you're doing before using it.
 * Accidentally calling `install` multiple times, may result in an unexpected behavior that's very hard to debug.
 *
 * It's called `Client' to be in-line with Raven Node implementation.
 *
 * HOWTO:
 *
 * import Raven from 'raven-js';
 *
 * const someAppReporter = new Raven.Client();
 * const someOtherAppReporter = new Raven.Client();
 *
 * someAppReporter.config('__DSN__', {
 *   ...config goes here
 * });
 *
 * someOtherAppReporter.config('__OTHER_DSN__', {
 *   ...config goes here
 * });
 *
 * someAppReporter.captureMessage(...);
 * someAppReporter.captureException(...);
 * someAppReporter.captureBreadcrumb(...);
 *
 * someOtherAppReporter.captureMessage(...);
 * someOtherAppReporter.captureException(...);
 * someOtherAppReporter.captureBreadcrumb(...);
 *
 * It should "just work".
 */
module.exports.Client = RavenConstructor;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./raven":9}],11:[function(require,module,exports){
(function (global){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var stringify = require('../vendor/json-stringify-safe/stringify');

var _window = typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

function isObject(what) {
  return (typeof what === 'undefined' ? 'undefined' : _typeof(what)) === 'object' && what !== null;
}

// Yanked from https://git.io/vS8DV re-used under CC0
// with some tiny modifications
function isError(value) {
  switch (Object.prototype.toString.call(value)) {
    case '[object Error]':
      return true;
    case '[object Exception]':
      return true;
    case '[object DOMException]':
      return true;
    default:
      return value instanceof Error;
  }
}

function isErrorEvent(value) {
  return Object.prototype.toString.call(value) === '[object ErrorEvent]';
}

function isDOMError(value) {
  return Object.prototype.toString.call(value) === '[object DOMError]';
}

function isDOMException(value) {
  return Object.prototype.toString.call(value) === '[object DOMException]';
}

function isUndefined(what) {
  return what === void 0;
}

function isFunction(what) {
  return typeof what === 'function';
}

function isPlainObject(what) {
  return Object.prototype.toString.call(what) === '[object Object]';
}

function isString(what) {
  return Object.prototype.toString.call(what) === '[object String]';
}

function isArray(what) {
  return Object.prototype.toString.call(what) === '[object Array]';
}

function isEmptyObject(what) {
  if (!isPlainObject(what)) return false;

  for (var _ in what) {
    if (what.hasOwnProperty(_)) {
      return false;
    }
  }
  return true;
}

function supportsErrorEvent() {
  try {
    new ErrorEvent(''); // eslint-disable-line no-new
    return true;
  } catch (e) {
    return false;
  }
}

function supportsDOMError() {
  try {
    new DOMError(''); // eslint-disable-line no-new
    return true;
  } catch (e) {
    return false;
  }
}

function supportsDOMException() {
  try {
    new DOMException(''); // eslint-disable-line no-new
    return true;
  } catch (e) {
    return false;
  }
}

function supportsFetch() {
  if (!('fetch' in _window)) return false;

  try {
    new Headers(); // eslint-disable-line no-new
    new Request(''); // eslint-disable-line no-new
    new Response(); // eslint-disable-line no-new
    return true;
  } catch (e) {
    return false;
  }
}

// Despite all stars in the sky saying that Edge supports old draft syntax, aka 'never', 'always', 'origin' and 'default
// https://caniuse.com/#feat=referrer-policy
// It doesn't. And it throw exception instead of ignoring this parameter...
// REF: https://github.com/getsentry/raven-js/issues/1233
function supportsReferrerPolicy() {
  if (!supportsFetch()) return false;

  try {
    // eslint-disable-next-line no-new
    new Request('pickleRick', {
      referrerPolicy: 'origin'
    });
    return true;
  } catch (e) {
    return false;
  }
}

function supportsPromiseRejectionEvent() {
  return typeof PromiseRejectionEvent === 'function';
}

function wrappedCallback(callback) {
  function dataCallback(data, original) {
    var normalizedData = callback(data) || data;
    if (original) {
      return original(normalizedData) || normalizedData;
    }
    return normalizedData;
  }

  return dataCallback;
}

function each(obj, callback) {
  var i, j;

  if (isUndefined(obj.length)) {
    for (i in obj) {
      if (hasKey(obj, i)) {
        callback.call(null, i, obj[i]);
      }
    }
  } else {
    j = obj.length;
    if (j) {
      for (i = 0; i < j; i++) {
        callback.call(null, i, obj[i]);
      }
    }
  }
}

function objectMerge(obj1, obj2) {
  if (!obj2) {
    return obj1;
  }
  each(obj2, function (key, value) {
    obj1[key] = value;
  });
  return obj1;
}

/**
 * This function is only used for react-native.
 * react-native freezes object that have already been sent over the
 * js bridge. We need this function in order to check if the object is frozen.
 * So it's ok that objectFrozen returns false if Object.isFrozen is not
 * supported because it's not relevant for other "platforms". See related issue:
 * https://github.com/getsentry/react-native-sentry/issues/57
 */
function objectFrozen(obj) {
  if (!Object.isFrozen) {
    return false;
  }
  return Object.isFrozen(obj);
}

function truncate(str, max) {
  if (typeof max !== 'number') {
    throw new Error('2nd argument to `truncate` function should be a number');
  }
  if (typeof str !== 'string' || max === 0) {
    return str;
  }
  return str.length <= max ? str : str.substr(0, max) + '\u2026';
}

/**
 * hasKey, a better form of hasOwnProperty
 * Example: hasKey(MainHostObject, property) === true/false
 *
 * @param {Object} host object to check property
 * @param {string} key to check
 */
function hasKey(object, key) {
  return Object.prototype.hasOwnProperty.call(object, key);
}

function joinRegExp(patterns) {
  // Combine an array of regular expressions and strings into one large regexp
  // Be mad.
  var sources = [],
      i = 0,
      len = patterns.length,
      pattern;

  for (; i < len; i++) {
    pattern = patterns[i];
    if (isString(pattern)) {
      // If it's a string, we need to escape it
      // Taken from: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Regular_Expressions
      sources.push(pattern.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, '\\$1'));
    } else if (pattern && pattern.source) {
      // If it's a regexp already, we want to extract the source
      sources.push(pattern.source);
    }
    // Intentionally skip other cases
  }
  return new RegExp(sources.join('|'), 'i');
}

function urlencode(o) {
  var pairs = [];
  each(o, function (key, value) {
    pairs.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
  });
  return pairs.join('&');
}

// borrowed from https://tools.ietf.org/html/rfc3986#appendix-B
// intentionally using regex and not <a/> href parsing trick because React Native and other
// environments where DOM might not be available
function parseUrl(url) {
  if (typeof url !== 'string') return {};
  var match = url.match(/^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/);

  // coerce to undefined values to empty string so we don't get 'undefined'
  var query = match[6] || '';
  var fragment = match[8] || '';
  return {
    protocol: match[2],
    host: match[4],
    path: match[5],
    relative: match[5] + query + fragment // everything minus origin
  };
}
function uuid4() {
  var crypto = _window.crypto || _window.msCrypto;

  if (!isUndefined(crypto) && crypto.getRandomValues) {
    // Use window.crypto API if available
    // eslint-disable-next-line no-undef
    var arr = new Uint16Array(8);
    crypto.getRandomValues(arr);

    // set 4 in byte 7
    arr[3] = arr[3] & 0xfff | 0x4000;
    // set 2 most significant bits of byte 9 to '10'
    arr[4] = arr[4] & 0x3fff | 0x8000;

    var pad = function pad(num) {
      var v = num.toString(16);
      while (v.length < 4) {
        v = '0' + v;
      }
      return v;
    };

    return pad(arr[0]) + pad(arr[1]) + pad(arr[2]) + pad(arr[3]) + pad(arr[4]) + pad(arr[5]) + pad(arr[6]) + pad(arr[7]);
  } else {
    // http://stackoverflow.com/questions/105034/how-to-create-a-guid-uuid-in-javascript/2117523#2117523
    return 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0,
          v = c === 'x' ? r : r & 0x3 | 0x8;
      return v.toString(16);
    });
  }
}

/**
 * Given a child DOM element, returns a query-selector statement describing that
 * and its ancestors
 * e.g. [HTMLElement] => body > div > input#foo.btn[name=baz]
 * @param elem
 * @returns {string}
 */
function htmlTreeAsString(elem) {
  /* eslint no-extra-parens:0*/
  var MAX_TRAVERSE_HEIGHT = 5,
      MAX_OUTPUT_LEN = 80,
      out = [],
      height = 0,
      len = 0,
      separator = ' > ',
      sepLength = separator.length,
      nextStr;

  while (elem && height++ < MAX_TRAVERSE_HEIGHT) {
    nextStr = htmlElementAsString(elem);
    // bail out if
    // - nextStr is the 'html' element
    // - the length of the string that would be created exceeds MAX_OUTPUT_LEN
    //   (ignore this limit if we are on the first iteration)
    if (nextStr === 'html' || height > 1 && len + out.length * sepLength + nextStr.length >= MAX_OUTPUT_LEN) {
      break;
    }

    out.push(nextStr);

    len += nextStr.length;
    elem = elem.parentNode;
  }

  return out.reverse().join(separator);
}

/**
 * Returns a simple, query-selector representation of a DOM element
 * e.g. [HTMLElement] => input#foo.btn[name=baz]
 * @param HTMLElement
 * @returns {string}
 */
function htmlElementAsString(elem) {
  var out = [],
      className,
      classes,
      key,
      attr,
      i;

  if (!elem || !elem.tagName) {
    return '';
  }

  out.push(elem.tagName.toLowerCase());
  if (elem.id) {
    out.push('#' + elem.id);
  }

  className = elem.className;
  if (className && isString(className)) {
    classes = className.split(/\s+/);
    for (i = 0; i < classes.length; i++) {
      out.push('.' + classes[i]);
    }
  }
  var attrWhitelist = ['type', 'name', 'title', 'alt'];
  for (i = 0; i < attrWhitelist.length; i++) {
    key = attrWhitelist[i];
    attr = elem.getAttribute(key);
    if (attr) {
      out.push('[' + key + '="' + attr + '"]');
    }
  }
  return out.join('');
}

/**
 * Returns true if either a OR b is truthy, but not both
 */
function isOnlyOneTruthy(a, b) {
  return !!(!!a ^ !!b);
}

/**
 * Returns true if both parameters are undefined
 */
function isBothUndefined(a, b) {
  return isUndefined(a) && isUndefined(b);
}

/**
 * Returns true if the two input exception interfaces have the same content
 */
function isSameException(ex1, ex2) {
  if (isOnlyOneTruthy(ex1, ex2)) return false;

  ex1 = ex1.values[0];
  ex2 = ex2.values[0];

  if (ex1.type !== ex2.type || ex1.value !== ex2.value) return false;

  // in case both stacktraces are undefined, we can't decide so default to false
  if (isBothUndefined(ex1.stacktrace, ex2.stacktrace)) return false;

  return isSameStacktrace(ex1.stacktrace, ex2.stacktrace);
}

/**
 * Returns true if the two input stack trace interfaces have the same content
 */
function isSameStacktrace(stack1, stack2) {
  if (isOnlyOneTruthy(stack1, stack2)) return false;

  var frames1 = stack1.frames;
  var frames2 = stack2.frames;

  // Exit early if stacktrace is malformed
  if (frames1 === undefined || frames2 === undefined) return false;

  // Exit early if frame count differs
  if (frames1.length !== frames2.length) return false;

  // Iterate through every frame; bail out if anything differs
  var a, b;
  for (var i = 0; i < frames1.length; i++) {
    a = frames1[i];
    b = frames2[i];
    if (a.filename !== b.filename || a.lineno !== b.lineno || a.colno !== b.colno || a['function'] !== b['function']) return false;
  }
  return true;
}

/**
 * Polyfill a method
 * @param obj object e.g. `document`
 * @param name method name present on object e.g. `addEventListener`
 * @param replacement replacement function
 * @param track {optional} record instrumentation to an array
 */
function fill(obj, name, replacement, track) {
  if (obj == null) return;
  var orig = obj[name];
  obj[name] = replacement(orig);
  obj[name].__raven__ = true;
  obj[name].__orig__ = orig;
  if (track) {
    track.push([obj, name, orig]);
  }
}

/**
 * Join values in array
 * @param input array of values to be joined together
 * @param delimiter string to be placed in-between values
 * @returns {string}
 */
function safeJoin(input, delimiter) {
  if (!isArray(input)) return '';

  var output = [];

  for (var i = 0; i < input.length; i++) {
    try {
      output.push(String(input[i]));
    } catch (e) {
      output.push('[value cannot be serialized]');
    }
  }

  return output.join(delimiter);
}

// Default Node.js REPL depth
var MAX_SERIALIZE_EXCEPTION_DEPTH = 3;
// 50kB, as 100kB is max payload size, so half sounds reasonable
var MAX_SERIALIZE_EXCEPTION_SIZE = 50 * 1024;
var MAX_SERIALIZE_KEYS_LENGTH = 40;

function utf8Length(value) {
  return ~-encodeURI(value).split(/%..|./).length;
}

function jsonSize(value) {
  return utf8Length(JSON.stringify(value));
}

function serializeValue(value) {
  if (typeof value === 'string') {
    var maxLength = 40;
    return truncate(value, maxLength);
  } else if (typeof value === 'number' || typeof value === 'boolean' || typeof value === 'undefined') {
    return value;
  }

  var type = Object.prototype.toString.call(value);

  // Node.js REPL notation
  if (type === '[object Object]') return '[Object]';
  if (type === '[object Array]') return '[Array]';
  if (type === '[object Function]') return value.name ? '[Function: ' + value.name + ']' : '[Function]';

  return value;
}

function serializeObject(value, depth) {
  if (depth === 0) return serializeValue(value);

  if (isPlainObject(value)) {
    return Object.keys(value).reduce(function (acc, key) {
      acc[key] = serializeObject(value[key], depth - 1);
      return acc;
    }, {});
  } else if (Array.isArray(value)) {
    return value.map(function (val) {
      return serializeObject(val, depth - 1);
    });
  }

  return serializeValue(value);
}

function serializeException(ex, depth, maxSize) {
  if (!isPlainObject(ex)) return ex;

  depth = typeof depth !== 'number' ? MAX_SERIALIZE_EXCEPTION_DEPTH : depth;
  maxSize = typeof depth !== 'number' ? MAX_SERIALIZE_EXCEPTION_SIZE : maxSize;

  var serialized = serializeObject(ex, depth);

  if (jsonSize(stringify(serialized)) > maxSize) {
    return serializeException(ex, depth - 1);
  }

  return serialized;
}

function serializeKeysForMessage(keys, maxLength) {
  if (typeof keys === 'number' || typeof keys === 'string') return keys.toString();
  if (!Array.isArray(keys)) return '';

  keys = keys.filter(function (key) {
    return typeof key === 'string';
  });
  if (keys.length === 0) return '[object has no keys]';

  maxLength = typeof maxLength !== 'number' ? MAX_SERIALIZE_KEYS_LENGTH : maxLength;
  if (keys[0].length >= maxLength) return keys[0];

  for (var usedKeys = keys.length; usedKeys > 0; usedKeys--) {
    var serialized = keys.slice(0, usedKeys).join(', ');
    if (serialized.length > maxLength) continue;
    if (usedKeys === keys.length) return serialized;
    return serialized + '\u2026';
  }

  return '';
}

function sanitize(input, sanitizeKeys) {
  if (!isArray(sanitizeKeys) || isArray(sanitizeKeys) && sanitizeKeys.length === 0) return input;

  var sanitizeRegExp = joinRegExp(sanitizeKeys);
  var sanitizeMask = '********';
  var safeInput;

  try {
    safeInput = JSON.parse(stringify(input));
  } catch (o_O) {
    return input;
  }

  function sanitizeWorker(workerInput) {
    if (isArray(workerInput)) {
      return workerInput.map(function (val) {
        return sanitizeWorker(val);
      });
    }

    if (isPlainObject(workerInput)) {
      return Object.keys(workerInput).reduce(function (acc, k) {
        if (sanitizeRegExp.test(k)) {
          acc[k] = sanitizeMask;
        } else {
          acc[k] = sanitizeWorker(workerInput[k]);
        }
        return acc;
      }, {});
    }

    return workerInput;
  }

  return sanitizeWorker(safeInput);
}

module.exports = {
  isObject: isObject,
  isError: isError,
  isErrorEvent: isErrorEvent,
  isDOMError: isDOMError,
  isDOMException: isDOMException,
  isUndefined: isUndefined,
  isFunction: isFunction,
  isPlainObject: isPlainObject,
  isString: isString,
  isArray: isArray,
  isEmptyObject: isEmptyObject,
  supportsErrorEvent: supportsErrorEvent,
  supportsDOMError: supportsDOMError,
  supportsDOMException: supportsDOMException,
  supportsFetch: supportsFetch,
  supportsReferrerPolicy: supportsReferrerPolicy,
  supportsPromiseRejectionEvent: supportsPromiseRejectionEvent,
  wrappedCallback: wrappedCallback,
  each: each,
  objectMerge: objectMerge,
  truncate: truncate,
  objectFrozen: objectFrozen,
  hasKey: hasKey,
  joinRegExp: joinRegExp,
  urlencode: urlencode,
  uuid4: uuid4,
  htmlTreeAsString: htmlTreeAsString,
  htmlElementAsString: htmlElementAsString,
  isSameException: isSameException,
  isSameStacktrace: isSameStacktrace,
  parseUrl: parseUrl,
  fill: fill,
  safeJoin: safeJoin,
  serializeException: serializeException,
  serializeKeysForMessage: serializeKeysForMessage,
  sanitize: sanitize
};

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"../vendor/json-stringify-safe/stringify":13}],12:[function(require,module,exports){
(function (global){
'use strict';

var utils = require('../../src/utils');

/*
 TraceKit - Cross brower stack traces

 This was originally forked from github.com/occ/TraceKit, but has since been
 largely re-written and is now maintained as part of raven-js.  Tests for
 this are in test/vendor.

 MIT license
*/

var TraceKit = {
  collectWindowErrors: true,
  debug: false
};

// This is to be defensive in environments where window does not exist (see https://github.com/getsentry/raven-js/pull/785)
var _window = typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

// global reference to slice
var _slice = [].slice;
var UNKNOWN_FUNCTION = '?';

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error#Error_types
var ERROR_TYPES_RE = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/;

function getLocationHref() {
  if (typeof document === 'undefined' || document.location == null) return '';
  return document.location.href;
}

function getLocationOrigin() {
  if (typeof document === 'undefined' || document.location == null) return '';

  // Oh dear IE10...
  if (!document.location.origin) {
    return document.location.protocol + '//' + document.location.hostname + (document.location.port ? ':' + document.location.port : '');
  }

  return document.location.origin;
}

/**
 * TraceKit.report: cross-browser processing of unhandled exceptions
 *
 * Syntax:
 *   TraceKit.report.subscribe(function(stackInfo) { ... })
 *   TraceKit.report.unsubscribe(function(stackInfo) { ... })
 *   TraceKit.report(exception)
 *   try { ...code... } catch(ex) { TraceKit.report(ex); }
 *
 * Supports:
 *   - Firefox: full stack trace with line numbers, plus column number
 *              on top frame; column number is not guaranteed
 *   - Opera:   full stack trace with line and column numbers
 *   - Chrome:  full stack trace with line and column numbers
 *   - Safari:  line and column number for the top frame only; some frames
 *              may be missing, and column number is not guaranteed
 *   - IE:      line and column number for the top frame only; some frames
 *              may be missing, and column number is not guaranteed
 *
 * In theory, TraceKit should work on all of the following versions:
 *   - IE5.5+ (only 8.0 tested)
 *   - Firefox 0.9+ (only 3.5+ tested)
 *   - Opera 7+ (only 10.50 tested; versions 9 and earlier may require
 *     Exceptions Have Stacktrace to be enabled in opera:config)
 *   - Safari 3+ (only 4+ tested)
 *   - Chrome 1+ (only 5+ tested)
 *   - Konqueror 3.5+ (untested)
 *
 * Requires TraceKit.computeStackTrace.
 *
 * Tries to catch all unhandled exceptions and report them to the
 * subscribed handlers. Please note that TraceKit.report will rethrow the
 * exception. This is REQUIRED in order to get a useful stack trace in IE.
 * If the exception does not reach the top of the browser, you will only
 * get a stack trace from the point where TraceKit.report was called.
 *
 * Handlers receive a stackInfo object as described in the
 * TraceKit.computeStackTrace docs.
 */
TraceKit.report = function reportModuleWrapper() {
  var handlers = [],
      lastArgs = null,
      lastException = null,
      lastExceptionStack = null;

  /**
   * Add a crash handler.
   * @param {Function} handler
   */
  function subscribe(handler) {
    installGlobalHandler();
    handlers.push(handler);
  }

  /**
   * Remove a crash handler.
   * @param {Function} handler
   */
  function unsubscribe(handler) {
    for (var i = handlers.length - 1; i >= 0; --i) {
      if (handlers[i] === handler) {
        handlers.splice(i, 1);
      }
    }
  }

  /**
   * Remove all crash handlers.
   */
  function unsubscribeAll() {
    uninstallGlobalHandler();
    handlers = [];
  }

  /**
   * Dispatch stack information to all handlers.
   * @param {Object.<string, *>} stack
   */
  function notifyHandlers(stack, isWindowError) {
    var exception = null;
    if (isWindowError && !TraceKit.collectWindowErrors) {
      return;
    }
    for (var i in handlers) {
      if (handlers.hasOwnProperty(i)) {
        try {
          handlers[i].apply(null, [stack].concat(_slice.call(arguments, 2)));
        } catch (inner) {
          exception = inner;
        }
      }
    }

    if (exception) {
      throw exception;
    }
  }

  var _oldOnerrorHandler, _onErrorHandlerInstalled;

  /**
   * Ensures all global unhandled exceptions are recorded.
   * Supported by Gecko and IE.
   * @param {string} msg Error message.
   * @param {string} url URL of script that generated the exception.
   * @param {(number|string)} lineNo The line number at which the error
   * occurred.
   * @param {?(number|string)} colNo The column number at which the error
   * occurred.
   * @param {?Error} ex The actual Error object.
   */
  function traceKitWindowOnError(msg, url, lineNo, colNo, ex) {
    var stack = null;
    // If 'ex' is ErrorEvent, get real Error from inside
    var exception = utils.isErrorEvent(ex) ? ex.error : ex;
    // If 'msg' is ErrorEvent, get real message from inside
    var message = utils.isErrorEvent(msg) ? msg.message : msg;

    if (lastExceptionStack) {
      TraceKit.computeStackTrace.augmentStackTraceWithInitialElement(lastExceptionStack, url, lineNo, message);
      processLastException();
    } else if (exception && utils.isError(exception)) {
      // non-string `exception` arg; attempt to extract stack trace

      // New chrome and blink send along a real error object
      // Let's just report that like a normal error.
      // See: https://mikewest.org/2013/08/debugging-runtime-errors-with-window-onerror
      stack = TraceKit.computeStackTrace(exception);
      notifyHandlers(stack, true);
    } else {
      var location = {
        url: url,
        line: lineNo,
        column: colNo
      };

      var name = undefined;
      var groups;

      if ({}.toString.call(message) === '[object String]') {
        var groups = message.match(ERROR_TYPES_RE);
        if (groups) {
          name = groups[1];
          message = groups[2];
        }
      }

      location.func = UNKNOWN_FUNCTION;

      stack = {
        name: name,
        message: message,
        url: getLocationHref(),
        stack: [location]
      };
      notifyHandlers(stack, true);
    }

    if (_oldOnerrorHandler) {
      return _oldOnerrorHandler.apply(this, arguments);
    }

    return false;
  }

  function installGlobalHandler() {
    if (_onErrorHandlerInstalled) {
      return;
    }
    _oldOnerrorHandler = _window.onerror;
    _window.onerror = traceKitWindowOnError;
    _onErrorHandlerInstalled = true;
  }

  function uninstallGlobalHandler() {
    if (!_onErrorHandlerInstalled) {
      return;
    }
    _window.onerror = _oldOnerrorHandler;
    _onErrorHandlerInstalled = false;
    _oldOnerrorHandler = undefined;
  }

  function processLastException() {
    var _lastExceptionStack = lastExceptionStack,
        _lastArgs = lastArgs;
    lastArgs = null;
    lastExceptionStack = null;
    lastException = null;
    notifyHandlers.apply(null, [_lastExceptionStack, false].concat(_lastArgs));
  }

  /**
   * Reports an unhandled Error to TraceKit.
   * @param {Error} ex
   * @param {?boolean} rethrow If false, do not re-throw the exception.
   * Only used for window.onerror to not cause an infinite loop of
   * rethrowing.
   */
  function report(ex, rethrow) {
    var args = _slice.call(arguments, 1);
    if (lastExceptionStack) {
      if (lastException === ex) {
        return; // already caught by an inner catch block, ignore
      } else {
        processLastException();
      }
    }

    var stack = TraceKit.computeStackTrace(ex);
    lastExceptionStack = stack;
    lastException = ex;
    lastArgs = args;

    // If the stack trace is incomplete, wait for 2 seconds for
    // slow slow IE to see if onerror occurs or not before reporting
    // this exception; otherwise, we will end up with an incomplete
    // stack trace
    setTimeout(function () {
      if (lastException === ex) {
        processLastException();
      }
    }, stack.incomplete ? 2000 : 0);

    if (rethrow !== false) {
      throw ex; // re-throw to propagate to the top level (and cause window.onerror)
    }
  }

  report.subscribe = subscribe;
  report.unsubscribe = unsubscribe;
  report.uninstall = unsubscribeAll;
  return report;
}();

/**
 * TraceKit.computeStackTrace: cross-browser stack traces in JavaScript
 *
 * Syntax:
 *   s = TraceKit.computeStackTrace(exception) // consider using TraceKit.report instead (see below)
 * Returns:
 *   s.name              - exception name
 *   s.message           - exception message
 *   s.stack[i].url      - JavaScript or HTML file URL
 *   s.stack[i].func     - function name, or empty for anonymous functions (if guessing did not work)
 *   s.stack[i].args     - arguments passed to the function, if known
 *   s.stack[i].line     - line number, if known
 *   s.stack[i].column   - column number, if known
 *
 * Supports:
 *   - Firefox:  full stack trace with line numbers and unreliable column
 *               number on top frame
 *   - Opera 10: full stack trace with line and column numbers
 *   - Opera 9-: full stack trace with line numbers
 *   - Chrome:   full stack trace with line and column numbers
 *   - Safari:   line and column number for the topmost stacktrace element
 *               only
 *   - IE:       no line numbers whatsoever
 *
 * Tries to guess names of anonymous functions by looking for assignments
 * in the source code. In IE and Safari, we have to guess source file names
 * by searching for function bodies inside all page scripts. This will not
 * work for scripts that are loaded cross-domain.
 * Here be dragons: some function names may be guessed incorrectly, and
 * duplicate functions may be mismatched.
 *
 * TraceKit.computeStackTrace should only be used for tracing purposes.
 * Logging of unhandled exceptions should be done with TraceKit.report,
 * which builds on top of TraceKit.computeStackTrace and provides better
 * IE support by utilizing the window.onerror event to retrieve information
 * about the top of the stack.
 *
 * Note: In IE and Safari, no stack trace is recorded on the Error object,
 * so computeStackTrace instead walks its *own* chain of callers.
 * This means that:
 *  * in Safari, some methods may be missing from the stack trace;
 *  * in IE, the topmost function in the stack trace will always be the
 *    caller of computeStackTrace.
 *
 * This is okay for tracing (because you are likely to be calling
 * computeStackTrace from the function you want to be the topmost element
 * of the stack trace anyway), but not okay for logging unhandled
 * exceptions (because your catch block will likely be far away from the
 * inner function that actually caused the exception).
 *
 */
TraceKit.computeStackTrace = function computeStackTraceWrapper() {
  // Contents of Exception in various browsers.
  //
  // SAFARI:
  // ex.message = Can't find variable: qq
  // ex.line = 59
  // ex.sourceId = 580238192
  // ex.sourceURL = http://...
  // ex.expressionBeginOffset = 96
  // ex.expressionCaretOffset = 98
  // ex.expressionEndOffset = 98
  // ex.name = ReferenceError
  //
  // FIREFOX:
  // ex.message = qq is not defined
  // ex.fileName = http://...
  // ex.lineNumber = 59
  // ex.columnNumber = 69
  // ex.stack = ...stack trace... (see the example below)
  // ex.name = ReferenceError
  //
  // CHROME:
  // ex.message = qq is not defined
  // ex.name = ReferenceError
  // ex.type = not_defined
  // ex.arguments = ['aa']
  // ex.stack = ...stack trace...
  //
  // INTERNET EXPLORER:
  // ex.message = ...
  // ex.name = ReferenceError
  //
  // OPERA:
  // ex.message = ...message... (see the example below)
  // ex.name = ReferenceError
  // ex.opera#sourceloc = 11  (pretty much useless, duplicates the info in ex.message)
  // ex.stacktrace = n/a; see 'opera:config#UserPrefs|Exceptions Have Stacktrace'

  /**
   * Computes stack trace information from the stack property.
   * Chrome and Gecko use this property.
   * @param {Error} ex
   * @return {?Object.<string, *>} Stack trace information.
   */
  function computeStackTraceFromStackProp(ex) {
    if (typeof ex.stack === 'undefined' || !ex.stack) return;

    var chrome = /^\s*at (?:(.*?) ?\()?((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|[a-z]:|\/).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i;
    var winjs = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx(?:-web)|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i;
    // NOTE: blob urls are now supposed to always have an origin, therefore it's format
    // which is `blob:http://url/path/with-some-uuid`, is matched by `blob.*?:\/` as well
    var gecko = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|moz-extension).*?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js))(?::(\d+))?(?::(\d+))?\s*$/i;
    // Used to additionally parse URL/line/column from eval frames
    var geckoEval = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;
    var chromeEval = /\((\S*)(?::(\d+))(?::(\d+))\)/;
    var lines = ex.stack.split('\n');
    var stack = [];
    var submatch;
    var parts;
    var element;
    var reference = /^(.*) is undefined$/.exec(ex.message);

    for (var i = 0, j = lines.length; i < j; ++i) {
      if (parts = chrome.exec(lines[i])) {
        var isNative = parts[2] && parts[2].indexOf('native') === 0; // start of line
        var isEval = parts[2] && parts[2].indexOf('eval') === 0; // start of line
        if (isEval && (submatch = chromeEval.exec(parts[2]))) {
          // throw out eval line/column and use top-most line/column number
          parts[2] = submatch[1]; // url
          parts[3] = submatch[2]; // line
          parts[4] = submatch[3]; // column
        }
        element = {
          url: !isNative ? parts[2] : null,
          func: parts[1] || UNKNOWN_FUNCTION,
          args: isNative ? [parts[2]] : [],
          line: parts[3] ? +parts[3] : null,
          column: parts[4] ? +parts[4] : null
        };
      } else if (parts = winjs.exec(lines[i])) {
        element = {
          url: parts[2],
          func: parts[1] || UNKNOWN_FUNCTION,
          args: [],
          line: +parts[3],
          column: parts[4] ? +parts[4] : null
        };
      } else if (parts = gecko.exec(lines[i])) {
        var isEval = parts[3] && parts[3].indexOf(' > eval') > -1;
        if (isEval && (submatch = geckoEval.exec(parts[3]))) {
          // throw out eval line/column and use top-most line number
          parts[3] = submatch[1];
          parts[4] = submatch[2];
          parts[5] = null; // no column when eval
        } else if (i === 0 && !parts[5] && typeof ex.columnNumber !== 'undefined') {
          // FireFox uses this awesome columnNumber property for its top frame
          // Also note, Firefox's column number is 0-based and everything else expects 1-based,
          // so adding 1
          // NOTE: this hack doesn't work if top-most frame is eval
          stack[0].column = ex.columnNumber + 1;
        }
        element = {
          url: parts[3],
          func: parts[1] || UNKNOWN_FUNCTION,
          args: parts[2] ? parts[2].split(',') : [],
          line: parts[4] ? +parts[4] : null,
          column: parts[5] ? +parts[5] : null
        };
      } else {
        continue;
      }

      if (!element.func && element.line) {
        element.func = UNKNOWN_FUNCTION;
      }

      if (element.url && element.url.substr(0, 5) === 'blob:') {
        // Special case for handling JavaScript loaded into a blob.
        // We use a synchronous AJAX request here as a blob is already in
        // memory - it's not making a network request.  This will generate a warning
        // in the browser console, but there has already been an error so that's not
        // that much of an issue.
        var xhr = new XMLHttpRequest();
        xhr.open('GET', element.url, false);
        xhr.send(null);

        // If we failed to download the source, skip this patch
        if (xhr.status === 200) {
          var source = xhr.responseText || '';

          // We trim the source down to the last 300 characters as sourceMappingURL is always at the end of the file.
          // Why 300? To be in line with: https://github.com/getsentry/sentry/blob/4af29e8f2350e20c28a6933354e4f42437b4ba42/src/sentry/lang/javascript/processor.py#L164-L175
          source = source.slice(-300);

          // Now we dig out the source map URL
          var sourceMaps = source.match(/\/\/# sourceMappingURL=(.*)$/);

          // If we don't find a source map comment or we find more than one, continue on to the next element.
          if (sourceMaps) {
            var sourceMapAddress = sourceMaps[1];

            // Now we check to see if it's a relative URL.
            // If it is, convert it to an absolute one.
            if (sourceMapAddress.charAt(0) === '~') {
              sourceMapAddress = getLocationOrigin() + sourceMapAddress.slice(1);
            }

            // Now we strip the '.map' off of the end of the URL and update the
            // element so that Sentry can match the map to the blob.
            element.url = sourceMapAddress.slice(0, -4);
          }
        }
      }

      stack.push(element);
    }

    if (!stack.length) {
      return null;
    }

    return {
      name: ex.name,
      message: ex.message,
      url: getLocationHref(),
      stack: stack
    };
  }

  /**
   * Adds information about the first frame to incomplete stack traces.
   * Safari and IE require this to get complete data on the first frame.
   * @param {Object.<string, *>} stackInfo Stack trace information from
   * one of the compute* methods.
   * @param {string} url The URL of the script that caused an error.
   * @param {(number|string)} lineNo The line number of the script that
   * caused an error.
   * @param {string=} message The error generated by the browser, which
   * hopefully contains the name of the object that caused the error.
   * @return {boolean} Whether or not the stack information was
   * augmented.
   */
  function augmentStackTraceWithInitialElement(stackInfo, url, lineNo, message) {
    var initial = {
      url: url,
      line: lineNo
    };

    if (initial.url && initial.line) {
      stackInfo.incomplete = false;

      if (!initial.func) {
        initial.func = UNKNOWN_FUNCTION;
      }

      if (stackInfo.stack.length > 0) {
        if (stackInfo.stack[0].url === initial.url) {
          if (stackInfo.stack[0].line === initial.line) {
            return false; // already in stack trace
          } else if (!stackInfo.stack[0].line && stackInfo.stack[0].func === initial.func) {
            stackInfo.stack[0].line = initial.line;
            return false;
          }
        }
      }

      stackInfo.stack.unshift(initial);
      stackInfo.partial = true;
      return true;
    } else {
      stackInfo.incomplete = true;
    }

    return false;
  }

  /**
   * Computes stack trace information by walking the arguments.caller
   * chain at the time the exception occurred. This will cause earlier
   * frames to be missed but is the only way to get any stack trace in
   * Safari and IE. The top frame is restored by
   * {@link augmentStackTraceWithInitialElement}.
   * @param {Error} ex
   * @return {?Object.<string, *>} Stack trace information.
   */
  function computeStackTraceByWalkingCallerChain(ex, depth) {
    var functionName = /function\s+([_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*)?\s*\(/i,
        stack = [],
        funcs = {},
        recursion = false,
        parts,
        item,
        source;

    for (var curr = computeStackTraceByWalkingCallerChain.caller; curr && !recursion; curr = curr.caller) {
      if (curr === computeStackTrace || curr === TraceKit.report) {
        // console.log('skipping internal function');
        continue;
      }

      item = {
        url: null,
        func: UNKNOWN_FUNCTION,
        line: null,
        column: null
      };

      if (curr.name) {
        item.func = curr.name;
      } else if (parts = functionName.exec(curr.toString())) {
        item.func = parts[1];
      }

      if (typeof item.func === 'undefined') {
        try {
          item.func = parts.input.substring(0, parts.input.indexOf('{'));
        } catch (e) {}
      }

      if (funcs['' + curr]) {
        recursion = true;
      } else {
        funcs['' + curr] = true;
      }

      stack.push(item);
    }

    if (depth) {
      // console.log('depth is ' + depth);
      // console.log('stack is ' + stack.length);
      stack.splice(0, depth);
    }

    var result = {
      name: ex.name,
      message: ex.message,
      url: getLocationHref(),
      stack: stack
    };
    augmentStackTraceWithInitialElement(result, ex.sourceURL || ex.fileName, ex.line || ex.lineNumber, ex.message || ex.description);
    return result;
  }

  /**
   * Computes a stack trace for an exception.
   * @param {Error} ex
   * @param {(string|number)=} depth
   */
  function computeStackTrace(ex, depth) {
    var stack = null;
    depth = depth == null ? 0 : +depth;

    try {
      stack = computeStackTraceFromStackProp(ex);
      if (stack) {
        return stack;
      }
    } catch (e) {
      if (TraceKit.debug) {
        throw e;
      }
    }

    try {
      stack = computeStackTraceByWalkingCallerChain(ex, depth + 1);
      if (stack) {
        return stack;
      }
    } catch (e) {
      if (TraceKit.debug) {
        throw e;
      }
    }
    return {
      name: ex.name,
      message: ex.message,
      url: getLocationHref()
    };
  }

  computeStackTrace.augmentStackTraceWithInitialElement = augmentStackTraceWithInitialElement;
  computeStackTrace.computeStackTraceFromStackProp = computeStackTraceFromStackProp;

  return computeStackTrace;
}();

module.exports = TraceKit;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"../../src/utils":11}],13:[function(require,module,exports){
'use strict';

/*
 json-stringify-safe
 Like JSON.stringify, but doesn't throw on circular references.

 Originally forked from https://github.com/isaacs/json-stringify-safe
 version 5.0.1 on 3/8/2017 and modified to handle Errors serialization
 and IE8 compatibility. Tests for this are in test/vendor.

 ISC license: https://github.com/isaacs/json-stringify-safe/blob/master/LICENSE
*/

exports = module.exports = stringify;
exports.getSerialize = serializer;

function indexOf(haystack, needle) {
  for (var i = 0; i < haystack.length; ++i) {
    if (haystack[i] === needle) return i;
  }
  return -1;
}

function stringify(obj, replacer, spaces, cycleReplacer) {
  return JSON.stringify(obj, serializer(replacer, cycleReplacer), spaces);
}

// https://github.com/ftlabs/js-abbreviate/blob/fa709e5f139e7770a71827b1893f22418097fbda/index.js#L95-L106
function stringifyError(value) {
  var err = {
    // These properties are implemented as magical getters and don't show up in for in
    stack: value.stack,
    message: value.message,
    name: value.name
  };

  for (var i in value) {
    if (Object.prototype.hasOwnProperty.call(value, i)) {
      err[i] = value[i];
    }
  }

  return err;
}

function serializer(replacer, cycleReplacer) {
  var stack = [];
  var keys = [];

  if (cycleReplacer == null) {
    cycleReplacer = function cycleReplacer(key, value) {
      if (stack[0] === value) {
        return '[Circular ~]';
      }
      return '[Circular ~.' + keys.slice(0, indexOf(stack, value)).join('.') + ']';
    };
  }

  return function (key, value) {
    if (stack.length > 0) {
      var thisPos = indexOf(stack, this);
      ~thisPos ? stack.splice(thisPos + 1) : stack.push(this);
      ~thisPos ? keys.splice(thisPos, Infinity, key) : keys.push(key);

      if (~indexOf(stack, value)) {
        value = cycleReplacer.call(this, key, value);
      }
    } else {
      stack.push(value);
    }

    return replacer == null ? value instanceof Error ? stringifyError(value) : value : replacer.call(this, key, value);
  };
}

},{}],14:[function(require,module,exports){
'use strict';

/*
 * JavaScript MD5
 * https://github.com/blueimp/JavaScript-MD5
 *
 * Copyright 2011, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * https://opensource.org/licenses/MIT
 *
 * Based on
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 * Version 2.2 Copyright (C) Paul Johnston 1999 - 2009
 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
 * Distributed under the BSD License
 * See http://pajhome.org.uk/crypt/md5 for more info.
 */

/*
* Add integers, wrapping at 2^32. This uses 16-bit operations internally
* to work around bugs in some JS interpreters.
*/
function safeAdd(x, y) {
  var lsw = (x & 0xffff) + (y & 0xffff);
  var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
  return msw << 16 | lsw & 0xffff;
}

/*
* Bitwise rotate a 32-bit number to the left.
*/
function bitRotateLeft(num, cnt) {
  return num << cnt | num >>> 32 - cnt;
}

/*
* These functions implement the four basic operations the algorithm uses.
*/
function md5cmn(q, a, b, x, s, t) {
  return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
}
function md5ff(a, b, c, d, x, s, t) {
  return md5cmn(b & c | ~b & d, a, b, x, s, t);
}
function md5gg(a, b, c, d, x, s, t) {
  return md5cmn(b & d | c & ~d, a, b, x, s, t);
}
function md5hh(a, b, c, d, x, s, t) {
  return md5cmn(b ^ c ^ d, a, b, x, s, t);
}
function md5ii(a, b, c, d, x, s, t) {
  return md5cmn(c ^ (b | ~d), a, b, x, s, t);
}

/*
* Calculate the MD5 of an array of little-endian words, and a bit length.
*/
function binlMD5(x, len) {
  /* append padding */
  x[len >> 5] |= 0x80 << len % 32;
  x[(len + 64 >>> 9 << 4) + 14] = len;

  var i;
  var olda;
  var oldb;
  var oldc;
  var oldd;
  var a = 1732584193;
  var b = -271733879;
  var c = -1732584194;
  var d = 271733878;

  for (i = 0; i < x.length; i += 16) {
    olda = a;
    oldb = b;
    oldc = c;
    oldd = d;

    a = md5ff(a, b, c, d, x[i], 7, -680876936);
    d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
    c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
    b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
    a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
    d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
    c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
    b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
    a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
    d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
    c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
    b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
    a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
    d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
    c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
    b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);

    a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
    d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
    c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
    b = md5gg(b, c, d, a, x[i], 20, -373897302);
    a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
    d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
    c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
    b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
    a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
    d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
    c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
    b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
    a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
    d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
    c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
    b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);

    a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
    d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
    c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
    b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
    a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
    d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
    c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
    b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
    a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
    d = md5hh(d, a, b, c, x[i], 11, -358537222);
    c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
    b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
    a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
    d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
    c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
    b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);

    a = md5ii(a, b, c, d, x[i], 6, -198630844);
    d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
    c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
    b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
    a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
    d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
    c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
    b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
    a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
    d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
    c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
    b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
    a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
    d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
    c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
    b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);

    a = safeAdd(a, olda);
    b = safeAdd(b, oldb);
    c = safeAdd(c, oldc);
    d = safeAdd(d, oldd);
  }
  return [a, b, c, d];
}

/*
* Convert an array of little-endian words to a string
*/
function binl2rstr(input) {
  var i;
  var output = '';
  var length32 = input.length * 32;
  for (i = 0; i < length32; i += 8) {
    output += String.fromCharCode(input[i >> 5] >>> i % 32 & 0xff);
  }
  return output;
}

/*
* Convert a raw string to an array of little-endian words
* Characters >255 have their high-byte silently ignored.
*/
function rstr2binl(input) {
  var i;
  var output = [];
  output[(input.length >> 2) - 1] = undefined;
  for (i = 0; i < output.length; i += 1) {
    output[i] = 0;
  }
  var length8 = input.length * 8;
  for (i = 0; i < length8; i += 8) {
    output[i >> 5] |= (input.charCodeAt(i / 8) & 0xff) << i % 32;
  }
  return output;
}

/*
* Calculate the MD5 of a raw string
*/
function rstrMD5(s) {
  return binl2rstr(binlMD5(rstr2binl(s), s.length * 8));
}

/*
* Calculate the HMAC-MD5, of a key and some data (raw strings)
*/
function rstrHMACMD5(key, data) {
  var i;
  var bkey = rstr2binl(key);
  var ipad = [];
  var opad = [];
  var hash;
  ipad[15] = opad[15] = undefined;
  if (bkey.length > 16) {
    bkey = binlMD5(bkey, key.length * 8);
  }
  for (i = 0; i < 16; i += 1) {
    ipad[i] = bkey[i] ^ 0x36363636;
    opad[i] = bkey[i] ^ 0x5c5c5c5c;
  }
  hash = binlMD5(ipad.concat(rstr2binl(data)), 512 + data.length * 8);
  return binl2rstr(binlMD5(opad.concat(hash), 512 + 128));
}

/*
* Convert a raw string to a hex string
*/
function rstr2hex(input) {
  var hexTab = '0123456789abcdef';
  var output = '';
  var x;
  var i;
  for (i = 0; i < input.length; i += 1) {
    x = input.charCodeAt(i);
    output += hexTab.charAt(x >>> 4 & 0x0f) + hexTab.charAt(x & 0x0f);
  }
  return output;
}

/*
* Encode a string as utf-8
*/
function str2rstrUTF8(input) {
  return unescape(encodeURIComponent(input));
}

/*
* Take string arguments and return either raw or hex encoded strings
*/
function rawMD5(s) {
  return rstrMD5(str2rstrUTF8(s));
}
function hexMD5(s) {
  return rstr2hex(rawMD5(s));
}
function rawHMACMD5(k, d) {
  return rstrHMACMD5(str2rstrUTF8(k), str2rstrUTF8(d));
}
function hexHMACMD5(k, d) {
  return rstr2hex(rawHMACMD5(k, d));
}

function md5(string, key, raw) {
  if (!key) {
    if (!raw) {
      return hexMD5(string);
    }
    return rawMD5(string);
  }
  if (!raw) {
    return hexHMACMD5(key, string);
  }
  return rawHMACMD5(key, string);
}

module.exports = md5;

},{}],15:[function(require,module,exports){
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var punycode = require('punycode');
var util = require('./util');

exports.parse = urlParse;
exports.resolve = urlResolve;
exports.resolveObject = urlResolveObject;
exports.format = urlFormat;

exports.Url = Url;

function Url() {
  this.protocol = null;
  this.slashes = null;
  this.auth = null;
  this.host = null;
  this.port = null;
  this.hostname = null;
  this.hash = null;
  this.search = null;
  this.query = null;
  this.pathname = null;
  this.path = null;
  this.href = null;
}

// Reference: RFC 3986, RFC 1808, RFC 2396

// define these here so at least they only have to be
// compiled once on the first module load.
var protocolPattern = /^([a-z0-9.+-]+:)/i,
    portPattern = /:[0-9]*$/,


// Special case for a simple path URL
simplePathPattern = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/,


// RFC 2396: characters reserved for delimiting URLs.
// We actually just auto-escape these.
delims = ['<', '>', '"', '`', ' ', '\r', '\n', '\t'],


// RFC 2396: characters not allowed for various reasons.
unwise = ['{', '}', '|', '\\', '^', '`'].concat(delims),


// Allowed by RFCs, but cause of XSS attacks.  Always escape these.
autoEscape = ['\''].concat(unwise),

// Characters that are never ever allowed in a hostname.
// Note that any invalid chars are also handled, but these
// are the ones that are *expected* to be seen, so we fast-path
// them.
nonHostChars = ['%', '/', '?', ';', '#'].concat(autoEscape),
    hostEndingChars = ['/', '?', '#'],
    hostnameMaxLen = 255,
    hostnamePartPattern = /^[+a-z0-9A-Z_-]{0,63}$/,
    hostnamePartStart = /^([+a-z0-9A-Z_-]{0,63})(.*)$/,

// protocols that can allow "unsafe" and "unwise" chars.
unsafeProtocol = {
  'javascript': true,
  'javascript:': true
},

// protocols that never have a hostname.
hostlessProtocol = {
  'javascript': true,
  'javascript:': true
},

// protocols that always contain a // bit.
slashedProtocol = {
  'http': true,
  'https': true,
  'ftp': true,
  'gopher': true,
  'file': true,
  'http:': true,
  'https:': true,
  'ftp:': true,
  'gopher:': true,
  'file:': true
},
    querystring = require('querystring');

function urlParse(url, parseQueryString, slashesDenoteHost) {
  if (url && util.isObject(url) && url instanceof Url) return url;

  var u = new Url();
  u.parse(url, parseQueryString, slashesDenoteHost);
  return u;
}

Url.prototype.parse = function (url, parseQueryString, slashesDenoteHost) {
  if (!util.isString(url)) {
    throw new TypeError("Parameter 'url' must be a string, not " + (typeof url === 'undefined' ? 'undefined' : _typeof(url)));
  }

  // Copy chrome, IE, opera backslash-handling behavior.
  // Back slashes before the query string get converted to forward slashes
  // See: https://code.google.com/p/chromium/issues/detail?id=25916
  var queryIndex = url.indexOf('?'),
      splitter = queryIndex !== -1 && queryIndex < url.indexOf('#') ? '?' : '#',
      uSplit = url.split(splitter),
      slashRegex = /\\/g;
  uSplit[0] = uSplit[0].replace(slashRegex, '/');
  url = uSplit.join(splitter);

  var rest = url;

  // trim before proceeding.
  // This is to support parse stuff like "  http://foo.com  \n"
  rest = rest.trim();

  if (!slashesDenoteHost && url.split('#').length === 1) {
    // Try fast path regexp
    var simplePath = simplePathPattern.exec(rest);
    if (simplePath) {
      this.path = rest;
      this.href = rest;
      this.pathname = simplePath[1];
      if (simplePath[2]) {
        this.search = simplePath[2];
        if (parseQueryString) {
          this.query = querystring.parse(this.search.substr(1));
        } else {
          this.query = this.search.substr(1);
        }
      } else if (parseQueryString) {
        this.search = '';
        this.query = {};
      }
      return this;
    }
  }

  var proto = protocolPattern.exec(rest);
  if (proto) {
    proto = proto[0];
    var lowerProto = proto.toLowerCase();
    this.protocol = lowerProto;
    rest = rest.substr(proto.length);
  }

  // figure out if it's got a host
  // user@server is *always* interpreted as a hostname, and url
  // resolution will treat //foo/bar as host=foo,path=bar because that's
  // how the browser resolves relative URLs.
  if (slashesDenoteHost || proto || rest.match(/^\/\/[^@\/]+@[^@\/]+/)) {
    var slashes = rest.substr(0, 2) === '//';
    if (slashes && !(proto && hostlessProtocol[proto])) {
      rest = rest.substr(2);
      this.slashes = true;
    }
  }

  if (!hostlessProtocol[proto] && (slashes || proto && !slashedProtocol[proto])) {

    // there's a hostname.
    // the first instance of /, ?, ;, or # ends the host.
    //
    // If there is an @ in the hostname, then non-host chars *are* allowed
    // to the left of the last @ sign, unless some host-ending character
    // comes *before* the @-sign.
    // URLs are obnoxious.
    //
    // ex:
    // http://a@b@c/ => user:a@b host:c
    // http://a@b?@c => user:a host:c path:/?@c

    // v0.12 TODO(isaacs): This is not quite how Chrome does things.
    // Review our test case against browsers more comprehensively.

    // find the first instance of any hostEndingChars
    var hostEnd = -1;
    for (var i = 0; i < hostEndingChars.length; i++) {
      var hec = rest.indexOf(hostEndingChars[i]);
      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd)) hostEnd = hec;
    }

    // at this point, either we have an explicit point where the
    // auth portion cannot go past, or the last @ char is the decider.
    var auth, atSign;
    if (hostEnd === -1) {
      // atSign can be anywhere.
      atSign = rest.lastIndexOf('@');
    } else {
      // atSign must be in auth portion.
      // http://a@b/c@d => host:b auth:a path:/c@d
      atSign = rest.lastIndexOf('@', hostEnd);
    }

    // Now we have a portion which is definitely the auth.
    // Pull that off.
    if (atSign !== -1) {
      auth = rest.slice(0, atSign);
      rest = rest.slice(atSign + 1);
      this.auth = decodeURIComponent(auth);
    }

    // the host is the remaining to the left of the first non-host char
    hostEnd = -1;
    for (var i = 0; i < nonHostChars.length; i++) {
      var hec = rest.indexOf(nonHostChars[i]);
      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd)) hostEnd = hec;
    }
    // if we still have not hit it, then the entire thing is a host.
    if (hostEnd === -1) hostEnd = rest.length;

    this.host = rest.slice(0, hostEnd);
    rest = rest.slice(hostEnd);

    // pull out port.
    this.parseHost();

    // we've indicated that there is a hostname,
    // so even if it's empty, it has to be present.
    this.hostname = this.hostname || '';

    // if hostname begins with [ and ends with ]
    // assume that it's an IPv6 address.
    var ipv6Hostname = this.hostname[0] === '[' && this.hostname[this.hostname.length - 1] === ']';

    // validate a little.
    if (!ipv6Hostname) {
      var hostparts = this.hostname.split(/\./);
      for (var i = 0, l = hostparts.length; i < l; i++) {
        var part = hostparts[i];
        if (!part) continue;
        if (!part.match(hostnamePartPattern)) {
          var newpart = '';
          for (var j = 0, k = part.length; j < k; j++) {
            if (part.charCodeAt(j) > 127) {
              // we replace non-ASCII char with a temporary placeholder
              // we need this to make sure size of hostname is not
              // broken by replacing non-ASCII by nothing
              newpart += 'x';
            } else {
              newpart += part[j];
            }
          }
          // we test again with ASCII char only
          if (!newpart.match(hostnamePartPattern)) {
            var validParts = hostparts.slice(0, i);
            var notHost = hostparts.slice(i + 1);
            var bit = part.match(hostnamePartStart);
            if (bit) {
              validParts.push(bit[1]);
              notHost.unshift(bit[2]);
            }
            if (notHost.length) {
              rest = '/' + notHost.join('.') + rest;
            }
            this.hostname = validParts.join('.');
            break;
          }
        }
      }
    }

    if (this.hostname.length > hostnameMaxLen) {
      this.hostname = '';
    } else {
      // hostnames are always lower case.
      this.hostname = this.hostname.toLowerCase();
    }

    if (!ipv6Hostname) {
      // IDNA Support: Returns a punycoded representation of "domain".
      // It only converts parts of the domain name that
      // have non-ASCII characters, i.e. it doesn't matter if
      // you call it with a domain that already is ASCII-only.
      this.hostname = punycode.toASCII(this.hostname);
    }

    var p = this.port ? ':' + this.port : '';
    var h = this.hostname || '';
    this.host = h + p;
    this.href += this.host;

    // strip [ and ] from the hostname
    // the host field still retains them, though
    if (ipv6Hostname) {
      this.hostname = this.hostname.substr(1, this.hostname.length - 2);
      if (rest[0] !== '/') {
        rest = '/' + rest;
      }
    }
  }

  // now rest is set to the post-host stuff.
  // chop off any delim chars.
  if (!unsafeProtocol[lowerProto]) {

    // First, make 100% sure that any "autoEscape" chars get
    // escaped, even if encodeURIComponent doesn't think they
    // need to be.
    for (var i = 0, l = autoEscape.length; i < l; i++) {
      var ae = autoEscape[i];
      if (rest.indexOf(ae) === -1) continue;
      var esc = encodeURIComponent(ae);
      if (esc === ae) {
        esc = escape(ae);
      }
      rest = rest.split(ae).join(esc);
    }
  }

  // chop off from the tail first.
  var hash = rest.indexOf('#');
  if (hash !== -1) {
    // got a fragment string.
    this.hash = rest.substr(hash);
    rest = rest.slice(0, hash);
  }
  var qm = rest.indexOf('?');
  if (qm !== -1) {
    this.search = rest.substr(qm);
    this.query = rest.substr(qm + 1);
    if (parseQueryString) {
      this.query = querystring.parse(this.query);
    }
    rest = rest.slice(0, qm);
  } else if (parseQueryString) {
    // no query string, but parseQueryString still requested
    this.search = '';
    this.query = {};
  }
  if (rest) this.pathname = rest;
  if (slashedProtocol[lowerProto] && this.hostname && !this.pathname) {
    this.pathname = '/';
  }

  //to support http.request
  if (this.pathname || this.search) {
    var p = this.pathname || '';
    var s = this.search || '';
    this.path = p + s;
  }

  // finally, reconstruct the href based on what has been validated.
  this.href = this.format();
  return this;
};

// format a parsed object into a url string
function urlFormat(obj) {
  // ensure it's an object, and not a string url.
  // If it's an obj, this is a no-op.
  // this way, you can call url_format() on strings
  // to clean up potentially wonky urls.
  if (util.isString(obj)) obj = urlParse(obj);
  if (!(obj instanceof Url)) return Url.prototype.format.call(obj);
  return obj.format();
}

Url.prototype.format = function () {
  var auth = this.auth || '';
  if (auth) {
    auth = encodeURIComponent(auth);
    auth = auth.replace(/%3A/i, ':');
    auth += '@';
  }

  var protocol = this.protocol || '',
      pathname = this.pathname || '',
      hash = this.hash || '',
      host = false,
      query = '';

  if (this.host) {
    host = auth + this.host;
  } else if (this.hostname) {
    host = auth + (this.hostname.indexOf(':') === -1 ? this.hostname : '[' + this.hostname + ']');
    if (this.port) {
      host += ':' + this.port;
    }
  }

  if (this.query && util.isObject(this.query) && Object.keys(this.query).length) {
    query = querystring.stringify(this.query);
  }

  var search = this.search || query && '?' + query || '';

  if (protocol && protocol.substr(-1) !== ':') protocol += ':';

  // only the slashedProtocols get the //.  Not mailto:, xmpp:, etc.
  // unless they had them to begin with.
  if (this.slashes || (!protocol || slashedProtocol[protocol]) && host !== false) {
    host = '//' + (host || '');
    if (pathname && pathname.charAt(0) !== '/') pathname = '/' + pathname;
  } else if (!host) {
    host = '';
  }

  if (hash && hash.charAt(0) !== '#') hash = '#' + hash;
  if (search && search.charAt(0) !== '?') search = '?' + search;

  pathname = pathname.replace(/[?#]/g, function (match) {
    return encodeURIComponent(match);
  });
  search = search.replace('#', '%23');

  return protocol + host + pathname + search + hash;
};

function urlResolve(source, relative) {
  return urlParse(source, false, true).resolve(relative);
}

Url.prototype.resolve = function (relative) {
  return this.resolveObject(urlParse(relative, false, true)).format();
};

function urlResolveObject(source, relative) {
  if (!source) return relative;
  return urlParse(source, false, true).resolveObject(relative);
}

Url.prototype.resolveObject = function (relative) {
  if (util.isString(relative)) {
    var rel = new Url();
    rel.parse(relative, false, true);
    relative = rel;
  }

  var result = new Url();
  var tkeys = Object.keys(this);
  for (var tk = 0; tk < tkeys.length; tk++) {
    var tkey = tkeys[tk];
    result[tkey] = this[tkey];
  }

  // hash is always overridden, no matter what.
  // even href="" will remove it.
  result.hash = relative.hash;

  // if the relative url is empty, then there's nothing left to do here.
  if (relative.href === '') {
    result.href = result.format();
    return result;
  }

  // hrefs like //foo/bar always cut to the protocol.
  if (relative.slashes && !relative.protocol) {
    // take everything except the protocol from relative
    var rkeys = Object.keys(relative);
    for (var rk = 0; rk < rkeys.length; rk++) {
      var rkey = rkeys[rk];
      if (rkey !== 'protocol') result[rkey] = relative[rkey];
    }

    //urlParse appends trailing / to urls like http://www.example.com
    if (slashedProtocol[result.protocol] && result.hostname && !result.pathname) {
      result.path = result.pathname = '/';
    }

    result.href = result.format();
    return result;
  }

  if (relative.protocol && relative.protocol !== result.protocol) {
    // if it's a known url protocol, then changing
    // the protocol does weird things
    // first, if it's not file:, then we MUST have a host,
    // and if there was a path
    // to begin with, then we MUST have a path.
    // if it is file:, then the host is dropped,
    // because that's known to be hostless.
    // anything else is assumed to be absolute.
    if (!slashedProtocol[relative.protocol]) {
      var keys = Object.keys(relative);
      for (var v = 0; v < keys.length; v++) {
        var k = keys[v];
        result[k] = relative[k];
      }
      result.href = result.format();
      return result;
    }

    result.protocol = relative.protocol;
    if (!relative.host && !hostlessProtocol[relative.protocol]) {
      var relPath = (relative.pathname || '').split('/');
      while (relPath.length && !(relative.host = relPath.shift())) {}
      if (!relative.host) relative.host = '';
      if (!relative.hostname) relative.hostname = '';
      if (relPath[0] !== '') relPath.unshift('');
      if (relPath.length < 2) relPath.unshift('');
      result.pathname = relPath.join('/');
    } else {
      result.pathname = relative.pathname;
    }
    result.search = relative.search;
    result.query = relative.query;
    result.host = relative.host || '';
    result.auth = relative.auth;
    result.hostname = relative.hostname || relative.host;
    result.port = relative.port;
    // to support http.request
    if (result.pathname || result.search) {
      var p = result.pathname || '';
      var s = result.search || '';
      result.path = p + s;
    }
    result.slashes = result.slashes || relative.slashes;
    result.href = result.format();
    return result;
  }

  var isSourceAbs = result.pathname && result.pathname.charAt(0) === '/',
      isRelAbs = relative.host || relative.pathname && relative.pathname.charAt(0) === '/',
      mustEndAbs = isRelAbs || isSourceAbs || result.host && relative.pathname,
      removeAllDots = mustEndAbs,
      srcPath = result.pathname && result.pathname.split('/') || [],
      relPath = relative.pathname && relative.pathname.split('/') || [],
      psychotic = result.protocol && !slashedProtocol[result.protocol];

  // if the url is a non-slashed url, then relative
  // links like ../.. should be able
  // to crawl up to the hostname, as well.  This is strange.
  // result.protocol has already been set by now.
  // Later on, put the first path part into the host field.
  if (psychotic) {
    result.hostname = '';
    result.port = null;
    if (result.host) {
      if (srcPath[0] === '') srcPath[0] = result.host;else srcPath.unshift(result.host);
    }
    result.host = '';
    if (relative.protocol) {
      relative.hostname = null;
      relative.port = null;
      if (relative.host) {
        if (relPath[0] === '') relPath[0] = relative.host;else relPath.unshift(relative.host);
      }
      relative.host = null;
    }
    mustEndAbs = mustEndAbs && (relPath[0] === '' || srcPath[0] === '');
  }

  if (isRelAbs) {
    // it's absolute.
    result.host = relative.host || relative.host === '' ? relative.host : result.host;
    result.hostname = relative.hostname || relative.hostname === '' ? relative.hostname : result.hostname;
    result.search = relative.search;
    result.query = relative.query;
    srcPath = relPath;
    // fall through to the dot-handling below.
  } else if (relPath.length) {
    // it's relative
    // throw away the existing file, and take the new path instead.
    if (!srcPath) srcPath = [];
    srcPath.pop();
    srcPath = srcPath.concat(relPath);
    result.search = relative.search;
    result.query = relative.query;
  } else if (!util.isNullOrUndefined(relative.search)) {
    // just pull out the search.
    // like href='?foo'.
    // Put this after the other two cases because it simplifies the booleans
    if (psychotic) {
      result.hostname = result.host = srcPath.shift();
      //occationaly the auth can get stuck only in host
      //this especially happens in cases like
      //url.resolveObject('mailto:local1@domain1', 'local2@domain2')
      var authInHost = result.host && result.host.indexOf('@') > 0 ? result.host.split('@') : false;
      if (authInHost) {
        result.auth = authInHost.shift();
        result.host = result.hostname = authInHost.shift();
      }
    }
    result.search = relative.search;
    result.query = relative.query;
    //to support http.request
    if (!util.isNull(result.pathname) || !util.isNull(result.search)) {
      result.path = (result.pathname ? result.pathname : '') + (result.search ? result.search : '');
    }
    result.href = result.format();
    return result;
  }

  if (!srcPath.length) {
    // no path at all.  easy.
    // we've already handled the other stuff above.
    result.pathname = null;
    //to support http.request
    if (result.search) {
      result.path = '/' + result.search;
    } else {
      result.path = null;
    }
    result.href = result.format();
    return result;
  }

  // if a url ENDs in . or .., then it must get a trailing slash.
  // however, if it ends in anything else non-slashy,
  // then it must NOT get a trailing slash.
  var last = srcPath.slice(-1)[0];
  var hasTrailingSlash = (result.host || relative.host || srcPath.length > 1) && (last === '.' || last === '..') || last === '';

  // strip single dots, resolve double dots to parent dir
  // if the path tries to go above the root, `up` ends up > 0
  var up = 0;
  for (var i = srcPath.length; i >= 0; i--) {
    last = srcPath[i];
    if (last === '.') {
      srcPath.splice(i, 1);
    } else if (last === '..') {
      srcPath.splice(i, 1);
      up++;
    } else if (up) {
      srcPath.splice(i, 1);
      up--;
    }
  }

  // if the path is allowed to go above the root, restore leading ..s
  if (!mustEndAbs && !removeAllDots) {
    for (; up--; up) {
      srcPath.unshift('..');
    }
  }

  if (mustEndAbs && srcPath[0] !== '' && (!srcPath[0] || srcPath[0].charAt(0) !== '/')) {
    srcPath.unshift('');
  }

  if (hasTrailingSlash && srcPath.join('/').substr(-1) !== '/') {
    srcPath.push('');
  }

  var isAbsolute = srcPath[0] === '' || srcPath[0] && srcPath[0].charAt(0) === '/';

  // put the host back
  if (psychotic) {
    result.hostname = result.host = isAbsolute ? '' : srcPath.length ? srcPath.shift() : '';
    //occationaly the auth can get stuck only in host
    //this especially happens in cases like
    //url.resolveObject('mailto:local1@domain1', 'local2@domain2')
    var authInHost = result.host && result.host.indexOf('@') > 0 ? result.host.split('@') : false;
    if (authInHost) {
      result.auth = authInHost.shift();
      result.host = result.hostname = authInHost.shift();
    }
  }

  mustEndAbs = mustEndAbs || result.host && srcPath.length;

  if (mustEndAbs && !isAbsolute) {
    srcPath.unshift('');
  }

  if (!srcPath.length) {
    result.pathname = null;
    result.path = null;
  } else {
    result.pathname = srcPath.join('/');
  }

  //to support request.http
  if (!util.isNull(result.pathname) || !util.isNull(result.search)) {
    result.path = (result.pathname ? result.pathname : '') + (result.search ? result.search : '');
  }
  result.auth = relative.auth || result.auth;
  result.slashes = result.slashes || relative.slashes;
  result.href = result.format();
  return result;
};

Url.prototype.parseHost = function () {
  var host = this.host;
  var port = portPattern.exec(host);
  if (port) {
    port = port[0];
    if (port !== ':') {
      this.port = port.substr(1);
    }
    host = host.substr(0, host.length - port.length);
  }
  if (host) this.hostname = host;
};

},{"./util":16,"punycode":3,"querystring":6}],16:[function(require,module,exports){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports = {
  isString: function isString(arg) {
    return typeof arg === 'string';
  },
  isObject: function isObject(arg) {
    return (typeof arg === 'undefined' ? 'undefined' : _typeof(arg)) === 'object' && arg !== null;
  },
  isNull: function isNull(arg) {
    return arg === null;
  },
  isNullOrUndefined: function isNullOrUndefined(arg) {
    return arg == null;
  }
};

},{}],17:[function(require,module,exports){
'use strict';

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */
var byteToHex = [];
for (var i = 0; i < 256; ++i) {
  byteToHex[i] = (i + 0x100).toString(16).substr(1);
}

function bytesToUuid(buf, offset) {
  var i = offset || 0;
  var bth = byteToHex;
  // join used to fix memory issue caused by concatenation: https://bugs.chromium.org/p/v8/issues/detail?id=3175#c4
  return [bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]]].join('');
}

module.exports = bytesToUuid;

},{}],18:[function(require,module,exports){
'use strict';

// Unique ID creation requires a high quality random # generator.  In the
// browser this is a little complicated due to unknown quality of Math.random()
// and inconsistent support for the `crypto` API.  We do the best we can via
// feature-detection

// getRandomValues needs to be invoked in a context where "this" is a Crypto
// implementation. Also, find the complete implementation of crypto on IE11.
var getRandomValues = typeof crypto != 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto != 'undefined' && typeof window.msCrypto.getRandomValues == 'function' && msCrypto.getRandomValues.bind(msCrypto);

if (getRandomValues) {
  // WHATWG crypto RNG - http://wiki.whatwg.org/wiki/Crypto
  var rnds8 = new Uint8Array(16); // eslint-disable-line no-undef

  module.exports = function whatwgRNG() {
    getRandomValues(rnds8);
    return rnds8;
  };
} else {
  // Math.random()-based (RNG)
  //
  // If all else fails, use Math.random().  It's fast, but is of unspecified
  // quality.
  var rnds = new Array(16);

  module.exports = function mathRNG() {
    for (var i = 0, r; i < 16; i++) {
      if ((i & 0x03) === 0) r = Math.random() * 0x100000000;
      rnds[i] = r >>> ((i & 0x03) << 3) & 0xff;
    }

    return rnds;
  };
}

},{}],19:[function(require,module,exports){
// Adapted from Chris Veness' SHA1 code at
// http://www.movable-type.co.uk/scripts/sha1.html
'use strict';

function f(s, x, y, z) {
  switch (s) {
    case 0:
      return x & y ^ ~x & z;
    case 1:
      return x ^ y ^ z;
    case 2:
      return x & y ^ x & z ^ y & z;
    case 3:
      return x ^ y ^ z;
  }
}

function ROTL(x, n) {
  return x << n | x >>> 32 - n;
}

function sha1(bytes) {
  var K = [0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xca62c1d6];
  var H = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0];

  if (typeof bytes == 'string') {
    var msg = unescape(encodeURIComponent(bytes)); // UTF8 escape
    bytes = new Array(msg.length);
    for (var i = 0; i < msg.length; i++) {
      bytes[i] = msg.charCodeAt(i);
    }
  }

  bytes.push(0x80);

  var l = bytes.length / 4 + 2;
  var N = Math.ceil(l / 16);
  var M = new Array(N);

  for (var i = 0; i < N; i++) {
    M[i] = new Array(16);
    for (var j = 0; j < 16; j++) {
      M[i][j] = bytes[i * 64 + j * 4] << 24 | bytes[i * 64 + j * 4 + 1] << 16 | bytes[i * 64 + j * 4 + 2] << 8 | bytes[i * 64 + j * 4 + 3];
    }
  }

  M[N - 1][14] = (bytes.length - 1) * 8 / Math.pow(2, 32);M[N - 1][14] = Math.floor(M[N - 1][14]);
  M[N - 1][15] = (bytes.length - 1) * 8 & 0xffffffff;

  for (var i = 0; i < N; i++) {
    var W = new Array(80);

    for (var t = 0; t < 16; t++) {
      W[t] = M[i][t];
    }for (var t = 16; t < 80; t++) {
      W[t] = ROTL(W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16], 1);
    }

    var a = H[0];
    var b = H[1];
    var c = H[2];
    var d = H[3];
    var e = H[4];

    for (var t = 0; t < 80; t++) {
      var s = Math.floor(t / 20);
      var T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[t] >>> 0;
      e = d;
      d = c;
      c = ROTL(b, 30) >>> 0;
      b = a;
      a = T;
    }

    H[0] = H[0] + a >>> 0;
    H[1] = H[1] + b >>> 0;
    H[2] = H[2] + c >>> 0;
    H[3] = H[3] + d >>> 0;
    H[4] = H[4] + e >>> 0;
  }

  return [H[0] >> 24 & 0xff, H[0] >> 16 & 0xff, H[0] >> 8 & 0xff, H[0] & 0xff, H[1] >> 24 & 0xff, H[1] >> 16 & 0xff, H[1] >> 8 & 0xff, H[1] & 0xff, H[2] >> 24 & 0xff, H[2] >> 16 & 0xff, H[2] >> 8 & 0xff, H[2] & 0xff, H[3] >> 24 & 0xff, H[3] >> 16 & 0xff, H[3] >> 8 & 0xff, H[3] & 0xff, H[4] >> 24 & 0xff, H[4] >> 16 & 0xff, H[4] >> 8 & 0xff, H[4] & 0xff];
}

module.exports = sha1;

},{}],20:[function(require,module,exports){
'use strict';

var bytesToUuid = require('./bytesToUuid');

function uuidToBytes(uuid) {
  // Note: We assume we're being passed a valid uuid string
  var bytes = [];
  uuid.replace(/[a-fA-F0-9]{2}/g, function (hex) {
    bytes.push(parseInt(hex, 16));
  });

  return bytes;
}

function stringToBytes(str) {
  str = unescape(encodeURIComponent(str)); // UTF8 escape
  var bytes = new Array(str.length);
  for (var i = 0; i < str.length; i++) {
    bytes[i] = str.charCodeAt(i);
  }
  return bytes;
}

module.exports = function (name, version, hashfunc) {
  var generateUUID = function generateUUID(value, namespace, buf, offset) {
    var off = buf && offset || 0;

    if (typeof value == 'string') value = stringToBytes(value);
    if (typeof namespace == 'string') namespace = uuidToBytes(namespace);

    if (!Array.isArray(value)) throw TypeError('value must be an array of bytes');
    if (!Array.isArray(namespace) || namespace.length !== 16) throw TypeError('namespace must be uuid string or an Array of 16 byte values');

    // Per 4.3
    var bytes = hashfunc(namespace.concat(value));
    bytes[6] = bytes[6] & 0x0f | version;
    bytes[8] = bytes[8] & 0x3f | 0x80;

    if (buf) {
      for (var idx = 0; idx < 16; ++idx) {
        buf[off + idx] = bytes[idx];
      }
    }

    return buf || bytesToUuid(bytes);
  };

  // Function#name is not settable on some platforms (#270)
  try {
    generateUUID.name = name;
  } catch (err) {}

  // Pre-defined namespaces, per Appendix C
  generateUUID.DNS = '6ba7b810-9dad-11d1-80b4-00c04fd430c8';
  generateUUID.URL = '6ba7b811-9dad-11d1-80b4-00c04fd430c8';

  return generateUUID;
};

},{"./bytesToUuid":17}],21:[function(require,module,exports){
'use strict';

var rng = require('./lib/rng');
var bytesToUuid = require('./lib/bytesToUuid');

function v4(options, buf, offset) {
  var i = buf && offset || 0;

  if (typeof options == 'string') {
    buf = options === 'binary' ? new Array(16) : null;
    options = null;
  }
  options = options || {};

  var rnds = options.random || (options.rng || rng)();

  // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`
  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80;

  // Copy bytes to buffer, if provided
  if (buf) {
    for (var ii = 0; ii < 16; ++ii) {
      buf[i + ii] = rnds[ii];
    }
  }

  return buf || bytesToUuid(rnds);
}

module.exports = v4;

},{"./lib/bytesToUuid":17,"./lib/rng":18}],22:[function(require,module,exports){
'use strict';

var v35 = require('./lib/v35.js');
var sha1 = require('./lib/sha1');
module.exports = v35('v5', 0x50, sha1);

},{"./lib/sha1":19,"./lib/v35.js":20}],23:[function(require,module,exports){
'use strict';

var v4 = require('uuid/v4'),
    v5 = require('uuid/v5');

var uuidv4 = function uuidv4() {
  return v4();
};

uuidv4.regex = {
  v4: /^([a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[a-f0-9]{4}-[a-f0-9]{12})|(0{8}-0{4}-0{4}-0{4}-0{12})$/,
  v5: /^([a-f0-9]{8}-[a-f0-9]{4}-5[a-f0-9]{3}-[a-f0-9]{4}-[a-f0-9]{12})|(0{8}-0{4}-0{4}-0{4}-0{12})$/
};

uuidv4.is = function (value) {
  if (!value) {
    return false;
  }

  return uuidv4.regex.v4.test(value) || uuidv4.regex.v5.test(value);
};

uuidv4.empty = function () {
  return '00000000-0000-0000-0000-000000000000';
};

uuidv4.fromString = function (text) {
  if (!text) {
    throw new Error('Text is missing.');
  }

  var namespace = 'bb5d0ffa-9a4c-4d7c-8fc2-0a7d2220ba45';

  var uuidFromString = v5(text, namespace);

  return uuidFromString;
};

module.exports = uuidv4;

},{"uuid/v4":21,"uuid/v5":22}],24:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

var __read = undefined && undefined.__read || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o),
        r,
        ar = [],
        e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) {
            ar.push(r.value);
        }
    } catch (error) {
        e = { error: error };
    } finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        } finally {
            if (e) throw e.error;
        }
    }
    return ar;
};
var __spread = undefined && undefined.__spread || function () {
    for (var ar = [], i = 0; i < arguments.length; i++) {
        ar = ar.concat(__read(arguments[i]));
    }return ar;
};
var __values = undefined && undefined.__values || function (o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator],
        i = 0;
    if (m) return m.call(o);
    return {
        next: function next() {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
};
Object.defineProperty(exports, "__esModule", { value: true });
var shadowsocks_config_1 = require("ShadowsocksConfig/shadowsocks_config");
var errors = require("../model/errors");
var events = require("../model/events");
var settings_1 = require("./settings");
// If s is a URL whose fragment contains a Shadowsocks URL then return that Shadowsocks URL,
// otherwise return s.
function unwrapInvite(s) {
    try {
        var url = new URL(s);
        if (url.hash) {
            var decodedFragment = decodeURIComponent(url.hash);
            // Search in the fragment for ss:// for two reasons:
            //  - URL.hash includes the leading # (what).
            //  - When a user opens invite.html#ENCODEDSSURL in their browser, the website (currently)
            //    redirects to invite.html#/en/invite/ENCODEDSSURL. Since copying that redirected URL
            //    seems like a reasonable thing to do, let's support those URLs too.
            var possibleShadowsocksUrl = decodedFragment.substring(decodedFragment.indexOf('ss://'));
            if (new URL(possibleShadowsocksUrl).protocol === 'ss:') {
                return possibleShadowsocksUrl;
            }
        }
    } catch (e) {
        // Something wasn't a URL, or it couldn't be decoded - no problem, people put all kinds of
        // crazy things in the clipboard.
    }
    return s;
}
exports.unwrapInvite = unwrapInvite;
var App = /** @class */function () {
    function App(eventQueue, serverRepo, rootEl, debugMode, urlInterceptor, clipboard, errorReporter, settings, environmentVars, updater, quitApplication, document) {
        if (document === void 0) {
            document = window.document;
        }
        this.eventQueue = eventQueue;
        this.serverRepo = serverRepo;
        this.rootEl = rootEl;
        this.debugMode = debugMode;
        this.clipboard = clipboard;
        this.errorReporter = errorReporter;
        this.settings = settings;
        this.environmentVars = environmentVars;
        this.updater = updater;
        this.quitApplication = quitApplication;
        this.ignoredAccessKeys = {};
        this.serverListEl = rootEl.$.serversView.$.serverList;
        this.feedbackViewEl = rootEl.$.feedbackView;
        this.syncServersToUI();
        this.syncConnectivityStateToServerCards();
        rootEl.$.aboutView.version = environmentVars.APP_VERSION;
        this.localize = this.rootEl.localize.bind(this.rootEl);
        if (urlInterceptor) {
            this.registerUrlInterceptionListener(urlInterceptor);
        } else {
            console.warn('no urlInterceptor, ss:// urls will not be intercepted');
        }
        this.clipboard.setListener(this.handleClipboardText.bind(this));
        this.updater.setListener(this.updateDownloaded.bind(this));
        // Register Cordova mobile foreground event to sync server connectivity.
        document.addEventListener('resume', this.syncConnectivityStateToServerCards.bind(this));
        // Register handlers for events fired by Polymer components.
        this.rootEl.addEventListener('PromptAddServerRequested', this.requestPromptAddServer.bind(this));
        this.rootEl.addEventListener('AddServerConfirmationRequested', this.requestAddServerConfirmation.bind(this));
        this.rootEl.addEventListener('AddServerRequested', this.requestAddServer.bind(this));
        this.rootEl.addEventListener('IgnoreServerRequested', this.requestIgnoreServer.bind(this));
        this.rootEl.addEventListener('ConnectPressed', this.connectServer.bind(this));
        this.rootEl.addEventListener('DisconnectPressed', this.disconnectServer.bind(this));
        this.rootEl.addEventListener('ForgetPressed', this.forgetServer.bind(this));
        this.rootEl.addEventListener('RenameRequested', this.renameServer.bind(this));
        this.rootEl.addEventListener('QuitPressed', this.quitApplication.bind(this));
        this.rootEl.addEventListener('AutoConnectDialogDismissed', this.autoConnectDialogDismissed.bind(this));
        this.rootEl.addEventListener('ShowServerRename', this.rootEl.showServerRename.bind(this.rootEl));
        this.feedbackViewEl.$.submitButton.addEventListener('tap', this.submitFeedback.bind(this));
        this.rootEl.addEventListener('PrivacyTermsAcked', this.ackPrivacyTerms.bind(this));
        // Register handlers for events published to our event queue.
        this.eventQueue.subscribe(events.ServerAdded, this.showServerAdded.bind(this));
        this.eventQueue.subscribe(events.ServerForgotten, this.showServerForgotten.bind(this));
        this.eventQueue.subscribe(events.ServerRenamed, this.showServerRenamed.bind(this));
        this.eventQueue.subscribe(events.ServerForgetUndone, this.showServerForgetUndone.bind(this));
        this.eventQueue.subscribe(events.ServerConnected, this.showServerConnected.bind(this));
        this.eventQueue.subscribe(events.ServerDisconnected, this.showServerDisconnected.bind(this));
        this.eventQueue.subscribe(events.ServerReconnecting, this.showServerReconnecting.bind(this));
        this.eventQueue.startPublishing();
        if (!this.arePrivacyTermsAcked()) {
            this.displayPrivacyView();
        }
        this.displayZeroStateUi();
        this.pullClipboardText();
    }
    App.prototype.showLocalizedError = function (e, toastDuration) {
        var _this = this;
        if (toastDuration === void 0) {
            toastDuration = 10000;
        }
        var messageKey;
        var messageParams;
        var buttonKey;
        var buttonHandler;
        var buttonLink;
        if (e instanceof errors.VpnPermissionNotGranted) {
            messageKey = 'outline-plugin-error-vpn-permission-not-granted';
        } else if (e instanceof errors.InvalidServerCredentials) {
            messageKey = 'outline-plugin-error-invalid-server-credentials';
        } else if (e instanceof errors.RemoteUdpForwardingDisabled) {
            messageKey = 'outline-plugin-error-udp-forwarding-not-enabled';
        } else if (e instanceof errors.ServerUnreachable) {
            messageKey = 'outline-plugin-error-server-unreachable';
        } else if (e instanceof errors.FeedbackSubmissionError) {
            messageKey = 'error-feedback-submission';
        } else if (e instanceof errors.ServerUrlInvalid) {
            messageKey = 'error-invalid-access-key';
        } else if (e instanceof errors.ServerIncompatible) {
            messageKey = 'error-server-incompatible';
        } else if (e instanceof errors.OperationTimedOut) {
            messageKey = 'error-timeout';
        } else if (e instanceof errors.ShadowsocksStartFailure && this.isWindows()) {
            // Fall through to `error-unexpected` for other platforms.
            messageKey = 'outline-plugin-error-antivirus';
            buttonKey = 'fix-this';
            buttonLink = 'https://s3.amazonaws.com/outline-vpn/index.html#/en/support/antivirusBlock';
        } else if (e instanceof errors.ConfigureSystemProxyFailure) {
            messageKey = 'outline-plugin-error-routing-tables';
            buttonKey = 'feedback-page-title';
            buttonHandler = function buttonHandler() {
                // TODO: Drop-down has no selected item, why not?
                _this.rootEl.changePage('feedback');
            };
        } else if (e instanceof errors.NoAdminPermissions) {
            messageKey = 'outline-plugin-error-admin-permissions';
        } else if (e instanceof errors.UnsupportedRoutingTable) {
            messageKey = 'outline-plugin-error-unsupported-routing-table';
        } else if (e instanceof errors.ServerAlreadyAdded) {
            messageKey = 'error-server-already-added';
            messageParams = ['serverName', e.server.name];
        } else if (e instanceof errors.SystemConfigurationException) {
            messageKey = 'outline-plugin-error-system-configuration';
        } else {
            messageKey = 'error-unexpected';
        }
        var message = messageParams ? this.localize.apply(this, __spread([messageKey], messageParams)) : this.localize(messageKey);
        // Defer by 500ms so that this toast is shown after any toasts that get shown when any
        // currently-in-flight domain events land (e.g. fake servers added).
        if (this.rootEl && this.rootEl.async) {
            this.rootEl.async(function () {
                _this.rootEl.showToast(message, toastDuration, buttonKey ? _this.localize(buttonKey) : undefined, buttonHandler, buttonLink);
            }, 500);
        }
    };
    App.prototype.pullClipboardText = function () {
        var _this = this;
        this.clipboard.getContents().then(function (text) {
            _this.handleClipboardText(text);
        }, function (e) {
            console.warn('cannot read clipboard, system may lack clipboard support');
        });
    };
    App.prototype.showServerConnected = function (event) {
        console.debug("server " + event.server.id + " connected");
        var card = this.serverListEl.getServerCard(event.server.id);
        card.state = 'CONNECTED';
    };
    App.prototype.showServerDisconnected = function (event) {
        console.debug("server " + event.server.id + " disconnected");
        try {
            this.serverListEl.getServerCard(event.server.id).state = 'DISCONNECTED';
        } catch (e) {
            console.warn('server card not found after disconnection event, assuming forgotten');
        }
    };
    App.prototype.showServerReconnecting = function (event) {
        console.debug("server " + event.server.id + " reconnecting");
        var card = this.serverListEl.getServerCard(event.server.id);
        card.state = 'RECONNECTING';
    };
    App.prototype.displayZeroStateUi = function () {
        if (this.rootEl.$.serversView.shouldShowZeroState) {
            this.rootEl.$.addServerView.openAddServerSheet();
        }
    };
    App.prototype.arePrivacyTermsAcked = function () {
        try {
            if (this.environmentVars.BETA_BUILD) {
                return this.settings.get(settings_1.SettingsKey.BETA_ACK) === 'true';
            }
            return this.settings.get(settings_1.SettingsKey.PRIVACY_ACK) === 'true';
        } catch (e) {
            console.error("could not read privacy acknowledgement setting, assuming not acknowledged");
        }
        return false;
    };
    App.prototype.displayPrivacyView = function () {
        this.rootEl.$.serversView.hidden = true;
        this.rootEl.$.privacyView.isBetaRelease = this.environmentVars.BETA_BUILD;
        this.rootEl.$.privacyView.hidden = false;
    };
    App.prototype.ackPrivacyTerms = function () {
        this.rootEl.$.serversView.hidden = false;
        this.rootEl.$.privacyView.hidden = true;
        this.settings.set(this.environmentVars.BETA_BUILD ? settings_1.SettingsKey.BETA_ACK : settings_1.SettingsKey.PRIVACY_ACK, 'true');
    };
    App.prototype.handleClipboardText = function (text) {
        // Shorten, sanitise.
        // Note that we always check the text, even if the contents are same as last time, because we
        // keep an in-memory cache of user-ignored access keys.
        text = text.substring(0, 1000).trim();
        try {
            this.confirmAddServer(text, true);
        } catch (err) {
            // Don't alert the user; high false positive rate.
        }
    };
    App.prototype.updateDownloaded = function () {
        this.rootEl.showToast(this.localize('update-downloaded'), 60000);
    };
    App.prototype.requestPromptAddServer = function () {
        this.rootEl.promptAddServer();
    };
    // Caches an ignored server access key so we don't prompt the user to add it again.
    App.prototype.requestIgnoreServer = function (event) {
        var accessKey = event.detail.accessKey;
        this.ignoredAccessKeys[accessKey] = true;
    };
    App.prototype.requestAddServer = function (event) {
        try {
            this.serverRepo.add(event.detail.serverConfig);
        } catch (err) {
            this.changeToDefaultPage();
            this.showLocalizedError(err);
        }
    };
    App.prototype.requestAddServerConfirmation = function (event) {
        var accessKey = event.detail.accessKey;
        console.debug('Got add server confirmation request from UI');
        try {
            this.confirmAddServer(accessKey);
        } catch (err) {
            console.error('Failed to confirm add sever.', err);
            var addServerView = this.rootEl.$.addServerView;
            addServerView.$.accessKeyInput.invalid = true;
        }
    };
    App.prototype.confirmAddServer = function (accessKey, fromClipboard) {
        if (fromClipboard === void 0) {
            fromClipboard = false;
        }
        var addServerView = this.rootEl.$.addServerView;
        accessKey = unwrapInvite(accessKey);
        if (fromClipboard && accessKey in this.ignoredAccessKeys) {
            return console.debug('Ignoring access key');
        } else if (fromClipboard && addServerView.isAddingServer()) {
            return console.debug('Already adding a server');
        }
        // Expect SHADOWSOCKS_URI.parse to throw on invalid access key; propagate any exception.
        var shadowsocksConfig = null;
        try {
            shadowsocksConfig = shadowsocks_config_1.SHADOWSOCKS_URI.parse(accessKey);
        } catch (error) {
            var message = !!error.message ? error.message : 'Failed to parse access key';
            throw new errors.ServerUrlInvalid(message);
        }
        if (shadowsocksConfig.host.isIPv6) {
            throw new errors.ServerIncompatible('Only IPv4 addresses are currently supported');
        }
        var name = shadowsocksConfig.extra.outline ? this.localize('server-default-name-outline') : shadowsocksConfig.tag.data ? shadowsocksConfig.tag.data : this.localize('server-default-name');
        var serverConfig = {
            host: shadowsocksConfig.host.data,
            port: shadowsocksConfig.port.data,
            method: shadowsocksConfig.method.data,
            password: shadowsocksConfig.password.data,
            name: name
        };
        if (!this.serverRepo.containsServer(serverConfig)) {
            // Only prompt the user to add new servers.
            try {
                addServerView.openAddServerConfirmationSheet(accessKey, serverConfig);
            } catch (err) {
                console.error('Failed to open add sever confirmation sheet:', err.message);
                if (!fromClipboard) this.showLocalizedError();
            }
        } else if (!fromClipboard) {
            // Display error message if this is not a clipboard add.
            addServerView.close();
            this.showLocalizedError(new errors.ServerAlreadyAdded(this.serverRepo.createServer('', serverConfig, this.eventQueue)));
        }
    };
    App.prototype.forgetServer = function (event) {
        var _this = this;
        var serverId = event.detail.serverId;
        var server = this.serverRepo.getById(serverId);
        if (!server) {
            console.error("No server with id " + serverId);
            return this.showLocalizedError();
        }
        var onceNotRunning = server.checkRunning().then(function (isRunning) {
            return isRunning ? _this.disconnectServer(event) : Promise.resolve();
        });
        onceNotRunning.then(function () {
            _this.serverRepo.forget(serverId);
        });
    };
    App.prototype.renameServer = function (event) {
        var serverId = event.detail.serverId;
        var newName = event.detail.newName;
        this.serverRepo.rename(serverId, newName);
    };
    App.prototype.connectServer = function (event) {
        var _this = this;
        var serverId = event.detail.serverId;
        if (!serverId) {
            throw new Error("connectServer event had no server ID");
        }
        var server = this.getServerByServerId(serverId);
        var card = this.getCardByServerId(serverId);
        console.log("connecting to server " + serverId);
        card.state = 'CONNECTING';
        server.connect().then(function () {
            card.state = 'CONNECTED';
            console.log("connected to server " + serverId);
            _this.rootEl.showToast(_this.localize('server-connected', 'serverName', server.name));
            _this.maybeShowAutoConnectDialog();
        }, function (e) {
            card.state = 'DISCONNECTED';
            _this.showLocalizedError(e);
            console.error("could not connect to server " + serverId + ": " + e.name);
            if (!(e instanceof errors.RegularNativeError)) {
                _this.errorReporter.report("connection failure: " + e.name, 'connection-failure');
            }
        });
    };
    App.prototype.maybeShowAutoConnectDialog = function () {
        var dismissed = false;
        try {
            dismissed = this.settings.get(settings_1.SettingsKey.AUTO_CONNECT_DIALOG_DISMISSED) === 'true';
        } catch (e) {
            console.error("Failed to read auto-connect dialog status, assuming not dismissed: " + e);
        }
        if (!dismissed) {
            this.rootEl.$.serversView.$.autoConnectDialog.show();
        }
    };
    App.prototype.autoConnectDialogDismissed = function () {
        this.settings.set(settings_1.SettingsKey.AUTO_CONNECT_DIALOG_DISMISSED, 'true');
    };
    App.prototype.disconnectServer = function (event) {
        var _this = this;
        var serverId = event.detail.serverId;
        if (!serverId) {
            throw new Error("disconnectServer event had no server ID");
        }
        var server = this.getServerByServerId(serverId);
        var card = this.getCardByServerId(serverId);
        console.log("disconnecting from server " + serverId);
        card.state = 'DISCONNECTING';
        server.disconnect().then(function () {
            card.state = 'DISCONNECTED';
            console.log("disconnected from server " + serverId);
            _this.rootEl.showToast(_this.localize('server-disconnected', 'serverName', server.name));
        }, function (e) {
            card.state = 'CONNECTED';
            _this.showLocalizedError(e);
            console.warn("could not disconnect from server " + serverId + ": " + e.name);
        });
    };
    App.prototype.submitFeedback = function (event) {
        var _this = this;
        var formData = this.feedbackViewEl.getValidatedFormData();
        if (!formData) {
            return;
        }
        var feedback = formData.feedback,
            category = formData.category,
            email = formData.email;
        this.rootEl.$.feedbackView.submitting = true;
        this.errorReporter.report(feedback, category, email).then(function () {
            _this.rootEl.$.feedbackView.submitting = false;
            _this.rootEl.$.feedbackView.resetForm();
            _this.changeToDefaultPage();
            _this.rootEl.showToast(_this.rootEl.localize('feedback-thanks'));
        }, function (err) {
            _this.rootEl.$.feedbackView.submitting = false;
            _this.showLocalizedError(new errors.FeedbackSubmissionError());
        });
    };
    // EventQueue event handlers:
    App.prototype.showServerAdded = function (event) {
        var server = event.server;
        console.debug('Server added');
        this.syncServersToUI();
        this.syncServerConnectivityState(server);
        this.changeToDefaultPage();
        this.rootEl.showToast(this.localize('server-added', 'serverName', server.name));
    };
    App.prototype.showServerForgotten = function (event) {
        var _this = this;
        var server = event.server;
        console.debug('Server forgotten');
        this.syncServersToUI();
        this.rootEl.showToast(this.localize('server-forgotten', 'serverName', server.name), 10000, this.localize('undo-button-label'), function () {
            _this.serverRepo.undoForget(server.id);
        });
    };
    App.prototype.showServerForgetUndone = function (event) {
        this.syncServersToUI();
        var server = event.server;
        this.rootEl.showToast(this.localize('server-forgotten-undo', 'serverName', server.name));
    };
    App.prototype.showServerRenamed = function (event) {
        var server = event.server;
        console.debug('Server renamed');
        this.serverListEl.getServerCard(server.id).serverName = server.name;
        this.rootEl.showToast(this.localize('server-rename-complete'));
    };
    // Helpers:
    App.prototype.syncServersToUI = function () {
        this.rootEl.servers = this.serverRepo.getAll();
    };
    App.prototype.syncConnectivityStateToServerCards = function () {
        var e_1, _a;
        try {
            for (var _b = __values(this.serverRepo.getAll()), _c = _b.next(); !_c.done; _c = _b.next()) {
                var server = _c.value;
                this.syncServerConnectivityState(server);
            }
        } catch (e_1_1) {
            e_1 = { error: e_1_1 };
        } finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            } finally {
                if (e_1) throw e_1.error;
            }
        }
    };
    App.prototype.syncServerConnectivityState = function (server) {
        var _this = this;
        server.checkRunning().then(function (isRunning) {
            var card = _this.serverListEl.getServerCard(server.id);
            if (!isRunning) {
                card.state = 'DISCONNECTED';
                return;
            }
            server.checkReachable().then(function (isReachable) {
                if (isReachable) {
                    card.state = 'CONNECTED';
                } else {
                    console.log("Server " + server.id + " reconnecting");
                    card.state = 'RECONNECTING';
                }
            });
        }).catch(function (e) {
            console.error('Failed to sync server connectivity state', e);
        });
    };
    App.prototype.registerUrlInterceptionListener = function (urlInterceptor) {
        var _this = this;
        urlInterceptor.registerListener(function (url) {
            if (!url || !unwrapInvite(url).startsWith('ss://')) {
                // This check is necessary to ignore empty and malformed install-referrer URLs in Android
                // while allowing ss:// and invite URLs.
                // TODO: Stop receiving install referrer intents so we can remove this.
                return console.debug("Ignoring intercepted non-shadowsocks url");
            }
            try {
                _this.confirmAddServer(url);
            } catch (err) {
                _this.showLocalizedErrorInDefaultPage(err);
            }
        });
    };
    App.prototype.changeToDefaultPage = function () {
        this.rootEl.changePage(this.rootEl.DEFAULT_PAGE);
    };
    // Returns the server having serverId, throws if the server cannot be found.
    App.prototype.getServerByServerId = function (serverId) {
        var server = this.serverRepo.getById(serverId);
        if (!server) {
            throw new Error("could not find server with ID " + serverId);
        }
        return server;
    };
    // Returns the card associated with serverId, throws if no such card exists.
    // See server-list.html.
    App.prototype.getCardByServerId = function (serverId) {
        return this.serverListEl.getServerCard(serverId);
    };
    App.prototype.showLocalizedErrorInDefaultPage = function (err) {
        this.changeToDefaultPage();
        this.showLocalizedError(err);
    };
    App.prototype.isWindows = function () {
        return !('cordova' in window);
    };
    return App;
}();
exports.App = App;

},{"../model/errors":36,"../model/events":37,"./settings":33,"ShadowsocksConfig/shadowsocks_config":1}],25:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

Object.defineProperty(exports, "__esModule", { value: true });
// Generic clipboard. Implementations should only have to implement getContents().
var AbstractClipboard = /** @class */function () {
    function AbstractClipboard() {
        this.listener = null;
    }
    AbstractClipboard.prototype.getContents = function () {
        return Promise.reject(new Error('unimplemented skeleton method'));
    };
    AbstractClipboard.prototype.setListener = function (listener) {
        this.listener = listener;
    };
    AbstractClipboard.prototype.emitEvent = function () {
        if (this.listener) {
            this.getContents().then(this.listener);
        }
    };
    return AbstractClipboard;
}();
exports.AbstractClipboard = AbstractClipboard;

},{}],26:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

var __extends = undefined && undefined.__extends || function () {
    var _extendStatics = function extendStatics(d, b) {
        _extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function (d, b) {
            d.__proto__ = b;
        } || function (d, b) {
            for (var p in b) {
                if (b.hasOwnProperty(p)) d[p] = b[p];
            }
        };
        return _extendStatics(d, b);
    };
    return function (d, b) {
        _extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
Object.defineProperty(exports, "__esModule", { value: true });
/// <reference path='../../types/ambient/outlinePlugin.d.ts'/>
/// <reference path='../../types/ambient/webintents.d.ts'/>
var Raven = require("raven-js");
var clipboard_1 = require("./clipboard");
var error_reporter_1 = require("./error_reporter");
var fake_connection_1 = require("./fake_connection");
var main_1 = require("./main");
var outline_server_1 = require("./outline_server");
var updater_1 = require("./updater");
var interceptors = require("./url_interceptor");
// Pushes a clipboard event whenever the app is brought to the foreground.
var CordovaClipboard = /** @class */function (_super) {
    __extends(CordovaClipboard, _super);
    function CordovaClipboard() {
        var _this = _super.call(this) || this;
        document.addEventListener('resume', _this.emitEvent.bind(_this));
        return _this;
    }
    CordovaClipboard.prototype.getContents = function () {
        return new Promise(function (resolve, reject) {
            cordova.plugins.clipboard.paste(resolve, reject);
        });
    };
    return CordovaClipboard;
}(clipboard_1.AbstractClipboard);
// Adds reports from the (native) Cordova plugin.
var CordovaErrorReporter = /** @class */function (_super) {
    __extends(CordovaErrorReporter, _super);
    function CordovaErrorReporter(appVersion, appBuildNumber, dsn, nativeDsn) {
        var _this = _super.call(this, appVersion, dsn, { 'build.number': appBuildNumber }) || this;
        cordova.plugins.outline.log.initialize(nativeDsn).catch(console.error);
        return _this;
    }
    CordovaErrorReporter.prototype.report = function (userFeedback, feedbackCategory, userEmail) {
        return _super.prototype.report.call(this, userFeedback, feedbackCategory, userEmail).then(function () {
            return cordova.plugins.outline.log.send(Raven.lastEventId());
        });
    };
    return CordovaErrorReporter;
}(error_reporter_1.SentryErrorReporter);
exports.CordovaErrorReporter = CordovaErrorReporter;
// This class should only be instantiated after Cordova fires the deviceready event.
var CordovaPlatform = /** @class */function () {
    function CordovaPlatform() {}
    CordovaPlatform.isBrowser = function () {
        return device.platform === 'browser';
    };
    CordovaPlatform.prototype.hasDeviceSupport = function () {
        return !CordovaPlatform.isBrowser();
    };
    CordovaPlatform.prototype.getPersistentServerFactory = function () {
        var _this = this;
        return function (serverId, config, eventQueue) {
            return new outline_server_1.OutlineServer(serverId, config, _this.hasDeviceSupport() ? new cordova.plugins.outline.Connection(config, serverId) : new fake_connection_1.FakeOutlineConnection(config, serverId), eventQueue);
        };
    };
    CordovaPlatform.prototype.getUrlInterceptor = function () {
        if (device.platform === 'iOS' || device.platform === 'Mac OS X') {
            return new interceptors.AppleUrlInterceptor(appleLaunchUrl);
        } else if (device.platform === 'Android') {
            return new interceptors.AndroidUrlInterceptor();
        }
        console.warn('no intent interceptor available');
        return new interceptors.UrlInterceptor();
    };
    CordovaPlatform.prototype.getClipboard = function () {
        return new CordovaClipboard();
    };
    CordovaPlatform.prototype.getErrorReporter = function (env) {
        return this.hasDeviceSupport() ? new CordovaErrorReporter(env.APP_VERSION, env.APP_BUILD_NUMBER, env.SENTRY_DSN, env.SENTRY_NATIVE_DSN) : new error_reporter_1.SentryErrorReporter(env.APP_VERSION, env.SENTRY_DSN, {});
    };
    CordovaPlatform.prototype.getUpdater = function () {
        return new updater_1.AbstractUpdater();
    };
    CordovaPlatform.prototype.quitApplication = function () {
        // Only used in macOS because menu bar apps provide no alternative way of quitting.
        cordova.plugins.outline.quitApplication();
    };
    return CordovaPlatform;
}();
// https://cordova.apache.org/docs/en/latest/cordova/events/events.html#deviceready
var onceDeviceReady = new Promise(function (resolve) {
    document.addEventListener('deviceready', resolve);
});
// cordova-[ios|osx] call a global function with this signature when a URL is
// intercepted. We handle URL interceptions with an intent interceptor; however,
// when the app is launched via URL our start up sequence misses the call due to
// a race. Define the function temporarily here, and set a global variable.
var appleLaunchUrl;
window.handleOpenURL = function (url) {
    appleLaunchUrl = url;
};
onceDeviceReady.then(function () {
    main_1.main(new CordovaPlatform());
});

},{"./clipboard":25,"./error_reporter":28,"./fake_connection":29,"./main":30,"./outline_server":31,"./updater":34,"./url_interceptor":35,"raven-js":10}],27:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

Object.defineProperty(exports, "__esModule", { value: true });
// Keep these in sync with the EnvironmentVariables interface above.
var ENV_KEYS = {
    APP_VERSION: 'APP_VERSION',
    APP_BUILD_NUMBER: 'APP_BUILD_NUMBER',
    BETA_BUILD: 'BETA_BUILD',
    SENTRY_DSN: 'SENTRY_DSN',
    SENTRY_NATIVE_DSN: 'SENTRY_NATIVE_DSN'
};
function validateEnvVars(json) {
    for (var key in ENV_KEYS) {
        if (!json.hasOwnProperty(key)) {
            throw new Error("Missing environment variable: " + key);
        }
    }
}
// According to http://caniuse.com/#feat=fetch fetch didn't hit iOS Safari
// until v10.3 released 3/26/17, so use XMLHttpRequest instead.
exports.onceEnvVars = new Promise(function (resolve, reject) {
    var xhr = new XMLHttpRequest();
    xhr.onload = function () {
        try {
            var json = JSON.parse(xhr.responseText);
            validateEnvVars(json);
            console.debug('Resolving with envVars:', json);
            resolve(json);
        } catch (err) {
            reject(err);
        }
    };
    xhr.open('GET', 'environment.json', true);
    xhr.send();
});

},{}],28:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

Object.defineProperty(exports, "__esModule", { value: true });
var Raven = require("raven-js");
var SentryErrorReporter = /** @class */function () {
    function SentryErrorReporter(appVersion, dsn, tags) {
        Raven.config(dsn, { release: appVersion, 'tags': tags }).install();
        this.setUpUnhandledRejectionListener();
    }
    SentryErrorReporter.prototype.report = function (userFeedback, feedbackCategory, userEmail) {
        Raven.setUserContext({ email: userEmail || '' });
        Raven.captureMessage(userFeedback, { tags: { category: feedbackCategory } });
        Raven.setUserContext(); // Reset the user context, don't cache the email
        return Promise.resolve();
    };
    SentryErrorReporter.prototype.setUpUnhandledRejectionListener = function () {
        // Chrome is the only browser that supports the unhandledrejection event.
        // This is fine for Android, but will not work in iOS.
        var unhandledRejection = 'unhandledrejection';
        window.addEventListener(unhandledRejection, function (event) {
            var reason = event.reason;
            var msg = reason.stack ? reason.stack : reason;
            Raven.captureBreadcrumb({ message: msg, category: unhandledRejection });
        });
    };
    return SentryErrorReporter;
}();
exports.SentryErrorReporter = SentryErrorReporter;

},{"raven-js":10}],29:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

Object.defineProperty(exports, "__esModule", { value: true });
/// <reference path='../../types/ambient/outlinePlugin.d.ts'/>
var errors = require("../model/errors");
// Note that because this implementation does not emit disconnection events, "switching" between
// servers in the server list will not work as expected.
var FakeOutlineConnection = /** @class */function () {
    function FakeOutlineConnection(config, id) {
        this.config = config;
        this.id = id;
        this.running = false;
    }
    FakeOutlineConnection.prototype.playBroken = function () {
        return this.config.name && this.config.name.toLowerCase().includes('broken');
    };
    FakeOutlineConnection.prototype.playUnreachable = function () {
        return !(this.config.name && this.config.name.toLowerCase().includes('unreachable'));
    };
    FakeOutlineConnection.prototype.start = function () {
        if (this.running) {
            return Promise.resolve();
        }
        if (!this.playUnreachable()) {
            return Promise.reject(new errors.OutlinePluginError(5 /* SERVER_UNREACHABLE */));
        } else if (this.playBroken()) {
            return Promise.reject(new errors.OutlinePluginError(8 /* SHADOWSOCKS_START_FAILURE */));
        } else {
            this.running = true;
            return Promise.resolve();
        }
    };
    FakeOutlineConnection.prototype.stop = function () {
        if (!this.running) {
            return Promise.resolve();
        }
        this.running = false;
        return Promise.resolve();
    };
    FakeOutlineConnection.prototype.isRunning = function () {
        return Promise.resolve(this.running);
    };
    FakeOutlineConnection.prototype.isReachable = function () {
        return Promise.resolve(!this.playUnreachable());
    };
    FakeOutlineConnection.prototype.onStatusChange = function (listener) {
        // NOOP
    };
    return FakeOutlineConnection;
}();
exports.FakeOutlineConnection = FakeOutlineConnection;

},{"../model/errors":36}],30:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

var __read = undefined && undefined.__read || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o),
        r,
        ar = [],
        e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) {
            ar.push(r.value);
        }
    } catch (error) {
        e = { error: error };
    } finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        } finally {
            if (e) throw e.error;
        }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
var url = require("url");
var events_1 = require("../model/events");
var app_1 = require("./app");
var environment_1 = require("./environment");
var persistent_server_1 = require("./persistent_server");
var settings_1 = require("./settings");
// Used to determine whether to use Polymer functionality on app initialization failure.
var webComponentsAreReady = false;
document.addEventListener('WebComponentsReady', function () {
    console.debug('received WebComponentsReady event');
    webComponentsAreReady = true;
});
// Used to delay loading the app until (translation) resources have been loaded. This can happen a
// little later than WebComponentsReady.
var oncePolymerIsReady = new Promise(function (resolve) {
    document.addEventListener('app-localize-resources-loaded', function () {
        console.debug('received app-localize-resources-loaded event');
        resolve();
    });
});
// Helpers
// Do not call until WebComponentsReady has fired!
function getRootEl() {
    return document.querySelector('app-root');
}
function createServerRepo(eventQueue, storage, deviceSupport, connectionType) {
    var repo = new persistent_server_1.PersistentServerRepository(connectionType, eventQueue, storage);
    if (!deviceSupport) {
        console.debug('Detected development environment, using fake servers.');
        if (repo.getAll().length === 0) {
            repo.add({ name: 'Fake Working Server', host: '127.0.0.1', port: 123 });
            repo.add({ name: 'Fake Broken Server', host: '192.0.2.1', port: 123 });
            repo.add({ name: 'Fake Unreachable Server', host: '10.0.0.24', port: 123 });
        }
    }
    return repo;
}
function main(platform) {
    return Promise.all([environment_1.onceEnvVars, oncePolymerIsReady]).then(function (_a) {
        var _b = __read(_a, 1),
            environmentVars = _b[0];
        console.debug('running main() function');
        var queryParams = url.parse(document.URL, true).query;
        var debugMode = queryParams.debug === 'true';
        var eventQueue = new events_1.EventQueue();
        var serverRepo = createServerRepo(eventQueue, window.localStorage, platform.hasDeviceSupport(), platform.getPersistentServerFactory());
        var settings = new settings_1.Settings();
        var app = new app_1.App(eventQueue, serverRepo, getRootEl(), debugMode, platform.getUrlInterceptor(), platform.getClipboard(), platform.getErrorReporter(environmentVars), settings, environmentVars, platform.getUpdater(), platform.quitApplication);
    }, function (e) {
        onUnexpectedError(e);
        throw e;
    });
}
exports.main = main;
function onUnexpectedError(error) {
    var rootEl = getRootEl();
    if (webComponentsAreReady && rootEl && rootEl.localize) {
        var localize = rootEl.localize.bind(rootEl);
        rootEl.showToast(localize('error-unexpected'), 120000);
    } else {
        // Something went terribly wrong (i.e. Polymer failed to initialize). Provide some messaging to
        // the user, even if we are not able to display it in a toast or localize it.
        // TODO: provide an help email once we have a domain.
        alert("An unexpected error occurred.");
    }
    console.error(error);
}
// Returns Polymer's localization function. Must be called after WebComponentsReady has fired.
function getLocalizationFunction() {
    var rootEl = getRootEl();
    if (!rootEl) {
        return null;
    }
    return rootEl.localize;
}
exports.getLocalizationFunction = getLocalizationFunction;

},{"../model/events":37,"./app":24,"./environment":27,"./persistent_server":32,"./settings":33,"url":15}],31:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

Object.defineProperty(exports, "__esModule", { value: true });
/// <reference path='../../types/ambient/outlinePlugin.d.ts'/>
var errors = require("../model/errors");
var events = require("../model/events");
var OutlineServer = /** @class */function () {
    function OutlineServer(id, config, connection, eventQueue) {
        var _this = this;
        this.id = id;
        this.config = config;
        this.connection = connection;
        this.eventQueue = eventQueue;
        this.connection.onStatusChange(function (status) {
            var statusEvent;
            switch (status) {
                case 0 /* CONNECTED */:
                    statusEvent = new events.ServerConnected(_this);
                    break;
                case 1 /* DISCONNECTED */:
                    statusEvent = new events.ServerDisconnected(_this);
                    break;
                case 2 /* RECONNECTING */:
                    statusEvent = new events.ServerReconnecting(_this);
                    break;
                default:
                    console.warn("Received unknown connection status " + status);
                    return;
            }
            eventQueue.enqueue(statusEvent);
        });
    }
    Object.defineProperty(OutlineServer.prototype, "name", {
        get: function get() {
            return this.config.name || this.config.host || '';
        },
        set: function set(newName) {
            this.config.name = newName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(OutlineServer.prototype, "host", {
        get: function get() {
            return this.config.host;
        },
        enumerable: true,
        configurable: true
    });
    OutlineServer.prototype.connect = function () {
        return this.connection.start().catch(function (e) {
            // e originates in "native" code: either Cordova or Electron's main process.
            // Because of this, we cannot assume "instanceof OutlinePluginError" will work.
            if (e.errorCode) {
                throw errors.fromErrorCode(e.errorCode);
            }
            throw e;
        });
    };
    OutlineServer.prototype.disconnect = function () {
        return this.connection.stop().catch(function (e) {
            // TODO: None of the plugins currently return an ErrorCode on disconnection.
            throw new errors.RegularNativeError();
        });
    };
    OutlineServer.prototype.checkRunning = function () {
        return this.connection.isRunning();
    };
    OutlineServer.prototype.checkReachable = function () {
        return this.connection.isReachable();
    };
    return OutlineServer;
}();
exports.OutlineServer = OutlineServer;

},{"../model/errors":36,"../model/events":37}],32:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

var __values = undefined && undefined.__values || function (o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator],
        i = 0;
    if (m) return m.call(o);
    return {
        next: function next() {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
};
Object.defineProperty(exports, "__esModule", { value: true });
var uuidv4 = require("uuidv4");
var errors_1 = require("../model/errors");
var events = require("../model/events");
// Maintains a persisted set of servers and liaises with the core.
var PersistentServerRepository = /** @class */function () {
    function PersistentServerRepository(createServer, eventQueue, storage) {
        this.createServer = createServer;
        this.eventQueue = eventQueue;
        this.storage = storage;
        this.lastForgottenServer = null;
        this.loadServers();
    }
    PersistentServerRepository.prototype.getAll = function () {
        return Array.from(this.serverById.values());
    };
    PersistentServerRepository.prototype.getById = function (serverId) {
        return this.serverById.get(serverId);
    };
    PersistentServerRepository.prototype.add = function (serverConfig) {
        var alreadyAddedServer = this.serverFromConfig(serverConfig);
        if (alreadyAddedServer) {
            throw new errors_1.ServerAlreadyAdded(alreadyAddedServer);
        }
        var server = this.createServer(uuidv4(), serverConfig, this.eventQueue);
        this.serverById.set(server.id, server);
        this.storeServers();
        this.eventQueue.enqueue(new events.ServerAdded(server));
    };
    PersistentServerRepository.prototype.rename = function (serverId, newName) {
        var server = this.serverById.get(serverId);
        if (!server) {
            console.warn("Cannot rename nonexistent server " + serverId);
            return;
        }
        server.name = newName;
        this.storeServers();
        this.eventQueue.enqueue(new events.ServerRenamed(server));
    };
    PersistentServerRepository.prototype.forget = function (serverId) {
        var server = this.serverById.get(serverId);
        if (!server) {
            console.warn("Cannot remove nonexistent server " + serverId);
            return;
        }
        this.serverById.delete(serverId);
        this.lastForgottenServer = server;
        this.storeServers();
        this.eventQueue.enqueue(new events.ServerForgotten(server));
    };
    PersistentServerRepository.prototype.undoForget = function (serverId) {
        if (!this.lastForgottenServer) {
            console.warn('No forgotten server to unforget');
            return;
        } else if (this.lastForgottenServer.id !== serverId) {
            console.warn('id of forgotten server', this.lastForgottenServer, 'does not match', serverId);
            return;
        }
        this.serverById.set(this.lastForgottenServer.id, this.lastForgottenServer);
        this.storeServers();
        this.eventQueue.enqueue(new events.ServerForgetUndone(this.lastForgottenServer));
        this.lastForgottenServer = null;
    };
    PersistentServerRepository.prototype.containsServer = function (config) {
        return !!this.serverFromConfig(config);
    };
    PersistentServerRepository.prototype.serverFromConfig = function (config) {
        var e_1, _a;
        try {
            for (var _b = __values(this.getAll()), _c = _b.next(); !_c.done; _c = _b.next()) {
                var server = _c.value;
                if (configsMatch(server.config, config)) {
                    return server;
                }
            }
        } catch (e_1_1) {
            e_1 = { error: e_1_1 };
        } finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            } finally {
                if (e_1) throw e_1.error;
            }
        }
    };
    PersistentServerRepository.prototype.storeServers = function () {
        var e_2, _a;
        var configById = {};
        try {
            for (var _b = __values(this.serverById.values()), _c = _b.next(); !_c.done; _c = _b.next()) {
                var server = _c.value;
                configById[server.id] = server.config;
            }
        } catch (e_2_1) {
            e_2 = { error: e_2_1 };
        } finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            } finally {
                if (e_2) throw e_2.error;
            }
        }
        var json = JSON.stringify(configById);
        this.storage.setItem(PersistentServerRepository.SERVERS_STORAGE_KEY, json);
    };
    // Loads servers from storage,
    // raising an error if there is any problem loading.
    PersistentServerRepository.prototype.loadServers = function () {
        this.serverById = new Map();
        var serversJson = this.storage.getItem(PersistentServerRepository.SERVERS_STORAGE_KEY);
        if (!serversJson) {
            console.debug("no servers found in storage");
            return;
        }
        var configById = {};
        try {
            configById = JSON.parse(serversJson);
        } catch (e) {
            throw new Error("could not parse saved servers: " + e.message);
        }
        for (var serverId in configById) {
            if (configById.hasOwnProperty(serverId)) {
                var config = configById[serverId];
                try {
                    var server = this.createServer(serverId, config, this.eventQueue);
                    this.serverById.set(serverId, server);
                } catch (e) {
                    // Don't propagate so other stored servers can be created.
                    console.error(e);
                }
            }
        }
    };
    // Name by which servers are saved to storage.
    PersistentServerRepository.SERVERS_STORAGE_KEY = 'servers';
    return PersistentServerRepository;
}();
exports.PersistentServerRepository = PersistentServerRepository;
function configsMatch(left, right) {
    return left.host === right.host && left.port === right.port && left.method === right.method && left.password === right.password;
}

},{"../model/errors":36,"../model/events":37,"uuidv4":23}],33:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

var __values = undefined && undefined.__values || function (o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator],
        i = 0;
    if (m) return m.call(o);
    return {
        next: function next() {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
};
var __read = undefined && undefined.__read || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o),
        r,
        ar = [],
        e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) {
            ar.push(r.value);
        }
    } catch (error) {
        e = { error: error };
    } finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        } finally {
            if (e) throw e.error;
        }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
// Setting keys supported by the `Settings` class.
var SettingsKey;
(function (SettingsKey) {
    SettingsKey["VPN_WARNING_DISMISSED"] = "vpn-warning-dismissed";
    SettingsKey["AUTO_CONNECT_DIALOG_DISMISSED"] = "auto-connect-dialog-dismissed";
    SettingsKey["PRIVACY_ACK"] = "privacy-ack";
    SettingsKey["BETA_ACK"] = "beta-ack";
})(SettingsKey = exports.SettingsKey || (exports.SettingsKey = {}));
// Persistent storage for user settings that supports a limited set of keys.
var Settings = /** @class */function () {
    function Settings(storage, validKeys) {
        if (storage === void 0) {
            storage = window.localStorage;
        }
        if (validKeys === void 0) {
            validKeys = Object.values(SettingsKey);
        }
        this.storage = storage;
        this.validKeys = validKeys;
        this.settings = new Map();
        this.loadSettings();
    }
    Settings.prototype.get = function (key) {
        return this.settings.get(key);
    };
    Settings.prototype.set = function (key, value) {
        if (!this.isValidSetting(key)) {
            throw new Error("Cannot set invalid key " + key);
        }
        this.settings.set(key, value);
        this.storeSettings();
    };
    Settings.prototype.remove = function (key) {
        this.settings.delete(key);
        this.storeSettings();
    };
    Settings.prototype.isValidSetting = function (key) {
        return this.validKeys.includes(key);
    };
    Settings.prototype.loadSettings = function () {
        var settingsJson = this.storage.getItem(Settings.STORAGE_KEY);
        if (!settingsJson) {
            console.debug("No settings found in storage");
            return;
        }
        var storageSettings = JSON.parse(settingsJson);
        for (var key in storageSettings) {
            if (storageSettings.hasOwnProperty(key)) {
                this.settings.set(key, storageSettings[key]);
            }
        }
    };
    Settings.prototype.storeSettings = function () {
        var e_1, _a;
        var storageSettings = {};
        try {
            for (var _b = __values(this.settings), _c = _b.next(); !_c.done; _c = _b.next()) {
                var _d = __read(_c.value, 2),
                    key = _d[0],
                    value = _d[1];
                storageSettings[key] = value;
            }
        } catch (e_1_1) {
            e_1 = { error: e_1_1 };
        } finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            } finally {
                if (e_1) throw e_1.error;
            }
        }
        var storageSettingsJson = JSON.stringify(storageSettings);
        this.storage.setItem(Settings.STORAGE_KEY, storageSettingsJson);
    };
    Settings.STORAGE_KEY = 'settings';
    return Settings;
}();
exports.Settings = Settings;

},{}],34:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

Object.defineProperty(exports, "__esModule", { value: true });
var AbstractUpdater = /** @class */function () {
    function AbstractUpdater() {
        this.listener = null;
    }
    AbstractUpdater.prototype.setListener = function (listener) {
        this.listener = listener;
    };
    AbstractUpdater.prototype.emitEvent = function () {
        if (this.listener) {
            this.listener();
        }
    };
    return AbstractUpdater;
}();
exports.AbstractUpdater = AbstractUpdater;

},{}],35:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

var __extends = undefined && undefined.__extends || function () {
    var _extendStatics = function extendStatics(d, b) {
        _extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function (d, b) {
            d.__proto__ = b;
        } || function (d, b) {
            for (var p in b) {
                if (b.hasOwnProperty(p)) d[p] = b[p];
            }
        };
        return _extendStatics(d, b);
    };
    return function (d, b) {
        _extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
var __values = undefined && undefined.__values || function (o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator],
        i = 0;
    if (m) return m.call(o);
    return {
        next: function next() {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
};
Object.defineProperty(exports, "__esModule", { value: true });
/// <reference path='../../types/ambient/webintents.d.ts'/>
var UrlInterceptor = /** @class */function () {
    function UrlInterceptor() {
        this.listeners = [];
    }
    UrlInterceptor.prototype.registerListener = function (listener) {
        this.listeners.push(listener);
        if (this.launchUrl) {
            listener(this.launchUrl);
            this.launchUrl = undefined;
        }
    };
    UrlInterceptor.prototype.executeListeners = function (url) {
        var e_1, _a;
        if (!url) {
            return;
        }
        if (!this.listeners.length) {
            console.log('no listeners have been added, delaying intent firing');
            this.launchUrl = url;
            return;
        }
        try {
            for (var _b = __values(this.listeners), _c = _b.next(); !_c.done; _c = _b.next()) {
                var listener = _c.value;
                listener(url);
            }
        } catch (e_1_1) {
            e_1 = { error: e_1_1 };
        } finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            } finally {
                if (e_1) throw e_1.error;
            }
        }
    };
    return UrlInterceptor;
}();
exports.UrlInterceptor = UrlInterceptor;
var AndroidUrlInterceptor = /** @class */function (_super) {
    __extends(AndroidUrlInterceptor, _super);
    function AndroidUrlInterceptor() {
        var _this = _super.call(this) || this;
        window.webintent.getUri(function (launchUrl) {
            window.webintent.onNewIntent(_this.executeListeners.bind(_this));
            _this.executeListeners(launchUrl);
        });
        return _this;
    }
    return AndroidUrlInterceptor;
}(UrlInterceptor);
exports.AndroidUrlInterceptor = AndroidUrlInterceptor;
var AppleUrlInterceptor = /** @class */function (_super) {
    __extends(AppleUrlInterceptor, _super);
    function AppleUrlInterceptor(launchUrl) {
        var _this = _super.call(this) || this;
        // cordova-[ios|osx] call a global function with this signature when a URL is intercepted.
        // We define it in |cordova_main|, redefine it to use this interceptor.
        window.handleOpenURL = function (url) {
            _this.executeListeners(url);
        };
        if (launchUrl) {
            _this.executeListeners(launchUrl);
        }
        return _this;
    }
    return AppleUrlInterceptor;
}(UrlInterceptor);
exports.AppleUrlInterceptor = AppleUrlInterceptor;

},{}],36:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

var __extends = undefined && undefined.__extends || function () {
    var _extendStatics = function extendStatics(d, b) {
        _extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function (d, b) {
            d.__proto__ = b;
        } || function (d, b) {
            for (var p in b) {
                if (b.hasOwnProperty(p)) d[p] = b[p];
            }
        };
        return _extendStatics(d, b);
    };
    return function (d, b) {
        _extendStatics(d, b);
        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
}();
Object.defineProperty(exports, "__esModule", { value: true });
var OutlineError = /** @class */function (_super) {
    __extends(OutlineError, _super);
    function OutlineError(message) {
        var _newTarget = this.constructor;
        var _this =
        // ref:
        // https://www.typescriptlang.org/docs/handbook/release-notes/typescript-2-2.html#support-for-newtarget
        _super.call(this, message) || this;
        Object.setPrototypeOf(_this, _newTarget.prototype); // restore prototype chain
        _this.name = _newTarget.name;
        return _this;
    }
    return OutlineError;
}(Error);
exports.OutlineError = OutlineError;
var ServerAlreadyAdded = /** @class */function (_super) {
    __extends(ServerAlreadyAdded, _super);
    function ServerAlreadyAdded(server) {
        var _this = _super.call(this) || this;
        _this.server = server;
        return _this;
    }
    return ServerAlreadyAdded;
}(OutlineError);
exports.ServerAlreadyAdded = ServerAlreadyAdded;
var ServerIncompatible = /** @class */function (_super) {
    __extends(ServerIncompatible, _super);
    function ServerIncompatible(message) {
        return _super.call(this, message) || this;
    }
    return ServerIncompatible;
}(OutlineError);
exports.ServerIncompatible = ServerIncompatible;
var ServerUrlInvalid = /** @class */function (_super) {
    __extends(ServerUrlInvalid, _super);
    function ServerUrlInvalid(message) {
        return _super.call(this, message) || this;
    }
    return ServerUrlInvalid;
}(OutlineError);
exports.ServerUrlInvalid = ServerUrlInvalid;
var OperationTimedOut = /** @class */function (_super) {
    __extends(OperationTimedOut, _super);
    function OperationTimedOut(timeoutMs, operationName) {
        var _this = _super.call(this) || this;
        _this.timeoutMs = timeoutMs;
        _this.operationName = operationName;
        return _this;
    }
    return OperationTimedOut;
}(OutlineError);
exports.OperationTimedOut = OperationTimedOut;
var FeedbackSubmissionError = /** @class */function (_super) {
    __extends(FeedbackSubmissionError, _super);
    function FeedbackSubmissionError() {
        return _super.call(this) || this;
    }
    return FeedbackSubmissionError;
}(OutlineError);
exports.FeedbackSubmissionError = FeedbackSubmissionError;
// Error thrown by "native" code.
//
// Must be kept in sync with its Cordova doppelganger:
//   cordova-plugin-outline/outlinePlugin.js
//
// TODO: Rename this class, "plugin" is a poor name since the Electron apps do not have plugins.
var OutlinePluginError = /** @class */function (_super) {
    __extends(OutlinePluginError, _super);
    function OutlinePluginError(errorCode) {
        var _this = _super.call(this) || this;
        _this.errorCode = errorCode;
        return _this;
    }
    return OutlinePluginError;
}(OutlineError);
exports.OutlinePluginError = OutlinePluginError;
// Marker class for errors originating in native code.
// Bifurcates into two subclasses:
//  - "expected" errors originating in native code, e.g. incorrect password
//  - "unexpected" errors originating in native code, e.g. unhandled routing table
var NativeError = /** @class */function (_super) {
    __extends(NativeError, _super);
    function NativeError() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return NativeError;
}(OutlineError);
exports.NativeError = NativeError;
var RegularNativeError = /** @class */function (_super) {
    __extends(RegularNativeError, _super);
    function RegularNativeError() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return RegularNativeError;
}(NativeError);
exports.RegularNativeError = RegularNativeError;
var RedFlagNativeError = /** @class */function (_super) {
    __extends(RedFlagNativeError, _super);
    function RedFlagNativeError() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return RedFlagNativeError;
}(NativeError);
exports.RedFlagNativeError = RedFlagNativeError;
//////
// "Expected" errors.
//////
var UnexpectedPluginError = /** @class */function (_super) {
    __extends(UnexpectedPluginError, _super);
    function UnexpectedPluginError() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return UnexpectedPluginError;
}(RegularNativeError);
exports.UnexpectedPluginError = UnexpectedPluginError;
var VpnPermissionNotGranted = /** @class */function (_super) {
    __extends(VpnPermissionNotGranted, _super);
    function VpnPermissionNotGranted() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return VpnPermissionNotGranted;
}(RegularNativeError);
exports.VpnPermissionNotGranted = VpnPermissionNotGranted;
var InvalidServerCredentials = /** @class */function (_super) {
    __extends(InvalidServerCredentials, _super);
    function InvalidServerCredentials() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return InvalidServerCredentials;
}(RegularNativeError);
exports.InvalidServerCredentials = InvalidServerCredentials;
var RemoteUdpForwardingDisabled = /** @class */function (_super) {
    __extends(RemoteUdpForwardingDisabled, _super);
    function RemoteUdpForwardingDisabled() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return RemoteUdpForwardingDisabled;
}(RegularNativeError);
exports.RemoteUdpForwardingDisabled = RemoteUdpForwardingDisabled;
var ServerUnreachable = /** @class */function (_super) {
    __extends(ServerUnreachable, _super);
    function ServerUnreachable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return ServerUnreachable;
}(RegularNativeError);
exports.ServerUnreachable = ServerUnreachable;
var IllegalServerConfiguration = /** @class */function (_super) {
    __extends(IllegalServerConfiguration, _super);
    function IllegalServerConfiguration() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return IllegalServerConfiguration;
}(RegularNativeError);
exports.IllegalServerConfiguration = IllegalServerConfiguration;
var NoAdminPermissions = /** @class */function (_super) {
    __extends(NoAdminPermissions, _super);
    function NoAdminPermissions() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return NoAdminPermissions;
}(RegularNativeError);
exports.NoAdminPermissions = NoAdminPermissions;
var SystemConfigurationException = /** @class */function (_super) {
    __extends(SystemConfigurationException, _super);
    function SystemConfigurationException() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return SystemConfigurationException;
}(RegularNativeError);
exports.SystemConfigurationException = SystemConfigurationException;
//////
// Now, "unexpected" errors.
// Use these sparingly because each occurrence triggers a Sentry report.
//////
// Windows.
var ShadowsocksStartFailure = /** @class */function (_super) {
    __extends(ShadowsocksStartFailure, _super);
    function ShadowsocksStartFailure() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return ShadowsocksStartFailure;
}(RedFlagNativeError);
exports.ShadowsocksStartFailure = ShadowsocksStartFailure;
var ConfigureSystemProxyFailure = /** @class */function (_super) {
    __extends(ConfigureSystemProxyFailure, _super);
    function ConfigureSystemProxyFailure() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return ConfigureSystemProxyFailure;
}(RedFlagNativeError);
exports.ConfigureSystemProxyFailure = ConfigureSystemProxyFailure;
var UnsupportedRoutingTable = /** @class */function (_super) {
    __extends(UnsupportedRoutingTable, _super);
    function UnsupportedRoutingTable() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return UnsupportedRoutingTable;
}(RedFlagNativeError);
exports.UnsupportedRoutingTable = UnsupportedRoutingTable;
// Used on Android and Apple to indicate that the plugin failed to establish the VPN tunnel.
var VpnStartFailure = /** @class */function (_super) {
    __extends(VpnStartFailure, _super);
    function VpnStartFailure() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return VpnStartFailure;
}(RedFlagNativeError);
exports.VpnStartFailure = VpnStartFailure;
// Converts an ErrorCode - originating in "native" code - to an instance of the relevant
// OutlineError subclass.
// Throws if the error code is not one defined in ErrorCode or is ErrorCode.NO_ERROR.
function fromErrorCode(errorCode) {
    switch (errorCode) {
        case 1 /* UNEXPECTED */:
            return new UnexpectedPluginError();
        case 2 /* VPN_PERMISSION_NOT_GRANTED */:
            return new VpnPermissionNotGranted();
        case 3 /* INVALID_SERVER_CREDENTIALS */:
            return new InvalidServerCredentials();
        case 4 /* UDP_RELAY_NOT_ENABLED */:
            return new RemoteUdpForwardingDisabled();
        case 5 /* SERVER_UNREACHABLE */:
            return new ServerUnreachable();
        case 6 /* VPN_START_FAILURE */:
            return new VpnStartFailure();
        case 7 /* ILLEGAL_SERVER_CONFIGURATION */:
            return new IllegalServerConfiguration();
        case 8 /* SHADOWSOCKS_START_FAILURE */:
            return new ShadowsocksStartFailure();
        case 9 /* CONFIGURE_SYSTEM_PROXY_FAILURE */:
            return new ConfigureSystemProxyFailure();
        case 10 /* NO_ADMIN_PERMISSIONS */:
            return new NoAdminPermissions();
        case 11 /* UNSUPPORTED_ROUTING_TABLE */:
            return new UnsupportedRoutingTable();
        case 12 /* SYSTEM_MISCONFIGURED */:
            return new SystemConfigurationException();
        default:
            throw new Error("unknown ErrorCode " + errorCode);
    }
}
exports.fromErrorCode = fromErrorCode;
// Converts a NativeError to an ErrorCode.
// Throws if the error is not a subclass of NativeError.
function toErrorCode(e) {
    if (e instanceof UnexpectedPluginError) {
        return 1 /* UNEXPECTED */;
    } else if (e instanceof VpnPermissionNotGranted) {
        return 2 /* VPN_PERMISSION_NOT_GRANTED */;
    } else if (e instanceof InvalidServerCredentials) {
        return 3 /* INVALID_SERVER_CREDENTIALS */;
    } else if (e instanceof RemoteUdpForwardingDisabled) {
        return 4 /* UDP_RELAY_NOT_ENABLED */;
    } else if (e instanceof ServerUnreachable) {
        return 5 /* SERVER_UNREACHABLE */;
    } else if (e instanceof VpnStartFailure) {
        return 6 /* VPN_START_FAILURE */;
    } else if (e instanceof IllegalServerConfiguration) {
        return 7 /* ILLEGAL_SERVER_CONFIGURATION */;
    } else if (e instanceof ShadowsocksStartFailure) {
        return 8 /* SHADOWSOCKS_START_FAILURE */;
    } else if (e instanceof ConfigureSystemProxyFailure) {
        return 9 /* CONFIGURE_SYSTEM_PROXY_FAILURE */;
    } else if (e instanceof UnsupportedRoutingTable) {
        return 11 /* UNSUPPORTED_ROUTING_TABLE */;
    } else if (e instanceof NoAdminPermissions) {
        return 10 /* NO_ADMIN_PERMISSIONS */;
    } else if (e instanceof SystemConfigurationException) {
        return 12 /* SYSTEM_MISCONFIGURED */;
    }
    throw new Error("unknown NativeError " + e.name);
}
exports.toErrorCode = toErrorCode;

},{}],37:[function(require,module,exports){
"use strict";
// Copyright 2018 The Outline Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

var __values = undefined && undefined.__values || function (o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator],
        i = 0;
    if (m) return m.call(o);
    return {
        next: function next() {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
};
Object.defineProperty(exports, "__esModule", { value: true });
var ServerAdded = /** @class */function () {
    function ServerAdded(server) {
        this.server = server;
    }
    return ServerAdded;
}();
exports.ServerAdded = ServerAdded;
var ServerAlreadyAdded = /** @class */function () {
    function ServerAlreadyAdded(server) {
        this.server = server;
    }
    return ServerAlreadyAdded;
}();
exports.ServerAlreadyAdded = ServerAlreadyAdded;
var ServerForgotten = /** @class */function () {
    function ServerForgotten(server) {
        this.server = server;
    }
    return ServerForgotten;
}();
exports.ServerForgotten = ServerForgotten;
var ServerForgetUndone = /** @class */function () {
    function ServerForgetUndone(server) {
        this.server = server;
    }
    return ServerForgetUndone;
}();
exports.ServerForgetUndone = ServerForgetUndone;
var ServerRenamed = /** @class */function () {
    function ServerRenamed(server) {
        this.server = server;
    }
    return ServerRenamed;
}();
exports.ServerRenamed = ServerRenamed;
var ServerUrlInvalid = /** @class */function () {
    function ServerUrlInvalid(serverUrl) {
        this.serverUrl = serverUrl;
    }
    return ServerUrlInvalid;
}();
exports.ServerUrlInvalid = ServerUrlInvalid;
var ServerConnected = /** @class */function () {
    function ServerConnected(server) {
        this.server = server;
    }
    return ServerConnected;
}();
exports.ServerConnected = ServerConnected;
var ServerDisconnected = /** @class */function () {
    function ServerDisconnected(server) {
        this.server = server;
    }
    return ServerDisconnected;
}();
exports.ServerDisconnected = ServerDisconnected;
var ServerReconnecting = /** @class */function () {
    function ServerReconnecting(server) {
        this.server = server;
    }
    return ServerReconnecting;
}();
exports.ServerReconnecting = ServerReconnecting;
// Simple publisher-subscriber queue.
var EventQueue = /** @class */function () {
    function EventQueue() {
        this.queuedEvents = [];
        this.listenersByEventType = new Map();
        this.isStarted = false;
        this.isPublishing = false;
    }
    EventQueue.prototype.startPublishing = function () {
        this.isStarted = true;
        this.publishQueuedEvents();
    };
    // Registers a listener for events of the type of the given constructor.
    EventQueue.prototype.subscribe = function (eventType, listener) {
        var listeners = this.listenersByEventType.get(eventType);
        if (!listeners) {
            listeners = [];
            this.listenersByEventType.set(eventType, listeners);
        }
        listeners.push(listener);
    };
    // Enqueues the given event for publishing and publishes all queued events if
    // publishing is not already happening.
    //
    // The enqueue method is reentrant: it may be called by an event listener
    // during the publishing of the events. In that case the method adds the event
    // to the end of the queue and returns immediately.
    //
    // This guarantees that events are published and handled in the order that
    // they are queued.
    //
    // There's no guarantee that the subscribers for the event have been called by
    // the time this function returns.
    EventQueue.prototype.enqueue = function (event) {
        this.queuedEvents.push(event);
        if (this.isStarted) {
            this.publishQueuedEvents();
        }
    };
    // Triggers the subscribers for all the enqueued events.
    EventQueue.prototype.publishQueuedEvents = function () {
        var e_1, _a;
        if (this.isPublishing) return;
        this.isPublishing = true;
        while (this.queuedEvents.length > 0) {
            var event_1 = this.queuedEvents.shift();
            var listeners = this.listenersByEventType.get(event_1.constructor);
            if (!listeners) {
                console.warn('Dropping event with no listeners:', event_1);
                continue;
            }
            try {
                for (var listeners_1 = __values(listeners), listeners_1_1 = listeners_1.next(); !listeners_1_1.done; listeners_1_1 = listeners_1.next()) {
                    var listener = listeners_1_1.value;
                    listener(event_1);
                }
            } catch (e_1_1) {
                e_1 = { error: e_1_1 };
            } finally {
                try {
                    if (listeners_1_1 && !listeners_1_1.done && (_a = listeners_1.return)) _a.call(listeners_1);
                } finally {
                    if (e_1) throw e_1.error;
                }
            }
        }
        this.isPublishing = false;
    };
    return EventQueue;
}();
exports.EventQueue = EventQueue;

},{}]},{},[26])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJub2RlX21vZHVsZXMvU2hhZG93c29ja3NDb25maWcvc2hhZG93c29ja3NfY29uZmlnLnRzIiwibm9kZV9tb2R1bGVzL2Jhc2UtNjQvYmFzZTY0LmpzIiwibm9kZV9tb2R1bGVzL3B1bnljb2RlL3B1bnljb2RlLmpzIiwibm9kZV9tb2R1bGVzL3F1ZXJ5c3RyaW5nLWVzMy9kZWNvZGUuanMiLCJub2RlX21vZHVsZXMvcXVlcnlzdHJpbmctZXMzL2VuY29kZS5qcyIsIm5vZGVfbW9kdWxlcy9xdWVyeXN0cmluZy1lczMvaW5kZXguanMiLCJub2RlX21vZHVsZXMvcmF2ZW4tanMvc3JjL2NvbmZpZ0Vycm9yLmpzIiwibm9kZV9tb2R1bGVzL3JhdmVuLWpzL3NyYy9jb25zb2xlLmpzIiwibm9kZV9tb2R1bGVzL3JhdmVuLWpzL3NyYy9yYXZlbi5qcyIsIm5vZGVfbW9kdWxlcy9yYXZlbi1qcy9zcmMvc2luZ2xldG9uLmpzIiwibm9kZV9tb2R1bGVzL3JhdmVuLWpzL3NyYy91dGlscy5qcyIsIm5vZGVfbW9kdWxlcy9yYXZlbi1qcy92ZW5kb3IvVHJhY2VLaXQvdHJhY2VraXQuanMiLCJub2RlX21vZHVsZXMvcmF2ZW4tanMvdmVuZG9yL2pzb24tc3RyaW5naWZ5LXNhZmUvc3RyaW5naWZ5LmpzIiwibm9kZV9tb2R1bGVzL3JhdmVuLWpzL3ZlbmRvci9tZDUvbWQ1LmpzIiwibm9kZV9tb2R1bGVzL3VybC91cmwuanMiLCJub2RlX21vZHVsZXMvdXJsL3V0aWwuanMiLCJub2RlX21vZHVsZXMvdXVpZC9saWIvYnl0ZXNUb1V1aWQuanMiLCJub2RlX21vZHVsZXMvdXVpZC9saWIvcm5nLWJyb3dzZXIuanMiLCJub2RlX21vZHVsZXMvdXVpZC9saWIvc2hhMS1icm93c2VyLmpzIiwibm9kZV9tb2R1bGVzL3V1aWQvbGliL3YzNS5qcyIsIm5vZGVfbW9kdWxlcy91dWlkL3Y0LmpzIiwibm9kZV9tb2R1bGVzL3V1aWQvdjUuanMiLCJub2RlX21vZHVsZXMvdXVpZHY0L2xpYi91dWlkdjQuanMiLCJ3d3cvYXBwL2FwcC5qcyIsInd3dy9hcHAvY2xpcGJvYXJkLmpzIiwid3d3L2FwcC9jb3Jkb3ZhX21haW4uanMiLCJ3d3cvYXBwL2Vudmlyb25tZW50LmpzIiwid3d3L2FwcC9lcnJvcl9yZXBvcnRlci5qcyIsInd3dy9hcHAvZmFrZV9jb25uZWN0aW9uLmpzIiwid3d3L2FwcC9tYWluLmpzIiwid3d3L2FwcC9vdXRsaW5lX3NlcnZlci5qcyIsInd3dy9hcHAvcGVyc2lzdGVudF9zZXJ2ZXIuanMiLCJ3d3cvYXBwL3NldHRpbmdzLmpzIiwid3d3L2FwcC91cGRhdGVyLmpzIiwid3d3L2FwcC91cmxfaW50ZXJjZXB0b3IuanMiLCJ3d3cvbW9kZWwvZXJyb3JzLmpzIiwid3d3L21vZGVsL2V2ZW50cy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVBLFFBQUEsb0JBQW9CLFNBQUEsdUJBQUEsR0FBQTtBQUNkLFlBQUEsT0FBUyxNQUFULEtBQW1CLFdBQW5CLElBQThCLE9BQVksT0FBMUMsRUFBMEM7QUFDMUMsbUJBQVMsT0FBRyxPQUFaLENBRDBDLENBQ2xCO0FBQ3hCLFNBRkEsTUFFQSxJQUFTLE9BQUcsTUFBSCxLQUFvQixXQUE3QixFQUF1QztBQUN2QyxtQkFBTSxNQUFOLENBRHVDLENBQ3JCO0FBQ2xCO0FBQ0YsY0FBQyxJQUFTLEtBQVQsQ0FBVyx1RUFBWCxDQUFEO0FBQ0YsS0FQa0IsRUFBcEI7QUFTQTtBQUNBLFFBQUEsWUFBQSxPQUFtQixNQUFuQixLQUFtQixXQUFuQjtBQUVBLFFBQUEsWUFBQSxZQUEwQixJQUExQixHQUEwQixRQUFBLFNBQUEsRUFBQSxNQUExQjtBQUNBLFFBQUEsWUFBQSxZQUFBLElBQUEsR0FBQSxRQUFBLFNBQUEsRUFBQSxNQUFBO1FBQTRDLE1BQUEsWUFBQSxPQUFBLEdBQUEsR0FBQSxRQUFBLEtBQUEsRUFBSyxHO1FBQy9DLFdBQUEsWUFBQSxPQUFBLFFBQUEsR0FBMkIsUUFBQSxVQUFBLEM7O0FBQTNCLGNBQUEsSUFBQSxLQUFBLENBQ0UsNkhBREYsQ0FBQTtBQUVFO0FBQ0E7O1FBQ0YseUJBQUMsYUFBQSxVQUFBLE1BQUEsRUFBQTtBQUNILGtCQUFBLHNCQUFBLEVBQUMsTUFBRDtBQU40QyxpQkFNM0Msc0JBTjJDLENBTTNDLE9BTjJDLEVBTTNDO0FBTlksZ0JBQUEsYUFBQSxLQUFBLFdBQUE7QUFRYixnQkFBQSxRQUFBLE9BQUEsSUFBQSxDQUFBLElBQUEsRUFBQSxPQUFBLEtBQUEsSUFBQTtBQUF3QyxtQkFBQSxjQUFBLENBQUEsS0FBQSxFQUFBLFdBQXNCLFNBQXRCLEVBRnZDLENBRTZEO0FBQTlELGtCQUFBLElBQUEsR0FBQSxXQUFBLElBQUE7O0FBQWlFO0FBQUQsZUFBQSxzQkFBQTtBQUFDLEtBSDlELENBR3FDLEtBSHJDLEM7QUFHVSxzQkFBQSxzQkFBQSxHQUFBLHNCQUFBO0FBRWIsUUFBQSxxQkFBQSxhQUFBLFVBQUEsTUFBQSxFQUFBO0FBQWdDLGtCQUFBLGtCQUFBLEVBQXNCLE1BQXRCO0FBQWhDLGlCQUFBLGtCQUFBLEdBQUE7O0FBQXlEO0FBQUQsZUFBQSxrQkFBQTtBQUFDLEtBQXpELENBQWdDLHNCQUFoQyxDQUFBO0FBQWEsc0JBQUEsa0JBQUEsR0FBVSxrQkFBVjtBQUViLFFBQUEsYUFBQSxhQUFBLFVBQUEsTUFBQSxFQUFBO0FBQ0Esa0JBQUEsVUFBQSxFQUFBLE1BQUE7QUFDQSxpQkFBQSxVQUFBLEdBQUE7QUFBQSxtQkFBQSxXQUFBLElBQUEsSUFBQSxPQUFBLEtBQUEsQ0FBQSxJQUFBLEVBQUEsU0FBQSxDQUFBLElBQUEsSUFBQTtBQUE2QztBQUFELGVBQUEsVUFBQTtBQUFDLEtBRjdDLENBRTZDLHNCQUY3QyxDQUFBO0FBRXNCLHNCQUFBLFVBQUEsR0FBQSxVQUFBO0FBRXRCO0FBQ0U7QUFDRixRQUFDLHVCQUFBLGFBQUEsWUFBQTtBQUVELGlCQUFBLG9CQUFBLEdBQUEsQ0FBMEI7QUFTeEIsZUFBQSxvQkFBQTtBQUFBLEtBWEQsRUFBRDtBQWFJLHNCQUFVLG9CQUFWLEdBQVksb0JBQVo7YUFDRSx5QixDQUFBLEksRUFBMEIsSyxFQUFRLE0sRUFBTTtBQUMxQyxjQUFDLElBQUEsa0JBQUEsQ0FBQSxhQUFBLElBQUEsR0FBQSxJQUFBLEdBQUEsS0FBQSxHQUFBLEdBQUEsSUFBQSxVQUFBLEVBQUEsQ0FBQSxDQUFEO0FBQ0E7ZUFDRSxhQUFZLFVBQUssTUFBTCxFQUFLO0FBQ25CLGtCQUFDLElBQUQsRUFBQyxNQUFEO0FBQ0EsaUJBQUksSUFBSixDQUFPLElBQVAsRUFBZ0I7QUFDaEIsZ0JBQUEsUUFBVyxPQUFPLElBQVAsQ0FBUSxJQUFSLEtBQXFCLElBQWhDO0FBQ0EsZ0JBQUEsQ0FBSSxJQUFKLEVBQUs7QUFDTCwwQ0FBdUIsTUFBdkIsRUFBaUMsSUFBakM7QUFDQTtnQkFDRSxnQkFBQSxJLEVBQUE7QUFDRCx1QkFBQSxLQUFBLElBQUE7QUFDRDs7QUFDRCxrQkFBQSxNQUFBLEdBQUEsS0FBQSxZQUFBLENBQUEsSUFBQSxDQUFBLElBQUEsQ0FBQTtBQXhCYSxrQkFBQSxNQUFBLEdBQVksTUFBRyxNQUFILEdBQUcsS0FBSCxHQUFHLEtBQUEsWUFBQSxDQUFrQyxJQUFsQyxDQUFrQyxJQUFsQyxDQUFmO0FBQ0Esa0JBQUEsVUFBQSxHQUFlLE1BQUEsTUFBQSxJQUFBLE1BQUEsTUFBQSxHQUFBLEtBQUEsR0FBd0MsS0FBQSxnQkFBQSxDQUFBLElBQUEsQ0FBQSxJQUFBLENBQXZEO0FBQ0EsZ0JBQUEsRUFBQSxNQUFBLE1BQUEsSUFBbUIsTUFBQSxNQUFuQixJQUFtQixNQUFBLFVBQW5CLENBQUEsRUFBNkM7QUF1QjdELDBDQUFDLE1BQUQsRUFBQyxJQUFEO0FBMUIwQjtBQUFiLGtCQUFBLElBQUEsR0FBSSxJQUFKO0FBNEJiLG1CQUFBLEtBQUE7QUFBMEI7QUFJeEIsYUFBQSxZQUFBLEdBQXdDLGlDQUF4QztBQUFBLGFBQUEsWUFBQSxHQUNFLHVDQURGO0FBRUUsYUFBQSxnQkFBQSxHQUFvQix5QkFBcEI7ZUFDRSxJO0tBcEJZLENBcUJkLG9CQXJCYyxDO0FBc0JkLHNCQUFJLElBQUosR0FBZSxJQUFmO2VBQ0UsYUFBQSxVQUFBLE1BQUEsRUFBQTtBQUNBLGtCQUFBLElBQUEsRUFBTyxNQUFQO0FBQ0YsaUJBQUMsSUFBRCxDQUFDLElBQUQsRUFBQztBQUNELGdCQUFJLFFBQU0sT0FBUSxJQUFSLENBQWEsSUFBYixLQUFxQixJQUEvQjtnQkFDRSxnQkFBQSxJLEVBQUE7QUFDRCx1QkFBQSxLQUFBLElBQUE7QUFDRDtBQUNBLGdCQUFBLE9BQUEsSUFBQSxLQUFBLFFBQUEsRUFBQTtBQUNJO0FBQ0EsdUJBQU8sS0FBSyxRQUFMLEVBQVA7QUFDRjtBQUNGLGdCQUFDLENBQUEsS0FBQSxPQUFBLENBQUEsSUFBQSxDQUFBLElBQUEsQ0FBRCxFQUFDO0FBQ0QsMENBQWlCLE1BQWpCLEVBQWlCLElBQWpCOztBQUNEO0FBdEJzQjtBQXVCekIsbUJBQUMsT0FBQSxJQUFBLENBQUQ7QUF4QjBCLGdCQUFBLE9BQUEsS0FBQSxFQXdCekI7QUF4QlksMENBQUksTUFBSixFQUFJLElBQUo7QUEwQmI7QUFDQSxrQkFBQSxJQUFBLEdBQUEsSUFBQTtBQUNhLG1CQUFPLEtBQVA7QUFDWDtBQUNBLGFBQUEsT0FBQSxHQUFhLGNBQWI7QUFDQSxlQUFBLElBQUE7S0FyQkksQ0FzQkosb0JBdEJJLEM7QUF1Qkosc0JBQWEsSUFBYixHQUFhLElBQWI7QUFDQTtBQUNBO0FBQ0Esc0JBQWEsT0FBYixHQUFhLElBQUEsR0FBQSxDQUFBLENBQ2IsU0FEYSxFQUViLGFBRmEsRUFHYixhQUhhLEVBSWIsYUFKYSxFQUtiLGFBTGEsRUFNYixhQU5hLEVBT2IsYUFQYSxFQVFiLGFBUmEsRUFTYixhQVRhLEVBVWIsYUFWYSxFQVdiLGtCQVhhLEVBWVosa0JBWlksRUFjZixrQkFkZSxFQWNhLFFBZGIsRUFnQmIsd0JBaEJhLEVBZ0JiLFNBaEJhLEVBa0JYLFVBbEJXLEVBbUJULGVBbkJTLEVBb0JYLHlCQXBCVyxDQUFBLENBQWI7UUFzQkksU0FBQSxhQUFBLFVBQTBCLE1BQTFCLEVBQWtDO0FBQ3BDLGtCQUFDLE1BQUQsRUFBQyxNQUFEO0FBQ0EsaUJBQUksTUFBSixDQUFTLE1BQVQsRUFBbUI7O0FBQ3BCLGdCQUFBLGtCQUFBLE1BQUEsRUFBQTtBQUNILHlCQUFDLE9BQUEsSUFBRDtBQVo0QjtBQUFmLGdCQUFBLENBQUEsa0JBQU0sT0FBTixDQUFNLEdBQU4sQ0FBTSxNQUFOLENBQUEsRUFBTTtBQWNuQiwwQ0FBQSxRQUFBLEVBQUEsTUFBQTtBQUE4QjtBQUc1QixrQkFBQSxJQUFBLEdBQUEsTUFBQTtBQUFBLG1CQUFBLEtBQUE7QUFFRTs7S0FYRSxDQVlKLG9CQVpJLEM7QUFhTixzQkFBQSxNQUFBLEdBQUMsTUFBRDtBQVBBLFFBQThCLFdBQUEsYUFPN0IsVUFBQSxNQUFBLEVBQUE7QUFQWSxrQkFBQSxRQUFBLEVBQUEsTUFBQTtBQVNiLGlCQUFBLFFBQUEsQ0FBQSxRQUFBLEVBQUE7QUFBeUIsZ0JBQUEsUUFBQSxPQUFvQixJQUFwQixDQUFvQixJQUFwQixLQUFvQixJQUFwQjtBQUd2QixrQkFBQSxJQUFBLEdBQWtDLG9CQUFBLFFBQUEsR0FBQSxTQUFBLElBQUEsR0FBQSxRQUFsQztBQUFZLG1CQUFBLEtBQUE7QUFBWjtBQUVFLGVBQUEsUUFBQTtLQVBILEMsb0JBQUEsQ0FQRDtBQWVFLHNCQUFDLFFBQUQsR0FBQyxRQUFEO1FBQ0YsTUFBQSxhQUFDLFVBQUEsTUFBQSxFQUFBO0FBUHdCLGtCQUFBLEdBQUEsRUFBQSxNQUFBO0FBQVosaUJBQUEsR0FBQSxDQUFBLEdBQUEsRUFBRztBQW1CaEIsZ0JBQUEsUUFBQSxLQUFBLENBQUEsRUFBQTtBQUFBLHNCQUFrQyxFQUFsQztBQUFrQztBQUNsQyxnQkFBQSxRQUEyQixPQUEyQixJQUEzQixDQUEyQixJQUEzQixLQUEyQixJQUF0RDtBQUNFLGtCQUFBLElBQUEsR0FBQSxlQUFBLEdBQUEsR0FBQSxJQUFBLElBQUEsR0FBQSxHQUFBO0FBQ0EsbUJBQUEsS0FBQTtBQUNBO0FBQ0UsZUFBQSxHQUFBO0tBakJILENBa0JHLG9CQWxCSCxDO0FBbUJHLHNCQUFRLEdBQVIsR0FBWSxHQUFaO0FBQ0E7QUFDQSxhQUFBLFVBQUEsQ0FBWSxLQUFaLEVBQW1CO0FBQ25CO0FBQ0Q7QUFDRCxZQUFBLFNBQUE7QUFDSSxrQkFBYyxJQUFBLElBQUEsQ0FBQSxNQUFBLElBQUEsQ0FEbEI7QUFDSyxrQkFBTSxJQUFHLElBQUgsQ0FBRyxNQUFBLElBQUgsQ0FEWDtBQUVFLG9CQUFLLElBQUEsTUFBQSxDQUFBLE1BQUEsTUFBQSxDQUZQO0FBR0ksc0JBQU0sSUFBQyxRQUFELENBQVcsTUFBUSxRQUFuQixDQUhWO0FBSUUsaUJBQUMsSUFBQSxHQUFBLENBQUEsTUFBQSxHQUFBLENBSkg7QUFLQyxtQkFBQTtBQUxELFNBQUE7QUFPRDtBQWxCRCxhQUFBLElBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxPQWtCQyxJQWxCRCxDQWtCQyxLQWxCRCxDQUFBLEVBa0JDLEtBQUEsR0FBQSxNQWxCRCxFQWtCQyxJQWxCRCxFQWtCQztBQUVZLGdCQUFBLE1BQUEsR0FBQSxFQUFBLENBQUE7QUFDWCxnQkFBUSxDQUFBLG9DQUFPLElBQVAsQ0FBTyxHQUFQLENBQVIsRUFBZTtBQUVmLHVCQUFBLEtBQUEsQ0FBcUIsR0FBckIsSUFBcUIsTUFBQyxHQUFELEtBQVcsTUFBQSxHQUFBLEVBQUEsUUFBQSxFQUFoQztBQUNFO0FBQ0Q7QUFFRCxlQUFPLE1BQVA7QUFDRTtBQUNGLHNCQUFDLFVBQUQsR0FBQyxVQUFEO0FBRUEsc0JBQUEsZUFBQSxHQUE4QjtBQUM1QixrQkFBSyxLQUR1QjtBQUUxQiw2QkFBVSw2QkFBVyxJQUFYLEVBQVc7QUFDdkIsbUJBQUMsS0FBQSxNQUFBLEdBQUEsTUFBQSxLQUFBLElBQUEsR0FBQSxHQUFBLEdBQUEsS0FBQSxJQUFEO0FBQ0QsU0FKNkI7QUFNOUIsaUJBQU8saUJBQUMsR0FBRCxFQUFZO0FBQ2pCLG1CQUFJLElBQXlCLElBQXpCLEdBQXlCLE1BQUEsbUJBQUEsSUFBQSxJQUFBLENBQXpCLEdBQXlCLEVBQTdCO0FBQ0EsU0FSNEI7QUFRdkIsMEJBQU0sMEJBQU8sR0FBUCxFQUFPO2dCQUNoQixDQUFBLElBQUssVUFBTCxDQUFLLGtCQUFBLGVBQUEsQ0FBQSxRQUFMLEMsRUFBSztBQUNILHNCQUFBLElBQU0sVUFBTixDQUFlLDJCQUFXLGtCQUFBLGVBQUEsQ0FBQSxRQUFYLEdBQVcsSUFBMUIsQ0FBQTtBQUNGO0FBQUUsU0FYd0I7ZUFZeEIsZUFBSyxHQUFMLEVBQVU7Z0JBQ1osSztBQUNELGlCQUFBLElBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxDQUFBLGtCQUFBLFVBQUEsRUFBQSxrQkFBQSxpQkFBQSxDQUFBLEVBQUEsS0FBQSxHQUFBLE1BQUEsRUFBQSxJQUFBLEVBQUE7QUFDRyxvQkFBRSxVQUFLLEdBQUEsRUFBQSxDQUFQO0FBQ0Ysb0JBQU07QUFDQSwyQkFBQSxRQUFBLEtBQUEsQ0FBb0IsR0FBcEIsQ0FBQTtBQUNOLGlCQUZBLENBR0EsT0FBTSxDQUFOLEVBQU07QUFDTiw0QkFBWSxDQUFaO0FBQ0Q7QUFDRDtBQUNELGdCQUFBLEVBQUEsaUJBQUEsVUFBQSxDQUFBLEVBQUE7QUFDRCxvQkFBQSxvQkFBQSxNQUFBLElBQUEsSUFBQSxpQkFBQTtBQUVGLG9CQUFBLHVCQUFBLE1BQUEsT0FBQSxJQUFBLDZCQUFBO0FBQ2Esb0JBQUEsc0JBQW9CLG9CQUFBLElBQUEsR0FBQSxvQkFBcEI7QUFDSixvQkFBQSxrQkFBWSxvQkFBQSxtQkFBWjtBQUNMLHdCQUFBLElBQUEsVUFBQSxDQUFnQixlQUFoQixDQUFBO0FBQ0E7QUFDQSxrQkFBTSxLQUFOO0FBQ0E7QUFoQzRCLEtBQTlCO0FBa0NFO0FBQ0Esc0JBQU0saUJBQU4sR0FBMkI7QUFDM0IsZUFBQSxlQUFNLEdBQU4sRUFBb0I7QUFDcEIsOEJBQW9CLGVBQXBCLENBQW1DLGdCQUFuQyxDQUFvRCxHQUFwRDtBQUNBLGdCQUFJLFlBQVcsSUFBSyxPQUFMLENBQVUsR0FBVixDQUFmO2dCQUNFLFNBQU0sY0FBZSxDQUFBLEM7QUFDdkIsZ0JBQUMsY0FBQSxTQUFBLFNBQUEsR0FBQSxJQUFBLE1BQUQ7QUFDQSxnQkFBTSxnQkFBQSxTQUFvQixZQUFlLENBQW5DLEdBQW1DLElBQVUsTUFBbkQ7QUFDQSxnQkFBTSxNQUFBLElBQUEsR0FBQSxDQUFjLG1CQUFHLElBQWtCLFNBQWxCLENBQThCLGFBQTlCLENBQUgsQ0FBZCxDQUFOO0FBQ0EsZ0JBQUksaUJBQWMsSUFBTyxTQUFQLENBQVUsUUFBQSxNQUFWLEVBQVUsV0FBVixDQUFsQjtnQkFDRSxpQkFBVSxVQUFXLGNBQVgsQztBQUNaLGdCQUFDLGNBQUEsZUFBQSxXQUFBLENBQUEsR0FBQSxDQUFEO0FBQ0EsZ0JBQU0sZ0JBQWUsQ0FBQSxDQUFyQixFQUFxQjtBQUNmLHNCQUFNLElBQUcsVUFBSCxDQUFjLGVBQWQsQ0FBTjtBQUNOO0FBQ0EsZ0JBQU0sb0JBQWlCLGVBQWtCLFNBQWxCLENBQTRCLENBQTVCLEVBQTRCLFdBQTVCLENBQXZCO0FBQ0EsZ0JBQU0saUJBQWUsa0JBQVMsT0FBVCxDQUF5QixHQUF6QixDQUFyQjtBQUNBLGdCQUFNLG1CQUFpQixDQUFBLENBQXZCLEVBQXVCO0FBQ2pCLHNCQUFBLElBQUEsVUFBQSxDQUFjLGtCQUFkLENBQUE7QUFDTjtBQUNBLGdCQUFJLGVBQVksa0JBQVUsU0FBVixDQUFVLENBQVYsRUFBVSxjQUFWLENBQWhCO2dCQUNFLFNBQU0sSUFBSSxNQUFKLENBQWMsWUFBZCxDO0FBQ1IsZ0JBQUMscUJBQUEsaUJBQUEsQ0FBRDtBQUNBLGdCQUFNLGlCQUFnQixrQkFBZSxTQUFmLENBQTRCLGtCQUE1QixDQUF0QjtBQUNBLGdCQUFJLFdBQVcsSUFBQSxRQUFBLENBQUEsY0FBQSxDQUFmO0FBQ0EsZ0JBQUksaUJBQUMsY0FBQSxDQUFMO2dCQUNFLGNBQVcsZUFBSyxTQUFMLENBQXVCLGNBQXZCLEM7QUFDYixnQkFBQyxlQUFBLFlBQUEsV0FBQSxDQUFBLEdBQUEsQ0FBRDtBQUFFLGdCQUFBLGlCQUFXLENBQUEsQ0FBWCxFQUFXO0FBQ1gsc0JBQUEsSUFBQSxVQUFBLENBQUEsY0FBQSxDQUFBO0FBQ0E7Z0JBQ0EsbUJBQWdCLFlBQUEsU0FBQSxDQUFpQixDQUFqQixFQUE0QixZQUE1QixDO0FBQ2xCLGdCQUFDLElBQUQ7QUFDQSxnQkFBTTtBQUNBLHVCQUFBLElBQVUsSUFBVixDQUFhLGdCQUFiLENBQUE7QUFDTixhQUZBLENBR0EsT0FBTSxDQUFOLEVBQVc7QUFDWDtBQUNEO0FBRUQsdUJBQVcsSUFBQSxJQUFBLENBQUMsaUJBQWMsU0FBZCxDQUFjLENBQWQsRUFBYyxpQkFBQSxNQUFBLEdBQUEsQ0FBZCxDQUFELENBQVg7QUFDUztBQUNQLGdCQUFNLGlCQUFPLGVBQWdCLENBQTdCO0FBQ0EsZ0JBQUksYUFBQSxZQUFpQixTQUFqQixDQUFxQyxjQUFyQyxDQUFKO0FBQ0EsZ0JBQU0sT0FBQSxJQUFVLElBQVYsQ0FBYSxVQUFiLENBQU47QUFDQSxnQkFBSSxRQUFBLEVBQUosQ0ExQ29CLENBMENoQjtBQUNKLG1CQUFPLEVBQUEsUUFBQSxNQUFBLEVBQWUsVUFBYSxRQUE1QixFQUFnQyxNQUFBLElBQWhDLEVBQThDLE1BQVUsSUFBeEQsRUFBd0QsS0FBQSxHQUF4RCxFQUF1RSxPQUFBLEtBQXZFLEVBQVA7QUFBK0UsU0E1Q3BEO0FBNkMzQixtQkFBQSxtQkFBaUIsTUFBakIsRUFBaUI7Z0JBQ2IsT0FBQSxPQUFjLEk7Z0JBQUMsT0FBVyxPQUFFLEk7Z0JBQVUsU0FBRyxPQUFlLE07Z0JBQUEsV0FBQSxPQUFBLFE7Z0JBQUEsTUFBQSxPQUFBLEc7QUFDNUQsZ0JBQUEsT0FBTyxrQkFBUSxlQUFSLENBQWdDLE9BQWhDLENBQWdDLEdBQWhDLENBQVA7QUFDRCxnQkFBQSxpQkFBQSxVQUFBLE9BQUEsSUFBQSxHQUFBLEdBQUEsR0FBQSxTQUFBLElBQUEsR0FBQSxHQUFBLEdBQUEsS0FBQSxJQUFBLEdBQUEsR0FBQSxHQUFBLEtBQUEsSUFBQSxDQUFBO0FBQ0QsZ0JBQUEsYUFBQSxlQUFBLE1BQUE7QUFFRixnQkFBQSxnQkFBQSxDQUFBO0FBQ2EsbUJBQUEsZUFBYSxhQUFBLENBQUEsR0FBQSxhQUFiLE1BQWEsR0FBYixFQUFhLGVBQWI7QUFFVCw2QkFBQSxrQkFBZ0IsQ0FBaEIsR0FBZ0IsY0FBaEIsR0FDQSxlQUFBLFNBQUEsQ0FBQSxDQUFBLEVBQUEsYUFBQSxhQUFBLENBREE7QUFFQSxtQkFBQSxVQUFBLGNBQUEsR0FBQSxJQUFBO0FBQ0E7QUF6RDJCLEtBQTNCO0FBMkRBO0FBQ0Esc0JBQU0sVUFBTixHQUF5QjtBQUN6QixlQUFBLGVBQUEsR0FBQSxFQUFBO0FBQ0EsOEJBQWEsZUFBYixDQUFvQyxnQkFBcEMsQ0FBeUMsR0FBekM7QUFDQTtBQUNBO0FBQ0EsZ0JBQU0sb0JBQWdCLFNBQVksSUFBQSxTQUFBLENBQUEsQ0FBQSxDQUFsQztBQUNBO0FBQ0EsZ0JBQUksa0JBQWtCLElBQUMsR0FBRCxDQUFPLGlCQUFQLENBQXRCO2dCQUNFLG1CQUFBLGdCQUFBLFE7QUFDQTtnQkFDQSxPQUFBLGlCQUFnQixNQUFoQixHQUFnQixDO0FBQ2xCLGdCQUFDLFdBQUEsaUJBQUEsQ0FBQSxNQUFBLEdBQUEsSUFBQSxpQkFBQSxJQUFBLE1BQUEsR0FBRDtBQUNBLGdCQUFNLGFBQVcsV0FBSyxpQkFBWSxTQUFaLENBQVksQ0FBWixFQUFZLElBQVosQ0FBTCxHQUFpQixnQkFBbEM7QUFDQSxnQkFBTSxPQUFNLElBQUksSUFBSixDQUFRLFVBQVIsQ0FBWjtBQUNBLGdCQUFNLGFBQUEsZ0JBQXFCLElBQTNCO0FBQ0EsZ0JBQUEsQ0FBQSxVQUFBLElBQUEsSUFBQSxLQUFBLENBQUEsWUFBQSxDQUFBLEVBQUE7QUFDTTtBQUNBO0FBQ0YsNkJBQWEsRUFBYjtBQUNGO0FBQ0YsZ0JBQUMsT0FBQSxJQUFBLElBQUEsQ0FBQSxVQUFBLENBQUQ7QUFDQSxnQkFBTSxNQUFBLElBQUEsR0FBQSxDQUFZLG1CQUFxQixnQkFBYyxJQUFkLENBQWMsU0FBZCxDQUF3QixDQUF4QixDQUFyQixDQUFaLENBQU47QUFDQSxnQkFBTSxxQkFBb0IsZ0JBQWMsUUFBZCxDQUFjLE9BQWQsQ0FBYyxNQUFkLEVBQWMsR0FBZCxDQUExQjtBQUNBO0FBQ0EsZ0JBQU0scUJBQWUsVUFBUyxrQkFBVCxDQUFyQjtBQUNBLGdCQUFNLFdBQVcsbUJBQW1CLE9BQW5CLENBQTBCLEdBQTFCLENBQWpCO0FBQ0EsZ0JBQU0sYUFBc0MsQ0FBQSxDQUE1QyxFQUE0QztBQUN4QyxzQkFBZSxJQUFBLFVBQUEsQ0FBQSxrQkFBQSxDQUFmO0FBQUM7Z0JBQ0csZUFBQSxtQkFBQyxTQUFELENBQU0sQ0FBTixFQUFNLFFBQU4sQztnQkFDTixTQUFTLElBQUEsTUFBQSxDQUFBLFlBQUEsQztnQkFBQyxpQkFBUyxtQkFBQSxTQUFBLENBQUEsV0FBQSxDQUFBLEM7Z0JBQ25CLFdBQVUsSUFBRyxRQUFILENBQUcsY0FBSCxDO0FBQ1gsZ0JBQUEsY0FBQSxnQkFBQSxNQUFBLENBQUEsU0FBQSxDQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsR0FBQSxDQUFBO0FBQ0QsZ0JBQUEsUUFBUSxFQUFSO0FBQ0QsaUJBQUEsSUFBQSxLQUFBLENBQUEsRUFBQSxnQkFBQSxXQUFBLEVBQUEsS0FBQSxjQUFBLE1BQUEsRUFBQSxJQUFBLEVBQUE7QUFFRCxvQkFBVyxPQUFBLGNBQWUsRUFBZixDQUFYO0FBQ1Msb0JBQUEsS0FBQSxLQUFBLEtBQUEsQ0FBTSxHQUFOLEVBQU0sQ0FBTixDQUFBO0FBQUEsb0JBQU0sTUFBQSxHQUFJLENBQUosQ0FBTjtBQUFBLG9CQUFZLFFBQUEsR0FBQSxDQUFBLENBQVo7QUFDRCxvQkFBQSxDQUFBLEdBQUEsRUFDQTtBQUNBLHNCQUFJLEdBQUosSUFBTyxtQkFBZ0IsU0FBUSxFQUF4QixDQUFQO0FBQ047QUFDQSxtQkFBSyxFQUFNLFFBQU8sTUFBYixFQUFxQixVQUFBLFFBQXJCLEVBQXFCLE1BQUEsSUFBckIsRUFBcUIsTUFBQSxJQUFyQixFQUFxQixLQUFBLEdBQXJCLEVBQXFCLE9BQUEsS0FBckIsRUFBTDtBQUNFLFNBMUN1QjttQkEwQ2IsbUJBQVMsTUFBVCxFQUFTO2dCQUNuQixPQUFBLE9BQVcsSTtnQkFBSyxPQUFXLE9BQU8sSTtnQkFBTSxTQUFTLE9BQUksTTtnQkFBQSxXQUFtQixPQUFNLFE7Z0JBQVEsTUFBQSxPQUFBLEc7Z0JBQUEsUUFBQSxPQUFBLEs7QUFDeEYsZ0JBQUMsV0FBQSxVQUFBLE9BQUEsSUFBQSxHQUFBLEdBQUEsR0FBQSxTQUFBLElBQUEsQ0FBRDtBQUNBLGdCQUFBLFVBQU8sa0JBQWdCLGVBQWhCLENBQTJCLG1CQUEzQixDQUE0QyxJQUE1QyxDQUFQO0FBQ0QsZ0JBQUEsT0FBQSxrQkFBQSxlQUFBLENBQUEsT0FBQSxDQUFBLEdBQUEsQ0FBQTtBQUNELGdCQUFBLGNBQUEsRUFBQTs7Ozs7OztBQS9DMkIsS0FBekI7Ozs7Ozs7OztBQ3RTSjtBQUNBLENBQUUsV0FBUyxJQUFULEVBQWU7O0FBRWhCO0FBQ0EsS0FBSSxjQUFjLFFBQU8sT0FBUCx5Q0FBTyxPQUFQLE1BQWtCLFFBQWxCLElBQThCLE9BQWhEOztBQUVBO0FBQ0EsS0FBSSxhQUFhLFFBQU8sTUFBUCx5Q0FBTyxNQUFQLE1BQWlCLFFBQWpCLElBQTZCLE1BQTdCLElBQ2hCLE9BQU8sT0FBUCxJQUFrQixXQURGLElBQ2lCLE1BRGxDOztBQUdBO0FBQ0E7QUFDQSxLQUFJLGFBQWEsUUFBTyxNQUFQLHlDQUFPLE1BQVAsTUFBaUIsUUFBakIsSUFBNkIsTUFBOUM7QUFDQSxLQUFJLFdBQVcsTUFBWCxLQUFzQixVQUF0QixJQUFvQyxXQUFXLE1BQVgsS0FBc0IsVUFBOUQsRUFBMEU7QUFDekUsU0FBTyxVQUFQO0FBQ0E7O0FBRUQ7O0FBRUEsS0FBSSx3QkFBd0IsU0FBeEIscUJBQXdCLENBQVMsT0FBVCxFQUFrQjtBQUM3QyxPQUFLLE9BQUwsR0FBZSxPQUFmO0FBQ0EsRUFGRDtBQUdBLHVCQUFzQixTQUF0QixHQUFrQyxJQUFJLEtBQUosRUFBbEM7QUFDQSx1QkFBc0IsU0FBdEIsQ0FBZ0MsSUFBaEMsR0FBdUMsdUJBQXZDOztBQUVBLEtBQUksUUFBUSxTQUFSLEtBQVEsQ0FBUyxPQUFULEVBQWtCO0FBQzdCO0FBQ0E7QUFDQSxRQUFNLElBQUkscUJBQUosQ0FBMEIsT0FBMUIsQ0FBTjtBQUNBLEVBSkQ7O0FBTUEsS0FBSSxRQUFRLGtFQUFaO0FBQ0E7QUFDQSxLQUFJLHlCQUF5QixjQUE3Qjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUksU0FBUyxTQUFULE1BQVMsQ0FBUyxLQUFULEVBQWdCO0FBQzVCLFVBQVEsT0FBTyxLQUFQLEVBQ04sT0FETSxDQUNFLHNCQURGLEVBQzBCLEVBRDFCLENBQVI7QUFFQSxNQUFJLFNBQVMsTUFBTSxNQUFuQjtBQUNBLE1BQUksU0FBUyxDQUFULElBQWMsQ0FBbEIsRUFBcUI7QUFDcEIsV0FBUSxNQUFNLE9BQU4sQ0FBYyxNQUFkLEVBQXNCLEVBQXRCLENBQVI7QUFDQSxZQUFTLE1BQU0sTUFBZjtBQUNBO0FBQ0QsTUFDQyxTQUFTLENBQVQsSUFBYyxDQUFkO0FBQ0E7QUFDQSxtQkFBaUIsSUFBakIsQ0FBc0IsS0FBdEIsQ0FIRCxFQUlFO0FBQ0QsU0FDQyx1RUFERDtBQUdBO0FBQ0QsTUFBSSxhQUFhLENBQWpCO0FBQ0EsTUFBSSxVQUFKO0FBQ0EsTUFBSSxNQUFKO0FBQ0EsTUFBSSxTQUFTLEVBQWI7QUFDQSxNQUFJLFdBQVcsQ0FBQyxDQUFoQjtBQUNBLFNBQU8sRUFBRSxRQUFGLEdBQWEsTUFBcEIsRUFBNEI7QUFDM0IsWUFBUyxNQUFNLE9BQU4sQ0FBYyxNQUFNLE1BQU4sQ0FBYSxRQUFiLENBQWQsQ0FBVDtBQUNBLGdCQUFhLGFBQWEsQ0FBYixHQUFpQixhQUFhLEVBQWIsR0FBa0IsTUFBbkMsR0FBNEMsTUFBekQ7QUFDQTtBQUNBLE9BQUksZUFBZSxDQUFuQixFQUFzQjtBQUNyQjtBQUNBLGNBQVUsT0FBTyxZQUFQLENBQ1QsT0FBTyxlQUFlLENBQUMsQ0FBRCxHQUFLLFVBQUwsR0FBa0IsQ0FBakMsQ0FERSxDQUFWO0FBR0E7QUFDRDtBQUNELFNBQU8sTUFBUDtBQUNBLEVBbENEOztBQW9DQTtBQUNBO0FBQ0EsS0FBSSxTQUFTLFNBQVQsTUFBUyxDQUFTLEtBQVQsRUFBZ0I7QUFDNUIsVUFBUSxPQUFPLEtBQVAsQ0FBUjtBQUNBLE1BQUksYUFBYSxJQUFiLENBQWtCLEtBQWxCLENBQUosRUFBOEI7QUFDN0I7QUFDQTtBQUNBLFNBQ0MsaUVBQ0EsZUFGRDtBQUlBO0FBQ0QsTUFBSSxVQUFVLE1BQU0sTUFBTixHQUFlLENBQTdCO0FBQ0EsTUFBSSxTQUFTLEVBQWI7QUFDQSxNQUFJLFdBQVcsQ0FBQyxDQUFoQjtBQUNBLE1BQUksQ0FBSjtBQUNBLE1BQUksQ0FBSjtBQUNBLE1BQUksQ0FBSjtBQUNBLE1BQUksQ0FBSjtBQUNBLE1BQUksTUFBSjtBQUNBO0FBQ0EsTUFBSSxTQUFTLE1BQU0sTUFBTixHQUFlLE9BQTVCOztBQUVBLFNBQU8sRUFBRSxRQUFGLEdBQWEsTUFBcEIsRUFBNEI7QUFDM0I7QUFDQSxPQUFJLE1BQU0sVUFBTixDQUFpQixRQUFqQixLQUE4QixFQUFsQztBQUNBLE9BQUksTUFBTSxVQUFOLENBQWlCLEVBQUUsUUFBbkIsS0FBZ0MsQ0FBcEM7QUFDQSxPQUFJLE1BQU0sVUFBTixDQUFpQixFQUFFLFFBQW5CLENBQUo7QUFDQSxZQUFTLElBQUksQ0FBSixHQUFRLENBQWpCO0FBQ0E7QUFDQTtBQUNBLGFBQ0MsTUFBTSxNQUFOLENBQWEsVUFBVSxFQUFWLEdBQWUsSUFBNUIsSUFDQSxNQUFNLE1BQU4sQ0FBYSxVQUFVLEVBQVYsR0FBZSxJQUE1QixDQURBLEdBRUEsTUFBTSxNQUFOLENBQWEsVUFBVSxDQUFWLEdBQWMsSUFBM0IsQ0FGQSxHQUdBLE1BQU0sTUFBTixDQUFhLFNBQVMsSUFBdEIsQ0FKRDtBQU1BOztBQUVELE1BQUksV0FBVyxDQUFmLEVBQWtCO0FBQ2pCLE9BQUksTUFBTSxVQUFOLENBQWlCLFFBQWpCLEtBQThCLENBQWxDO0FBQ0EsT0FBSSxNQUFNLFVBQU4sQ0FBaUIsRUFBRSxRQUFuQixDQUFKO0FBQ0EsWUFBUyxJQUFJLENBQWI7QUFDQSxhQUNDLE1BQU0sTUFBTixDQUFhLFVBQVUsRUFBdkIsSUFDQSxNQUFNLE1BQU4sQ0FBYyxVQUFVLENBQVgsR0FBZ0IsSUFBN0IsQ0FEQSxHQUVBLE1BQU0sTUFBTixDQUFjLFVBQVUsQ0FBWCxHQUFnQixJQUE3QixDQUZBLEdBR0EsR0FKRDtBQU1BLEdBVkQsTUFVTyxJQUFJLFdBQVcsQ0FBZixFQUFrQjtBQUN4QixZQUFTLE1BQU0sVUFBTixDQUFpQixRQUFqQixDQUFUO0FBQ0EsYUFDQyxNQUFNLE1BQU4sQ0FBYSxVQUFVLENBQXZCLElBQ0EsTUFBTSxNQUFOLENBQWMsVUFBVSxDQUFYLEdBQWdCLElBQTdCLENBREEsR0FFQSxJQUhEO0FBS0E7O0FBRUQsU0FBTyxNQUFQO0FBQ0EsRUF6REQ7O0FBMkRBLEtBQUksU0FBUztBQUNaLFlBQVUsTUFERTtBQUVaLFlBQVUsTUFGRTtBQUdaLGFBQVc7QUFIQyxFQUFiOztBQU1BO0FBQ0E7QUFDQSxLQUNDLE9BQU8sTUFBUCxJQUFpQixVQUFqQixJQUNBLFFBQU8sT0FBTyxHQUFkLEtBQXFCLFFBRHJCLElBRUEsT0FBTyxHQUhSLEVBSUU7QUFDRCxTQUFPLFlBQVc7QUFDakIsVUFBTyxNQUFQO0FBQ0EsR0FGRDtBQUdBLEVBUkQsTUFRTyxJQUFJLGVBQWUsQ0FBQyxZQUFZLFFBQWhDLEVBQTBDO0FBQ2hELE1BQUksVUFBSixFQUFnQjtBQUFFO0FBQ2pCLGNBQVcsT0FBWCxHQUFxQixNQUFyQjtBQUNBLEdBRkQsTUFFTztBQUFFO0FBQ1IsUUFBSyxJQUFJLEdBQVQsSUFBZ0IsTUFBaEIsRUFBd0I7QUFDdkIsV0FBTyxjQUFQLENBQXNCLEdBQXRCLE1BQStCLFlBQVksR0FBWixJQUFtQixPQUFPLEdBQVAsQ0FBbEQ7QUFDQTtBQUNEO0FBQ0QsRUFSTSxNQVFBO0FBQUU7QUFDUixPQUFLLE1BQUwsR0FBYyxNQUFkO0FBQ0E7QUFFRCxDQW5LQyxZQUFEOzs7Ozs7Ozs7O0FDREQ7QUFDQSxDQUFFLFdBQVMsSUFBVCxFQUFlOztBQUVoQjtBQUNBLEtBQUksY0FBYyxRQUFPLE9BQVAseUNBQU8sT0FBUCxNQUFrQixRQUFsQixJQUE4QixPQUE5QixJQUNqQixDQUFDLFFBQVEsUUFEUSxJQUNJLE9BRHRCO0FBRUEsS0FBSSxhQUFhLFFBQU8sTUFBUCx5Q0FBTyxNQUFQLE1BQWlCLFFBQWpCLElBQTZCLE1BQTdCLElBQ2hCLENBQUMsT0FBTyxRQURRLElBQ0ksTUFEckI7QUFFQSxLQUFJLGFBQWEsUUFBTyxNQUFQLHlDQUFPLE1BQVAsTUFBaUIsUUFBakIsSUFBNkIsTUFBOUM7QUFDQSxLQUNDLFdBQVcsTUFBWCxLQUFzQixVQUF0QixJQUNBLFdBQVcsTUFBWCxLQUFzQixVQUR0QixJQUVBLFdBQVcsSUFBWCxLQUFvQixVQUhyQixFQUlFO0FBQ0QsU0FBTyxVQUFQO0FBQ0E7O0FBRUQ7Ozs7O0FBS0EsS0FBSSxRQUFKOzs7QUFFQTtBQUNBLFVBQVMsVUFIVDtBQUFBLEtBR3FCOztBQUVyQjtBQUNBLFFBQU8sRUFOUDtBQUFBLEtBT0EsT0FBTyxDQVBQO0FBQUEsS0FRQSxPQUFPLEVBUlA7QUFBQSxLQVNBLE9BQU8sRUFUUDtBQUFBLEtBVUEsT0FBTyxHQVZQO0FBQUEsS0FXQSxjQUFjLEVBWGQ7QUFBQSxLQVlBLFdBQVcsR0FaWDtBQUFBLEtBWWdCO0FBQ2hCLGFBQVksR0FiWjtBQUFBLEtBYWlCOztBQUVqQjtBQUNBLGlCQUFnQixPQWhCaEI7QUFBQSxLQWlCQSxnQkFBZ0IsY0FqQmhCO0FBQUEsS0FpQmdDO0FBQ2hDLG1CQUFrQiwyQkFsQmxCO0FBQUEsS0FrQitDOztBQUUvQztBQUNBLFVBQVM7QUFDUixjQUFZLGlEQURKO0FBRVIsZUFBYSxnREFGTDtBQUdSLG1CQUFpQjtBQUhULEVBckJUOzs7QUEyQkE7QUFDQSxpQkFBZ0IsT0FBTyxJQTVCdkI7QUFBQSxLQTZCQSxRQUFRLEtBQUssS0E3QmI7QUFBQSxLQThCQSxxQkFBcUIsT0FBTyxZQTlCNUI7OztBQWdDQTtBQUNBLElBakNBOztBQW1DQTs7QUFFQTs7Ozs7O0FBTUEsVUFBUyxLQUFULENBQWUsSUFBZixFQUFxQjtBQUNwQixRQUFNLElBQUksVUFBSixDQUFlLE9BQU8sSUFBUCxDQUFmLENBQU47QUFDQTs7QUFFRDs7Ozs7Ozs7QUFRQSxVQUFTLEdBQVQsQ0FBYSxLQUFiLEVBQW9CLEVBQXBCLEVBQXdCO0FBQ3ZCLE1BQUksU0FBUyxNQUFNLE1BQW5CO0FBQ0EsTUFBSSxTQUFTLEVBQWI7QUFDQSxTQUFPLFFBQVAsRUFBaUI7QUFDaEIsVUFBTyxNQUFQLElBQWlCLEdBQUcsTUFBTSxNQUFOLENBQUgsQ0FBakI7QUFDQTtBQUNELFNBQU8sTUFBUDtBQUNBOztBQUVEOzs7Ozs7Ozs7O0FBVUEsVUFBUyxTQUFULENBQW1CLE1BQW5CLEVBQTJCLEVBQTNCLEVBQStCO0FBQzlCLE1BQUksUUFBUSxPQUFPLEtBQVAsQ0FBYSxHQUFiLENBQVo7QUFDQSxNQUFJLFNBQVMsRUFBYjtBQUNBLE1BQUksTUFBTSxNQUFOLEdBQWUsQ0FBbkIsRUFBc0I7QUFDckI7QUFDQTtBQUNBLFlBQVMsTUFBTSxDQUFOLElBQVcsR0FBcEI7QUFDQSxZQUFTLE1BQU0sQ0FBTixDQUFUO0FBQ0E7QUFDRDtBQUNBLFdBQVMsT0FBTyxPQUFQLENBQWUsZUFBZixFQUFnQyxNQUFoQyxDQUFUO0FBQ0EsTUFBSSxTQUFTLE9BQU8sS0FBUCxDQUFhLEdBQWIsQ0FBYjtBQUNBLE1BQUksVUFBVSxJQUFJLE1BQUosRUFBWSxFQUFaLEVBQWdCLElBQWhCLENBQXFCLEdBQXJCLENBQWQ7QUFDQSxTQUFPLFNBQVMsT0FBaEI7QUFDQTs7QUFFRDs7Ozs7Ozs7Ozs7OztBQWFBLFVBQVMsVUFBVCxDQUFvQixNQUFwQixFQUE0QjtBQUMzQixNQUFJLFNBQVMsRUFBYjtBQUFBLE1BQ0ksVUFBVSxDQURkO0FBQUEsTUFFSSxTQUFTLE9BQU8sTUFGcEI7QUFBQSxNQUdJLEtBSEo7QUFBQSxNQUlJLEtBSko7QUFLQSxTQUFPLFVBQVUsTUFBakIsRUFBeUI7QUFDeEIsV0FBUSxPQUFPLFVBQVAsQ0FBa0IsU0FBbEIsQ0FBUjtBQUNBLE9BQUksU0FBUyxNQUFULElBQW1CLFNBQVMsTUFBNUIsSUFBc0MsVUFBVSxNQUFwRCxFQUE0RDtBQUMzRDtBQUNBLFlBQVEsT0FBTyxVQUFQLENBQWtCLFNBQWxCLENBQVI7QUFDQSxRQUFJLENBQUMsUUFBUSxNQUFULEtBQW9CLE1BQXhCLEVBQWdDO0FBQUU7QUFDakMsWUFBTyxJQUFQLENBQVksQ0FBQyxDQUFDLFFBQVEsS0FBVCxLQUFtQixFQUFwQixLQUEyQixRQUFRLEtBQW5DLElBQTRDLE9BQXhEO0FBQ0EsS0FGRCxNQUVPO0FBQ047QUFDQTtBQUNBLFlBQU8sSUFBUCxDQUFZLEtBQVo7QUFDQTtBQUNBO0FBQ0QsSUFYRCxNQVdPO0FBQ04sV0FBTyxJQUFQLENBQVksS0FBWjtBQUNBO0FBQ0Q7QUFDRCxTQUFPLE1BQVA7QUFDQTs7QUFFRDs7Ozs7Ozs7QUFRQSxVQUFTLFVBQVQsQ0FBb0IsS0FBcEIsRUFBMkI7QUFDMUIsU0FBTyxJQUFJLEtBQUosRUFBVyxVQUFTLEtBQVQsRUFBZ0I7QUFDakMsT0FBSSxTQUFTLEVBQWI7QUFDQSxPQUFJLFFBQVEsTUFBWixFQUFvQjtBQUNuQixhQUFTLE9BQVQ7QUFDQSxjQUFVLG1CQUFtQixVQUFVLEVBQVYsR0FBZSxLQUFmLEdBQXVCLE1BQTFDLENBQVY7QUFDQSxZQUFRLFNBQVMsUUFBUSxLQUF6QjtBQUNBO0FBQ0QsYUFBVSxtQkFBbUIsS0FBbkIsQ0FBVjtBQUNBLFVBQU8sTUFBUDtBQUNBLEdBVE0sRUFTSixJQVRJLENBU0MsRUFURCxDQUFQO0FBVUE7O0FBRUQ7Ozs7Ozs7OztBQVNBLFVBQVMsWUFBVCxDQUFzQixTQUF0QixFQUFpQztBQUNoQyxNQUFJLFlBQVksRUFBWixHQUFpQixFQUFyQixFQUF5QjtBQUN4QixVQUFPLFlBQVksRUFBbkI7QUFDQTtBQUNELE1BQUksWUFBWSxFQUFaLEdBQWlCLEVBQXJCLEVBQXlCO0FBQ3hCLFVBQU8sWUFBWSxFQUFuQjtBQUNBO0FBQ0QsTUFBSSxZQUFZLEVBQVosR0FBaUIsRUFBckIsRUFBeUI7QUFDeEIsVUFBTyxZQUFZLEVBQW5CO0FBQ0E7QUFDRCxTQUFPLElBQVA7QUFDQTs7QUFFRDs7Ozs7Ozs7Ozs7QUFXQSxVQUFTLFlBQVQsQ0FBc0IsS0FBdEIsRUFBNkIsSUFBN0IsRUFBbUM7QUFDbEM7QUFDQTtBQUNBLFNBQU8sUUFBUSxFQUFSLEdBQWEsTUFBTSxRQUFRLEVBQWQsQ0FBYixJQUFrQyxDQUFDLFFBQVEsQ0FBVCxLQUFlLENBQWpELENBQVA7QUFDQTs7QUFFRDs7Ozs7QUFLQSxVQUFTLEtBQVQsQ0FBZSxLQUFmLEVBQXNCLFNBQXRCLEVBQWlDLFNBQWpDLEVBQTRDO0FBQzNDLE1BQUksSUFBSSxDQUFSO0FBQ0EsVUFBUSxZQUFZLE1BQU0sUUFBUSxJQUFkLENBQVosR0FBa0MsU0FBUyxDQUFuRDtBQUNBLFdBQVMsTUFBTSxRQUFRLFNBQWQsQ0FBVDtBQUNBLFNBQUssdUJBQXlCLFFBQVEsZ0JBQWdCLElBQWhCLElBQXdCLENBQTlELEVBQWlFLEtBQUssSUFBdEUsRUFBNEU7QUFDM0UsV0FBUSxNQUFNLFFBQVEsYUFBZCxDQUFSO0FBQ0E7QUFDRCxTQUFPLE1BQU0sSUFBSSxDQUFDLGdCQUFnQixDQUFqQixJQUFzQixLQUF0QixJQUErQixRQUFRLElBQXZDLENBQVYsQ0FBUDtBQUNBOztBQUVEOzs7Ozs7O0FBT0EsVUFBUyxNQUFULENBQWdCLEtBQWhCLEVBQXVCO0FBQ3RCO0FBQ0EsTUFBSSxTQUFTLEVBQWI7QUFBQSxNQUNJLGNBQWMsTUFBTSxNQUR4QjtBQUFBLE1BRUksR0FGSjtBQUFBLE1BR0ksSUFBSSxDQUhSO0FBQUEsTUFJSSxJQUFJLFFBSlI7QUFBQSxNQUtJLE9BQU8sV0FMWDtBQUFBLE1BTUksS0FOSjtBQUFBLE1BT0ksQ0FQSjtBQUFBLE1BUUksS0FSSjtBQUFBLE1BU0ksSUFUSjtBQUFBLE1BVUksQ0FWSjtBQUFBLE1BV0ksQ0FYSjtBQUFBLE1BWUksS0FaSjtBQUFBLE1BYUksQ0FiSjs7QUFjSTtBQUNBLFlBZko7O0FBaUJBO0FBQ0E7QUFDQTs7QUFFQSxVQUFRLE1BQU0sV0FBTixDQUFrQixTQUFsQixDQUFSO0FBQ0EsTUFBSSxRQUFRLENBQVosRUFBZTtBQUNkLFdBQVEsQ0FBUjtBQUNBOztBQUVELE9BQUssSUFBSSxDQUFULEVBQVksSUFBSSxLQUFoQixFQUF1QixFQUFFLENBQXpCLEVBQTRCO0FBQzNCO0FBQ0EsT0FBSSxNQUFNLFVBQU4sQ0FBaUIsQ0FBakIsS0FBdUIsSUFBM0IsRUFBaUM7QUFDaEMsVUFBTSxXQUFOO0FBQ0E7QUFDRCxVQUFPLElBQVAsQ0FBWSxNQUFNLFVBQU4sQ0FBaUIsQ0FBakIsQ0FBWjtBQUNBOztBQUVEO0FBQ0E7O0FBRUEsT0FBSyxRQUFRLFFBQVEsQ0FBUixHQUFZLFFBQVEsQ0FBcEIsR0FBd0IsQ0FBckMsRUFBd0MsUUFBUSxXQUFoRCxHQUE2RCx5QkFBMkI7O0FBRXZGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFLLE9BQU8sQ0FBUCxFQUFVLElBQUksQ0FBZCxFQUFpQixJQUFJLElBQTFCLEdBQWdDLGtCQUFvQixLQUFLLElBQXpELEVBQStEOztBQUU5RCxRQUFJLFNBQVMsV0FBYixFQUEwQjtBQUN6QixXQUFNLGVBQU47QUFDQTs7QUFFRCxZQUFRLGFBQWEsTUFBTSxVQUFOLENBQWlCLE9BQWpCLENBQWIsQ0FBUjs7QUFFQSxRQUFJLFNBQVMsSUFBVCxJQUFpQixRQUFRLE1BQU0sQ0FBQyxTQUFTLENBQVYsSUFBZSxDQUFyQixDQUE3QixFQUFzRDtBQUNyRCxXQUFNLFVBQU47QUFDQTs7QUFFRCxTQUFLLFFBQVEsQ0FBYjtBQUNBLFFBQUksS0FBSyxJQUFMLEdBQVksSUFBWixHQUFvQixLQUFLLE9BQU8sSUFBWixHQUFtQixJQUFuQixHQUEwQixJQUFJLElBQXREOztBQUVBLFFBQUksUUFBUSxDQUFaLEVBQWU7QUFDZDtBQUNBOztBQUVELGlCQUFhLE9BQU8sQ0FBcEI7QUFDQSxRQUFJLElBQUksTUFBTSxTQUFTLFVBQWYsQ0FBUixFQUFvQztBQUNuQyxXQUFNLFVBQU47QUFDQTs7QUFFRCxTQUFLLFVBQUw7QUFFQTs7QUFFRCxTQUFNLE9BQU8sTUFBUCxHQUFnQixDQUF0QjtBQUNBLFVBQU8sTUFBTSxJQUFJLElBQVYsRUFBZ0IsR0FBaEIsRUFBcUIsUUFBUSxDQUE3QixDQUFQOztBQUVBO0FBQ0E7QUFDQSxPQUFJLE1BQU0sSUFBSSxHQUFWLElBQWlCLFNBQVMsQ0FBOUIsRUFBaUM7QUFDaEMsVUFBTSxVQUFOO0FBQ0E7O0FBRUQsUUFBSyxNQUFNLElBQUksR0FBVixDQUFMO0FBQ0EsUUFBSyxHQUFMOztBQUVBO0FBQ0EsVUFBTyxNQUFQLENBQWMsR0FBZCxFQUFtQixDQUFuQixFQUFzQixDQUF0QjtBQUVBOztBQUVELFNBQU8sV0FBVyxNQUFYLENBQVA7QUFDQTs7QUFFRDs7Ozs7OztBQU9BLFVBQVMsTUFBVCxDQUFnQixLQUFoQixFQUF1QjtBQUN0QixNQUFJLENBQUo7QUFBQSxNQUNJLEtBREo7QUFBQSxNQUVJLGNBRko7QUFBQSxNQUdJLFdBSEo7QUFBQSxNQUlJLElBSko7QUFBQSxNQUtJLENBTEo7QUFBQSxNQU1JLENBTko7QUFBQSxNQU9JLENBUEo7QUFBQSxNQVFJLENBUko7QUFBQSxNQVNJLENBVEo7QUFBQSxNQVVJLFlBVko7QUFBQSxNQVdJLFNBQVMsRUFYYjs7QUFZSTtBQUNBLGFBYko7O0FBY0k7QUFDQSx1QkFmSjtBQUFBLE1BZ0JJLFVBaEJKO0FBQUEsTUFpQkksT0FqQko7O0FBbUJBO0FBQ0EsVUFBUSxXQUFXLEtBQVgsQ0FBUjs7QUFFQTtBQUNBLGdCQUFjLE1BQU0sTUFBcEI7O0FBRUE7QUFDQSxNQUFJLFFBQUo7QUFDQSxVQUFRLENBQVI7QUFDQSxTQUFPLFdBQVA7O0FBRUE7QUFDQSxPQUFLLElBQUksQ0FBVCxFQUFZLElBQUksV0FBaEIsRUFBNkIsRUFBRSxDQUEvQixFQUFrQztBQUNqQyxrQkFBZSxNQUFNLENBQU4sQ0FBZjtBQUNBLE9BQUksZUFBZSxJQUFuQixFQUF5QjtBQUN4QixXQUFPLElBQVAsQ0FBWSxtQkFBbUIsWUFBbkIsQ0FBWjtBQUNBO0FBQ0Q7O0FBRUQsbUJBQWlCLGNBQWMsT0FBTyxNQUF0Qzs7QUFFQTtBQUNBOztBQUVBO0FBQ0EsTUFBSSxXQUFKLEVBQWlCO0FBQ2hCLFVBQU8sSUFBUCxDQUFZLFNBQVo7QUFDQTs7QUFFRDtBQUNBLFNBQU8saUJBQWlCLFdBQXhCLEVBQXFDOztBQUVwQztBQUNBO0FBQ0EsUUFBSyxJQUFJLE1BQUosRUFBWSxJQUFJLENBQXJCLEVBQXdCLElBQUksV0FBNUIsRUFBeUMsRUFBRSxDQUEzQyxFQUE4QztBQUM3QyxtQkFBZSxNQUFNLENBQU4sQ0FBZjtBQUNBLFFBQUksZ0JBQWdCLENBQWhCLElBQXFCLGVBQWUsQ0FBeEMsRUFBMkM7QUFDMUMsU0FBSSxZQUFKO0FBQ0E7QUFDRDs7QUFFRDtBQUNBO0FBQ0EsMkJBQXdCLGlCQUFpQixDQUF6QztBQUNBLE9BQUksSUFBSSxDQUFKLEdBQVEsTUFBTSxDQUFDLFNBQVMsS0FBVixJQUFtQixxQkFBekIsQ0FBWixFQUE2RDtBQUM1RCxVQUFNLFVBQU47QUFDQTs7QUFFRCxZQUFTLENBQUMsSUFBSSxDQUFMLElBQVUscUJBQW5CO0FBQ0EsT0FBSSxDQUFKOztBQUVBLFFBQUssSUFBSSxDQUFULEVBQVksSUFBSSxXQUFoQixFQUE2QixFQUFFLENBQS9CLEVBQWtDO0FBQ2pDLG1CQUFlLE1BQU0sQ0FBTixDQUFmOztBQUVBLFFBQUksZUFBZSxDQUFmLElBQW9CLEVBQUUsS0FBRixHQUFVLE1BQWxDLEVBQTBDO0FBQ3pDLFdBQU0sVUFBTjtBQUNBOztBQUVELFFBQUksZ0JBQWdCLENBQXBCLEVBQXVCO0FBQ3RCO0FBQ0EsVUFBSyxJQUFJLEtBQUosRUFBVyxJQUFJLElBQXBCLEdBQTBCLGtCQUFvQixLQUFLLElBQW5ELEVBQXlEO0FBQ3hELFVBQUksS0FBSyxJQUFMLEdBQVksSUFBWixHQUFvQixLQUFLLE9BQU8sSUFBWixHQUFtQixJQUFuQixHQUEwQixJQUFJLElBQXREO0FBQ0EsVUFBSSxJQUFJLENBQVIsRUFBVztBQUNWO0FBQ0E7QUFDRCxnQkFBVSxJQUFJLENBQWQ7QUFDQSxtQkFBYSxPQUFPLENBQXBCO0FBQ0EsYUFBTyxJQUFQLENBQ0MsbUJBQW1CLGFBQWEsSUFBSSxVQUFVLFVBQTNCLEVBQXVDLENBQXZDLENBQW5CLENBREQ7QUFHQSxVQUFJLE1BQU0sVUFBVSxVQUFoQixDQUFKO0FBQ0E7O0FBRUQsWUFBTyxJQUFQLENBQVksbUJBQW1CLGFBQWEsQ0FBYixFQUFnQixDQUFoQixDQUFuQixDQUFaO0FBQ0EsWUFBTyxNQUFNLEtBQU4sRUFBYSxxQkFBYixFQUFvQyxrQkFBa0IsV0FBdEQsQ0FBUDtBQUNBLGFBQVEsQ0FBUjtBQUNBLE9BQUUsY0FBRjtBQUNBO0FBQ0Q7O0FBRUQsS0FBRSxLQUFGO0FBQ0EsS0FBRSxDQUFGO0FBRUE7QUFDRCxTQUFPLE9BQU8sSUFBUCxDQUFZLEVBQVosQ0FBUDtBQUNBOztBQUVEOzs7Ozs7Ozs7OztBQVdBLFVBQVMsU0FBVCxDQUFtQixLQUFuQixFQUEwQjtBQUN6QixTQUFPLFVBQVUsS0FBVixFQUFpQixVQUFTLE1BQVQsRUFBaUI7QUFDeEMsVUFBTyxjQUFjLElBQWQsQ0FBbUIsTUFBbkIsSUFDSixPQUFPLE9BQU8sS0FBUCxDQUFhLENBQWIsRUFBZ0IsV0FBaEIsRUFBUCxDQURJLEdBRUosTUFGSDtBQUdBLEdBSk0sQ0FBUDtBQUtBOztBQUVEOzs7Ozs7Ozs7OztBQVdBLFVBQVMsT0FBVCxDQUFpQixLQUFqQixFQUF3QjtBQUN2QixTQUFPLFVBQVUsS0FBVixFQUFpQixVQUFTLE1BQVQsRUFBaUI7QUFDeEMsVUFBTyxjQUFjLElBQWQsQ0FBbUIsTUFBbkIsSUFDSixTQUFTLE9BQU8sTUFBUCxDQURMLEdBRUosTUFGSDtBQUdBLEdBSk0sQ0FBUDtBQUtBOztBQUVEOztBQUVBO0FBQ0EsWUFBVztBQUNWOzs7OztBQUtBLGFBQVcsT0FORDtBQU9WOzs7Ozs7O0FBT0EsVUFBUTtBQUNQLGFBQVUsVUFESDtBQUVQLGFBQVU7QUFGSCxHQWRFO0FBa0JWLFlBQVUsTUFsQkE7QUFtQlYsWUFBVSxNQW5CQTtBQW9CVixhQUFXLE9BcEJEO0FBcUJWLGVBQWE7QUFyQkgsRUFBWDs7QUF3QkE7QUFDQTtBQUNBO0FBQ0EsS0FDQyxPQUFPLE1BQVAsSUFBaUIsVUFBakIsSUFDQSxRQUFPLE9BQU8sR0FBZCxLQUFxQixRQURyQixJQUVBLE9BQU8sR0FIUixFQUlFO0FBQ0QsU0FBTyxVQUFQLEVBQW1CLFlBQVc7QUFDN0IsVUFBTyxRQUFQO0FBQ0EsR0FGRDtBQUdBLEVBUkQsTUFRTyxJQUFJLGVBQWUsVUFBbkIsRUFBK0I7QUFDckMsTUFBSSxPQUFPLE9BQVAsSUFBa0IsV0FBdEIsRUFBbUM7QUFDbEM7QUFDQSxjQUFXLE9BQVgsR0FBcUIsUUFBckI7QUFDQSxHQUhELE1BR087QUFDTjtBQUNBLFFBQUssR0FBTCxJQUFZLFFBQVosRUFBc0I7QUFDckIsYUFBUyxjQUFULENBQXdCLEdBQXhCLE1BQWlDLFlBQVksR0FBWixJQUFtQixTQUFTLEdBQVQsQ0FBcEQ7QUFDQTtBQUNEO0FBQ0QsRUFWTSxNQVVBO0FBQ047QUFDQSxPQUFLLFFBQUwsR0FBZ0IsUUFBaEI7QUFDQTtBQUVELENBbmhCQyxZQUFEOzs7OztBQ0REO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUNBLFNBQVMsY0FBVCxDQUF3QixHQUF4QixFQUE2QixJQUE3QixFQUFtQztBQUNqQyxTQUFPLE9BQU8sU0FBUCxDQUFpQixjQUFqQixDQUFnQyxJQUFoQyxDQUFxQyxHQUFyQyxFQUEwQyxJQUExQyxDQUFQO0FBQ0Q7O0FBRUQsT0FBTyxPQUFQLEdBQWlCLFVBQVMsRUFBVCxFQUFhLEdBQWIsRUFBa0IsRUFBbEIsRUFBc0IsT0FBdEIsRUFBK0I7QUFDOUMsUUFBTSxPQUFPLEdBQWI7QUFDQSxPQUFLLE1BQU0sR0FBWDtBQUNBLE1BQUksTUFBTSxFQUFWOztBQUVBLE1BQUksT0FBTyxFQUFQLEtBQWMsUUFBZCxJQUEwQixHQUFHLE1BQUgsS0FBYyxDQUE1QyxFQUErQztBQUM3QyxXQUFPLEdBQVA7QUFDRDs7QUFFRCxNQUFJLFNBQVMsS0FBYjtBQUNBLE9BQUssR0FBRyxLQUFILENBQVMsR0FBVCxDQUFMOztBQUVBLE1BQUksVUFBVSxJQUFkO0FBQ0EsTUFBSSxXQUFXLE9BQU8sUUFBUSxPQUFmLEtBQTJCLFFBQTFDLEVBQW9EO0FBQ2xELGNBQVUsUUFBUSxPQUFsQjtBQUNEOztBQUVELE1BQUksTUFBTSxHQUFHLE1BQWI7QUFDQTtBQUNBLE1BQUksVUFBVSxDQUFWLElBQWUsTUFBTSxPQUF6QixFQUFrQztBQUNoQyxVQUFNLE9BQU47QUFDRDs7QUFFRCxPQUFLLElBQUksSUFBSSxDQUFiLEVBQWdCLElBQUksR0FBcEIsRUFBeUIsRUFBRSxDQUEzQixFQUE4QjtBQUM1QixRQUFJLElBQUksR0FBRyxDQUFILEVBQU0sT0FBTixDQUFjLE1BQWQsRUFBc0IsS0FBdEIsQ0FBUjtBQUFBLFFBQ0ksTUFBTSxFQUFFLE9BQUYsQ0FBVSxFQUFWLENBRFY7QUFBQSxRQUVJLElBRko7QUFBQSxRQUVVLElBRlY7QUFBQSxRQUVnQixDQUZoQjtBQUFBLFFBRW1CLENBRm5COztBQUlBLFFBQUksT0FBTyxDQUFYLEVBQWM7QUFDWixhQUFPLEVBQUUsTUFBRixDQUFTLENBQVQsRUFBWSxHQUFaLENBQVA7QUFDQSxhQUFPLEVBQUUsTUFBRixDQUFTLE1BQU0sQ0FBZixDQUFQO0FBQ0QsS0FIRCxNQUdPO0FBQ0wsYUFBTyxDQUFQO0FBQ0EsYUFBTyxFQUFQO0FBQ0Q7O0FBRUQsUUFBSSxtQkFBbUIsSUFBbkIsQ0FBSjtBQUNBLFFBQUksbUJBQW1CLElBQW5CLENBQUo7O0FBRUEsUUFBSSxDQUFDLGVBQWUsR0FBZixFQUFvQixDQUFwQixDQUFMLEVBQTZCO0FBQzNCLFVBQUksQ0FBSixJQUFTLENBQVQ7QUFDRCxLQUZELE1BRU8sSUFBSSxRQUFRLElBQUksQ0FBSixDQUFSLENBQUosRUFBcUI7QUFDMUIsVUFBSSxDQUFKLEVBQU8sSUFBUCxDQUFZLENBQVo7QUFDRCxLQUZNLE1BRUE7QUFDTCxVQUFJLENBQUosSUFBUyxDQUFDLElBQUksQ0FBSixDQUFELEVBQVMsQ0FBVCxDQUFUO0FBQ0Q7QUFDRjs7QUFFRCxTQUFPLEdBQVA7QUFDRCxDQWpERDs7QUFtREEsSUFBSSxVQUFVLE1BQU0sT0FBTixJQUFpQixVQUFVLEVBQVYsRUFBYztBQUMzQyxTQUFPLE9BQU8sU0FBUCxDQUFpQixRQUFqQixDQUEwQixJQUExQixDQUErQixFQUEvQixNQUF1QyxnQkFBOUM7QUFDRCxDQUZEOzs7QUNqRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7OztBQUVBLElBQUkscUJBQXFCLFNBQXJCLGtCQUFxQixDQUFTLENBQVQsRUFBWTtBQUNuQyxpQkFBZSxDQUFmLHlDQUFlLENBQWY7QUFDRSxTQUFLLFFBQUw7QUFDRSxhQUFPLENBQVA7O0FBRUYsU0FBSyxTQUFMO0FBQ0UsYUFBTyxJQUFJLE1BQUosR0FBYSxPQUFwQjs7QUFFRixTQUFLLFFBQUw7QUFDRSxhQUFPLFNBQVMsQ0FBVCxJQUFjLENBQWQsR0FBa0IsRUFBekI7O0FBRUY7QUFDRSxhQUFPLEVBQVA7QUFYSjtBQWFELENBZEQ7O0FBZ0JBLE9BQU8sT0FBUCxHQUFpQixVQUFTLEdBQVQsRUFBYyxHQUFkLEVBQW1CLEVBQW5CLEVBQXVCLElBQXZCLEVBQTZCO0FBQzVDLFFBQU0sT0FBTyxHQUFiO0FBQ0EsT0FBSyxNQUFNLEdBQVg7QUFDQSxNQUFJLFFBQVEsSUFBWixFQUFrQjtBQUNoQixVQUFNLFNBQU47QUFDRDs7QUFFRCxNQUFJLFFBQU8sR0FBUCx5Q0FBTyxHQUFQLE9BQWUsUUFBbkIsRUFBNkI7QUFDM0IsV0FBTyxJQUFJLFdBQVcsR0FBWCxDQUFKLEVBQXFCLFVBQVMsQ0FBVCxFQUFZO0FBQ3RDLFVBQUksS0FBSyxtQkFBbUIsbUJBQW1CLENBQW5CLENBQW5CLElBQTRDLEVBQXJEO0FBQ0EsVUFBSSxRQUFRLElBQUksQ0FBSixDQUFSLENBQUosRUFBcUI7QUFDbkIsZUFBTyxJQUFJLElBQUksQ0FBSixDQUFKLEVBQVksVUFBUyxDQUFULEVBQVk7QUFDN0IsaUJBQU8sS0FBSyxtQkFBbUIsbUJBQW1CLENBQW5CLENBQW5CLENBQVo7QUFDRCxTQUZNLEVBRUosSUFGSSxDQUVDLEdBRkQsQ0FBUDtBQUdELE9BSkQsTUFJTztBQUNMLGVBQU8sS0FBSyxtQkFBbUIsbUJBQW1CLElBQUksQ0FBSixDQUFuQixDQUFuQixDQUFaO0FBQ0Q7QUFDRixLQVRNLEVBU0osSUFUSSxDQVNDLEdBVEQsQ0FBUDtBQVdEOztBQUVELE1BQUksQ0FBQyxJQUFMLEVBQVcsT0FBTyxFQUFQO0FBQ1gsU0FBTyxtQkFBbUIsbUJBQW1CLElBQW5CLENBQW5CLElBQStDLEVBQS9DLEdBQ0EsbUJBQW1CLG1CQUFtQixHQUFuQixDQUFuQixDQURQO0FBRUQsQ0F4QkQ7O0FBMEJBLElBQUksVUFBVSxNQUFNLE9BQU4sSUFBaUIsVUFBVSxFQUFWLEVBQWM7QUFDM0MsU0FBTyxPQUFPLFNBQVAsQ0FBaUIsUUFBakIsQ0FBMEIsSUFBMUIsQ0FBK0IsRUFBL0IsTUFBdUMsZ0JBQTlDO0FBQ0QsQ0FGRDs7QUFJQSxTQUFTLEdBQVQsQ0FBYyxFQUFkLEVBQWtCLENBQWxCLEVBQXFCO0FBQ25CLE1BQUksR0FBRyxHQUFQLEVBQVksT0FBTyxHQUFHLEdBQUgsQ0FBTyxDQUFQLENBQVA7QUFDWixNQUFJLE1BQU0sRUFBVjtBQUNBLE9BQUssSUFBSSxJQUFJLENBQWIsRUFBZ0IsSUFBSSxHQUFHLE1BQXZCLEVBQStCLEdBQS9CLEVBQW9DO0FBQ2xDLFFBQUksSUFBSixDQUFTLEVBQUUsR0FBRyxDQUFILENBQUYsRUFBUyxDQUFULENBQVQ7QUFDRDtBQUNELFNBQU8sR0FBUDtBQUNEOztBQUVELElBQUksYUFBYSxPQUFPLElBQVAsSUFBZSxVQUFVLEdBQVYsRUFBZTtBQUM3QyxNQUFJLE1BQU0sRUFBVjtBQUNBLE9BQUssSUFBSSxHQUFULElBQWdCLEdBQWhCLEVBQXFCO0FBQ25CLFFBQUksT0FBTyxTQUFQLENBQWlCLGNBQWpCLENBQWdDLElBQWhDLENBQXFDLEdBQXJDLEVBQTBDLEdBQTFDLENBQUosRUFBb0QsSUFBSSxJQUFKLENBQVMsR0FBVDtBQUNyRDtBQUNELFNBQU8sR0FBUDtBQUNELENBTkQ7OztBQzlFQTs7QUFFQSxRQUFRLE1BQVIsR0FBaUIsUUFBUSxLQUFSLEdBQWdCLFFBQVEsVUFBUixDQUFqQztBQUNBLFFBQVEsTUFBUixHQUFpQixRQUFRLFNBQVIsR0FBb0IsUUFBUSxVQUFSLENBQXJDOzs7OztBQ0hBLFNBQVMsZ0JBQVQsQ0FBMEIsT0FBMUIsRUFBbUM7QUFDakMsT0FBSyxJQUFMLEdBQVksa0JBQVo7QUFDQSxPQUFLLE9BQUwsR0FBZSxPQUFmO0FBQ0Q7QUFDRCxpQkFBaUIsU0FBakIsR0FBNkIsSUFBSSxLQUFKLEVBQTdCO0FBQ0EsaUJBQWlCLFNBQWpCLENBQTJCLFdBQTNCLEdBQXlDLGdCQUF6Qzs7QUFFQSxPQUFPLE9BQVAsR0FBaUIsZ0JBQWpCOzs7OztBQ1BBLElBQUksUUFBUSxRQUFRLFNBQVIsQ0FBWjs7QUFFQSxJQUFJLGFBQWEsU0FBYixVQUFhLENBQVMsT0FBVCxFQUFrQixLQUFsQixFQUF5QixRQUF6QixFQUFtQztBQUNsRCxNQUFJLHVCQUF1QixRQUFRLEtBQVIsQ0FBM0I7QUFDQSxNQUFJLGtCQUFrQixPQUF0Qjs7QUFFQSxNQUFJLEVBQUUsU0FBUyxPQUFYLENBQUosRUFBeUI7QUFDdkI7QUFDRDs7QUFFRCxNQUFJLGNBQWMsVUFBVSxNQUFWLEdBQW1CLFNBQW5CLEdBQStCLEtBQWpEOztBQUVBLFVBQVEsS0FBUixJQUFpQixZQUFXO0FBQzFCLFFBQUksT0FBTyxHQUFHLEtBQUgsQ0FBUyxJQUFULENBQWMsU0FBZCxDQUFYOztBQUVBLFFBQUksTUFBTSxNQUFNLFFBQU4sQ0FBZSxJQUFmLEVBQXFCLEdBQXJCLENBQVY7QUFDQSxRQUFJLE9BQU8sRUFBQyxPQUFPLFdBQVIsRUFBcUIsUUFBUSxTQUE3QixFQUF3QyxPQUFPLEVBQUMsV0FBVyxJQUFaLEVBQS9DLEVBQVg7O0FBRUEsUUFBSSxVQUFVLFFBQWQsRUFBd0I7QUFDdEIsVUFBSSxLQUFLLENBQUwsTUFBWSxLQUFoQixFQUF1QjtBQUNyQjtBQUNBLGNBQ0Usd0JBQXdCLE1BQU0sUUFBTixDQUFlLEtBQUssS0FBTCxDQUFXLENBQVgsQ0FBZixFQUE4QixHQUE5QixLQUFzQyxnQkFBOUQsQ0FERjtBQUVBLGFBQUssS0FBTCxDQUFXLFNBQVgsR0FBdUIsS0FBSyxLQUFMLENBQVcsQ0FBWCxDQUF2QjtBQUNBLG9CQUFZLFNBQVMsR0FBVCxFQUFjLElBQWQsQ0FBWjtBQUNEO0FBQ0YsS0FSRCxNQVFPO0FBQ0wsa0JBQVksU0FBUyxHQUFULEVBQWMsSUFBZCxDQUFaO0FBQ0Q7O0FBRUQ7QUFDQSxRQUFJLG9CQUFKLEVBQTBCO0FBQ3hCO0FBQ0E7QUFDQSxlQUFTLFNBQVQsQ0FBbUIsS0FBbkIsQ0FBeUIsSUFBekIsQ0FBOEIsb0JBQTlCLEVBQW9ELGVBQXBELEVBQXFFLElBQXJFO0FBQ0Q7QUFDRixHQXhCRDtBQXlCRCxDQW5DRDs7QUFxQ0EsT0FBTyxPQUFQLEdBQWlCO0FBQ2YsY0FBWTtBQURHLENBQWpCOzs7Ozs7OztBQ3ZDQTs7QUFFQSxJQUFJLFdBQVcsUUFBUSw2QkFBUixDQUFmO0FBQ0EsSUFBSSxZQUFZLFFBQVEseUNBQVIsQ0FBaEI7QUFDQSxJQUFJLE1BQU0sUUFBUSxtQkFBUixDQUFWO0FBQ0EsSUFBSSxtQkFBbUIsUUFBUSxlQUFSLENBQXZCOztBQUVBLElBQUksUUFBUSxRQUFRLFNBQVIsQ0FBWjtBQUNBLElBQUksZUFBZSxNQUFNLFlBQXpCO0FBQ0EsSUFBSSxhQUFhLE1BQU0sVUFBdkI7QUFDQSxJQUFJLGlCQUFpQixNQUFNLGNBQTNCO0FBQ0EsSUFBSSxVQUFVLE1BQU0sT0FBcEI7QUFDQSxJQUFJLFdBQVcsTUFBTSxRQUFyQjtBQUNBLElBQUksZ0JBQWdCLE1BQU0sYUFBMUI7QUFDQSxJQUFJLGNBQWMsTUFBTSxXQUF4QjtBQUNBLElBQUksYUFBYSxNQUFNLFVBQXZCO0FBQ0EsSUFBSSxXQUFXLE1BQU0sUUFBckI7QUFDQSxJQUFJLFVBQVUsTUFBTSxPQUFwQjtBQUNBLElBQUksZ0JBQWdCLE1BQU0sYUFBMUI7QUFDQSxJQUFJLE9BQU8sTUFBTSxJQUFqQjtBQUNBLElBQUksY0FBYyxNQUFNLFdBQXhCO0FBQ0EsSUFBSSxXQUFXLE1BQU0sUUFBckI7QUFDQSxJQUFJLGVBQWUsTUFBTSxZQUF6QjtBQUNBLElBQUksU0FBUyxNQUFNLE1BQW5CO0FBQ0EsSUFBSSxhQUFhLE1BQU0sVUFBdkI7QUFDQSxJQUFJLFlBQVksTUFBTSxTQUF0QjtBQUNBLElBQUksUUFBUSxNQUFNLEtBQWxCO0FBQ0EsSUFBSSxtQkFBbUIsTUFBTSxnQkFBN0I7QUFDQSxJQUFJLGtCQUFrQixNQUFNLGVBQTVCO0FBQ0EsSUFBSSxtQkFBbUIsTUFBTSxnQkFBN0I7QUFDQSxJQUFJLFdBQVcsTUFBTSxRQUFyQjtBQUNBLElBQUksT0FBTyxNQUFNLElBQWpCO0FBQ0EsSUFBSSxnQkFBZ0IsTUFBTSxhQUExQjtBQUNBLElBQUkseUJBQXlCLE1BQU0sc0JBQW5DO0FBQ0EsSUFBSSwwQkFBMEIsTUFBTSx1QkFBcEM7QUFDQSxJQUFJLHFCQUFxQixNQUFNLGtCQUEvQjtBQUNBLElBQUksV0FBVyxNQUFNLFFBQXJCOztBQUVBLElBQUksb0JBQW9CLFFBQVEsV0FBUixFQUFxQixVQUE3Qzs7QUFFQSxJQUFJLFVBQVUsMkNBQTJDLEtBQTNDLENBQWlELEdBQWpELENBQWQ7QUFBQSxJQUNFLGFBQWEsK0RBRGY7O0FBR0EsU0FBUyxHQUFULEdBQWU7QUFDYixTQUFPLENBQUMsSUFBSSxJQUFKLEVBQVI7QUFDRDs7QUFFRDtBQUNBLElBQUksVUFDRixPQUFPLE1BQVAsS0FBa0IsV0FBbEIsR0FDSSxNQURKLEdBRUksT0FBTyxNQUFQLEtBQWtCLFdBQWxCLEdBQWdDLE1BQWhDLEdBQXlDLE9BQU8sSUFBUCxLQUFnQixXQUFoQixHQUE4QixJQUE5QixHQUFxQyxFQUhwRjtBQUlBLElBQUksWUFBWSxRQUFRLFFBQXhCO0FBQ0EsSUFBSSxhQUFhLFFBQVEsU0FBekI7O0FBRUEsU0FBUyxvQkFBVCxDQUE4QixRQUE5QixFQUF3QyxRQUF4QyxFQUFrRDtBQUNoRCxTQUFPLFdBQVcsUUFBWCxJQUNILFVBQVMsSUFBVCxFQUFlO0FBQ2IsV0FBTyxTQUFTLElBQVQsRUFBZSxRQUFmLENBQVA7QUFDRCxHQUhFLEdBSUgsUUFKSjtBQUtEOztBQUVEO0FBQ0E7QUFDQTtBQUNBLFNBQVMsS0FBVCxHQUFpQjtBQUNmLE9BQUssUUFBTCxHQUFnQixDQUFDLEVBQUUsUUFBTyxJQUFQLHlDQUFPLElBQVAsT0FBZ0IsUUFBaEIsSUFBNEIsS0FBSyxTQUFuQyxDQUFqQjtBQUNBO0FBQ0EsT0FBSyxZQUFMLEdBQW9CLENBQUMsWUFBWSxTQUFaLENBQXJCO0FBQ0EsT0FBSyxhQUFMLEdBQXFCLENBQUMsWUFBWSxVQUFaLENBQXRCO0FBQ0EsT0FBSyxzQkFBTCxHQUE4QixJQUE5QjtBQUNBLE9BQUssU0FBTCxHQUFpQixJQUFqQjtBQUNBLE9BQUssWUFBTCxHQUFvQixJQUFwQjtBQUNBLE9BQUssYUFBTCxHQUFxQixJQUFyQjtBQUNBLE9BQUssVUFBTCxHQUFrQixJQUFsQjtBQUNBLE9BQUssY0FBTCxHQUFzQixJQUF0QjtBQUNBLE9BQUssY0FBTCxHQUFzQixFQUF0QjtBQUNBLE9BQUssY0FBTCxHQUFzQjtBQUNwQjtBQUNBLGFBQVMsUUFBUSxjQUFSLElBQTBCLFFBQVEsY0FBUixDQUF1QixFQUZ0QztBQUdwQixZQUFRLFlBSFk7QUFJcEIsa0JBQWMsRUFKTTtBQUtwQixnQkFBWSxFQUxRO0FBTXBCLG1CQUFlLEVBTks7QUFPcEIsa0JBQWMsRUFQTTtBQVFwQixhQUFTLElBUlc7QUFTcEIseUJBQXFCLElBVEQ7QUFVcEIsZ0NBQTRCLElBVlI7QUFXcEIsc0JBQWtCLENBWEU7QUFZcEI7QUFDQSxrQkFBYyxHQWJNO0FBY3BCLHFCQUFpQixFQWRHO0FBZXBCLHFCQUFpQixJQWZHO0FBZ0JwQixnQkFBWSxJQWhCUTtBQWlCcEIsZ0JBQVksQ0FqQlE7QUFrQnBCLGtCQUFjO0FBbEJNLEdBQXRCO0FBb0JBLE9BQUssY0FBTCxHQUFzQjtBQUNwQixZQUFRLE1BRFk7QUFFcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBZ0IsMkJBQTJCLFFBQTNCLEdBQXNDO0FBTmxDLEdBQXRCO0FBUUEsT0FBSyxjQUFMLEdBQXNCLENBQXRCO0FBQ0EsT0FBSyxpQkFBTCxHQUF5QixLQUF6QjtBQUNBLE9BQUssNkJBQUwsR0FBcUMsTUFBTSxlQUEzQztBQUNBO0FBQ0E7QUFDQSxPQUFLLGdCQUFMLEdBQXdCLFFBQVEsT0FBUixJQUFtQixFQUEzQztBQUNBLE9BQUssdUJBQUwsR0FBK0IsRUFBL0I7QUFDQSxPQUFLLFFBQUwsR0FBZ0IsRUFBaEI7QUFDQSxPQUFLLFVBQUwsR0FBa0IsS0FBbEI7QUFDQSxPQUFLLGdCQUFMLEdBQXdCLEVBQXhCO0FBQ0EsT0FBSyxZQUFMLEdBQW9CLEVBQXBCO0FBQ0EsT0FBSyxrQkFBTCxHQUEwQixJQUExQjtBQUNBLE9BQUssZ0JBQUw7QUFDQSxPQUFLLFNBQUwsR0FBaUIsUUFBUSxRQUF6QjtBQUNBLE9BQUssU0FBTCxHQUFpQixLQUFLLFNBQUwsSUFBa0IsS0FBSyxTQUFMLENBQWUsSUFBbEQ7QUFDQSxPQUFLLGFBQUw7O0FBRUE7QUFDQSxPQUFLLElBQUksTUFBVCxJQUFtQixLQUFLLGdCQUF4QixFQUEwQztBQUN4QyxTQUFLLHVCQUFMLENBQTZCLE1BQTdCLElBQXVDLEtBQUssZ0JBQUwsQ0FBc0IsTUFBdEIsQ0FBdkM7QUFDRDtBQUNGOztBQUVEOzs7Ozs7QUFNQSxNQUFNLFNBQU4sR0FBa0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFTLFFBTE87O0FBT2hCLFNBQU8sS0FQUzs7QUFTaEIsWUFBVSxRQVRNLEVBU0k7O0FBRXBCOzs7Ozs7O0FBT0EsVUFBUSxnQkFBUyxHQUFULEVBQWMsT0FBZCxFQUF1QjtBQUM3QixRQUFJLE9BQU8sSUFBWDs7QUFFQSxRQUFJLEtBQUssYUFBVCxFQUF3QjtBQUN0QixXQUFLLFNBQUwsQ0FBZSxPQUFmLEVBQXdCLDBDQUF4QjtBQUNBLGFBQU8sSUFBUDtBQUNEO0FBQ0QsUUFBSSxDQUFDLEdBQUwsRUFBVSxPQUFPLElBQVA7O0FBRVYsUUFBSSxnQkFBZ0IsS0FBSyxjQUF6Qjs7QUFFQTtBQUNBLFFBQUksT0FBSixFQUFhO0FBQ1gsV0FBSyxPQUFMLEVBQWMsVUFBUyxHQUFULEVBQWMsS0FBZCxFQUFxQjtBQUNqQztBQUNBLFlBQUksUUFBUSxNQUFSLElBQWtCLFFBQVEsT0FBMUIsSUFBcUMsUUFBUSxNQUFqRCxFQUF5RDtBQUN2RCxlQUFLLGNBQUwsQ0FBb0IsR0FBcEIsSUFBMkIsS0FBM0I7QUFDRCxTQUZELE1BRU87QUFDTCx3QkFBYyxHQUFkLElBQXFCLEtBQXJCO0FBQ0Q7QUFDRixPQVBEO0FBUUQ7O0FBRUQsU0FBSyxNQUFMLENBQVksR0FBWjs7QUFFQTtBQUNBO0FBQ0Esa0JBQWMsWUFBZCxDQUEyQixJQUEzQixDQUFnQyxtQkFBaEM7QUFDQSxrQkFBYyxZQUFkLENBQTJCLElBQTNCLENBQWdDLCtDQUFoQzs7QUFFQTtBQUNBLGtCQUFjLFlBQWQsR0FBNkIsV0FBVyxjQUFjLFlBQXpCLENBQTdCO0FBQ0Esa0JBQWMsVUFBZCxHQUEyQixjQUFjLFVBQWQsQ0FBeUIsTUFBekIsR0FDdkIsV0FBVyxjQUFjLFVBQXpCLENBRHVCLEdBRXZCLEtBRko7QUFHQSxrQkFBYyxhQUFkLEdBQThCLGNBQWMsYUFBZCxDQUE0QixNQUE1QixHQUMxQixXQUFXLGNBQWMsYUFBekIsQ0FEMEIsR0FFMUIsS0FGSjtBQUdBLGtCQUFjLFlBQWQsR0FBNkIsV0FBVyxjQUFjLFlBQXpCLENBQTdCO0FBQ0Esa0JBQWMsY0FBZCxHQUErQixLQUFLLEdBQUwsQ0FDN0IsQ0FENkIsRUFFN0IsS0FBSyxHQUFMLENBQVMsY0FBYyxjQUFkLElBQWdDLEdBQXpDLEVBQThDLEdBQTlDLENBRjZCLENBQS9CLENBdkM2QixDQTBDMUI7O0FBRUgsUUFBSSx5QkFBeUI7QUFDM0IsV0FBSyxJQURzQjtBQUUzQixlQUFTLElBRmtCO0FBRzNCLFdBQUssSUFIc0I7QUFJM0IsZ0JBQVUsSUFKaUI7QUFLM0IsY0FBUTtBQUxtQixLQUE3Qjs7QUFRQSxRQUFJLGtCQUFrQixjQUFjLGVBQXBDO0FBQ0EsUUFBSSxHQUFHLFFBQUgsQ0FBWSxJQUFaLENBQWlCLGVBQWpCLE1BQXNDLGlCQUExQyxFQUE2RDtBQUMzRCx3QkFBa0IsWUFBWSxzQkFBWixFQUFvQyxlQUFwQyxDQUFsQjtBQUNELEtBRkQsTUFFTyxJQUFJLG9CQUFvQixLQUF4QixFQUErQjtBQUNwQyx3QkFBa0Isc0JBQWxCO0FBQ0Q7QUFDRCxrQkFBYyxlQUFkLEdBQWdDLGVBQWhDOztBQUVBLFFBQUkscUJBQXFCO0FBQ3ZCLGdCQUFVO0FBRGEsS0FBekI7O0FBSUEsUUFBSSxhQUFhLGNBQWMsVUFBL0I7QUFDQSxRQUFJLEdBQUcsUUFBSCxDQUFZLElBQVosQ0FBaUIsVUFBakIsTUFBaUMsaUJBQXJDLEVBQXdEO0FBQ3RELG1CQUFhLFlBQVksa0JBQVosRUFBZ0MsVUFBaEMsQ0FBYjtBQUNELEtBRkQsTUFFTyxJQUFJLGVBQWUsS0FBbkIsRUFBMEI7QUFDL0IsbUJBQWEsa0JBQWI7QUFDRDtBQUNELGtCQUFjLFVBQWQsR0FBMkIsVUFBM0I7O0FBRUEsYUFBUyxtQkFBVCxHQUErQixDQUFDLENBQUMsY0FBYyxtQkFBL0M7O0FBRUE7QUFDQSxXQUFPLElBQVA7QUFDRCxHQTlGZTs7QUFnR2hCOzs7Ozs7OztBQVFBLFdBQVMsbUJBQVc7QUFDbEIsUUFBSSxPQUFPLElBQVg7QUFDQSxRQUFJLEtBQUssT0FBTCxNQUFrQixDQUFDLEtBQUssaUJBQTVCLEVBQStDO0FBQzdDLGVBQVMsTUFBVCxDQUFnQixTQUFoQixDQUEwQixZQUFXO0FBQ25DLGFBQUssdUJBQUwsQ0FBNkIsS0FBN0IsQ0FBbUMsSUFBbkMsRUFBeUMsU0FBekM7QUFDRCxPQUZEOztBQUlBLFVBQUksS0FBSyxjQUFMLENBQW9CLDBCQUF4QixFQUFvRDtBQUNsRCxhQUFLLDhCQUFMO0FBQ0Q7O0FBRUQsV0FBSyxzQkFBTDs7QUFFQSxVQUFJLEtBQUssY0FBTCxDQUFvQixVQUFwQixJQUFrQyxLQUFLLGNBQUwsQ0FBb0IsVUFBcEIsQ0FBK0IsUUFBckUsRUFBK0U7QUFDN0UsYUFBSyxtQkFBTDtBQUNEOztBQUVELFVBQUksS0FBSyxjQUFMLENBQW9CLGVBQXhCLEVBQXlDLEtBQUssc0JBQUw7O0FBRXpDO0FBQ0EsV0FBSyxhQUFMOztBQUVBLFdBQUssaUJBQUwsR0FBeUIsSUFBekI7QUFDRDs7QUFFRCxVQUFNLGVBQU4sR0FBd0IsS0FBSyxjQUFMLENBQW9CLGVBQTVDO0FBQ0EsV0FBTyxJQUFQO0FBQ0QsR0FuSWU7O0FBcUloQjs7Ozs7QUFLQSxVQUFRLGdCQUFTLEdBQVQsRUFBYztBQUNwQixRQUFJLE9BQU8sSUFBWDtBQUFBLFFBQ0UsTUFBTSxLQUFLLFNBQUwsQ0FBZSxHQUFmLENBRFI7QUFBQSxRQUVFLFlBQVksSUFBSSxJQUFKLENBQVMsV0FBVCxDQUFxQixHQUFyQixDQUZkO0FBQUEsUUFHRSxPQUFPLElBQUksSUFBSixDQUFTLE1BQVQsQ0FBZ0IsQ0FBaEIsRUFBbUIsU0FBbkIsQ0FIVDs7QUFLQSxTQUFLLElBQUwsR0FBWSxHQUFaO0FBQ0EsU0FBSyxVQUFMLEdBQWtCLElBQUksSUFBdEI7QUFDQSxTQUFLLGFBQUwsR0FBcUIsSUFBSSxJQUFKLElBQVksSUFBSSxJQUFKLENBQVMsTUFBVCxDQUFnQixDQUFoQixDQUFqQztBQUNBLFNBQUssY0FBTCxHQUFzQixJQUFJLElBQUosQ0FBUyxNQUFULENBQWdCLFlBQVksQ0FBNUIsQ0FBdEI7O0FBRUEsU0FBSyxhQUFMLEdBQXFCLEtBQUssZ0JBQUwsQ0FBc0IsR0FBdEIsQ0FBckI7O0FBRUEsU0FBSyxlQUFMLEdBQ0UsS0FBSyxhQUFMLEdBQXFCLEdBQXJCLEdBQTJCLElBQTNCLEdBQWtDLE1BQWxDLEdBQTJDLEtBQUssY0FBaEQsR0FBaUUsU0FEbkU7O0FBR0E7QUFDQTtBQUNBLFNBQUssYUFBTDtBQUNELEdBN0plOztBQStKaEI7Ozs7Ozs7O0FBUUEsV0FBUyxpQkFBUyxPQUFULEVBQWtCLElBQWxCLEVBQXdCLElBQXhCLEVBQThCO0FBQ3JDLFFBQUksV0FBVyxPQUFYLENBQUosRUFBeUI7QUFDdkIsYUFBTyxRQUFRLEVBQWY7QUFDQSxhQUFPLE9BQVA7QUFDQSxnQkFBVSxFQUFWO0FBQ0Q7O0FBRUQsV0FBTyxLQUFLLElBQUwsQ0FBVSxPQUFWLEVBQW1CLElBQW5CLEVBQXlCLEtBQXpCLENBQStCLElBQS9CLEVBQXFDLElBQXJDLENBQVA7QUFDRCxHQS9LZTs7QUFpTGhCOzs7Ozs7OztBQVFBLFFBQU0sY0FBUyxPQUFULEVBQWtCLElBQWxCLEVBQXdCLE9BQXhCLEVBQWlDO0FBQ3JDLFFBQUksT0FBTyxJQUFYO0FBQ0E7QUFDQTtBQUNBLFFBQUksWUFBWSxJQUFaLEtBQXFCLENBQUMsV0FBVyxPQUFYLENBQTFCLEVBQStDO0FBQzdDLGFBQU8sT0FBUDtBQUNEOztBQUVEO0FBQ0EsUUFBSSxXQUFXLE9BQVgsQ0FBSixFQUF5QjtBQUN2QixhQUFPLE9BQVA7QUFDQSxnQkFBVSxTQUFWO0FBQ0Q7O0FBRUQ7QUFDQTtBQUNBLFFBQUksQ0FBQyxXQUFXLElBQVgsQ0FBTCxFQUF1QjtBQUNyQixhQUFPLElBQVA7QUFDRDs7QUFFRDtBQUNBLFFBQUk7QUFDRixVQUFJLEtBQUssU0FBVCxFQUFvQjtBQUNsQixlQUFPLElBQVA7QUFDRDs7QUFFRDtBQUNBLFVBQUksS0FBSyxpQkFBVCxFQUE0QjtBQUMxQixlQUFPLEtBQUssaUJBQVo7QUFDRDtBQUNGLEtBVEQsQ0FTRSxPQUFPLENBQVAsRUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBLGFBQU8sSUFBUDtBQUNEOztBQUVELGFBQVMsT0FBVCxHQUFtQjtBQUNqQixVQUFJLE9BQU8sRUFBWDtBQUFBLFVBQ0UsSUFBSSxVQUFVLE1BRGhCO0FBQUEsVUFFRSxPQUFPLENBQUMsT0FBRCxJQUFhLFdBQVcsUUFBUSxJQUFSLEtBQWlCLEtBRmxEOztBQUlBLFVBQUksV0FBVyxXQUFXLE9BQVgsQ0FBZixFQUFvQztBQUNsQyxnQkFBUSxLQUFSLENBQWMsSUFBZCxFQUFvQixTQUFwQjtBQUNEOztBQUVEO0FBQ0E7QUFDQSxhQUFPLEdBQVA7QUFBWSxhQUFLLENBQUwsSUFBVSxPQUFPLEtBQUssSUFBTCxDQUFVLE9BQVYsRUFBbUIsVUFBVSxDQUFWLENBQW5CLENBQVAsR0FBMEMsVUFBVSxDQUFWLENBQXBEO0FBQVosT0FFQSxJQUFJO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFPLEtBQUssS0FBTCxDQUFXLElBQVgsRUFBaUIsSUFBakIsQ0FBUDtBQUNELE9BTkQsQ0FNRSxPQUFPLENBQVAsRUFBVTtBQUNWLGFBQUssa0JBQUw7QUFDQSxhQUFLLGdCQUFMLENBQXNCLENBQXRCLEVBQXlCLE9BQXpCO0FBQ0EsY0FBTSxDQUFOO0FBQ0Q7QUFDRjs7QUFFRDtBQUNBLFNBQUssSUFBSSxRQUFULElBQXFCLElBQXJCLEVBQTJCO0FBQ3pCLFVBQUksT0FBTyxJQUFQLEVBQWEsUUFBYixDQUFKLEVBQTRCO0FBQzFCLGdCQUFRLFFBQVIsSUFBb0IsS0FBSyxRQUFMLENBQXBCO0FBQ0Q7QUFDRjtBQUNELFlBQVEsU0FBUixHQUFvQixLQUFLLFNBQXpCOztBQUVBLFNBQUssaUJBQUwsR0FBeUIsT0FBekI7QUFDQTtBQUNBO0FBQ0EsWUFBUSxTQUFSLEdBQW9CLElBQXBCO0FBQ0EsWUFBUSxRQUFSLEdBQW1CLElBQW5COztBQUVBLFdBQU8sT0FBUDtBQUNELEdBdlFlOztBQXlRaEI7Ozs7O0FBS0EsYUFBVyxxQkFBVztBQUNwQixhQUFTLE1BQVQsQ0FBZ0IsU0FBaEI7O0FBRUEsU0FBSyw4QkFBTDtBQUNBLFNBQUssd0JBQUw7QUFDQSxTQUFLLGdCQUFMO0FBQ0EsU0FBSyxlQUFMOztBQUVBLFVBQU0sZUFBTixHQUF3QixLQUFLLDZCQUE3QjtBQUNBLFNBQUssaUJBQUwsR0FBeUIsS0FBekI7O0FBRUEsV0FBTyxJQUFQO0FBQ0QsR0ExUmU7O0FBNFJoQjs7Ozs7Ozs7QUFRQSw0QkFBMEIsa0NBQVMsS0FBVCxFQUFnQjtBQUN4QyxTQUFLLFNBQUwsQ0FBZSxPQUFmLEVBQXdCLDJDQUF4QixFQUFxRSxLQUFyRTtBQUNBLFNBQUssZ0JBQUwsQ0FBc0IsTUFBTSxNQUE1QixFQUFvQztBQUNsQyxpQkFBVztBQUNULGNBQU0sc0JBREc7QUFFVCxpQkFBUztBQUZBO0FBRHVCLEtBQXBDO0FBTUQsR0E1U2U7O0FBOFNoQjs7Ozs7QUFLQSxrQ0FBZ0MsMENBQVc7QUFDekMsU0FBSyx3QkFBTCxHQUFnQyxLQUFLLHdCQUFMLENBQThCLElBQTlCLENBQW1DLElBQW5DLENBQWhDO0FBQ0EsWUFBUSxnQkFBUixJQUNFLFFBQVEsZ0JBQVIsQ0FBeUIsb0JBQXpCLEVBQStDLEtBQUssd0JBQXBELENBREY7QUFFQSxXQUFPLElBQVA7QUFDRCxHQXhUZTs7QUEwVGhCOzs7OztBQUtBLGtDQUFnQywwQ0FBVztBQUN6QyxZQUFRLG1CQUFSLElBQ0UsUUFBUSxtQkFBUixDQUE0QixvQkFBNUIsRUFBa0QsS0FBSyx3QkFBdkQsQ0FERjtBQUVBLFdBQU8sSUFBUDtBQUNELEdBblVlOztBQXFVaEI7Ozs7Ozs7QUFPQSxvQkFBa0IsMEJBQVMsRUFBVCxFQUFhLE9BQWIsRUFBc0I7QUFDdEMsY0FBVSxZQUFZLEVBQUMsZ0JBQWdCLENBQWpCLEVBQVosRUFBaUMsVUFBVSxPQUFWLEdBQW9CLEVBQXJELENBQVY7O0FBRUEsUUFBSSxhQUFhLEVBQWIsS0FBb0IsR0FBRyxLQUEzQixFQUFrQztBQUNoQztBQUNBLFdBQUssR0FBRyxLQUFSO0FBQ0QsS0FIRCxNQUdPLElBQUksV0FBVyxFQUFYLEtBQWtCLGVBQWUsRUFBZixDQUF0QixFQUEwQztBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQUksT0FBTyxHQUFHLElBQUgsS0FBWSxXQUFXLEVBQVgsSUFBaUIsVUFBakIsR0FBOEIsY0FBMUMsQ0FBWDtBQUNBLFVBQUksVUFBVSxHQUFHLE9BQUgsR0FBYSxPQUFPLElBQVAsR0FBYyxHQUFHLE9BQTlCLEdBQXdDLElBQXREOztBQUVBLGFBQU8sS0FBSyxjQUFMLENBQ0wsT0FESyxFQUVMLFlBQVksT0FBWixFQUFxQjtBQUNuQjtBQUNBO0FBQ0Esb0JBQVksSUFITztBQUluQix3QkFBZ0IsUUFBUSxjQUFSLEdBQXlCO0FBSnRCLE9BQXJCLENBRkssQ0FBUDtBQVNELEtBakJNLE1BaUJBLElBQUksUUFBUSxFQUFSLENBQUosRUFBaUI7QUFDdEI7QUFDQSxXQUFLLEVBQUw7QUFDRCxLQUhNLE1BR0EsSUFBSSxjQUFjLEVBQWQsQ0FBSixFQUF1QjtBQUM1QjtBQUNBO0FBQ0E7QUFDQSxnQkFBVSxLQUFLLDBDQUFMLENBQWdELE9BQWhELEVBQXlELEVBQXpELENBQVY7QUFDQSxXQUFLLElBQUksS0FBSixDQUFVLFFBQVEsT0FBbEIsQ0FBTDtBQUNELEtBTk0sTUFNQTtBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQU8sS0FBSyxjQUFMLENBQ0wsRUFESyxFQUVMLFlBQVksT0FBWixFQUFxQjtBQUNuQixvQkFBWSxJQURPLEVBQ0Q7QUFDbEIsd0JBQWdCLFFBQVEsY0FBUixHQUF5QjtBQUZ0QixPQUFyQixDQUZLLENBQVA7QUFPRDs7QUFFRDtBQUNBLFNBQUssc0JBQUwsR0FBOEIsRUFBOUI7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQUk7QUFDRixVQUFJLFFBQVEsU0FBUyxpQkFBVCxDQUEyQixFQUEzQixDQUFaO0FBQ0EsV0FBSyxnQkFBTCxDQUFzQixLQUF0QixFQUE2QixPQUE3QjtBQUNELEtBSEQsQ0FHRSxPQUFPLEdBQVAsRUFBWTtBQUNaLFVBQUksT0FBTyxHQUFYLEVBQWdCO0FBQ2QsY0FBTSxHQUFOO0FBQ0Q7QUFDRjs7QUFFRCxXQUFPLElBQVA7QUFDRCxHQTlZZTs7QUFnWmhCLDhDQUE0QyxvREFBUyxjQUFULEVBQXlCLEVBQXpCLEVBQTZCO0FBQ3ZFLFFBQUksU0FBUyxPQUFPLElBQVAsQ0FBWSxFQUFaLEVBQWdCLElBQWhCLEVBQWI7QUFDQSxRQUFJLFVBQVUsWUFBWSxjQUFaLEVBQTRCO0FBQ3hDLGVBQ0UsNkNBQTZDLHdCQUF3QixNQUF4QixDQUZQO0FBR3hDLG1CQUFhLENBQUMsSUFBSSxNQUFKLENBQUQsQ0FIMkI7QUFJeEMsYUFBTyxlQUFlLEtBQWYsSUFBd0I7QUFKUyxLQUE1QixDQUFkO0FBTUEsWUFBUSxLQUFSLENBQWMsY0FBZCxHQUErQixtQkFBbUIsRUFBbkIsQ0FBL0I7O0FBRUEsV0FBTyxPQUFQO0FBQ0QsR0EzWmU7O0FBNlpoQjs7Ozs7OztBQU9BLGtCQUFnQix3QkFBUyxHQUFULEVBQWMsT0FBZCxFQUF1QjtBQUNyQztBQUNBO0FBQ0E7QUFDQSxRQUNFLENBQUMsQ0FBQyxLQUFLLGNBQUwsQ0FBb0IsWUFBcEIsQ0FBaUMsSUFBbkMsSUFDQSxLQUFLLGNBQUwsQ0FBb0IsWUFBcEIsQ0FBaUMsSUFBakMsQ0FBc0MsR0FBdEMsQ0FGRixFQUdFO0FBQ0E7QUFDRDs7QUFFRCxjQUFVLFdBQVcsRUFBckI7QUFDQSxVQUFNLE1BQU0sRUFBWixDQVpxQyxDQVlyQjs7QUFFaEIsUUFBSSxPQUFPLFlBQ1Q7QUFDRSxlQUFTO0FBRFgsS0FEUyxFQUlULE9BSlMsQ0FBWDs7QUFPQSxRQUFJLEVBQUo7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFFBQUk7QUFDRixZQUFNLElBQUksS0FBSixDQUFVLEdBQVYsQ0FBTjtBQUNELEtBRkQsQ0FFRSxPQUFPLEdBQVAsRUFBWTtBQUNaLFdBQUssR0FBTDtBQUNEOztBQUVEO0FBQ0EsT0FBRyxJQUFILEdBQVUsSUFBVjtBQUNBLFFBQUksUUFBUSxTQUFTLGlCQUFULENBQTJCLEVBQTNCLENBQVo7O0FBRUE7QUFDQSxRQUFJLGNBQWMsUUFBUSxNQUFNLEtBQWQsS0FBd0IsTUFBTSxLQUFOLENBQVksQ0FBWixDQUExQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxRQUFJLGVBQWUsWUFBWSxJQUFaLEtBQXFCLHdCQUF4QyxFQUFrRTtBQUNoRSxvQkFBYyxNQUFNLEtBQU4sQ0FBWSxDQUFaLENBQWQ7QUFDRDs7QUFFRCxRQUFJLFVBQVcsZUFBZSxZQUFZLEdBQTVCLElBQW9DLEVBQWxEOztBQUVBLFFBQ0UsQ0FBQyxDQUFDLEtBQUssY0FBTCxDQUFvQixVQUFwQixDQUErQixJQUFqQyxJQUNBLEtBQUssY0FBTCxDQUFvQixVQUFwQixDQUErQixJQUEvQixDQUFvQyxPQUFwQyxDQUZGLEVBR0U7QUFDQTtBQUNEOztBQUVELFFBQ0UsQ0FBQyxDQUFDLEtBQUssY0FBTCxDQUFvQixhQUFwQixDQUFrQyxJQUFwQyxJQUNBLENBQUMsS0FBSyxjQUFMLENBQW9CLGFBQXBCLENBQWtDLElBQWxDLENBQXVDLE9BQXZDLENBRkgsRUFHRTtBQUNBO0FBQ0Q7O0FBRUQ7QUFDQTtBQUNBLFFBQUksS0FBSyxjQUFMLENBQW9CLFVBQXBCLElBQWtDLFFBQVEsVUFBMUMsSUFBd0QsS0FBSyxPQUFMLEtBQWlCLEVBQTdFLEVBQWlGO0FBQy9FO0FBQ0EsV0FBSyxXQUFMLEdBQW1CLEtBQUssV0FBTCxJQUFvQixJQUFwQixHQUEyQixHQUEzQixHQUFpQyxLQUFLLFdBQXpEOztBQUVBLGdCQUFVLFlBQ1I7QUFDRSx3QkFBZ0I7QUFEbEIsT0FEUSxFQUlSLE9BSlEsQ0FBVjtBQU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBUSxjQUFSLElBQTBCLENBQTFCOztBQUVBLFVBQUksU0FBUyxLQUFLLGNBQUwsQ0FBb0IsS0FBcEIsRUFBMkIsT0FBM0IsQ0FBYjtBQUNBLFdBQUssVUFBTCxHQUFrQjtBQUNoQjtBQUNBLGdCQUFRLE9BQU8sT0FBUDtBQUZRLE9BQWxCO0FBSUQ7O0FBRUQ7QUFDQSxRQUFJLEtBQUssV0FBVCxFQUFzQjtBQUNwQixXQUFLLFdBQUwsR0FBbUIsUUFBUSxLQUFLLFdBQWIsSUFDZixLQUFLLFdBRFUsR0FFZixDQUFDLEtBQUssV0FBTixDQUZKO0FBR0Q7O0FBRUQ7QUFDQSxTQUFLLEtBQUwsQ0FBVyxJQUFYOztBQUVBLFdBQU8sSUFBUDtBQUNELEdBdGdCZTs7QUF3Z0JoQixxQkFBbUIsMkJBQVMsR0FBVCxFQUFjO0FBQy9CLFFBQUksUUFBUSxZQUNWO0FBQ0UsaUJBQVcsUUFBUTtBQURyQixLQURVLEVBSVYsR0FKVSxDQUFaOztBQU9BLFFBQUksV0FBVyxLQUFLLGNBQUwsQ0FBb0Isa0JBQS9CLENBQUosRUFBd0Q7QUFDdEQsVUFBSSxTQUFTLEtBQUssY0FBTCxDQUFvQixrQkFBcEIsQ0FBdUMsS0FBdkMsQ0FBYjs7QUFFQSxVQUFJLFNBQVMsTUFBVCxLQUFvQixDQUFDLGNBQWMsTUFBZCxDQUF6QixFQUFnRDtBQUM5QyxnQkFBUSxNQUFSO0FBQ0QsT0FGRCxNQUVPLElBQUksV0FBVyxLQUFmLEVBQXNCO0FBQzNCLGVBQU8sSUFBUDtBQUNEO0FBQ0Y7O0FBRUQsU0FBSyxZQUFMLENBQWtCLElBQWxCLENBQXVCLEtBQXZCO0FBQ0EsUUFBSSxLQUFLLFlBQUwsQ0FBa0IsTUFBbEIsR0FBMkIsS0FBSyxjQUFMLENBQW9CLGNBQW5ELEVBQW1FO0FBQ2pFLFdBQUssWUFBTCxDQUFrQixLQUFsQjtBQUNEO0FBQ0QsV0FBTyxJQUFQO0FBQ0QsR0EvaEJlOztBQWlpQmhCLGFBQVcsbUJBQVMsTUFBVCxDQUFnQix3QkFBaEIsRUFBMEM7QUFDbkQsUUFBSSxhQUFhLEdBQUcsS0FBSCxDQUFTLElBQVQsQ0FBYyxTQUFkLEVBQXlCLENBQXpCLENBQWpCOztBQUVBLFNBQUssUUFBTCxDQUFjLElBQWQsQ0FBbUIsQ0FBQyxNQUFELEVBQVMsVUFBVCxDQUFuQjtBQUNBLFFBQUksS0FBSyxpQkFBVCxFQUE0QjtBQUMxQixXQUFLLGFBQUw7QUFDRDs7QUFFRCxXQUFPLElBQVA7QUFDRCxHQTFpQmU7O0FBNGlCaEI7Ozs7OztBQU1BLGtCQUFnQix3QkFBUyxJQUFULEVBQWU7QUFDN0I7QUFDQSxTQUFLLGNBQUwsQ0FBb0IsSUFBcEIsR0FBMkIsSUFBM0I7O0FBRUEsV0FBTyxJQUFQO0FBQ0QsR0F2akJlOztBQXlqQmhCOzs7Ozs7QUFNQSxtQkFBaUIseUJBQVMsS0FBVCxFQUFnQjtBQUMvQixTQUFLLGFBQUwsQ0FBbUIsT0FBbkIsRUFBNEIsS0FBNUI7O0FBRUEsV0FBTyxJQUFQO0FBQ0QsR0Fua0JlOztBQXFrQmhCOzs7Ozs7QUFNQSxrQkFBZ0Isd0JBQVMsSUFBVCxFQUFlO0FBQzdCLFNBQUssYUFBTCxDQUFtQixNQUFuQixFQUEyQixJQUEzQjs7QUFFQSxXQUFPLElBQVA7QUFDRCxHQS9rQmU7O0FBaWxCaEI7Ozs7O0FBS0EsZ0JBQWMsd0JBQVc7QUFDdkIsU0FBSyxjQUFMLEdBQXNCLEVBQXRCOztBQUVBLFdBQU8sSUFBUDtBQUNELEdBMWxCZTs7QUE0bEJoQjs7Ozs7QUFLQSxjQUFZLHNCQUFXO0FBQ3JCO0FBQ0EsV0FBTyxLQUFLLEtBQUwsQ0FBVyxVQUFVLEtBQUssY0FBZixDQUFYLENBQVA7QUFDRCxHQXBtQmU7O0FBc21CaEI7Ozs7OztBQU1BLGtCQUFnQix3QkFBUyxXQUFULEVBQXNCO0FBQ3BDLFNBQUssY0FBTCxDQUFvQixXQUFwQixHQUFrQyxXQUFsQzs7QUFFQSxXQUFPLElBQVA7QUFDRCxHQWhuQmU7O0FBa25CaEI7Ozs7OztBQU1BLGNBQVksb0JBQVMsT0FBVCxFQUFrQjtBQUM1QixTQUFLLGNBQUwsQ0FBb0IsT0FBcEIsR0FBOEIsT0FBOUI7O0FBRUEsV0FBTyxJQUFQO0FBQ0QsR0E1bkJlOztBQThuQmhCOzs7Ozs7O0FBT0EsbUJBQWlCLHlCQUFTLFFBQVQsRUFBbUI7QUFDbEMsUUFBSSxXQUFXLEtBQUssY0FBTCxDQUFvQixZQUFuQztBQUNBLFNBQUssY0FBTCxDQUFvQixZQUFwQixHQUFtQyxxQkFBcUIsUUFBckIsRUFBK0IsUUFBL0IsQ0FBbkM7QUFDQSxXQUFPLElBQVA7QUFDRCxHQXpvQmU7O0FBMm9CaEI7Ozs7Ozs7QUFPQSx5QkFBdUIsK0JBQVMsUUFBVCxFQUFtQjtBQUN4QyxRQUFJLFdBQVcsS0FBSyxjQUFMLENBQW9CLGtCQUFuQztBQUNBLFNBQUssY0FBTCxDQUFvQixrQkFBcEIsR0FBeUMscUJBQXFCLFFBQXJCLEVBQStCLFFBQS9CLENBQXpDO0FBQ0EsV0FBTyxJQUFQO0FBQ0QsR0F0cEJlOztBQXdwQmhCOzs7Ozs7O0FBT0EseUJBQXVCLCtCQUFTLFFBQVQsRUFBbUI7QUFDeEMsUUFBSSxXQUFXLEtBQUssY0FBTCxDQUFvQixrQkFBbkM7QUFDQSxTQUFLLGNBQUwsQ0FBb0Isa0JBQXBCLEdBQXlDLHFCQUFxQixRQUFyQixFQUErQixRQUEvQixDQUF6QztBQUNBLFdBQU8sSUFBUDtBQUNELEdBbnFCZTs7QUFxcUJoQjs7Ozs7Ozs7O0FBU0EsZ0JBQWMsc0JBQVMsU0FBVCxFQUFvQjtBQUNoQyxTQUFLLGNBQUwsQ0FBb0IsU0FBcEIsR0FBZ0MsU0FBaEM7O0FBRUEsV0FBTyxJQUFQO0FBQ0QsR0FsckJlOztBQW9yQmhCOzs7OztBQUtBLGlCQUFlLHlCQUFXO0FBQ3hCLFdBQU8sS0FBSyxzQkFBWjtBQUNELEdBM3JCZTs7QUE2ckJoQjs7Ozs7QUFLQSxlQUFhLHVCQUFXO0FBQ3RCLFdBQU8sS0FBSyxZQUFaO0FBQ0QsR0Fwc0JlOztBQXNzQmhCOzs7OztBQUtBLFdBQVMsbUJBQVc7QUFDbEIsUUFBSSxDQUFDLEtBQUssUUFBVixFQUFvQixPQUFPLEtBQVAsQ0FERixDQUNnQjtBQUNsQyxRQUFJLENBQUMsS0FBSyxhQUFWLEVBQXlCO0FBQ3ZCLFVBQUksQ0FBQyxLQUFLLHVCQUFWLEVBQW1DO0FBQ2pDLGFBQUssdUJBQUwsR0FBK0IsSUFBL0I7QUFDQSxhQUFLLFNBQUwsQ0FBZSxPQUFmLEVBQXdCLHVDQUF4QjtBQUNEO0FBQ0QsYUFBTyxLQUFQO0FBQ0Q7QUFDRCxXQUFPLElBQVA7QUFDRCxHQXJ0QmU7O0FBdXRCaEIsYUFBVyxxQkFBVztBQUNwQjs7QUFFQTtBQUNBLFFBQUksY0FBYyxRQUFRLFdBQTFCO0FBQ0EsUUFBSSxXQUFKLEVBQWlCO0FBQ2YsV0FBSyxNQUFMLENBQVksWUFBWSxHQUF4QixFQUE2QixZQUFZLE1BQXpDLEVBQWlELE9BQWpEO0FBQ0Q7QUFDRixHQS90QmU7O0FBaXVCaEIsb0JBQWtCLDBCQUFTLE9BQVQsRUFBa0I7QUFDbEMsUUFDRSxDQUFDLFNBREgsQ0FDYTtBQURiLE1BR0U7O0FBRUYsY0FBVSxZQUNSO0FBQ0UsZUFBUyxLQUFLLFdBQUwsRUFEWDtBQUVFLFdBQUssS0FBSyxJQUZaO0FBR0UsWUFBTSxLQUFLLGNBQUwsQ0FBb0IsSUFBcEIsSUFBNEI7QUFIcEMsS0FEUSxFQU1SLE9BTlEsQ0FBVjs7QUFTQSxRQUFJLENBQUMsUUFBUSxPQUFiLEVBQXNCO0FBQ3BCLFlBQU0sSUFBSSxnQkFBSixDQUFxQixpQkFBckIsQ0FBTjtBQUNEOztBQUVELFFBQUksQ0FBQyxRQUFRLEdBQWIsRUFBa0I7QUFDaEIsWUFBTSxJQUFJLGdCQUFKLENBQXFCLGFBQXJCLENBQU47QUFDRDs7QUFFRCxRQUFJLFNBQVMsa0JBQWI7QUFDQSxRQUFJLGlCQUFpQixFQUFyQjs7QUFFQSxTQUFLLElBQUksR0FBVCxJQUFnQixPQUFoQixFQUF5QjtBQUN2QixVQUFJLFFBQVEsTUFBWixFQUFvQjtBQUNsQixZQUFJLE9BQU8sUUFBUSxJQUFuQjtBQUNBLFlBQUksS0FBSyxJQUFULEVBQWUsZUFBZSxJQUFmLENBQW9CLFVBQVUsT0FBTyxLQUFLLElBQVosQ0FBOUI7QUFDZixZQUFJLEtBQUssS0FBVCxFQUFnQixlQUFlLElBQWYsQ0FBb0IsV0FBVyxPQUFPLEtBQUssS0FBWixDQUEvQjtBQUNqQixPQUpELE1BSU87QUFDTCx1QkFBZSxJQUFmLENBQW9CLE9BQU8sR0FBUCxJQUFjLEdBQWQsR0FBb0IsT0FBTyxRQUFRLEdBQVIsQ0FBUCxDQUF4QztBQUNEO0FBQ0Y7QUFDRCxRQUFJLGVBQWUsS0FBSyxnQkFBTCxDQUFzQixLQUFLLFNBQUwsQ0FBZSxRQUFRLEdBQXZCLENBQXRCLENBQW5COztBQUVBLFFBQUksU0FBUyxVQUFVLGFBQVYsQ0FBd0IsUUFBeEIsQ0FBYjtBQUNBLFdBQU8sS0FBUCxHQUFlLElBQWY7QUFDQSxXQUFPLEdBQVAsR0FBYSxlQUFlLHlCQUFmLEdBQTJDLGVBQWUsSUFBZixDQUFvQixHQUFwQixDQUF4RDtBQUNBLEtBQUMsVUFBVSxJQUFWLElBQWtCLFVBQVUsSUFBN0IsRUFBbUMsV0FBbkMsQ0FBK0MsTUFBL0M7QUFDRCxHQTF3QmU7O0FBNHdCaEI7QUFDQSxzQkFBb0IsOEJBQVc7QUFDN0IsUUFBSSxPQUFPLElBQVg7QUFDQSxTQUFLLGNBQUwsSUFBdUIsQ0FBdkI7QUFDQSxlQUFXLFlBQVc7QUFDcEI7QUFDQSxXQUFLLGNBQUwsSUFBdUIsQ0FBdkI7QUFDRCxLQUhEO0FBSUQsR0FweEJlOztBQXN4QmhCLGlCQUFlLHVCQUFTLFNBQVQsRUFBb0IsT0FBcEIsRUFBNkI7QUFDMUM7QUFDQSxRQUFJLEdBQUosRUFBUyxHQUFUOztBQUVBLFFBQUksQ0FBQyxLQUFLLFlBQVYsRUFBd0I7O0FBRXhCLGNBQVUsV0FBVyxFQUFyQjs7QUFFQSxnQkFBWSxVQUFVLFVBQVUsTUFBVixDQUFpQixDQUFqQixFQUFvQixDQUFwQixFQUF1QixXQUF2QixFQUFWLEdBQWlELFVBQVUsTUFBVixDQUFpQixDQUFqQixDQUE3RDs7QUFFQSxRQUFJLFVBQVUsV0FBZCxFQUEyQjtBQUN6QixZQUFNLFVBQVUsV0FBVixDQUFzQixZQUF0QixDQUFOO0FBQ0EsVUFBSSxTQUFKLENBQWMsU0FBZCxFQUF5QixJQUF6QixFQUErQixJQUEvQjtBQUNELEtBSEQsTUFHTztBQUNMLFlBQU0sVUFBVSxpQkFBVixFQUFOO0FBQ0EsVUFBSSxTQUFKLEdBQWdCLFNBQWhCO0FBQ0Q7O0FBRUQsU0FBSyxHQUFMLElBQVksT0FBWjtBQUNFLFVBQUksT0FBTyxPQUFQLEVBQWdCLEdBQWhCLENBQUosRUFBMEI7QUFDeEIsWUFBSSxHQUFKLElBQVcsUUFBUSxHQUFSLENBQVg7QUFDRDtBQUhILEtBS0EsSUFBSSxVQUFVLFdBQWQsRUFBMkI7QUFDekI7QUFDQSxnQkFBVSxhQUFWLENBQXdCLEdBQXhCO0FBQ0QsS0FIRCxNQUdPO0FBQ0w7QUFDQTtBQUNBLFVBQUk7QUFDRixrQkFBVSxTQUFWLENBQW9CLE9BQU8sSUFBSSxTQUFKLENBQWMsV0FBZCxFQUEzQixFQUF3RCxHQUF4RDtBQUNELE9BRkQsQ0FFRSxPQUFPLENBQVAsRUFBVTtBQUNWO0FBQ0Q7QUFDRjtBQUNGLEdBenpCZTs7QUEyekJoQjs7Ozs7O0FBTUEsMkJBQXlCLGlDQUFTLE9BQVQsRUFBa0I7QUFDekMsUUFBSSxPQUFPLElBQVg7QUFDQSxXQUFPLFVBQVMsR0FBVCxFQUFjO0FBQ25CO0FBQ0E7QUFDQTtBQUNBLFdBQUssZ0JBQUwsR0FBd0IsSUFBeEI7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsVUFBSSxLQUFLLGtCQUFMLEtBQTRCLEdBQWhDLEVBQXFDOztBQUVyQyxXQUFLLGtCQUFMLEdBQTBCLEdBQTFCOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBSSxNQUFKO0FBQ0EsVUFBSTtBQUNGLGlCQUFTLGlCQUFpQixJQUFJLE1BQXJCLENBQVQ7QUFDRCxPQUZELENBRUUsT0FBTyxDQUFQLEVBQVU7QUFDVixpQkFBUyxXQUFUO0FBQ0Q7O0FBRUQsV0FBSyxpQkFBTCxDQUF1QjtBQUNyQixrQkFBVSxRQUFRLE9BREcsRUFDTTtBQUMzQixpQkFBUztBQUZZLE9BQXZCO0FBSUQsS0E1QkQ7QUE2QkQsR0FoMkJlOztBQWsyQmhCOzs7OztBQUtBLHlCQUF1QixpQ0FBVztBQUNoQyxRQUFJLE9BQU8sSUFBWDtBQUFBLFFBQ0UsbUJBQW1CLElBRHJCLENBRGdDLENBRUw7O0FBRTNCO0FBQ0E7QUFDQTtBQUNBLFdBQU8sVUFBUyxHQUFULEVBQWM7QUFDbkIsVUFBSSxNQUFKO0FBQ0EsVUFBSTtBQUNGLGlCQUFTLElBQUksTUFBYjtBQUNELE9BRkQsQ0FFRSxPQUFPLENBQVAsRUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNEO0FBQ0QsVUFBSSxVQUFVLFVBQVUsT0FBTyxPQUEvQjs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxVQUNFLENBQUMsT0FBRCxJQUNDLFlBQVksT0FBWixJQUF1QixZQUFZLFVBQW5DLElBQWlELENBQUMsT0FBTyxpQkFGNUQsRUFJRTs7QUFFRjtBQUNBO0FBQ0EsVUFBSSxVQUFVLEtBQUssZ0JBQW5CO0FBQ0EsVUFBSSxDQUFDLE9BQUwsRUFBYztBQUNaLGFBQUssdUJBQUwsQ0FBNkIsT0FBN0IsRUFBc0MsR0FBdEM7QUFDRDtBQUNELG1CQUFhLE9BQWI7QUFDQSxXQUFLLGdCQUFMLEdBQXdCLFdBQVcsWUFBVztBQUM1QyxhQUFLLGdCQUFMLEdBQXdCLElBQXhCO0FBQ0QsT0FGdUIsRUFFckIsZ0JBRnFCLENBQXhCO0FBR0QsS0E5QkQ7QUErQkQsR0E3NEJlOztBQSs0QmhCOzs7Ozs7QUFNQSxxQkFBbUIsMkJBQVMsSUFBVCxFQUFlLEVBQWYsRUFBbUI7QUFDcEMsUUFBSSxZQUFZLFNBQVMsS0FBSyxTQUFMLENBQWUsSUFBeEIsQ0FBaEI7QUFDQSxRQUFJLFdBQVcsU0FBUyxFQUFULENBQWY7QUFDQSxRQUFJLGFBQWEsU0FBUyxJQUFULENBQWpCOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFNBQUssU0FBTCxHQUFpQixFQUFqQjs7QUFFQTtBQUNBO0FBQ0EsUUFBSSxVQUFVLFFBQVYsS0FBdUIsU0FBUyxRQUFoQyxJQUE0QyxVQUFVLElBQVYsS0FBbUIsU0FBUyxJQUE1RSxFQUNFLEtBQUssU0FBUyxRQUFkO0FBQ0YsUUFBSSxVQUFVLFFBQVYsS0FBdUIsV0FBVyxRQUFsQyxJQUE4QyxVQUFVLElBQVYsS0FBbUIsV0FBVyxJQUFoRixFQUNFLE9BQU8sV0FBVyxRQUFsQjs7QUFFRixTQUFLLGlCQUFMLENBQXVCO0FBQ3JCLGdCQUFVLFlBRFc7QUFFckIsWUFBTTtBQUNKLFlBQUksRUFEQTtBQUVKLGNBQU07QUFGRjtBQUZlLEtBQXZCO0FBT0QsR0E3NkJlOztBQSs2QmhCLDBCQUF3QixrQ0FBVztBQUNqQyxRQUFJLE9BQU8sSUFBWDtBQUNBLFNBQUsseUJBQUwsR0FBaUMsU0FBUyxTQUFULENBQW1CLFFBQXBEO0FBQ0E7QUFDQSxhQUFTLFNBQVQsQ0FBbUIsUUFBbkIsR0FBOEIsWUFBVztBQUN2QyxVQUFJLE9BQU8sSUFBUCxLQUFnQixVQUFoQixJQUE4QixLQUFLLFNBQXZDLEVBQWtEO0FBQ2hELGVBQU8sS0FBSyx5QkFBTCxDQUErQixLQUEvQixDQUFxQyxLQUFLLFFBQTFDLEVBQW9ELFNBQXBELENBQVA7QUFDRDtBQUNELGFBQU8sS0FBSyx5QkFBTCxDQUErQixLQUEvQixDQUFxQyxJQUFyQyxFQUEyQyxTQUEzQyxDQUFQO0FBQ0QsS0FMRDtBQU1ELEdBejdCZTs7QUEyN0JoQiw0QkFBMEIsb0NBQVc7QUFDbkMsUUFBSSxLQUFLLHlCQUFULEVBQW9DO0FBQ2xDO0FBQ0EsZUFBUyxTQUFULENBQW1CLFFBQW5CLEdBQThCLEtBQUsseUJBQW5DO0FBQ0Q7QUFDRixHQWg4QmU7O0FBazhCaEI7Ozs7QUFJQSx1QkFBcUIsK0JBQVc7QUFDOUIsUUFBSSxPQUFPLElBQVg7O0FBRUEsUUFBSSxrQkFBa0IsS0FBSyxnQkFBM0I7O0FBRUEsYUFBUyxVQUFULENBQW9CLElBQXBCLEVBQTBCO0FBQ3hCLGFBQU8sVUFBUyxFQUFULEVBQWEsQ0FBYixFQUFnQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQSxZQUFJLE9BQU8sSUFBSSxLQUFKLENBQVUsVUFBVSxNQUFwQixDQUFYO0FBQ0EsYUFBSyxJQUFJLElBQUksQ0FBYixFQUFnQixJQUFJLEtBQUssTUFBekIsRUFBaUMsRUFBRSxDQUFuQyxFQUFzQztBQUNwQyxlQUFLLENBQUwsSUFBVSxVQUFVLENBQVYsQ0FBVjtBQUNEO0FBQ0QsWUFBSSxtQkFBbUIsS0FBSyxDQUFMLENBQXZCO0FBQ0EsWUFBSSxXQUFXLGdCQUFYLENBQUosRUFBa0M7QUFDaEMsZUFBSyxDQUFMLElBQVUsS0FBSyxJQUFMLENBQ1I7QUFDRSx1QkFBVztBQUNULG9CQUFNLFlBREc7QUFFVCxvQkFBTSxFQUFDLFVBQVUsS0FBSyxJQUFMLElBQWEsYUFBeEI7QUFGRztBQURiLFdBRFEsRUFPUixnQkFQUSxDQUFWO0FBU0Q7O0FBRUQ7QUFDQTtBQUNBO0FBQ0EsWUFBSSxLQUFLLEtBQVQsRUFBZ0I7QUFDZCxpQkFBTyxLQUFLLEtBQUwsQ0FBVyxJQUFYLEVBQWlCLElBQWpCLENBQVA7QUFDRCxTQUZELE1BRU87QUFDTCxpQkFBTyxLQUFLLEtBQUssQ0FBTCxDQUFMLEVBQWMsS0FBSyxDQUFMLENBQWQsQ0FBUDtBQUNEO0FBQ0YsT0E3QkQ7QUE4QkQ7O0FBRUQsUUFBSSxrQkFBa0IsS0FBSyxjQUFMLENBQW9CLGVBQTFDOztBQUVBLGFBQVMsZUFBVCxDQUF5QixNQUF6QixFQUFpQztBQUMvQixVQUFJLFFBQVEsUUFBUSxNQUFSLEtBQW1CLFFBQVEsTUFBUixFQUFnQixTQUEvQztBQUNBLFVBQUksU0FBUyxNQUFNLGNBQWYsSUFBaUMsTUFBTSxjQUFOLENBQXFCLGtCQUFyQixDQUFyQyxFQUErRTtBQUM3RSxhQUNFLEtBREYsRUFFRSxrQkFGRixFQUdFLFVBQVMsSUFBVCxFQUFlO0FBQ2IsaUJBQU8sVUFBUyxPQUFULEVBQWtCLEVBQWxCLEVBQXNCLE9BQXRCLEVBQStCLE1BQS9CLEVBQXVDO0FBQzVDO0FBQ0EsZ0JBQUk7QUFDRixrQkFBSSxNQUFNLEdBQUcsV0FBYixFQUEwQjtBQUN4QixtQkFBRyxXQUFILEdBQWlCLEtBQUssSUFBTCxDQUNmO0FBQ0UsNkJBQVc7QUFDVCwwQkFBTSxZQURHO0FBRVQsMEJBQU07QUFDSiw4QkFBUSxNQURKO0FBRUosZ0NBQVUsYUFGTjtBQUdKLCtCQUFVLE1BQU0sR0FBRyxJQUFWLElBQW1CO0FBSHhCO0FBRkc7QUFEYixpQkFEZSxFQVdmLEdBQUcsV0FYWSxDQUFqQjtBQWFEO0FBQ0YsYUFoQkQsQ0FnQkUsT0FBTyxHQUFQLEVBQVksQ0FFYjtBQURDOzs7QUFHRjtBQUNBO0FBQ0EsZ0JBQUksTUFBSixFQUFZLFlBQVosRUFBMEIsZUFBMUI7O0FBRUEsZ0JBQ0UsbUJBQ0EsZ0JBQWdCLEdBRGhCLEtBRUMsV0FBVyxhQUFYLElBQTRCLFdBQVcsTUFGeEMsQ0FERixFQUlFO0FBQ0E7QUFDQTtBQUNBLDZCQUFlLEtBQUssdUJBQUwsQ0FBNkIsT0FBN0IsQ0FBZjtBQUNBLGdDQUFrQixLQUFLLHFCQUFMLEVBQWxCO0FBQ0EsdUJBQVMsZ0JBQVMsR0FBVCxFQUFjO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBLG9CQUFJLENBQUMsR0FBTCxFQUFVOztBQUVWLG9CQUFJLFNBQUo7QUFDQSxvQkFBSTtBQUNGLDhCQUFZLElBQUksSUFBaEI7QUFDRCxpQkFGRCxDQUVFLE9BQU8sQ0FBUCxFQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0Q7QUFDRCxvQkFBSSxjQUFjLE9BQWxCLEVBQTJCLE9BQU8sYUFBYSxHQUFiLENBQVAsQ0FBM0IsS0FDSyxJQUFJLGNBQWMsVUFBbEIsRUFBOEIsT0FBTyxnQkFBZ0IsR0FBaEIsQ0FBUDtBQUNwQyxlQWhCRDtBQWlCRDtBQUNELG1CQUFPLEtBQUssSUFBTCxDQUNMLElBREssRUFFTCxPQUZLLEVBR0wsS0FBSyxJQUFMLENBQ0U7QUFDRSx5QkFBVztBQUNULHNCQUFNLFlBREc7QUFFVCxzQkFBTTtBQUNKLDBCQUFRLE1BREo7QUFFSiw0QkFBVSxrQkFGTjtBQUdKLDJCQUFVLE1BQU0sR0FBRyxJQUFWLElBQW1CO0FBSHhCO0FBRkc7QUFEYixhQURGLEVBV0UsRUFYRixFQVlFLE1BWkYsQ0FISyxFQWlCTCxPQWpCSyxFQWtCTCxNQWxCSyxDQUFQO0FBb0JELFdBekVEO0FBMEVELFNBOUVILEVBK0VFLGVBL0VGO0FBaUZBLGFBQ0UsS0FERixFQUVFLHFCQUZGLEVBR0UsVUFBUyxJQUFULEVBQWU7QUFDYixpQkFBTyxVQUFTLEdBQVQsRUFBYyxFQUFkLEVBQWtCLE9BQWxCLEVBQTJCLE1BQTNCLEVBQW1DO0FBQ3hDLGdCQUFJO0FBQ0YsbUJBQUssT0FBTyxHQUFHLGlCQUFILEdBQXVCLEdBQUcsaUJBQTFCLEdBQThDLEVBQXJELENBQUw7QUFDRCxhQUZELENBRUUsT0FBTyxDQUFQLEVBQVU7QUFDVjtBQUNEO0FBQ0QsbUJBQU8sS0FBSyxJQUFMLENBQVUsSUFBVixFQUFnQixHQUFoQixFQUFxQixFQUFyQixFQUF5QixPQUF6QixFQUFrQyxNQUFsQyxDQUFQO0FBQ0QsV0FQRDtBQVFELFNBWkgsRUFhRSxlQWJGO0FBZUQ7QUFDRjs7QUFFRCxTQUFLLE9BQUwsRUFBYyxZQUFkLEVBQTRCLFVBQTVCLEVBQXdDLGVBQXhDO0FBQ0EsU0FBSyxPQUFMLEVBQWMsYUFBZCxFQUE2QixVQUE3QixFQUF5QyxlQUF6QztBQUNBLFFBQUksUUFBUSxxQkFBWixFQUFtQztBQUNqQyxXQUNFLE9BREYsRUFFRSx1QkFGRixFQUdFLFVBQVMsSUFBVCxFQUFlO0FBQ2IsZUFBTyxVQUFTLEVBQVQsRUFBYTtBQUNsQixpQkFBTyxLQUNMLEtBQUssSUFBTCxDQUNFO0FBQ0UsdUJBQVc7QUFDVCxvQkFBTSxZQURHO0FBRVQsb0JBQU07QUFDSiwwQkFBVSx1QkFETjtBQUVKLHlCQUFVLFFBQVEsS0FBSyxJQUFkLElBQXVCO0FBRjVCO0FBRkc7QUFEYixXQURGLEVBVUUsRUFWRixDQURLLENBQVA7QUFjRCxTQWZEO0FBZ0JELE9BcEJILEVBcUJFLGVBckJGO0FBdUJEOztBQUVEO0FBQ0E7QUFDQSxRQUFJLGVBQWUsQ0FDakIsYUFEaUIsRUFFakIsUUFGaUIsRUFHakIsTUFIaUIsRUFJakIsa0JBSmlCLEVBS2pCLGdCQUxpQixFQU1qQixtQkFOaUIsRUFPakIsaUJBUGlCLEVBUWpCLGFBUmlCLEVBU2pCLFlBVGlCLEVBVWpCLG9CQVZpQixFQVdqQixhQVhpQixFQVlqQixZQVppQixFQWFqQixnQkFiaUIsRUFjakIsY0FkaUIsRUFlakIsaUJBZmlCLEVBZ0JqQixhQWhCaUIsRUFpQmpCLGFBakJpQixFQWtCakIsY0FsQmlCLEVBbUJqQixvQkFuQmlCLEVBb0JqQixRQXBCaUIsRUFxQmpCLFdBckJpQixFQXNCakIsY0F0QmlCLEVBdUJqQixlQXZCaUIsRUF3QmpCLFdBeEJpQixFQXlCakIsaUJBekJpQixFQTBCakIsUUExQmlCLEVBMkJqQixnQkEzQmlCLEVBNEJqQiwyQkE1QmlCLEVBNkJqQixzQkE3QmlCLENBQW5CO0FBK0JBLFNBQUssSUFBSSxJQUFJLENBQWIsRUFBZ0IsSUFBSSxhQUFhLE1BQWpDLEVBQXlDLEdBQXpDLEVBQThDO0FBQzVDLHNCQUFnQixhQUFhLENBQWIsQ0FBaEI7QUFDRDtBQUNGLEdBcHBDZTs7QUFzcENoQjs7Ozs7Ozs7O0FBU0EsMEJBQXdCLGtDQUFXO0FBQ2pDLFFBQUksT0FBTyxJQUFYO0FBQ0EsUUFBSSxrQkFBa0IsS0FBSyxjQUFMLENBQW9CLGVBQTFDOztBQUVBLFFBQUksa0JBQWtCLEtBQUssZ0JBQTNCOztBQUVBLGFBQVMsUUFBVCxDQUFrQixJQUFsQixFQUF3QixHQUF4QixFQUE2QjtBQUMzQixVQUFJLFFBQVEsR0FBUixJQUFlLFdBQVcsSUFBSSxJQUFKLENBQVgsQ0FBbkIsRUFBMEM7QUFDeEMsYUFBSyxHQUFMLEVBQVUsSUFBVixFQUFnQixVQUFTLElBQVQsRUFBZTtBQUM3QixpQkFBTyxLQUFLLElBQUwsQ0FDTDtBQUNFLHVCQUFXO0FBQ1Qsb0JBQU0sWUFERztBQUVULG9CQUFNLEVBQUMsVUFBVSxJQUFYLEVBQWlCLFNBQVUsUUFBUSxLQUFLLElBQWQsSUFBdUIsYUFBakQ7QUFGRztBQURiLFdBREssRUFPTCxJQVBLLENBQVA7QUFTRCxTQVZELEVBRHdDLENBV3BDO0FBQ0w7QUFDRjs7QUFFRCxRQUFJLGdCQUFnQixHQUFoQixJQUF1QixvQkFBb0IsT0FBL0MsRUFBd0Q7QUFDdEQsVUFBSSxXQUFXLFFBQVEsY0FBUixJQUEwQixRQUFRLGNBQVIsQ0FBdUIsU0FBaEU7QUFDQSxXQUNFLFFBREYsRUFFRSxNQUZGLEVBR0UsVUFBUyxRQUFULEVBQW1CO0FBQ2pCLGVBQU8sVUFBUyxNQUFULEVBQWlCLEdBQWpCLEVBQXNCO0FBQzNCOztBQUVBO0FBQ0EsY0FBSSxTQUFTLEdBQVQsS0FBaUIsSUFBSSxPQUFKLENBQVksS0FBSyxVQUFqQixNQUFpQyxDQUFDLENBQXZELEVBQTBEO0FBQ3hELGlCQUFLLFdBQUwsR0FBbUI7QUFDakIsc0JBQVEsTUFEUztBQUVqQixtQkFBSyxHQUZZO0FBR2pCLDJCQUFhO0FBSEksYUFBbkI7QUFLRDs7QUFFRCxpQkFBTyxTQUFTLEtBQVQsQ0FBZSxJQUFmLEVBQXFCLFNBQXJCLENBQVA7QUFDRCxTQWJEO0FBY0QsT0FsQkgsRUFtQkUsZUFuQkY7O0FBc0JBLFdBQ0UsUUFERixFQUVFLE1BRkYsRUFHRSxVQUFTLFFBQVQsRUFBbUI7QUFDakIsZUFBTyxZQUFXO0FBQ2hCO0FBQ0EsY0FBSSxNQUFNLElBQVY7O0FBRUEsbUJBQVMseUJBQVQsR0FBcUM7QUFDbkMsZ0JBQUksSUFBSSxXQUFKLElBQW1CLElBQUksVUFBSixLQUFtQixDQUExQyxFQUE2QztBQUMzQyxrQkFBSTtBQUNGO0FBQ0E7QUFDQSxvQkFBSSxXQUFKLENBQWdCLFdBQWhCLEdBQThCLElBQUksTUFBbEM7QUFDRCxlQUpELENBSUUsT0FBTyxDQUFQLEVBQVU7QUFDVjtBQUNEOztBQUVELG1CQUFLLGlCQUFMLENBQXVCO0FBQ3JCLHNCQUFNLE1BRGU7QUFFckIsMEJBQVUsS0FGVztBQUdyQixzQkFBTSxJQUFJO0FBSFcsZUFBdkI7QUFLRDtBQUNGOztBQUVELGNBQUksUUFBUSxDQUFDLFFBQUQsRUFBVyxTQUFYLEVBQXNCLFlBQXRCLENBQVo7QUFDQSxlQUFLLElBQUksSUFBSSxDQUFiLEVBQWdCLElBQUksTUFBTSxNQUExQixFQUFrQyxHQUFsQyxFQUF1QztBQUNyQyxxQkFBUyxNQUFNLENBQU4sQ0FBVCxFQUFtQixHQUFuQjtBQUNEOztBQUVELGNBQUksd0JBQXdCLEdBQXhCLElBQStCLFdBQVcsSUFBSSxrQkFBZixDQUFuQyxFQUF1RTtBQUNyRSxpQkFDRSxHQURGLEVBRUUsb0JBRkYsRUFHRSxVQUFTLElBQVQsRUFBZTtBQUNiLHFCQUFPLEtBQUssSUFBTCxDQUNMO0FBQ0UsMkJBQVc7QUFDVCx3QkFBTSxZQURHO0FBRVQsd0JBQU07QUFDSiw4QkFBVSxvQkFETjtBQUVKLDZCQUFVLFFBQVEsS0FBSyxJQUFkLElBQXVCO0FBRjVCO0FBRkc7QUFEYixlQURLLEVBVUwsSUFWSyxFQVdMLHlCQVhLLENBQVA7QUFhRCxhQWpCSCxDQWlCSTtBQWpCSjtBQW1CRCxXQXBCRCxNQW9CTztBQUNMO0FBQ0E7QUFDQSxnQkFBSSxrQkFBSixHQUF5Qix5QkFBekI7QUFDRDs7QUFFRCxpQkFBTyxTQUFTLEtBQVQsQ0FBZSxJQUFmLEVBQXFCLFNBQXJCLENBQVA7QUFDRCxTQXRERDtBQXVERCxPQTNESCxFQTRERSxlQTVERjtBQThERDs7QUFFRCxRQUFJLGdCQUFnQixHQUFoQixJQUF1QixlQUEzQixFQUE0QztBQUMxQyxXQUNFLE9BREYsRUFFRSxPQUZGLEVBR0UsVUFBUyxTQUFULEVBQW9CO0FBQ2xCLGVBQU8sWUFBVztBQUNoQjtBQUNBO0FBQ0E7QUFDQSxjQUFJLE9BQU8sSUFBSSxLQUFKLENBQVUsVUFBVSxNQUFwQixDQUFYO0FBQ0EsZUFBSyxJQUFJLElBQUksQ0FBYixFQUFnQixJQUFJLEtBQUssTUFBekIsRUFBaUMsRUFBRSxDQUFuQyxFQUFzQztBQUNwQyxpQkFBSyxDQUFMLElBQVUsVUFBVSxDQUFWLENBQVY7QUFDRDs7QUFFRCxjQUFJLGFBQWEsS0FBSyxDQUFMLENBQWpCO0FBQ0EsY0FBSSxTQUFTLEtBQWI7QUFDQSxjQUFJLEdBQUo7O0FBRUEsY0FBSSxPQUFPLFVBQVAsS0FBc0IsUUFBMUIsRUFBb0M7QUFDbEMsa0JBQU0sVUFBTjtBQUNELFdBRkQsTUFFTyxJQUFJLGFBQWEsT0FBYixJQUF3QixzQkFBc0IsUUFBUSxPQUExRCxFQUFtRTtBQUN4RSxrQkFBTSxXQUFXLEdBQWpCO0FBQ0EsZ0JBQUksV0FBVyxNQUFmLEVBQXVCO0FBQ3JCLHVCQUFTLFdBQVcsTUFBcEI7QUFDRDtBQUNGLFdBTE0sTUFLQTtBQUNMLGtCQUFNLEtBQUssVUFBWDtBQUNEOztBQUVEO0FBQ0EsY0FBSSxJQUFJLE9BQUosQ0FBWSxLQUFLLFVBQWpCLE1BQWlDLENBQUMsQ0FBdEMsRUFBeUM7QUFDdkMsbUJBQU8sVUFBVSxLQUFWLENBQWdCLElBQWhCLEVBQXNCLElBQXRCLENBQVA7QUFDRDs7QUFFRCxjQUFJLEtBQUssQ0FBTCxLQUFXLEtBQUssQ0FBTCxFQUFRLE1BQXZCLEVBQStCO0FBQzdCLHFCQUFTLEtBQUssQ0FBTCxFQUFRLE1BQWpCO0FBQ0Q7O0FBRUQsY0FBSSxZQUFZO0FBQ2Qsb0JBQVEsTUFETTtBQUVkLGlCQUFLLEdBRlM7QUFHZCx5QkFBYTtBQUhDLFdBQWhCOztBQU1BLGlCQUFPLFVBQ0osS0FESSxDQUNFLElBREYsRUFDUSxJQURSLEVBRUosSUFGSSxDQUVDLFVBQVMsUUFBVCxFQUFtQjtBQUN2QixzQkFBVSxXQUFWLEdBQXdCLFNBQVMsTUFBakM7O0FBRUEsaUJBQUssaUJBQUwsQ0FBdUI7QUFDckIsb0JBQU0sTUFEZTtBQUVyQix3QkFBVSxPQUZXO0FBR3JCLG9CQUFNO0FBSGUsYUFBdkI7O0FBTUEsbUJBQU8sUUFBUDtBQUNELFdBWkksRUFhSixPQWJJLEVBYUssVUFBUyxHQUFULEVBQWM7QUFDdEI7QUFDQSxpQkFBSyxpQkFBTCxDQUF1QjtBQUNyQixvQkFBTSxNQURlO0FBRXJCLHdCQUFVLE9BRlc7QUFHckIsb0JBQU0sU0FIZTtBQUlyQixxQkFBTztBQUpjLGFBQXZCOztBQU9BLGtCQUFNLEdBQU47QUFDRCxXQXZCSSxDQUFQO0FBd0JELFNBL0REO0FBZ0VELE9BcEVILEVBcUVFLGVBckVGO0FBdUVEOztBQUVEO0FBQ0E7QUFDQSxRQUFJLGdCQUFnQixHQUFoQixJQUF1QixLQUFLLFlBQWhDLEVBQThDO0FBQzVDLFVBQUksVUFBVSxnQkFBZCxFQUFnQztBQUM5QixrQkFBVSxnQkFBVixDQUEyQixPQUEzQixFQUFvQyxLQUFLLHVCQUFMLENBQTZCLE9BQTdCLENBQXBDLEVBQTJFLEtBQTNFO0FBQ0Esa0JBQVUsZ0JBQVYsQ0FBMkIsVUFBM0IsRUFBdUMsS0FBSyxxQkFBTCxFQUF2QyxFQUFxRSxLQUFyRTtBQUNELE9BSEQsTUFHTyxJQUFJLFVBQVUsV0FBZCxFQUEyQjtBQUNoQztBQUNBLGtCQUFVLFdBQVYsQ0FBc0IsU0FBdEIsRUFBaUMsS0FBSyx1QkFBTCxDQUE2QixPQUE3QixDQUFqQztBQUNBLGtCQUFVLFdBQVYsQ0FBc0IsWUFBdEIsRUFBb0MsS0FBSyxxQkFBTCxFQUFwQztBQUNEO0FBQ0Y7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFJLFNBQVMsUUFBUSxNQUFyQjtBQUNBLFFBQUksc0JBQXNCLFVBQVUsT0FBTyxHQUFqQixJQUF3QixPQUFPLEdBQVAsQ0FBVyxPQUE3RDtBQUNBLFFBQUkseUJBQ0YsQ0FBQyxtQkFBRCxJQUNBLFFBQVEsT0FEUixJQUVBLFFBQVEsT0FBUixDQUFnQixTQUZoQixJQUdBLFFBQVEsT0FBUixDQUFnQixZQUpsQjtBQUtBLFFBQUksZ0JBQWdCLFFBQWhCLElBQTRCLHNCQUFoQyxFQUF3RDtBQUN0RDtBQUNBLFVBQUksZ0JBQWdCLFFBQVEsVUFBNUI7QUFDQSxjQUFRLFVBQVIsR0FBcUIsWUFBVztBQUM5QixZQUFJLGNBQWMsS0FBSyxTQUFMLENBQWUsSUFBakM7QUFDQSxhQUFLLGlCQUFMLENBQXVCLEtBQUssU0FBNUIsRUFBdUMsV0FBdkM7O0FBRUEsWUFBSSxhQUFKLEVBQW1CO0FBQ2pCLGlCQUFPLGNBQWMsS0FBZCxDQUFvQixJQUFwQixFQUEwQixTQUExQixDQUFQO0FBQ0Q7QUFDRixPQVBEOztBQVNBLFVBQUksNkJBQTZCLFNBQTdCLDBCQUE2QixDQUFTLGdCQUFULEVBQTJCO0FBQzFEO0FBQ0E7QUFDQSxlQUFPLFlBQVMsdUJBQXlCO0FBQ3ZDLGNBQUksTUFBTSxVQUFVLE1BQVYsR0FBbUIsQ0FBbkIsR0FBdUIsVUFBVSxDQUFWLENBQXZCLEdBQXNDLFNBQWhEOztBQUVBO0FBQ0EsY0FBSSxHQUFKLEVBQVM7QUFDUDtBQUNBLGlCQUFLLGlCQUFMLENBQXVCLEtBQUssU0FBNUIsRUFBdUMsTUFBTSxFQUE3QztBQUNEOztBQUVELGlCQUFPLGlCQUFpQixLQUFqQixDQUF1QixJQUF2QixFQUE2QixTQUE3QixDQUFQO0FBQ0QsU0FWRDtBQVdELE9BZEQ7O0FBZ0JBLFdBQUssUUFBUSxPQUFiLEVBQXNCLFdBQXRCLEVBQW1DLDBCQUFuQyxFQUErRCxlQUEvRDtBQUNBLFdBQUssUUFBUSxPQUFiLEVBQXNCLGNBQXRCLEVBQXNDLDBCQUF0QyxFQUFrRSxlQUFsRTtBQUNEOztBQUVELFFBQUksZ0JBQWdCLE9BQWhCLElBQTJCLGFBQWEsT0FBeEMsSUFBbUQsUUFBUSxHQUEvRCxFQUFvRTtBQUNsRTtBQUNBLFVBQUksd0JBQXdCLFNBQXhCLHFCQUF3QixDQUFTLEdBQVQsRUFBYyxJQUFkLEVBQW9CO0FBQzlDLGFBQUssaUJBQUwsQ0FBdUI7QUFDckIsbUJBQVMsR0FEWTtBQUVyQixpQkFBTyxLQUFLLEtBRlM7QUFHckIsb0JBQVU7QUFIVyxTQUF2QjtBQUtELE9BTkQ7O0FBUUEsV0FBSyxDQUFDLE9BQUQsRUFBVSxNQUFWLEVBQWtCLE1BQWxCLEVBQTBCLE9BQTFCLEVBQW1DLEtBQW5DLENBQUwsRUFBZ0QsVUFBUyxDQUFULEVBQVksS0FBWixFQUFtQjtBQUNqRSwwQkFBa0IsT0FBbEIsRUFBMkIsS0FBM0IsRUFBa0MscUJBQWxDO0FBQ0QsT0FGRDtBQUdEO0FBQ0YsR0E3NUNlOztBQSs1Q2hCLG9CQUFrQiw0QkFBVztBQUMzQjtBQUNBLFFBQUksT0FBSjtBQUNBLFdBQU8sS0FBSyxnQkFBTCxDQUFzQixNQUE3QixFQUFxQztBQUNuQyxnQkFBVSxLQUFLLGdCQUFMLENBQXNCLEtBQXRCLEVBQVY7O0FBRUEsVUFBSSxNQUFNLFFBQVEsQ0FBUixDQUFWO0FBQUEsVUFDRSxPQUFPLFFBQVEsQ0FBUixDQURUO0FBQUEsVUFFRSxPQUFPLFFBQVEsQ0FBUixDQUZUOztBQUlBLFVBQUksSUFBSixJQUFZLElBQVo7QUFDRDtBQUNGLEdBMzZDZTs7QUE2NkNoQixtQkFBaUIsMkJBQVc7QUFDMUI7QUFDQSxTQUFLLElBQUksTUFBVCxJQUFtQixLQUFLLHVCQUF4QixFQUFpRDtBQUMvQyxXQUFLLGdCQUFMLENBQXNCLE1BQXRCLElBQWdDLEtBQUssdUJBQUwsQ0FBNkIsTUFBN0IsQ0FBaEM7QUFDRDtBQUNGLEdBbDdDZTs7QUFvN0NoQixpQkFBZSx5QkFBVztBQUN4QixRQUFJLE9BQU8sSUFBWDs7QUFFQTtBQUNBLFNBQUssS0FBSyxRQUFWLEVBQW9CLFVBQVMsQ0FBVCxFQUFZLE1BQVosRUFBb0I7QUFDdEMsVUFBSSxZQUFZLE9BQU8sQ0FBUCxDQUFoQjtBQUNBLFVBQUksT0FBTyxPQUFPLENBQVAsQ0FBWDtBQUNBLGdCQUFVLEtBQVYsQ0FBZ0IsSUFBaEIsRUFBc0IsQ0FBQyxJQUFELEVBQU8sTUFBUCxDQUFjLElBQWQsQ0FBdEI7QUFDRCxLQUpEO0FBS0QsR0E3N0NlOztBQSs3Q2hCLGFBQVcsbUJBQVMsR0FBVCxFQUFjO0FBQ3ZCLFFBQUksSUFBSSxXQUFXLElBQVgsQ0FBZ0IsR0FBaEIsQ0FBUjtBQUFBLFFBQ0UsTUFBTSxFQURSO0FBQUEsUUFFRSxJQUFJLENBRk47O0FBSUEsUUFBSTtBQUNGLGFBQU8sR0FBUDtBQUFZLFlBQUksUUFBUSxDQUFSLENBQUosSUFBa0IsRUFBRSxDQUFGLEtBQVEsRUFBMUI7QUFBWjtBQUNELEtBRkQsQ0FFRSxPQUFPLENBQVAsRUFBVTtBQUNWLFlBQU0sSUFBSSxnQkFBSixDQUFxQixrQkFBa0IsR0FBdkMsQ0FBTjtBQUNEOztBQUVELFFBQUksSUFBSSxJQUFKLElBQVksQ0FBQyxLQUFLLGNBQUwsQ0FBb0IsY0FBckMsRUFBcUQ7QUFDbkQsWUFBTSxJQUFJLGdCQUFKLENBQ0osZ0ZBREksQ0FBTjtBQUdEOztBQUVELFdBQU8sR0FBUDtBQUNELEdBajlDZTs7QUFtOUNoQixvQkFBa0IsMEJBQVMsR0FBVCxFQUFjO0FBQzlCO0FBQ0EsUUFBSSxlQUFlLE9BQU8sSUFBSSxJQUFYLElBQW1CLElBQUksSUFBSixHQUFXLE1BQU0sSUFBSSxJQUFyQixHQUE0QixFQUEvQyxDQUFuQjs7QUFFQSxRQUFJLElBQUksUUFBUixFQUFrQjtBQUNoQixxQkFBZSxJQUFJLFFBQUosR0FBZSxHQUFmLEdBQXFCLFlBQXBDO0FBQ0Q7QUFDRCxXQUFPLFlBQVA7QUFDRCxHQTM5Q2U7O0FBNjlDaEIsMkJBQXlCLGlDQUFTLFNBQVQsRUFBb0IsT0FBcEIsRUFBNkI7QUFDcEQsY0FBVSxXQUFXLEVBQXJCO0FBQ0EsWUFBUSxTQUFSLEdBQW9CLFFBQVEsU0FBUixJQUFxQjtBQUN2QyxZQUFNLFNBRGlDO0FBRXZDLGVBQVM7QUFGOEIsS0FBekM7O0FBS0E7QUFDQSxRQUFJLENBQUMsS0FBSyxjQUFWLEVBQTBCO0FBQ3hCLFdBQUssZ0JBQUwsQ0FBc0IsU0FBdEIsRUFBaUMsT0FBakM7QUFDRDtBQUNGLEdBeCtDZTs7QUEwK0NoQixvQkFBa0IsMEJBQVMsU0FBVCxFQUFvQixPQUFwQixFQUE2QjtBQUM3QyxRQUFJLFNBQVMsS0FBSyxjQUFMLENBQW9CLFNBQXBCLEVBQStCLE9BQS9CLENBQWI7O0FBRUEsU0FBSyxhQUFMLENBQW1CLFFBQW5CLEVBQTZCO0FBQzNCLGlCQUFXLFNBRGdCO0FBRTNCLGVBQVM7QUFGa0IsS0FBN0I7O0FBS0EsU0FBSyxpQkFBTCxDQUNFLFVBQVUsSUFEWixFQUVFLFVBQVUsT0FGWixFQUdFLFVBQVUsR0FIWixFQUlFLFVBQVUsTUFKWixFQUtFLE1BTEYsRUFNRSxPQU5GO0FBUUQsR0ExL0NlOztBQTQvQ2hCLGtCQUFnQix3QkFBUyxTQUFULEVBQW9CLE9BQXBCLEVBQTZCO0FBQzNDLFFBQUksT0FBTyxJQUFYO0FBQ0EsUUFBSSxTQUFTLEVBQWI7QUFDQSxRQUFJLFVBQVUsS0FBVixJQUFtQixVQUFVLEtBQVYsQ0FBZ0IsTUFBdkMsRUFBK0M7QUFDN0MsV0FBSyxVQUFVLEtBQWYsRUFBc0IsVUFBUyxDQUFULEVBQVksS0FBWixFQUFtQjtBQUN2QyxZQUFJLFFBQVEsS0FBSyxlQUFMLENBQXFCLEtBQXJCLEVBQTRCLFVBQVUsR0FBdEMsQ0FBWjtBQUNBLFlBQUksS0FBSixFQUFXO0FBQ1QsaUJBQU8sSUFBUCxDQUFZLEtBQVo7QUFDRDtBQUNGLE9BTEQ7O0FBT0E7QUFDQSxVQUFJLFdBQVcsUUFBUSxjQUF2QixFQUF1QztBQUNyQyxhQUFLLElBQUksSUFBSSxDQUFiLEVBQWdCLElBQUksUUFBUSxjQUFaLElBQThCLElBQUksT0FBTyxNQUF6RCxFQUFpRSxHQUFqRSxFQUFzRTtBQUNwRSxpQkFBTyxDQUFQLEVBQVUsTUFBVixHQUFtQixLQUFuQjtBQUNEO0FBQ0Y7QUFDRjtBQUNELGFBQVMsT0FBTyxLQUFQLENBQWEsQ0FBYixFQUFnQixLQUFLLGNBQUwsQ0FBb0IsZUFBcEMsQ0FBVDtBQUNBLFdBQU8sTUFBUDtBQUNELEdBaGhEZTs7QUFraERoQixtQkFBaUIseUJBQVMsS0FBVCxFQUFnQixZQUFoQixFQUE4QjtBQUM3QztBQUNBLFFBQUksYUFBYTtBQUNmLGdCQUFVLE1BQU0sR0FERDtBQUVmLGNBQVEsTUFBTSxJQUZDO0FBR2YsYUFBTyxNQUFNLE1BSEU7QUFJZixnQkFBVSxNQUFNLElBQU4sSUFBYztBQUpULEtBQWpCOztBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFJLENBQUMsTUFBTSxHQUFYLEVBQWdCO0FBQ2QsaUJBQVcsUUFBWCxHQUFzQixZQUF0QixDQURjLENBQ3NCO0FBQ3JDOztBQUVELGVBQVcsTUFBWCxHQUFvQixHQUFDO0FBQ3JCO0FBRUcsS0FBQyxDQUFDLEtBQUssY0FBTCxDQUFvQixZQUFwQixDQUFpQyxJQUFuQyxJQUNDLENBQUMsS0FBSyxjQUFMLENBQW9CLFlBQXBCLENBQWlDLElBQWpDLENBQXNDLFdBQVcsUUFBakQsQ0FESDtBQUVBO0FBQ0EseUJBQXFCLElBQXJCLENBQTBCLFdBQVcsVUFBWCxDQUExQixDQUhBO0FBSUE7QUFDQSx5QkFBcUIsSUFBckIsQ0FBMEIsV0FBVyxRQUFyQyxDQVJrQixDQUFwQjs7QUFXQSxXQUFPLFVBQVA7QUFDRCxHQWhqRGU7O0FBa2pEaEIscUJBQW1CLDJCQUFTLElBQVQsRUFBZSxPQUFmLEVBQXdCLE9BQXhCLEVBQWlDLE1BQWpDLEVBQXlDLE1BQXpDLEVBQWlELE9BQWpELEVBQTBEO0FBQzNFLFFBQUksa0JBQWtCLENBQUMsT0FBTyxPQUFPLElBQWQsR0FBcUIsRUFBdEIsS0FBNkIsV0FBVyxFQUF4QyxDQUF0QjtBQUNBLFFBQ0UsQ0FBQyxDQUFDLEtBQUssY0FBTCxDQUFvQixZQUFwQixDQUFpQyxJQUFuQyxLQUNDLEtBQUssY0FBTCxDQUFvQixZQUFwQixDQUFpQyxJQUFqQyxDQUFzQyxPQUF0QyxLQUNDLEtBQUssY0FBTCxDQUFvQixZQUFwQixDQUFpQyxJQUFqQyxDQUFzQyxlQUF0QyxDQUZGLENBREYsRUFJRTtBQUNBO0FBQ0Q7O0FBRUQsUUFBSSxVQUFKOztBQUVBLFFBQUksVUFBVSxPQUFPLE1BQXJCLEVBQTZCO0FBQzNCLGdCQUFVLE9BQU8sQ0FBUCxFQUFVLFFBQVYsSUFBc0IsT0FBaEM7QUFDQTtBQUNBO0FBQ0EsYUFBTyxPQUFQO0FBQ0EsbUJBQWEsRUFBQyxRQUFRLE1BQVQsRUFBYjtBQUNELEtBTkQsTUFNTyxJQUFJLE9BQUosRUFBYTtBQUNsQixtQkFBYTtBQUNYLGdCQUFRLENBQ047QUFDRSxvQkFBVSxPQURaO0FBRUUsa0JBQVEsTUFGVjtBQUdFLGtCQUFRO0FBSFYsU0FETTtBQURHLE9BQWI7QUFTRDs7QUFFRCxRQUNFLENBQUMsQ0FBQyxLQUFLLGNBQUwsQ0FBb0IsVUFBcEIsQ0FBK0IsSUFBakMsSUFDQSxLQUFLLGNBQUwsQ0FBb0IsVUFBcEIsQ0FBK0IsSUFBL0IsQ0FBb0MsT0FBcEMsQ0FGRixFQUdFO0FBQ0E7QUFDRDs7QUFFRCxRQUNFLENBQUMsQ0FBQyxLQUFLLGNBQUwsQ0FBb0IsYUFBcEIsQ0FBa0MsSUFBcEMsSUFDQSxDQUFDLEtBQUssY0FBTCxDQUFvQixhQUFwQixDQUFrQyxJQUFsQyxDQUF1QyxPQUF2QyxDQUZILEVBR0U7QUFDQTtBQUNEOztBQUVELFFBQUksT0FBTyxZQUNUO0FBQ0U7QUFDQSxpQkFBVztBQUNULGdCQUFRLENBQ047QUFDRSxnQkFBTSxJQURSO0FBRUUsaUJBQU8sT0FGVDtBQUdFLHNCQUFZO0FBSGQsU0FETTtBQURDLE9BRmI7QUFXRSxtQkFBYTtBQVhmLEtBRFMsRUFjVCxPQWRTLENBQVg7O0FBaUJBLFFBQUksS0FBSyxLQUFLLFNBQUwsQ0FBZSxNQUFmLENBQXNCLENBQXRCLENBQVQ7QUFDQSxRQUFJLEdBQUcsSUFBSCxJQUFXLElBQVgsSUFBbUIsR0FBRyxLQUFILEtBQWEsRUFBcEMsRUFBd0M7QUFDdEMsU0FBRyxLQUFILEdBQVcsNEJBQVg7QUFDRDs7QUFFRDtBQUNBO0FBQ0E7QUFDQSxRQUFJLENBQUMsS0FBSyxTQUFMLENBQWUsU0FBaEIsSUFBNkIsS0FBSyxTQUF0QyxFQUFpRDtBQUMvQyxXQUFLLFNBQUwsQ0FBZSxTQUFmLEdBQTJCLEtBQUssU0FBaEM7QUFDQSxhQUFPLEtBQUssU0FBWjtBQUNEOztBQUVELFNBQUssU0FBTCxDQUFlLFNBQWYsR0FBMkIsWUFDekI7QUFDRSxZQUFNLFNBRFI7QUFFRSxlQUFTO0FBRlgsS0FEeUIsRUFLekIsS0FBSyxTQUFMLENBQWUsU0FBZixJQUE0QixFQUxILENBQTNCOztBQVFBO0FBQ0EsU0FBSyxLQUFMLENBQVcsSUFBWDtBQUNELEdBdG9EZTs7QUF3b0RoQixlQUFhLHFCQUFTLElBQVQsRUFBZTtBQUMxQjtBQUNBO0FBQ0EsUUFBSSxNQUFNLEtBQUssY0FBTCxDQUFvQixnQkFBOUI7QUFDQSxRQUFJLEtBQUssT0FBVCxFQUFrQjtBQUNoQixXQUFLLE9BQUwsR0FBZSxTQUFTLEtBQUssT0FBZCxFQUF1QixHQUF2QixDQUFmO0FBQ0Q7QUFDRCxRQUFJLEtBQUssU0FBVCxFQUFvQjtBQUNsQixVQUFJLFlBQVksS0FBSyxTQUFMLENBQWUsTUFBZixDQUFzQixDQUF0QixDQUFoQjtBQUNBLGdCQUFVLEtBQVYsR0FBa0IsU0FBUyxVQUFVLEtBQW5CLEVBQTBCLEdBQTFCLENBQWxCO0FBQ0Q7O0FBRUQsUUFBSSxVQUFVLEtBQUssT0FBbkI7QUFDQSxRQUFJLE9BQUosRUFBYTtBQUNYLFVBQUksUUFBUSxHQUFaLEVBQWlCO0FBQ2YsZ0JBQVEsR0FBUixHQUFjLFNBQVMsUUFBUSxHQUFqQixFQUFzQixLQUFLLGNBQUwsQ0FBb0IsWUFBMUMsQ0FBZDtBQUNEO0FBQ0QsVUFBSSxRQUFRLE9BQVosRUFBcUI7QUFDbkIsZ0JBQVEsT0FBUixHQUFrQixTQUFTLFFBQVEsT0FBakIsRUFBMEIsS0FBSyxjQUFMLENBQW9CLFlBQTlDLENBQWxCO0FBQ0Q7QUFDRjs7QUFFRCxRQUFJLEtBQUssV0FBTCxJQUFvQixLQUFLLFdBQUwsQ0FBaUIsTUFBekMsRUFDRSxLQUFLLGdCQUFMLENBQXNCLEtBQUssV0FBM0I7O0FBRUYsV0FBTyxJQUFQO0FBQ0QsR0FscURlOztBQW9xRGhCOzs7QUFHQSxvQkFBa0IsMEJBQVMsV0FBVCxFQUFzQjtBQUN0QztBQUNBO0FBQ0EsUUFBSSxXQUFXLENBQUMsSUFBRCxFQUFPLE1BQVAsRUFBZSxLQUFmLENBQWY7QUFBQSxRQUNFLE9BREY7QUFBQSxRQUVFLEtBRkY7QUFBQSxRQUdFLElBSEY7O0FBS0EsU0FBSyxJQUFJLElBQUksQ0FBYixFQUFnQixJQUFJLFlBQVksTUFBWixDQUFtQixNQUF2QyxFQUErQyxFQUFFLENBQWpELEVBQW9EO0FBQ2xELGNBQVEsWUFBWSxNQUFaLENBQW1CLENBQW5CLENBQVI7QUFDQSxVQUNFLENBQUMsTUFBTSxjQUFOLENBQXFCLE1BQXJCLENBQUQsSUFDQSxDQUFDLFNBQVMsTUFBTSxJQUFmLENBREQsSUFFQSxhQUFhLE1BQU0sSUFBbkIsQ0FIRixFQUtFOztBQUVGLGFBQU8sWUFBWSxFQUFaLEVBQWdCLE1BQU0sSUFBdEIsQ0FBUDtBQUNBLFdBQUssSUFBSSxJQUFJLENBQWIsRUFBZ0IsSUFBSSxTQUFTLE1BQTdCLEVBQXFDLEVBQUUsQ0FBdkMsRUFBMEM7QUFDeEMsa0JBQVUsU0FBUyxDQUFULENBQVY7QUFDQSxZQUFJLEtBQUssY0FBTCxDQUFvQixPQUFwQixLQUFnQyxLQUFLLE9BQUwsQ0FBcEMsRUFBbUQ7QUFDakQsZUFBSyxPQUFMLElBQWdCLFNBQVMsS0FBSyxPQUFMLENBQVQsRUFBd0IsS0FBSyxjQUFMLENBQW9CLFlBQTVDLENBQWhCO0FBQ0Q7QUFDRjtBQUNELGtCQUFZLE1BQVosQ0FBbUIsQ0FBbkIsRUFBc0IsSUFBdEIsR0FBNkIsSUFBN0I7QUFDRDtBQUNGLEdBanNEZTs7QUFtc0RoQixnQkFBYyx3QkFBVztBQUN2QixRQUFJLENBQUMsS0FBSyxhQUFOLElBQXVCLENBQUMsS0FBSyxZQUFqQyxFQUErQztBQUMvQyxRQUFJLFdBQVcsRUFBZjs7QUFFQSxRQUFJLEtBQUssYUFBTCxJQUFzQixXQUFXLFNBQXJDLEVBQWdEO0FBQzlDLGVBQVMsT0FBVCxHQUFtQjtBQUNqQixzQkFBYyxXQUFXO0FBRFIsT0FBbkI7QUFHRDs7QUFFRDtBQUNBLFFBQUksUUFBUSxRQUFSLElBQW9CLFFBQVEsUUFBUixDQUFpQixJQUF6QyxFQUErQztBQUM3QyxlQUFTLEdBQVQsR0FBZSxRQUFRLFFBQVIsQ0FBaUIsSUFBaEM7QUFDRDs7QUFFRCxRQUFJLEtBQUssWUFBTCxJQUFxQixVQUFVLFFBQW5DLEVBQTZDO0FBQzNDLFVBQUksQ0FBQyxTQUFTLE9BQWQsRUFBdUIsU0FBUyxPQUFULEdBQW1CLEVBQW5CO0FBQ3ZCLGVBQVMsT0FBVCxDQUFpQixPQUFqQixHQUEyQixVQUFVLFFBQXJDO0FBQ0Q7O0FBRUQsV0FBTyxRQUFQO0FBQ0QsR0F4dERlOztBQTB0RGhCLGlCQUFlLHlCQUFXO0FBQ3hCLFNBQUssZ0JBQUwsR0FBd0IsQ0FBeEI7QUFDQSxTQUFLLGFBQUwsR0FBcUIsSUFBckI7QUFDRCxHQTd0RGU7O0FBK3REaEIsa0JBQWdCLDBCQUFXO0FBQ3pCLFdBQU8sS0FBSyxnQkFBTCxJQUF5QixRQUFRLEtBQUssYUFBYixHQUE2QixLQUFLLGdCQUFsRTtBQUNELEdBanVEZTs7QUFtdURoQjs7Ozs7Ozs7O0FBU0EsaUJBQWUsdUJBQVMsT0FBVCxFQUFrQjtBQUMvQixRQUFJLE9BQU8sS0FBSyxTQUFoQjs7QUFFQSxRQUNFLENBQUMsSUFBRCxJQUNBLFFBQVEsT0FBUixLQUFvQixLQUFLLE9BRHpCLElBQ29DO0FBQ3BDLFlBQVEsV0FBUixLQUF3QixLQUFLLFdBSC9CLENBRzJDO0FBSDNDLE1BS0UsT0FBTyxLQUFQOztBQUVGO0FBQ0EsUUFBSSxRQUFRLFVBQVIsSUFBc0IsS0FBSyxVQUEvQixFQUEyQztBQUN6QyxhQUFPLGlCQUFpQixRQUFRLFVBQXpCLEVBQXFDLEtBQUssVUFBMUMsQ0FBUDtBQUNELEtBRkQsTUFFTyxJQUFJLFFBQVEsU0FBUixJQUFxQixLQUFLLFNBQTlCLEVBQXlDO0FBQzlDO0FBQ0EsYUFBTyxnQkFBZ0IsUUFBUSxTQUF4QixFQUFtQyxLQUFLLFNBQXhDLENBQVA7QUFDRCxLQUhNLE1BR0EsSUFBSSxRQUFRLFdBQVIsSUFBdUIsS0FBSyxXQUFoQyxFQUE2QztBQUNsRCxhQUFPLFFBQVEsUUFBUSxXQUFSLElBQXVCLEtBQUssV0FBcEMsS0FDTCxLQUFLLFNBQUwsQ0FBZSxRQUFRLFdBQXZCLE1BQXdDLEtBQUssU0FBTCxDQUFlLEtBQUssV0FBcEIsQ0FEMUM7QUFFRDs7QUFFRCxXQUFPLElBQVA7QUFDRCxHQWx3RGU7O0FBb3dEaEIsb0JBQWtCLDBCQUFTLE9BQVQsRUFBa0I7QUFDbEM7QUFDQSxRQUFJLEtBQUssY0FBTCxFQUFKLEVBQTJCO0FBQ3pCO0FBQ0Q7O0FBRUQsUUFBSSxTQUFTLFFBQVEsTUFBckI7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsUUFBSSxFQUFFLFdBQVcsR0FBWCxJQUFrQixXQUFXLEdBQTdCLElBQW9DLFdBQVcsR0FBakQsQ0FBSixFQUEyRDs7QUFFM0QsUUFBSSxLQUFKO0FBQ0EsUUFBSTtBQUNGO0FBQ0E7QUFDQSxVQUFJLGVBQUosRUFBcUI7QUFDbkIsZ0JBQVEsUUFBUSxPQUFSLENBQWdCLEdBQWhCLENBQW9CLGFBQXBCLENBQVI7QUFDRCxPQUZELE1BRU87QUFDTCxnQkFBUSxRQUFRLGlCQUFSLENBQTBCLGFBQTFCLENBQVI7QUFDRDs7QUFFRDtBQUNBLGNBQVEsU0FBUyxLQUFULEVBQWdCLEVBQWhCLElBQXNCLElBQTlCO0FBQ0QsS0FYRCxDQVdFLE9BQU8sQ0FBUCxFQUFVO0FBQ1Y7QUFDRDs7QUFFRCxTQUFLLGdCQUFMLEdBQXdCLFFBQ3BCO0FBQ0EsU0FGb0IsR0FHcEI7QUFDQSxTQUFLLGdCQUFMLEdBQXdCLENBQXhCLElBQTZCLElBSmpDOztBQU1BLFNBQUssYUFBTCxHQUFxQixLQUFyQjtBQUNELEdBeHlEZTs7QUEweURoQixTQUFPLGVBQVMsSUFBVCxFQUFlO0FBQ3BCLFFBQUksZ0JBQWdCLEtBQUssY0FBekI7O0FBRUEsUUFBSSxXQUFXO0FBQ1gsZUFBUyxLQUFLLGNBREg7QUFFWCxjQUFRLGNBQWMsTUFGWDtBQUdYLGdCQUFVO0FBSEMsS0FBZjtBQUFBLFFBS0UsV0FBVyxLQUFLLFlBQUwsRUFMYjs7QUFPQSxRQUFJLFFBQUosRUFBYztBQUNaLGVBQVMsT0FBVCxHQUFtQixRQUFuQjtBQUNEOztBQUVEO0FBQ0EsUUFBSSxLQUFLLGNBQVQsRUFBeUIsT0FBTyxLQUFLLGNBQVo7O0FBRXpCLFdBQU8sWUFBWSxRQUFaLEVBQXNCLElBQXRCLENBQVA7O0FBRUE7QUFDQSxTQUFLLElBQUwsR0FBWSxZQUFZLFlBQVksRUFBWixFQUFnQixLQUFLLGNBQUwsQ0FBb0IsSUFBcEMsQ0FBWixFQUF1RCxLQUFLLElBQTVELENBQVo7QUFDQSxTQUFLLEtBQUwsR0FBYSxZQUFZLFlBQVksRUFBWixFQUFnQixLQUFLLGNBQUwsQ0FBb0IsS0FBcEMsQ0FBWixFQUF3RCxLQUFLLEtBQTdELENBQWI7O0FBRUE7QUFDQSxTQUFLLEtBQUwsQ0FBVyxrQkFBWCxJQUFpQyxRQUFRLEtBQUssVUFBOUM7O0FBRUEsUUFBSSxLQUFLLFlBQUwsSUFBcUIsS0FBSyxZQUFMLENBQWtCLE1BQWxCLEdBQTJCLENBQXBELEVBQXVEO0FBQ3JEO0FBQ0E7QUFDQSxXQUFLLFdBQUwsR0FBbUI7QUFDakIsZ0JBQVEsR0FBRyxLQUFILENBQVMsSUFBVCxDQUFjLEtBQUssWUFBbkIsRUFBaUMsQ0FBakM7QUFEUyxPQUFuQjtBQUdEOztBQUVELFFBQUksS0FBSyxjQUFMLENBQW9CLElBQXhCLEVBQThCO0FBQzVCO0FBQ0EsV0FBSyxJQUFMLEdBQVksS0FBSyxjQUFMLENBQW9CLElBQWhDO0FBQ0Q7O0FBRUQ7QUFDQSxRQUFJLGNBQWMsV0FBbEIsRUFBK0IsS0FBSyxXQUFMLEdBQW1CLGNBQWMsV0FBakM7O0FBRS9CO0FBQ0EsUUFBSSxjQUFjLE9BQWxCLEVBQTJCLEtBQUssT0FBTCxHQUFlLGNBQWMsT0FBN0I7O0FBRTNCO0FBQ0EsUUFBSSxjQUFjLFVBQWxCLEVBQThCLEtBQUssV0FBTCxHQUFtQixjQUFjLFVBQWpDOztBQUU5QixXQUFPLEtBQUssYUFBTCxDQUFtQixJQUFuQixDQUFQOztBQUVBO0FBQ0EsV0FBTyxJQUFQLENBQVksSUFBWixFQUFrQixPQUFsQixDQUEwQixVQUFTLEdBQVQsRUFBYztBQUN0QyxVQUFJLEtBQUssR0FBTCxLQUFhLElBQWIsSUFBcUIsS0FBSyxHQUFMLE1BQWMsRUFBbkMsSUFBeUMsY0FBYyxLQUFLLEdBQUwsQ0FBZCxDQUE3QyxFQUF1RTtBQUNyRSxlQUFPLEtBQUssR0FBTCxDQUFQO0FBQ0Q7QUFDRixLQUpEOztBQU1BLFFBQUksV0FBVyxjQUFjLFlBQXpCLENBQUosRUFBNEM7QUFDMUMsYUFBTyxjQUFjLFlBQWQsQ0FBMkIsSUFBM0IsS0FBb0MsSUFBM0M7QUFDRDs7QUFFRDtBQUNBLFFBQUksQ0FBQyxJQUFELElBQVMsY0FBYyxJQUFkLENBQWIsRUFBa0M7QUFDaEM7QUFDRDs7QUFFRDtBQUNBLFFBQ0UsV0FBVyxjQUFjLGtCQUF6QixLQUNBLENBQUMsY0FBYyxrQkFBZCxDQUFpQyxJQUFqQyxDQUZILEVBR0U7QUFDQTtBQUNEOztBQUVEO0FBQ0E7QUFDQSxRQUFJLEtBQUssY0FBTCxFQUFKLEVBQTJCO0FBQ3pCLFdBQUssU0FBTCxDQUFlLE1BQWYsRUFBdUIsc0NBQXZCLEVBQStELElBQS9EO0FBQ0E7QUFDRDs7QUFFRCxRQUFJLE9BQU8sY0FBYyxVQUFyQixLQUFvQyxRQUF4QyxFQUFrRDtBQUNoRCxVQUFJLEtBQUssTUFBTCxLQUFnQixjQUFjLFVBQWxDLEVBQThDO0FBQzVDLGFBQUsscUJBQUwsQ0FBMkIsSUFBM0I7QUFDRDtBQUNGLEtBSkQsTUFJTztBQUNMLFdBQUsscUJBQUwsQ0FBMkIsSUFBM0I7QUFDRDtBQUNGLEdBbDREZTs7QUFvNERoQixpQkFBZSx1QkFBUyxJQUFULEVBQWU7QUFDNUIsV0FBTyxTQUFTLElBQVQsRUFBZSxLQUFLLGNBQUwsQ0FBb0IsWUFBbkMsQ0FBUDtBQUNELEdBdDREZTs7QUF3NERoQixZQUFVLG9CQUFXO0FBQ25CLFdBQU8sT0FBUDtBQUNELEdBMTREZTs7QUE0NERoQix5QkFBdUIsK0JBQVMsSUFBVCxFQUFlLFFBQWYsRUFBeUI7QUFDOUMsUUFBSSxPQUFPLElBQVg7QUFDQSxRQUFJLGdCQUFnQixLQUFLLGNBQXpCOztBQUVBLFFBQUksQ0FBQyxLQUFLLE9BQUwsRUFBTCxFQUFxQjs7QUFFckI7QUFDQSxXQUFPLEtBQUssV0FBTCxDQUFpQixJQUFqQixDQUFQOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFFBQUksQ0FBQyxLQUFLLGNBQUwsQ0FBb0IsZUFBckIsSUFBd0MsS0FBSyxhQUFMLENBQW1CLElBQW5CLENBQTVDLEVBQXNFO0FBQ3BFLFdBQUssU0FBTCxDQUFlLE1BQWYsRUFBdUIsOEJBQXZCLEVBQXVELElBQXZEO0FBQ0E7QUFDRDs7QUFFRDtBQUNBO0FBQ0E7QUFDQSxTQUFLLFlBQUwsR0FBb0IsS0FBSyxRQUFMLEtBQWtCLEtBQUssUUFBTCxHQUFnQixLQUFLLFFBQUwsRUFBbEMsQ0FBcEI7O0FBRUE7QUFDQSxTQUFLLFNBQUwsR0FBaUIsSUFBakI7O0FBRUEsU0FBSyxTQUFMLENBQWUsT0FBZixFQUF3QixzQkFBeEIsRUFBZ0QsSUFBaEQ7O0FBRUEsUUFBSSxPQUFPO0FBQ1Qsc0JBQWdCLEdBRFA7QUFFVCxxQkFBZSxjQUFjLEtBQUssT0FGekI7QUFHVCxrQkFBWSxLQUFLO0FBSFIsS0FBWDs7QUFNQSxRQUFJLEtBQUssYUFBVCxFQUF3QjtBQUN0QixXQUFLLGFBQUwsR0FBcUIsS0FBSyxhQUExQjtBQUNEOztBQUVELFFBQUksWUFBWSxLQUFLLFNBQUwsSUFBa0IsS0FBSyxTQUFMLENBQWUsTUFBZixDQUFzQixDQUF0QixDQUFsQzs7QUFFQTtBQUNBLFFBQ0UsS0FBSyxjQUFMLENBQW9CLGVBQXBCLElBQ0EsS0FBSyxjQUFMLENBQW9CLGVBQXBCLENBQW9DLE1BRnRDLEVBR0U7QUFDQSxXQUFLLGlCQUFMLENBQXVCO0FBQ3JCLGtCQUFVLFFBRFc7QUFFckIsaUJBQVMsWUFDTCxDQUFDLFVBQVUsSUFBVixHQUFpQixVQUFVLElBQVYsR0FBaUIsSUFBbEMsR0FBeUMsRUFBMUMsSUFBZ0QsVUFBVSxLQURyRCxHQUVMLEtBQUssT0FKWTtBQUtyQixrQkFBVSxLQUFLLFFBTE07QUFNckIsZUFBTyxLQUFLLEtBQUwsSUFBYyxPQU5BLENBTVE7QUFOUixPQUF2QjtBQVFEOztBQUVELFFBQUksTUFBTSxLQUFLLGVBQWY7QUFDQSxLQUFDLGNBQWMsU0FBZCxJQUEyQixLQUFLLFlBQWpDLEVBQStDLElBQS9DLENBQW9ELElBQXBELEVBQTBEO0FBQ3hELFdBQUssR0FEbUQ7QUFFeEQsWUFBTSxJQUZrRDtBQUd4RCxZQUFNLElBSGtEO0FBSXhELGVBQVMsYUFKK0M7QUFLeEQsaUJBQVcsU0FBUyxPQUFULEdBQW1CO0FBQzVCLGFBQUssYUFBTDs7QUFFQSxhQUFLLGFBQUwsQ0FBbUIsU0FBbkIsRUFBOEI7QUFDNUIsZ0JBQU0sSUFEc0I7QUFFNUIsZUFBSztBQUZ1QixTQUE5QjtBQUlBLG9CQUFZLFVBQVo7QUFDRCxPQWJ1RDtBQWN4RCxlQUFTLFNBQVMsT0FBVCxDQUFpQixLQUFqQixFQUF3QjtBQUMvQixhQUFLLFNBQUwsQ0FBZSxPQUFmLEVBQXdCLGtDQUF4QixFQUE0RCxLQUE1RDs7QUFFQSxZQUFJLE1BQU0sT0FBVixFQUFtQjtBQUNqQixlQUFLLGdCQUFMLENBQXNCLE1BQU0sT0FBNUI7QUFDRDs7QUFFRCxhQUFLLGFBQUwsQ0FBbUIsU0FBbkIsRUFBOEI7QUFDNUIsZ0JBQU0sSUFEc0I7QUFFNUIsZUFBSztBQUZ1QixTQUE5QjtBQUlBLGdCQUFRLFNBQVMsSUFBSSxLQUFKLENBQVUsb0RBQVYsQ0FBakI7QUFDQSxvQkFBWSxTQUFTLEtBQVQsQ0FBWjtBQUNEO0FBM0J1RCxLQUExRDtBQTZCRCxHQWgrRGU7O0FBaytEaEIsZ0JBQWMsc0JBQVMsSUFBVCxFQUFlO0FBQzNCO0FBQ0EsUUFBSSxNQUFNLEtBQUssR0FBTCxHQUFXLEdBQVgsR0FBaUIsVUFBVSxLQUFLLElBQWYsQ0FBM0I7O0FBRUEsUUFBSSxtQkFBbUIsSUFBdkI7QUFDQSxRQUFJLDJCQUEyQixFQUEvQjs7QUFFQSxRQUFJLEtBQUssT0FBTCxDQUFhLE9BQWpCLEVBQTBCO0FBQ3hCLHlCQUFtQixLQUFLLGFBQUwsQ0FBbUIsS0FBSyxPQUFMLENBQWEsT0FBaEMsQ0FBbkI7QUFDRDs7QUFFRCxRQUFJLEtBQUssT0FBTCxDQUFhLGVBQWpCLEVBQWtDO0FBQ2hDLGlDQUEyQixLQUFLLGFBQUwsQ0FBbUIsS0FBSyxPQUFMLENBQWEsZUFBaEMsQ0FBM0I7QUFDRDs7QUFFRCxRQUFJLGVBQUosRUFBcUI7QUFDbkIsK0JBQXlCLElBQXpCLEdBQWdDLFVBQVUsS0FBSyxJQUFmLENBQWhDOztBQUVBLFVBQUksc0JBQXNCLFlBQVksRUFBWixFQUFnQixLQUFLLGNBQXJCLENBQTFCO0FBQ0EsVUFBSSxlQUFlLFlBQVksbUJBQVosRUFBaUMsd0JBQWpDLENBQW5COztBQUVBLFVBQUksZ0JBQUosRUFBc0I7QUFDcEIscUJBQWEsT0FBYixHQUF1QixnQkFBdkI7QUFDRDs7QUFFRCxhQUFPLFFBQ0osS0FESSxDQUNFLEdBREYsRUFDTyxZQURQLEVBRUosSUFGSSxDQUVDLFVBQVMsUUFBVCxFQUFtQjtBQUN2QixZQUFJLFNBQVMsRUFBYixFQUFpQjtBQUNmLGVBQUssU0FBTCxJQUFrQixLQUFLLFNBQUwsRUFBbEI7QUFDRCxTQUZELE1BRU87QUFDTCxjQUFJLFFBQVEsSUFBSSxLQUFKLENBQVUsd0JBQXdCLFNBQVMsTUFBM0MsQ0FBWjtBQUNBO0FBQ0E7QUFDQSxnQkFBTSxPQUFOLEdBQWdCLFFBQWhCO0FBQ0EsZUFBSyxPQUFMLElBQWdCLEtBQUssT0FBTCxDQUFhLEtBQWIsQ0FBaEI7QUFDRDtBQUNGLE9BWkksRUFhSixPQWJJLEVBYUssWUFBVztBQUNuQixhQUFLLE9BQUwsSUFDRSxLQUFLLE9BQUwsQ0FBYSxJQUFJLEtBQUosQ0FBVSx3Q0FBVixDQUFiLENBREY7QUFFRCxPQWhCSSxDQUFQO0FBaUJEOztBQUVELFFBQUksVUFBVSxRQUFRLGNBQVIsSUFBMEIsSUFBSSxRQUFRLGNBQVosRUFBeEM7QUFDQSxRQUFJLENBQUMsT0FBTCxFQUFjOztBQUVkO0FBQ0EsUUFBSSxVQUFVLHFCQUFxQixPQUFyQixJQUFnQyxPQUFPLGNBQVAsS0FBMEIsV0FBeEU7O0FBRUEsUUFBSSxDQUFDLE9BQUwsRUFBYzs7QUFFZCxRQUFJLHFCQUFxQixPQUF6QixFQUFrQztBQUNoQyxjQUFRLGtCQUFSLEdBQTZCLFlBQVc7QUFDdEMsWUFBSSxRQUFRLFVBQVIsS0FBdUIsQ0FBM0IsRUFBOEI7QUFDNUI7QUFDRCxTQUZELE1BRU8sSUFBSSxRQUFRLE1BQVIsS0FBbUIsR0FBdkIsRUFBNEI7QUFDakMsZUFBSyxTQUFMLElBQWtCLEtBQUssU0FBTCxFQUFsQjtBQUNELFNBRk0sTUFFQSxJQUFJLEtBQUssT0FBVCxFQUFrQjtBQUN2QixjQUFJLE1BQU0sSUFBSSxLQUFKLENBQVUsd0JBQXdCLFFBQVEsTUFBMUMsQ0FBVjtBQUNBLGNBQUksT0FBSixHQUFjLE9BQWQ7QUFDQSxlQUFLLE9BQUwsQ0FBYSxHQUFiO0FBQ0Q7QUFDRixPQVZEO0FBV0QsS0FaRCxNQVlPO0FBQ0wsZ0JBQVUsSUFBSSxjQUFKLEVBQVY7QUFDQTtBQUNBO0FBQ0EsWUFBTSxJQUFJLE9BQUosQ0FBWSxVQUFaLEVBQXdCLEVBQXhCLENBQU47O0FBRUE7QUFDQSxVQUFJLEtBQUssU0FBVCxFQUFvQjtBQUNsQixnQkFBUSxNQUFSLEdBQWlCLEtBQUssU0FBdEI7QUFDRDtBQUNELFVBQUksS0FBSyxPQUFULEVBQWtCO0FBQ2hCLGdCQUFRLE9BQVIsR0FBa0IsWUFBVztBQUMzQixjQUFJLE1BQU0sSUFBSSxLQUFKLENBQVUsbUNBQVYsQ0FBVjtBQUNBLGNBQUksT0FBSixHQUFjLE9BQWQ7QUFDQSxlQUFLLE9BQUwsQ0FBYSxHQUFiO0FBQ0QsU0FKRDtBQUtEO0FBQ0Y7O0FBRUQsWUFBUSxJQUFSLENBQWEsTUFBYixFQUFxQixHQUFyQjs7QUFFQSxRQUFJLGdCQUFKLEVBQXNCO0FBQ3BCLFdBQUssZ0JBQUwsRUFBdUIsVUFBUyxHQUFULEVBQWMsS0FBZCxFQUFxQjtBQUMxQyxnQkFBUSxnQkFBUixDQUF5QixHQUF6QixFQUE4QixLQUE5QjtBQUNELE9BRkQ7QUFHRDs7QUFFRCxZQUFRLElBQVIsQ0FBYSxVQUFVLEtBQUssSUFBZixDQUFiO0FBQ0QsR0E5akVlOztBQWdrRWhCLGlCQUFlLHVCQUFTLElBQVQsRUFBZTtBQUM1QixRQUFJLFlBQVksRUFBaEI7O0FBRUEsU0FBSyxJQUFJLEdBQVQsSUFBZ0IsSUFBaEIsRUFBc0I7QUFDcEIsVUFBSSxLQUFLLGNBQUwsQ0FBb0IsR0FBcEIsQ0FBSixFQUE4QjtBQUM1QixZQUFJLFFBQVEsS0FBSyxHQUFMLENBQVo7QUFDQSxrQkFBVSxHQUFWLElBQWlCLE9BQU8sS0FBUCxLQUFpQixVQUFqQixHQUE4QixPQUE5QixHQUF3QyxLQUF6RDtBQUNEO0FBQ0Y7O0FBRUQsV0FBTyxTQUFQO0FBQ0QsR0Eza0VlOztBQTZrRWhCLGFBQVcsbUJBQVMsS0FBVCxFQUFnQjtBQUN6QjtBQUNBLFFBQ0UsS0FBSyx1QkFBTCxDQUE2QixLQUE3QixNQUNDLEtBQUssS0FBTCxJQUFjLEtBQUssY0FBTCxDQUFvQixLQURuQyxDQURGLEVBR0U7QUFDQTtBQUNBLGVBQVMsU0FBVCxDQUFtQixLQUFuQixDQUF5QixJQUF6QixDQUNFLEtBQUssdUJBQUwsQ0FBNkIsS0FBN0IsQ0FERixFQUVFLEtBQUssZ0JBRlAsRUFHRSxHQUFHLEtBQUgsQ0FBUyxJQUFULENBQWMsU0FBZCxFQUF5QixDQUF6QixDQUhGO0FBS0Q7QUFDRixHQTFsRWU7O0FBNGxFaEIsaUJBQWUsdUJBQVMsR0FBVCxFQUFjLE9BQWQsRUFBdUI7QUFDcEMsUUFBSSxZQUFZLE9BQVosQ0FBSixFQUEwQjtBQUN4QixhQUFPLEtBQUssY0FBTCxDQUFvQixHQUFwQixDQUFQO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsV0FBSyxjQUFMLENBQW9CLEdBQXBCLElBQTJCLFlBQVksS0FBSyxjQUFMLENBQW9CLEdBQXBCLEtBQTRCLEVBQXhDLEVBQTRDLE9BQTVDLENBQTNCO0FBQ0Q7QUFDRjtBQWxtRWUsQ0FBbEI7O0FBcW1FQTtBQUNBLE1BQU0sU0FBTixDQUFnQixPQUFoQixHQUEwQixNQUFNLFNBQU4sQ0FBZ0IsY0FBMUM7QUFDQSxNQUFNLFNBQU4sQ0FBZ0IsaUJBQWhCLEdBQW9DLE1BQU0sU0FBTixDQUFnQixVQUFwRDs7QUFFQSxPQUFPLE9BQVAsR0FBaUIsS0FBakI7Ozs7Ozs7O0FDaHZFQTs7Ozs7O0FBTUEsSUFBSSxtQkFBbUIsUUFBUSxTQUFSLENBQXZCOztBQUVBO0FBQ0EsSUFBSSxVQUNGLE9BQU8sTUFBUCxLQUFrQixXQUFsQixHQUNJLE1BREosR0FFSSxPQUFPLE1BQVAsS0FBa0IsV0FBbEIsR0FBZ0MsTUFBaEMsR0FBeUMsT0FBTyxJQUFQLEtBQWdCLFdBQWhCLEdBQThCLElBQTlCLEdBQXFDLEVBSHBGO0FBSUEsSUFBSSxTQUFTLFFBQVEsS0FBckI7O0FBRUEsSUFBSSxRQUFRLElBQUksZ0JBQUosRUFBWjs7QUFFQTs7Ozs7O0FBTUEsTUFBTSxVQUFOLEdBQW1CLFlBQVc7QUFDNUIsVUFBUSxLQUFSLEdBQWdCLE1BQWhCO0FBQ0EsU0FBTyxLQUFQO0FBQ0QsQ0FIRDs7QUFLQSxNQUFNLFNBQU47O0FBRUEsT0FBTyxPQUFQLEdBQWlCLEtBQWpCOztBQUVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBa0NBLE9BQU8sT0FBUCxDQUFlLE1BQWYsR0FBd0IsZ0JBQXhCOzs7Ozs7Ozs7O0FDbEVBLElBQUksWUFBWSxRQUFRLHlDQUFSLENBQWhCOztBQUVBLElBQUksVUFDRixPQUFPLE1BQVAsS0FBa0IsV0FBbEIsR0FDSSxNQURKLEdBRUksT0FBTyxNQUFQLEtBQWtCLFdBQWxCLEdBQ0UsTUFERixHQUVFLE9BQU8sSUFBUCxLQUFnQixXQUFoQixHQUNFLElBREYsR0FFRSxFQVBWOztBQVNBLFNBQVMsUUFBVCxDQUFrQixJQUFsQixFQUF3QjtBQUN0QixTQUFPLFFBQU8sSUFBUCx5Q0FBTyxJQUFQLE9BQWdCLFFBQWhCLElBQTRCLFNBQVMsSUFBNUM7QUFDRDs7QUFFRDtBQUNBO0FBQ0EsU0FBUyxPQUFULENBQWlCLEtBQWpCLEVBQXdCO0FBQ3RCLFVBQVEsT0FBTyxTQUFQLENBQWlCLFFBQWpCLENBQTBCLElBQTFCLENBQStCLEtBQS9CLENBQVI7QUFDRSxTQUFLLGdCQUFMO0FBQ0UsYUFBTyxJQUFQO0FBQ0YsU0FBSyxvQkFBTDtBQUNFLGFBQU8sSUFBUDtBQUNGLFNBQUssdUJBQUw7QUFDRSxhQUFPLElBQVA7QUFDRjtBQUNFLGFBQU8saUJBQWlCLEtBQXhCO0FBUko7QUFVRDs7QUFFRCxTQUFTLFlBQVQsQ0FBc0IsS0FBdEIsRUFBNkI7QUFDM0IsU0FBTyxPQUFPLFNBQVAsQ0FBaUIsUUFBakIsQ0FBMEIsSUFBMUIsQ0FBK0IsS0FBL0IsTUFBMEMscUJBQWpEO0FBQ0Q7O0FBRUQsU0FBUyxVQUFULENBQW9CLEtBQXBCLEVBQTJCO0FBQ3pCLFNBQU8sT0FBTyxTQUFQLENBQWlCLFFBQWpCLENBQTBCLElBQTFCLENBQStCLEtBQS9CLE1BQTBDLG1CQUFqRDtBQUNEOztBQUVELFNBQVMsY0FBVCxDQUF3QixLQUF4QixFQUErQjtBQUM3QixTQUFPLE9BQU8sU0FBUCxDQUFpQixRQUFqQixDQUEwQixJQUExQixDQUErQixLQUEvQixNQUEwQyx1QkFBakQ7QUFDRDs7QUFFRCxTQUFTLFdBQVQsQ0FBcUIsSUFBckIsRUFBMkI7QUFDekIsU0FBTyxTQUFTLEtBQUssQ0FBckI7QUFDRDs7QUFFRCxTQUFTLFVBQVQsQ0FBb0IsSUFBcEIsRUFBMEI7QUFDeEIsU0FBTyxPQUFPLElBQVAsS0FBZ0IsVUFBdkI7QUFDRDs7QUFFRCxTQUFTLGFBQVQsQ0FBdUIsSUFBdkIsRUFBNkI7QUFDM0IsU0FBTyxPQUFPLFNBQVAsQ0FBaUIsUUFBakIsQ0FBMEIsSUFBMUIsQ0FBK0IsSUFBL0IsTUFBeUMsaUJBQWhEO0FBQ0Q7O0FBRUQsU0FBUyxRQUFULENBQWtCLElBQWxCLEVBQXdCO0FBQ3RCLFNBQU8sT0FBTyxTQUFQLENBQWlCLFFBQWpCLENBQTBCLElBQTFCLENBQStCLElBQS9CLE1BQXlDLGlCQUFoRDtBQUNEOztBQUVELFNBQVMsT0FBVCxDQUFpQixJQUFqQixFQUF1QjtBQUNyQixTQUFPLE9BQU8sU0FBUCxDQUFpQixRQUFqQixDQUEwQixJQUExQixDQUErQixJQUEvQixNQUF5QyxnQkFBaEQ7QUFDRDs7QUFFRCxTQUFTLGFBQVQsQ0FBdUIsSUFBdkIsRUFBNkI7QUFDM0IsTUFBSSxDQUFDLGNBQWMsSUFBZCxDQUFMLEVBQTBCLE9BQU8sS0FBUDs7QUFFMUIsT0FBSyxJQUFJLENBQVQsSUFBYyxJQUFkLEVBQW9CO0FBQ2xCLFFBQUksS0FBSyxjQUFMLENBQW9CLENBQXBCLENBQUosRUFBNEI7QUFDMUIsYUFBTyxLQUFQO0FBQ0Q7QUFDRjtBQUNELFNBQU8sSUFBUDtBQUNEOztBQUVELFNBQVMsa0JBQVQsR0FBOEI7QUFDNUIsTUFBSTtBQUNGLFFBQUksVUFBSixDQUFlLEVBQWYsRUFERSxDQUNrQjtBQUNwQixXQUFPLElBQVA7QUFDRCxHQUhELENBR0UsT0FBTyxDQUFQLEVBQVU7QUFDVixXQUFPLEtBQVA7QUFDRDtBQUNGOztBQUVELFNBQVMsZ0JBQVQsR0FBNEI7QUFDMUIsTUFBSTtBQUNGLFFBQUksUUFBSixDQUFhLEVBQWIsRUFERSxDQUNnQjtBQUNsQixXQUFPLElBQVA7QUFDRCxHQUhELENBR0UsT0FBTyxDQUFQLEVBQVU7QUFDVixXQUFPLEtBQVA7QUFDRDtBQUNGOztBQUVELFNBQVMsb0JBQVQsR0FBZ0M7QUFDOUIsTUFBSTtBQUNGLFFBQUksWUFBSixDQUFpQixFQUFqQixFQURFLENBQ29CO0FBQ3RCLFdBQU8sSUFBUDtBQUNELEdBSEQsQ0FHRSxPQUFPLENBQVAsRUFBVTtBQUNWLFdBQU8sS0FBUDtBQUNEO0FBQ0Y7O0FBRUQsU0FBUyxhQUFULEdBQXlCO0FBQ3ZCLE1BQUksRUFBRSxXQUFXLE9BQWIsQ0FBSixFQUEyQixPQUFPLEtBQVA7O0FBRTNCLE1BQUk7QUFDRixRQUFJLE9BQUosR0FERSxDQUNhO0FBQ2YsUUFBSSxPQUFKLENBQVksRUFBWixFQUZFLENBRWU7QUFDakIsUUFBSSxRQUFKLEdBSEUsQ0FHYztBQUNoQixXQUFPLElBQVA7QUFDRCxHQUxELENBS0UsT0FBTyxDQUFQLEVBQVU7QUFDVixXQUFPLEtBQVA7QUFDRDtBQUNGOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxzQkFBVCxHQUFrQztBQUNoQyxNQUFJLENBQUMsZUFBTCxFQUFzQixPQUFPLEtBQVA7O0FBRXRCLE1BQUk7QUFDRjtBQUNBLFFBQUksT0FBSixDQUFZLFlBQVosRUFBMEI7QUFDeEIsc0JBQWdCO0FBRFEsS0FBMUI7QUFHQSxXQUFPLElBQVA7QUFDRCxHQU5ELENBTUUsT0FBTyxDQUFQLEVBQVU7QUFDVixXQUFPLEtBQVA7QUFDRDtBQUNGOztBQUVELFNBQVMsNkJBQVQsR0FBeUM7QUFDdkMsU0FBTyxPQUFPLHFCQUFQLEtBQWlDLFVBQXhDO0FBQ0Q7O0FBRUQsU0FBUyxlQUFULENBQXlCLFFBQXpCLEVBQW1DO0FBQ2pDLFdBQVMsWUFBVCxDQUFzQixJQUF0QixFQUE0QixRQUE1QixFQUFzQztBQUNwQyxRQUFJLGlCQUFpQixTQUFTLElBQVQsS0FBa0IsSUFBdkM7QUFDQSxRQUFJLFFBQUosRUFBYztBQUNaLGFBQU8sU0FBUyxjQUFULEtBQTRCLGNBQW5DO0FBQ0Q7QUFDRCxXQUFPLGNBQVA7QUFDRDs7QUFFRCxTQUFPLFlBQVA7QUFDRDs7QUFFRCxTQUFTLElBQVQsQ0FBYyxHQUFkLEVBQW1CLFFBQW5CLEVBQTZCO0FBQzNCLE1BQUksQ0FBSixFQUFPLENBQVA7O0FBRUEsTUFBSSxZQUFZLElBQUksTUFBaEIsQ0FBSixFQUE2QjtBQUMzQixTQUFLLENBQUwsSUFBVSxHQUFWLEVBQWU7QUFDYixVQUFJLE9BQU8sR0FBUCxFQUFZLENBQVosQ0FBSixFQUFvQjtBQUNsQixpQkFBUyxJQUFULENBQWMsSUFBZCxFQUFvQixDQUFwQixFQUF1QixJQUFJLENBQUosQ0FBdkI7QUFDRDtBQUNGO0FBQ0YsR0FORCxNQU1PO0FBQ0wsUUFBSSxJQUFJLE1BQVI7QUFDQSxRQUFJLENBQUosRUFBTztBQUNMLFdBQUssSUFBSSxDQUFULEVBQVksSUFBSSxDQUFoQixFQUFtQixHQUFuQixFQUF3QjtBQUN0QixpQkFBUyxJQUFULENBQWMsSUFBZCxFQUFvQixDQUFwQixFQUF1QixJQUFJLENBQUosQ0FBdkI7QUFDRDtBQUNGO0FBQ0Y7QUFDRjs7QUFFRCxTQUFTLFdBQVQsQ0FBcUIsSUFBckIsRUFBMkIsSUFBM0IsRUFBaUM7QUFDL0IsTUFBSSxDQUFDLElBQUwsRUFBVztBQUNULFdBQU8sSUFBUDtBQUNEO0FBQ0QsT0FBSyxJQUFMLEVBQVcsVUFBUyxHQUFULEVBQWMsS0FBZCxFQUFxQjtBQUM5QixTQUFLLEdBQUwsSUFBWSxLQUFaO0FBQ0QsR0FGRDtBQUdBLFNBQU8sSUFBUDtBQUNEOztBQUVEOzs7Ozs7OztBQVFBLFNBQVMsWUFBVCxDQUFzQixHQUF0QixFQUEyQjtBQUN6QixNQUFJLENBQUMsT0FBTyxRQUFaLEVBQXNCO0FBQ3BCLFdBQU8sS0FBUDtBQUNEO0FBQ0QsU0FBTyxPQUFPLFFBQVAsQ0FBZ0IsR0FBaEIsQ0FBUDtBQUNEOztBQUVELFNBQVMsUUFBVCxDQUFrQixHQUFsQixFQUF1QixHQUF2QixFQUE0QjtBQUMxQixNQUFJLE9BQU8sR0FBUCxLQUFlLFFBQW5CLEVBQTZCO0FBQzNCLFVBQU0sSUFBSSxLQUFKLENBQVUsd0RBQVYsQ0FBTjtBQUNEO0FBQ0QsTUFBSSxPQUFPLEdBQVAsS0FBZSxRQUFmLElBQTJCLFFBQVEsQ0FBdkMsRUFBMEM7QUFDeEMsV0FBTyxHQUFQO0FBQ0Q7QUFDRCxTQUFPLElBQUksTUFBSixJQUFjLEdBQWQsR0FBb0IsR0FBcEIsR0FBMEIsSUFBSSxNQUFKLENBQVcsQ0FBWCxFQUFjLEdBQWQsSUFBcUIsUUFBdEQ7QUFDRDs7QUFFRDs7Ozs7OztBQU9BLFNBQVMsTUFBVCxDQUFnQixNQUFoQixFQUF3QixHQUF4QixFQUE2QjtBQUMzQixTQUFPLE9BQU8sU0FBUCxDQUFpQixjQUFqQixDQUFnQyxJQUFoQyxDQUFxQyxNQUFyQyxFQUE2QyxHQUE3QyxDQUFQO0FBQ0Q7O0FBRUQsU0FBUyxVQUFULENBQW9CLFFBQXBCLEVBQThCO0FBQzVCO0FBQ0E7QUFDQSxNQUFJLFVBQVUsRUFBZDtBQUFBLE1BQ0UsSUFBSSxDQUROO0FBQUEsTUFFRSxNQUFNLFNBQVMsTUFGakI7QUFBQSxNQUdFLE9BSEY7O0FBS0EsU0FBTyxJQUFJLEdBQVgsRUFBZ0IsR0FBaEIsRUFBcUI7QUFDbkIsY0FBVSxTQUFTLENBQVQsQ0FBVjtBQUNBLFFBQUksU0FBUyxPQUFULENBQUosRUFBdUI7QUFDckI7QUFDQTtBQUNBLGNBQVEsSUFBUixDQUFhLFFBQVEsT0FBUixDQUFnQiw2QkFBaEIsRUFBK0MsTUFBL0MsQ0FBYjtBQUNELEtBSkQsTUFJTyxJQUFJLFdBQVcsUUFBUSxNQUF2QixFQUErQjtBQUNwQztBQUNBLGNBQVEsSUFBUixDQUFhLFFBQVEsTUFBckI7QUFDRDtBQUNEO0FBQ0Q7QUFDRCxTQUFPLElBQUksTUFBSixDQUFXLFFBQVEsSUFBUixDQUFhLEdBQWIsQ0FBWCxFQUE4QixHQUE5QixDQUFQO0FBQ0Q7O0FBRUQsU0FBUyxTQUFULENBQW1CLENBQW5CLEVBQXNCO0FBQ3BCLE1BQUksUUFBUSxFQUFaO0FBQ0EsT0FBSyxDQUFMLEVBQVEsVUFBUyxHQUFULEVBQWMsS0FBZCxFQUFxQjtBQUMzQixVQUFNLElBQU4sQ0FBVyxtQkFBbUIsR0FBbkIsSUFBMEIsR0FBMUIsR0FBZ0MsbUJBQW1CLEtBQW5CLENBQTNDO0FBQ0QsR0FGRDtBQUdBLFNBQU8sTUFBTSxJQUFOLENBQVcsR0FBWCxDQUFQO0FBQ0Q7O0FBRUQ7QUFDQTtBQUNBO0FBQ0EsU0FBUyxRQUFULENBQWtCLEdBQWxCLEVBQXVCO0FBQ3JCLE1BQUksT0FBTyxHQUFQLEtBQWUsUUFBbkIsRUFBNkIsT0FBTyxFQUFQO0FBQzdCLE1BQUksUUFBUSxJQUFJLEtBQUosQ0FBVSxnRUFBVixDQUFaOztBQUVBO0FBQ0EsTUFBSSxRQUFRLE1BQU0sQ0FBTixLQUFZLEVBQXhCO0FBQ0EsTUFBSSxXQUFXLE1BQU0sQ0FBTixLQUFZLEVBQTNCO0FBQ0EsU0FBTztBQUNMLGNBQVUsTUFBTSxDQUFOLENBREw7QUFFTCxVQUFNLE1BQU0sQ0FBTixDQUZEO0FBR0wsVUFBTSxNQUFNLENBQU4sQ0FIRDtBQUlMLGNBQVUsTUFBTSxDQUFOLElBQVcsS0FBWCxHQUFtQixRQUp4QixDQUlpQztBQUpqQyxHQUFQO0FBTUQ7QUFDRCxTQUFTLEtBQVQsR0FBaUI7QUFDZixNQUFJLFNBQVMsUUFBUSxNQUFSLElBQWtCLFFBQVEsUUFBdkM7O0FBRUEsTUFBSSxDQUFDLFlBQVksTUFBWixDQUFELElBQXdCLE9BQU8sZUFBbkMsRUFBb0Q7QUFDbEQ7QUFDQTtBQUNBLFFBQUksTUFBTSxJQUFJLFdBQUosQ0FBZ0IsQ0FBaEIsQ0FBVjtBQUNBLFdBQU8sZUFBUCxDQUF1QixHQUF2Qjs7QUFFQTtBQUNBLFFBQUksQ0FBSixJQUFVLElBQUksQ0FBSixJQUFTLEtBQVYsR0FBbUIsTUFBNUI7QUFDQTtBQUNBLFFBQUksQ0FBSixJQUFVLElBQUksQ0FBSixJQUFTLE1BQVYsR0FBb0IsTUFBN0I7O0FBRUEsUUFBSSxNQUFNLFNBQU4sR0FBTSxDQUFTLEdBQVQsRUFBYztBQUN0QixVQUFJLElBQUksSUFBSSxRQUFKLENBQWEsRUFBYixDQUFSO0FBQ0EsYUFBTyxFQUFFLE1BQUYsR0FBVyxDQUFsQixFQUFxQjtBQUNuQixZQUFJLE1BQU0sQ0FBVjtBQUNEO0FBQ0QsYUFBTyxDQUFQO0FBQ0QsS0FORDs7QUFRQSxXQUNFLElBQUksSUFBSSxDQUFKLENBQUosSUFDQSxJQUFJLElBQUksQ0FBSixDQUFKLENBREEsR0FFQSxJQUFJLElBQUksQ0FBSixDQUFKLENBRkEsR0FHQSxJQUFJLElBQUksQ0FBSixDQUFKLENBSEEsR0FJQSxJQUFJLElBQUksQ0FBSixDQUFKLENBSkEsR0FLQSxJQUFJLElBQUksQ0FBSixDQUFKLENBTEEsR0FNQSxJQUFJLElBQUksQ0FBSixDQUFKLENBTkEsR0FPQSxJQUFJLElBQUksQ0FBSixDQUFKLENBUkY7QUFVRCxHQTdCRCxNQTZCTztBQUNMO0FBQ0EsV0FBTyxtQ0FBbUMsT0FBbkMsQ0FBMkMsT0FBM0MsRUFBb0QsVUFBUyxDQUFULEVBQVk7QUFDckUsVUFBSSxJQUFLLEtBQUssTUFBTCxLQUFnQixFQUFqQixHQUF1QixDQUEvQjtBQUFBLFVBQ0UsSUFBSSxNQUFNLEdBQU4sR0FBWSxDQUFaLEdBQWlCLElBQUksR0FBTCxHQUFZLEdBRGxDO0FBRUEsYUFBTyxFQUFFLFFBQUYsQ0FBVyxFQUFYLENBQVA7QUFDRCxLQUpNLENBQVA7QUFLRDtBQUNGOztBQUVEOzs7Ozs7O0FBT0EsU0FBUyxnQkFBVCxDQUEwQixJQUExQixFQUFnQztBQUM5QjtBQUNBLE1BQUksc0JBQXNCLENBQTFCO0FBQUEsTUFDRSxpQkFBaUIsRUFEbkI7QUFBQSxNQUVFLE1BQU0sRUFGUjtBQUFBLE1BR0UsU0FBUyxDQUhYO0FBQUEsTUFJRSxNQUFNLENBSlI7QUFBQSxNQUtFLFlBQVksS0FMZDtBQUFBLE1BTUUsWUFBWSxVQUFVLE1BTnhCO0FBQUEsTUFPRSxPQVBGOztBQVNBLFNBQU8sUUFBUSxXQUFXLG1CQUExQixFQUErQztBQUM3QyxjQUFVLG9CQUFvQixJQUFwQixDQUFWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUNFLFlBQVksTUFBWixJQUNDLFNBQVMsQ0FBVCxJQUFjLE1BQU0sSUFBSSxNQUFKLEdBQWEsU0FBbkIsR0FBK0IsUUFBUSxNQUF2QyxJQUFpRCxjQUZsRSxFQUdFO0FBQ0E7QUFDRDs7QUFFRCxRQUFJLElBQUosQ0FBUyxPQUFUOztBQUVBLFdBQU8sUUFBUSxNQUFmO0FBQ0EsV0FBTyxLQUFLLFVBQVo7QUFDRDs7QUFFRCxTQUFPLElBQUksT0FBSixHQUFjLElBQWQsQ0FBbUIsU0FBbkIsQ0FBUDtBQUNEOztBQUVEOzs7Ozs7QUFNQSxTQUFTLG1CQUFULENBQTZCLElBQTdCLEVBQW1DO0FBQ2pDLE1BQUksTUFBTSxFQUFWO0FBQUEsTUFDRSxTQURGO0FBQUEsTUFFRSxPQUZGO0FBQUEsTUFHRSxHQUhGO0FBQUEsTUFJRSxJQUpGO0FBQUEsTUFLRSxDQUxGOztBQU9BLE1BQUksQ0FBQyxJQUFELElBQVMsQ0FBQyxLQUFLLE9BQW5CLEVBQTRCO0FBQzFCLFdBQU8sRUFBUDtBQUNEOztBQUVELE1BQUksSUFBSixDQUFTLEtBQUssT0FBTCxDQUFhLFdBQWIsRUFBVDtBQUNBLE1BQUksS0FBSyxFQUFULEVBQWE7QUFDWCxRQUFJLElBQUosQ0FBUyxNQUFNLEtBQUssRUFBcEI7QUFDRDs7QUFFRCxjQUFZLEtBQUssU0FBakI7QUFDQSxNQUFJLGFBQWEsU0FBUyxTQUFULENBQWpCLEVBQXNDO0FBQ3BDLGNBQVUsVUFBVSxLQUFWLENBQWdCLEtBQWhCLENBQVY7QUFDQSxTQUFLLElBQUksQ0FBVCxFQUFZLElBQUksUUFBUSxNQUF4QixFQUFnQyxHQUFoQyxFQUFxQztBQUNuQyxVQUFJLElBQUosQ0FBUyxNQUFNLFFBQVEsQ0FBUixDQUFmO0FBQ0Q7QUFDRjtBQUNELE1BQUksZ0JBQWdCLENBQUMsTUFBRCxFQUFTLE1BQVQsRUFBaUIsT0FBakIsRUFBMEIsS0FBMUIsQ0FBcEI7QUFDQSxPQUFLLElBQUksQ0FBVCxFQUFZLElBQUksY0FBYyxNQUE5QixFQUFzQyxHQUF0QyxFQUEyQztBQUN6QyxVQUFNLGNBQWMsQ0FBZCxDQUFOO0FBQ0EsV0FBTyxLQUFLLFlBQUwsQ0FBa0IsR0FBbEIsQ0FBUDtBQUNBLFFBQUksSUFBSixFQUFVO0FBQ1IsVUFBSSxJQUFKLENBQVMsTUFBTSxHQUFOLEdBQVksSUFBWixHQUFtQixJQUFuQixHQUEwQixJQUFuQztBQUNEO0FBQ0Y7QUFDRCxTQUFPLElBQUksSUFBSixDQUFTLEVBQVQsQ0FBUDtBQUNEOztBQUVEOzs7QUFHQSxTQUFTLGVBQVQsQ0FBeUIsQ0FBekIsRUFBNEIsQ0FBNUIsRUFBK0I7QUFDN0IsU0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUYsR0FBTSxDQUFDLENBQUMsQ0FBVixDQUFSO0FBQ0Q7O0FBRUQ7OztBQUdBLFNBQVMsZUFBVCxDQUF5QixDQUF6QixFQUE0QixDQUE1QixFQUErQjtBQUM3QixTQUFPLFlBQVksQ0FBWixLQUFrQixZQUFZLENBQVosQ0FBekI7QUFDRDs7QUFFRDs7O0FBR0EsU0FBUyxlQUFULENBQXlCLEdBQXpCLEVBQThCLEdBQTlCLEVBQW1DO0FBQ2pDLE1BQUksZ0JBQWdCLEdBQWhCLEVBQXFCLEdBQXJCLENBQUosRUFBK0IsT0FBTyxLQUFQOztBQUUvQixRQUFNLElBQUksTUFBSixDQUFXLENBQVgsQ0FBTjtBQUNBLFFBQU0sSUFBSSxNQUFKLENBQVcsQ0FBWCxDQUFOOztBQUVBLE1BQUksSUFBSSxJQUFKLEtBQWEsSUFBSSxJQUFqQixJQUF5QixJQUFJLEtBQUosS0FBYyxJQUFJLEtBQS9DLEVBQXNELE9BQU8sS0FBUDs7QUFFdEQ7QUFDQSxNQUFJLGdCQUFnQixJQUFJLFVBQXBCLEVBQWdDLElBQUksVUFBcEMsQ0FBSixFQUFxRCxPQUFPLEtBQVA7O0FBRXJELFNBQU8saUJBQWlCLElBQUksVUFBckIsRUFBaUMsSUFBSSxVQUFyQyxDQUFQO0FBQ0Q7O0FBRUQ7OztBQUdBLFNBQVMsZ0JBQVQsQ0FBMEIsTUFBMUIsRUFBa0MsTUFBbEMsRUFBMEM7QUFDeEMsTUFBSSxnQkFBZ0IsTUFBaEIsRUFBd0IsTUFBeEIsQ0FBSixFQUFxQyxPQUFPLEtBQVA7O0FBRXJDLE1BQUksVUFBVSxPQUFPLE1BQXJCO0FBQ0EsTUFBSSxVQUFVLE9BQU8sTUFBckI7O0FBRUE7QUFDQSxNQUFJLFlBQVksU0FBWixJQUF5QixZQUFZLFNBQXpDLEVBQW9ELE9BQU8sS0FBUDs7QUFFcEQ7QUFDQSxNQUFJLFFBQVEsTUFBUixLQUFtQixRQUFRLE1BQS9CLEVBQXVDLE9BQU8sS0FBUDs7QUFFdkM7QUFDQSxNQUFJLENBQUosRUFBTyxDQUFQO0FBQ0EsT0FBSyxJQUFJLElBQUksQ0FBYixFQUFnQixJQUFJLFFBQVEsTUFBNUIsRUFBb0MsR0FBcEMsRUFBeUM7QUFDdkMsUUFBSSxRQUFRLENBQVIsQ0FBSjtBQUNBLFFBQUksUUFBUSxDQUFSLENBQUo7QUFDQSxRQUNFLEVBQUUsUUFBRixLQUFlLEVBQUUsUUFBakIsSUFDQSxFQUFFLE1BQUYsS0FBYSxFQUFFLE1BRGYsSUFFQSxFQUFFLEtBQUYsS0FBWSxFQUFFLEtBRmQsSUFHQSxFQUFFLFVBQUYsTUFBa0IsRUFBRSxVQUFGLENBSnBCLEVBTUUsT0FBTyxLQUFQO0FBQ0g7QUFDRCxTQUFPLElBQVA7QUFDRDs7QUFFRDs7Ozs7OztBQU9BLFNBQVMsSUFBVCxDQUFjLEdBQWQsRUFBbUIsSUFBbkIsRUFBeUIsV0FBekIsRUFBc0MsS0FBdEMsRUFBNkM7QUFDM0MsTUFBSSxPQUFPLElBQVgsRUFBaUI7QUFDakIsTUFBSSxPQUFPLElBQUksSUFBSixDQUFYO0FBQ0EsTUFBSSxJQUFKLElBQVksWUFBWSxJQUFaLENBQVo7QUFDQSxNQUFJLElBQUosRUFBVSxTQUFWLEdBQXNCLElBQXRCO0FBQ0EsTUFBSSxJQUFKLEVBQVUsUUFBVixHQUFxQixJQUFyQjtBQUNBLE1BQUksS0FBSixFQUFXO0FBQ1QsVUFBTSxJQUFOLENBQVcsQ0FBQyxHQUFELEVBQU0sSUFBTixFQUFZLElBQVosQ0FBWDtBQUNEO0FBQ0Y7O0FBRUQ7Ozs7OztBQU1BLFNBQVMsUUFBVCxDQUFrQixLQUFsQixFQUF5QixTQUF6QixFQUFvQztBQUNsQyxNQUFJLENBQUMsUUFBUSxLQUFSLENBQUwsRUFBcUIsT0FBTyxFQUFQOztBQUVyQixNQUFJLFNBQVMsRUFBYjs7QUFFQSxPQUFLLElBQUksSUFBSSxDQUFiLEVBQWdCLElBQUksTUFBTSxNQUExQixFQUFrQyxHQUFsQyxFQUF1QztBQUNyQyxRQUFJO0FBQ0YsYUFBTyxJQUFQLENBQVksT0FBTyxNQUFNLENBQU4sQ0FBUCxDQUFaO0FBQ0QsS0FGRCxDQUVFLE9BQU8sQ0FBUCxFQUFVO0FBQ1YsYUFBTyxJQUFQLENBQVksOEJBQVo7QUFDRDtBQUNGOztBQUVELFNBQU8sT0FBTyxJQUFQLENBQVksU0FBWixDQUFQO0FBQ0Q7O0FBRUQ7QUFDQSxJQUFJLGdDQUFnQyxDQUFwQztBQUNBO0FBQ0EsSUFBSSwrQkFBK0IsS0FBSyxJQUF4QztBQUNBLElBQUksNEJBQTRCLEVBQWhDOztBQUVBLFNBQVMsVUFBVCxDQUFvQixLQUFwQixFQUEyQjtBQUN6QixTQUFPLENBQUMsQ0FBQyxVQUFVLEtBQVYsRUFBaUIsS0FBakIsQ0FBdUIsT0FBdkIsRUFBZ0MsTUFBekM7QUFDRDs7QUFFRCxTQUFTLFFBQVQsQ0FBa0IsS0FBbEIsRUFBeUI7QUFDdkIsU0FBTyxXQUFXLEtBQUssU0FBTCxDQUFlLEtBQWYsQ0FBWCxDQUFQO0FBQ0Q7O0FBRUQsU0FBUyxjQUFULENBQXdCLEtBQXhCLEVBQStCO0FBQzdCLE1BQUksT0FBTyxLQUFQLEtBQWlCLFFBQXJCLEVBQStCO0FBQzdCLFFBQUksWUFBWSxFQUFoQjtBQUNBLFdBQU8sU0FBUyxLQUFULEVBQWdCLFNBQWhCLENBQVA7QUFDRCxHQUhELE1BR08sSUFDTCxPQUFPLEtBQVAsS0FBaUIsUUFBakIsSUFDQSxPQUFPLEtBQVAsS0FBaUIsU0FEakIsSUFFQSxPQUFPLEtBQVAsS0FBaUIsV0FIWixFQUlMO0FBQ0EsV0FBTyxLQUFQO0FBQ0Q7O0FBRUQsTUFBSSxPQUFPLE9BQU8sU0FBUCxDQUFpQixRQUFqQixDQUEwQixJQUExQixDQUErQixLQUEvQixDQUFYOztBQUVBO0FBQ0EsTUFBSSxTQUFTLGlCQUFiLEVBQWdDLE9BQU8sVUFBUDtBQUNoQyxNQUFJLFNBQVMsZ0JBQWIsRUFBK0IsT0FBTyxTQUFQO0FBQy9CLE1BQUksU0FBUyxtQkFBYixFQUNFLE9BQU8sTUFBTSxJQUFOLEdBQWEsZ0JBQWdCLE1BQU0sSUFBdEIsR0FBNkIsR0FBMUMsR0FBZ0QsWUFBdkQ7O0FBRUYsU0FBTyxLQUFQO0FBQ0Q7O0FBRUQsU0FBUyxlQUFULENBQXlCLEtBQXpCLEVBQWdDLEtBQWhDLEVBQXVDO0FBQ3JDLE1BQUksVUFBVSxDQUFkLEVBQWlCLE9BQU8sZUFBZSxLQUFmLENBQVA7O0FBRWpCLE1BQUksY0FBYyxLQUFkLENBQUosRUFBMEI7QUFDeEIsV0FBTyxPQUFPLElBQVAsQ0FBWSxLQUFaLEVBQW1CLE1BQW5CLENBQTBCLFVBQVMsR0FBVCxFQUFjLEdBQWQsRUFBbUI7QUFDbEQsVUFBSSxHQUFKLElBQVcsZ0JBQWdCLE1BQU0sR0FBTixDQUFoQixFQUE0QixRQUFRLENBQXBDLENBQVg7QUFDQSxhQUFPLEdBQVA7QUFDRCxLQUhNLEVBR0osRUFISSxDQUFQO0FBSUQsR0FMRCxNQUtPLElBQUksTUFBTSxPQUFOLENBQWMsS0FBZCxDQUFKLEVBQTBCO0FBQy9CLFdBQU8sTUFBTSxHQUFOLENBQVUsVUFBUyxHQUFULEVBQWM7QUFDN0IsYUFBTyxnQkFBZ0IsR0FBaEIsRUFBcUIsUUFBUSxDQUE3QixDQUFQO0FBQ0QsS0FGTSxDQUFQO0FBR0Q7O0FBRUQsU0FBTyxlQUFlLEtBQWYsQ0FBUDtBQUNEOztBQUVELFNBQVMsa0JBQVQsQ0FBNEIsRUFBNUIsRUFBZ0MsS0FBaEMsRUFBdUMsT0FBdkMsRUFBZ0Q7QUFDOUMsTUFBSSxDQUFDLGNBQWMsRUFBZCxDQUFMLEVBQXdCLE9BQU8sRUFBUDs7QUFFeEIsVUFBUSxPQUFPLEtBQVAsS0FBaUIsUUFBakIsR0FBNEIsNkJBQTVCLEdBQTRELEtBQXBFO0FBQ0EsWUFBVSxPQUFPLEtBQVAsS0FBaUIsUUFBakIsR0FBNEIsNEJBQTVCLEdBQTJELE9BQXJFOztBQUVBLE1BQUksYUFBYSxnQkFBZ0IsRUFBaEIsRUFBb0IsS0FBcEIsQ0FBakI7O0FBRUEsTUFBSSxTQUFTLFVBQVUsVUFBVixDQUFULElBQWtDLE9BQXRDLEVBQStDO0FBQzdDLFdBQU8sbUJBQW1CLEVBQW5CLEVBQXVCLFFBQVEsQ0FBL0IsQ0FBUDtBQUNEOztBQUVELFNBQU8sVUFBUDtBQUNEOztBQUVELFNBQVMsdUJBQVQsQ0FBaUMsSUFBakMsRUFBdUMsU0FBdkMsRUFBa0Q7QUFDaEQsTUFBSSxPQUFPLElBQVAsS0FBZ0IsUUFBaEIsSUFBNEIsT0FBTyxJQUFQLEtBQWdCLFFBQWhELEVBQTBELE9BQU8sS0FBSyxRQUFMLEVBQVA7QUFDMUQsTUFBSSxDQUFDLE1BQU0sT0FBTixDQUFjLElBQWQsQ0FBTCxFQUEwQixPQUFPLEVBQVA7O0FBRTFCLFNBQU8sS0FBSyxNQUFMLENBQVksVUFBUyxHQUFULEVBQWM7QUFDL0IsV0FBTyxPQUFPLEdBQVAsS0FBZSxRQUF0QjtBQUNELEdBRk0sQ0FBUDtBQUdBLE1BQUksS0FBSyxNQUFMLEtBQWdCLENBQXBCLEVBQXVCLE9BQU8sc0JBQVA7O0FBRXZCLGNBQVksT0FBTyxTQUFQLEtBQXFCLFFBQXJCLEdBQWdDLHlCQUFoQyxHQUE0RCxTQUF4RTtBQUNBLE1BQUksS0FBSyxDQUFMLEVBQVEsTUFBUixJQUFrQixTQUF0QixFQUFpQyxPQUFPLEtBQUssQ0FBTCxDQUFQOztBQUVqQyxPQUFLLElBQUksV0FBVyxLQUFLLE1BQXpCLEVBQWlDLFdBQVcsQ0FBNUMsRUFBK0MsVUFBL0MsRUFBMkQ7QUFDekQsUUFBSSxhQUFhLEtBQUssS0FBTCxDQUFXLENBQVgsRUFBYyxRQUFkLEVBQXdCLElBQXhCLENBQTZCLElBQTdCLENBQWpCO0FBQ0EsUUFBSSxXQUFXLE1BQVgsR0FBb0IsU0FBeEIsRUFBbUM7QUFDbkMsUUFBSSxhQUFhLEtBQUssTUFBdEIsRUFBOEIsT0FBTyxVQUFQO0FBQzlCLFdBQU8sYUFBYSxRQUFwQjtBQUNEOztBQUVELFNBQU8sRUFBUDtBQUNEOztBQUVELFNBQVMsUUFBVCxDQUFrQixLQUFsQixFQUF5QixZQUF6QixFQUF1QztBQUNyQyxNQUFJLENBQUMsUUFBUSxZQUFSLENBQUQsSUFBMkIsUUFBUSxZQUFSLEtBQXlCLGFBQWEsTUFBYixLQUF3QixDQUFoRixFQUNFLE9BQU8sS0FBUDs7QUFFRixNQUFJLGlCQUFpQixXQUFXLFlBQVgsQ0FBckI7QUFDQSxNQUFJLGVBQWUsVUFBbkI7QUFDQSxNQUFJLFNBQUo7O0FBRUEsTUFBSTtBQUNGLGdCQUFZLEtBQUssS0FBTCxDQUFXLFVBQVUsS0FBVixDQUFYLENBQVo7QUFDRCxHQUZELENBRUUsT0FBTyxHQUFQLEVBQVk7QUFDWixXQUFPLEtBQVA7QUFDRDs7QUFFRCxXQUFTLGNBQVQsQ0FBd0IsV0FBeEIsRUFBcUM7QUFDbkMsUUFBSSxRQUFRLFdBQVIsQ0FBSixFQUEwQjtBQUN4QixhQUFPLFlBQVksR0FBWixDQUFnQixVQUFTLEdBQVQsRUFBYztBQUNuQyxlQUFPLGVBQWUsR0FBZixDQUFQO0FBQ0QsT0FGTSxDQUFQO0FBR0Q7O0FBRUQsUUFBSSxjQUFjLFdBQWQsQ0FBSixFQUFnQztBQUM5QixhQUFPLE9BQU8sSUFBUCxDQUFZLFdBQVosRUFBeUIsTUFBekIsQ0FBZ0MsVUFBUyxHQUFULEVBQWMsQ0FBZCxFQUFpQjtBQUN0RCxZQUFJLGVBQWUsSUFBZixDQUFvQixDQUFwQixDQUFKLEVBQTRCO0FBQzFCLGNBQUksQ0FBSixJQUFTLFlBQVQ7QUFDRCxTQUZELE1BRU87QUFDTCxjQUFJLENBQUosSUFBUyxlQUFlLFlBQVksQ0FBWixDQUFmLENBQVQ7QUFDRDtBQUNELGVBQU8sR0FBUDtBQUNELE9BUE0sRUFPSixFQVBJLENBQVA7QUFRRDs7QUFFRCxXQUFPLFdBQVA7QUFDRDs7QUFFRCxTQUFPLGVBQWUsU0FBZixDQUFQO0FBQ0Q7O0FBRUQsT0FBTyxPQUFQLEdBQWlCO0FBQ2YsWUFBVSxRQURLO0FBRWYsV0FBUyxPQUZNO0FBR2YsZ0JBQWMsWUFIQztBQUlmLGNBQVksVUFKRztBQUtmLGtCQUFnQixjQUxEO0FBTWYsZUFBYSxXQU5FO0FBT2YsY0FBWSxVQVBHO0FBUWYsaUJBQWUsYUFSQTtBQVNmLFlBQVUsUUFUSztBQVVmLFdBQVMsT0FWTTtBQVdmLGlCQUFlLGFBWEE7QUFZZixzQkFBb0Isa0JBWkw7QUFhZixvQkFBa0IsZ0JBYkg7QUFjZix3QkFBc0Isb0JBZFA7QUFlZixpQkFBZSxhQWZBO0FBZ0JmLDBCQUF3QixzQkFoQlQ7QUFpQmYsaUNBQStCLDZCQWpCaEI7QUFrQmYsbUJBQWlCLGVBbEJGO0FBbUJmLFFBQU0sSUFuQlM7QUFvQmYsZUFBYSxXQXBCRTtBQXFCZixZQUFVLFFBckJLO0FBc0JmLGdCQUFjLFlBdEJDO0FBdUJmLFVBQVEsTUF2Qk87QUF3QmYsY0FBWSxVQXhCRztBQXlCZixhQUFXLFNBekJJO0FBMEJmLFNBQU8sS0ExQlE7QUEyQmYsb0JBQWtCLGdCQTNCSDtBQTRCZix1QkFBcUIsbUJBNUJOO0FBNkJmLG1CQUFpQixlQTdCRjtBQThCZixvQkFBa0IsZ0JBOUJIO0FBK0JmLFlBQVUsUUEvQks7QUFnQ2YsUUFBTSxJQWhDUztBQWlDZixZQUFVLFFBakNLO0FBa0NmLHNCQUFvQixrQkFsQ0w7QUFtQ2YsMkJBQXlCLHVCQW5DVjtBQW9DZixZQUFVO0FBcENLLENBQWpCOzs7Ozs7OztBQ3RtQkEsSUFBSSxRQUFRLFFBQVEsaUJBQVIsQ0FBWjs7QUFFQTs7Ozs7Ozs7OztBQVVBLElBQUksV0FBVztBQUNiLHVCQUFxQixJQURSO0FBRWIsU0FBTztBQUZNLENBQWY7O0FBS0E7QUFDQSxJQUFJLFVBQ0YsT0FBTyxNQUFQLEtBQWtCLFdBQWxCLEdBQ0ksTUFESixHQUVJLE9BQU8sTUFBUCxLQUFrQixXQUFsQixHQUNBLE1BREEsR0FFQSxPQUFPLElBQVAsS0FBZ0IsV0FBaEIsR0FDQSxJQURBLEdBRUEsRUFQTjs7QUFTQTtBQUNBLElBQUksU0FBUyxHQUFHLEtBQWhCO0FBQ0EsSUFBSSxtQkFBbUIsR0FBdkI7O0FBRUE7QUFDQSxJQUFJLGlCQUFpQix5R0FBckI7O0FBRUEsU0FBUyxlQUFULEdBQTJCO0FBQ3pCLE1BQUksT0FBTyxRQUFQLEtBQW9CLFdBQXBCLElBQW1DLFNBQVMsUUFBVCxJQUFxQixJQUE1RCxFQUFrRSxPQUFPLEVBQVA7QUFDbEUsU0FBTyxTQUFTLFFBQVQsQ0FBa0IsSUFBekI7QUFDRDs7QUFFRCxTQUFTLGlCQUFULEdBQTZCO0FBQzNCLE1BQUksT0FBTyxRQUFQLEtBQW9CLFdBQXBCLElBQW1DLFNBQVMsUUFBVCxJQUFxQixJQUE1RCxFQUFrRSxPQUFPLEVBQVA7O0FBRWxFO0FBQ0EsTUFBSSxDQUFDLFNBQVMsUUFBVCxDQUFrQixNQUF2QixFQUErQjtBQUM3QixXQUNFLFNBQVMsUUFBVCxDQUFrQixRQUFsQixHQUNBLElBREEsR0FFQSxTQUFTLFFBQVQsQ0FBa0IsUUFGbEIsSUFHQyxTQUFTLFFBQVQsQ0FBa0IsSUFBbEIsR0FBeUIsTUFBTSxTQUFTLFFBQVQsQ0FBa0IsSUFBakQsR0FBd0QsRUFIekQsQ0FERjtBQU1EOztBQUVELFNBQU8sU0FBUyxRQUFULENBQWtCLE1BQXpCO0FBQ0Q7O0FBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXVDQSxTQUFTLE1BQVQsR0FBbUIsU0FBUyxtQkFBVCxHQUErQjtBQUNoRCxNQUFJLFdBQVcsRUFBZjtBQUFBLE1BQ0UsV0FBVyxJQURiO0FBQUEsTUFFRSxnQkFBZ0IsSUFGbEI7QUFBQSxNQUdFLHFCQUFxQixJQUh2Qjs7QUFLQTs7OztBQUlBLFdBQVMsU0FBVCxDQUFtQixPQUFuQixFQUE0QjtBQUMxQjtBQUNBLGFBQVMsSUFBVCxDQUFjLE9BQWQ7QUFDRDs7QUFFRDs7OztBQUlBLFdBQVMsV0FBVCxDQUFxQixPQUFyQixFQUE4QjtBQUM1QixTQUFLLElBQUksSUFBSSxTQUFTLE1BQVQsR0FBa0IsQ0FBL0IsRUFBa0MsS0FBSyxDQUF2QyxFQUEwQyxFQUFFLENBQTVDLEVBQStDO0FBQzdDLFVBQUksU0FBUyxDQUFULE1BQWdCLE9BQXBCLEVBQTZCO0FBQzNCLGlCQUFTLE1BQVQsQ0FBZ0IsQ0FBaEIsRUFBbUIsQ0FBbkI7QUFDRDtBQUNGO0FBQ0Y7O0FBRUQ7OztBQUdBLFdBQVMsY0FBVCxHQUEwQjtBQUN4QjtBQUNBLGVBQVcsRUFBWDtBQUNEOztBQUVEOzs7O0FBSUEsV0FBUyxjQUFULENBQXdCLEtBQXhCLEVBQStCLGFBQS9CLEVBQThDO0FBQzVDLFFBQUksWUFBWSxJQUFoQjtBQUNBLFFBQUksaUJBQWlCLENBQUMsU0FBUyxtQkFBL0IsRUFBb0Q7QUFDbEQ7QUFDRDtBQUNELFNBQUssSUFBSSxDQUFULElBQWMsUUFBZCxFQUF3QjtBQUN0QixVQUFJLFNBQVMsY0FBVCxDQUF3QixDQUF4QixDQUFKLEVBQWdDO0FBQzlCLFlBQUk7QUFDRixtQkFBUyxDQUFULEVBQVksS0FBWixDQUFrQixJQUFsQixFQUF3QixDQUFDLEtBQUQsRUFBUSxNQUFSLENBQWUsT0FBTyxJQUFQLENBQVksU0FBWixFQUF1QixDQUF2QixDQUFmLENBQXhCO0FBQ0QsU0FGRCxDQUVFLE9BQU8sS0FBUCxFQUFjO0FBQ2Qsc0JBQVksS0FBWjtBQUNEO0FBQ0Y7QUFDRjs7QUFFRCxRQUFJLFNBQUosRUFBZTtBQUNiLFlBQU0sU0FBTjtBQUNEO0FBQ0Y7O0FBRUQsTUFBSSxrQkFBSixFQUF3Qix3QkFBeEI7O0FBRUE7Ozs7Ozs7Ozs7O0FBV0EsV0FBUyxxQkFBVCxDQUErQixHQUEvQixFQUFvQyxHQUFwQyxFQUF5QyxNQUF6QyxFQUFpRCxLQUFqRCxFQUF3RCxFQUF4RCxFQUE0RDtBQUMxRCxRQUFJLFFBQVEsSUFBWjtBQUNBO0FBQ0EsUUFBSSxZQUFZLE1BQU0sWUFBTixDQUFtQixFQUFuQixJQUF5QixHQUFHLEtBQTVCLEdBQW9DLEVBQXBEO0FBQ0E7QUFDQSxRQUFJLFVBQVUsTUFBTSxZQUFOLENBQW1CLEdBQW5CLElBQTBCLElBQUksT0FBOUIsR0FBd0MsR0FBdEQ7O0FBRUEsUUFBSSxrQkFBSixFQUF3QjtBQUN0QixlQUFTLGlCQUFULENBQTJCLG1DQUEzQixDQUNFLGtCQURGLEVBRUUsR0FGRixFQUdFLE1BSEYsRUFJRSxPQUpGO0FBTUE7QUFDRCxLQVJELE1BUU8sSUFBSSxhQUFhLE1BQU0sT0FBTixDQUFjLFNBQWQsQ0FBakIsRUFBMkM7QUFDaEQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsY0FBUSxTQUFTLGlCQUFULENBQTJCLFNBQTNCLENBQVI7QUFDQSxxQkFBZSxLQUFmLEVBQXNCLElBQXRCO0FBQ0QsS0FSTSxNQVFBO0FBQ0wsVUFBSSxXQUFXO0FBQ2IsYUFBSyxHQURRO0FBRWIsY0FBTSxNQUZPO0FBR2IsZ0JBQVE7QUFISyxPQUFmOztBQU1BLFVBQUksT0FBTyxTQUFYO0FBQ0EsVUFBSSxNQUFKOztBQUVBLFVBQUksR0FBRyxRQUFILENBQVksSUFBWixDQUFpQixPQUFqQixNQUE4QixpQkFBbEMsRUFBcUQ7QUFDbkQsWUFBSSxTQUFTLFFBQVEsS0FBUixDQUFjLGNBQWQsQ0FBYjtBQUNBLFlBQUksTUFBSixFQUFZO0FBQ1YsaUJBQU8sT0FBTyxDQUFQLENBQVA7QUFDQSxvQkFBVSxPQUFPLENBQVAsQ0FBVjtBQUNEO0FBQ0Y7O0FBRUQsZUFBUyxJQUFULEdBQWdCLGdCQUFoQjs7QUFFQSxjQUFRO0FBQ04sY0FBTSxJQURBO0FBRU4saUJBQVMsT0FGSDtBQUdOLGFBQUssaUJBSEM7QUFJTixlQUFPLENBQUMsUUFBRDtBQUpELE9BQVI7QUFNQSxxQkFBZSxLQUFmLEVBQXNCLElBQXRCO0FBQ0Q7O0FBRUQsUUFBSSxrQkFBSixFQUF3QjtBQUN0QixhQUFPLG1CQUFtQixLQUFuQixDQUF5QixJQUF6QixFQUErQixTQUEvQixDQUFQO0FBQ0Q7O0FBRUQsV0FBTyxLQUFQO0FBQ0Q7O0FBRUQsV0FBUyxvQkFBVCxHQUFnQztBQUM5QixRQUFJLHdCQUFKLEVBQThCO0FBQzVCO0FBQ0Q7QUFDRCx5QkFBcUIsUUFBUSxPQUE3QjtBQUNBLFlBQVEsT0FBUixHQUFrQixxQkFBbEI7QUFDQSwrQkFBMkIsSUFBM0I7QUFDRDs7QUFFRCxXQUFTLHNCQUFULEdBQWtDO0FBQ2hDLFFBQUksQ0FBQyx3QkFBTCxFQUErQjtBQUM3QjtBQUNEO0FBQ0QsWUFBUSxPQUFSLEdBQWtCLGtCQUFsQjtBQUNBLCtCQUEyQixLQUEzQjtBQUNBLHlCQUFxQixTQUFyQjtBQUNEOztBQUVELFdBQVMsb0JBQVQsR0FBZ0M7QUFDOUIsUUFBSSxzQkFBc0Isa0JBQTFCO0FBQUEsUUFDRSxZQUFZLFFBRGQ7QUFFQSxlQUFXLElBQVg7QUFDQSx5QkFBcUIsSUFBckI7QUFDQSxvQkFBZ0IsSUFBaEI7QUFDQSxtQkFBZSxLQUFmLENBQXFCLElBQXJCLEVBQTJCLENBQUMsbUJBQUQsRUFBc0IsS0FBdEIsRUFBNkIsTUFBN0IsQ0FBb0MsU0FBcEMsQ0FBM0I7QUFDRDs7QUFFRDs7Ozs7OztBQU9BLFdBQVMsTUFBVCxDQUFnQixFQUFoQixFQUFvQixPQUFwQixFQUE2QjtBQUMzQixRQUFJLE9BQU8sT0FBTyxJQUFQLENBQVksU0FBWixFQUF1QixDQUF2QixDQUFYO0FBQ0EsUUFBSSxrQkFBSixFQUF3QjtBQUN0QixVQUFJLGtCQUFrQixFQUF0QixFQUEwQjtBQUN4QixlQUR3QixDQUNoQjtBQUNULE9BRkQsTUFFTztBQUNMO0FBQ0Q7QUFDRjs7QUFFRCxRQUFJLFFBQVEsU0FBUyxpQkFBVCxDQUEyQixFQUEzQixDQUFaO0FBQ0EseUJBQXFCLEtBQXJCO0FBQ0Esb0JBQWdCLEVBQWhCO0FBQ0EsZUFBVyxJQUFYOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFDRSxZQUFXO0FBQ1QsVUFBSSxrQkFBa0IsRUFBdEIsRUFBMEI7QUFDeEI7QUFDRDtBQUNGLEtBTEgsRUFNRSxNQUFNLFVBQU4sR0FBbUIsSUFBbkIsR0FBMEIsQ0FONUI7O0FBU0EsUUFBSSxZQUFZLEtBQWhCLEVBQXVCO0FBQ3JCLFlBQU0sRUFBTixDQURxQixDQUNYO0FBQ1g7QUFDRjs7QUFFRCxTQUFPLFNBQVAsR0FBbUIsU0FBbkI7QUFDQSxTQUFPLFdBQVAsR0FBcUIsV0FBckI7QUFDQSxTQUFPLFNBQVAsR0FBbUIsY0FBbkI7QUFDQSxTQUFPLE1BQVA7QUFDRCxDQTFNaUIsRUFBbEI7O0FBNE1BOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtREEsU0FBUyxpQkFBVCxHQUE4QixTQUFTLHdCQUFULEdBQW9DO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7Ozs7O0FBTUEsV0FBUyw4QkFBVCxDQUF3QyxFQUF4QyxFQUE0QztBQUMxQyxRQUFJLE9BQU8sR0FBRyxLQUFWLEtBQW9CLFdBQXBCLElBQW1DLENBQUMsR0FBRyxLQUEzQyxFQUFrRDs7QUFFbEQsUUFBSSxTQUFTLHlJQUFiO0FBQ0EsUUFBSSxRQUFRLHVIQUFaO0FBQ0E7QUFDQTtBQUNBLFFBQUksUUFBUSx3S0FBWjtBQUNBO0FBQ0EsUUFBSSxZQUFZLCtDQUFoQjtBQUNBLFFBQUksYUFBYSwrQkFBakI7QUFDQSxRQUFJLFFBQVEsR0FBRyxLQUFILENBQVMsS0FBVCxDQUFlLElBQWYsQ0FBWjtBQUNBLFFBQUksUUFBUSxFQUFaO0FBQ0EsUUFBSSxRQUFKO0FBQ0EsUUFBSSxLQUFKO0FBQ0EsUUFBSSxPQUFKO0FBQ0EsUUFBSSxZQUFZLHNCQUFzQixJQUF0QixDQUEyQixHQUFHLE9BQTlCLENBQWhCOztBQUVBLFNBQUssSUFBSSxJQUFJLENBQVIsRUFBVyxJQUFJLE1BQU0sTUFBMUIsRUFBa0MsSUFBSSxDQUF0QyxFQUF5QyxFQUFFLENBQTNDLEVBQThDO0FBQzVDLFVBQUssUUFBUSxPQUFPLElBQVAsQ0FBWSxNQUFNLENBQU4sQ0FBWixDQUFiLEVBQXFDO0FBQ25DLFlBQUksV0FBVyxNQUFNLENBQU4sS0FBWSxNQUFNLENBQU4sRUFBUyxPQUFULENBQWlCLFFBQWpCLE1BQStCLENBQTFELENBRG1DLENBQzBCO0FBQzdELFlBQUksU0FBUyxNQUFNLENBQU4sS0FBWSxNQUFNLENBQU4sRUFBUyxPQUFULENBQWlCLE1BQWpCLE1BQTZCLENBQXRELENBRm1DLENBRXNCO0FBQ3pELFlBQUksV0FBVyxXQUFXLFdBQVcsSUFBWCxDQUFnQixNQUFNLENBQU4sQ0FBaEIsQ0FBdEIsQ0FBSixFQUFzRDtBQUNwRDtBQUNBLGdCQUFNLENBQU4sSUFBVyxTQUFTLENBQVQsQ0FBWCxDQUZvRCxDQUU1QjtBQUN4QixnQkFBTSxDQUFOLElBQVcsU0FBUyxDQUFULENBQVgsQ0FIb0QsQ0FHNUI7QUFDeEIsZ0JBQU0sQ0FBTixJQUFXLFNBQVMsQ0FBVCxDQUFYLENBSm9ELENBSTVCO0FBQ3pCO0FBQ0Qsa0JBQVU7QUFDUixlQUFLLENBQUMsUUFBRCxHQUFZLE1BQU0sQ0FBTixDQUFaLEdBQXVCLElBRHBCO0FBRVIsZ0JBQU0sTUFBTSxDQUFOLEtBQVksZ0JBRlY7QUFHUixnQkFBTSxXQUFXLENBQUMsTUFBTSxDQUFOLENBQUQsQ0FBWCxHQUF3QixFQUh0QjtBQUlSLGdCQUFNLE1BQU0sQ0FBTixJQUFXLENBQUMsTUFBTSxDQUFOLENBQVosR0FBdUIsSUFKckI7QUFLUixrQkFBUSxNQUFNLENBQU4sSUFBVyxDQUFDLE1BQU0sQ0FBTixDQUFaLEdBQXVCO0FBTHZCLFNBQVY7QUFPRCxPQWhCRCxNQWdCTyxJQUFLLFFBQVEsTUFBTSxJQUFOLENBQVcsTUFBTSxDQUFOLENBQVgsQ0FBYixFQUFvQztBQUN6QyxrQkFBVTtBQUNSLGVBQUssTUFBTSxDQUFOLENBREc7QUFFUixnQkFBTSxNQUFNLENBQU4sS0FBWSxnQkFGVjtBQUdSLGdCQUFNLEVBSEU7QUFJUixnQkFBTSxDQUFDLE1BQU0sQ0FBTixDQUpDO0FBS1Isa0JBQVEsTUFBTSxDQUFOLElBQVcsQ0FBQyxNQUFNLENBQU4sQ0FBWixHQUF1QjtBQUx2QixTQUFWO0FBT0QsT0FSTSxNQVFBLElBQUssUUFBUSxNQUFNLElBQU4sQ0FBVyxNQUFNLENBQU4sQ0FBWCxDQUFiLEVBQW9DO0FBQ3pDLFlBQUksU0FBUyxNQUFNLENBQU4sS0FBWSxNQUFNLENBQU4sRUFBUyxPQUFULENBQWlCLFNBQWpCLElBQThCLENBQUMsQ0FBeEQ7QUFDQSxZQUFJLFdBQVcsV0FBVyxVQUFVLElBQVYsQ0FBZSxNQUFNLENBQU4sQ0FBZixDQUF0QixDQUFKLEVBQXFEO0FBQ25EO0FBQ0EsZ0JBQU0sQ0FBTixJQUFXLFNBQVMsQ0FBVCxDQUFYO0FBQ0EsZ0JBQU0sQ0FBTixJQUFXLFNBQVMsQ0FBVCxDQUFYO0FBQ0EsZ0JBQU0sQ0FBTixJQUFXLElBQVgsQ0FKbUQsQ0FJbEM7QUFDbEIsU0FMRCxNQUtPLElBQUksTUFBTSxDQUFOLElBQVcsQ0FBQyxNQUFNLENBQU4sQ0FBWixJQUF3QixPQUFPLEdBQUcsWUFBVixLQUEyQixXQUF2RCxFQUFvRTtBQUN6RTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFNLENBQU4sRUFBUyxNQUFULEdBQWtCLEdBQUcsWUFBSCxHQUFrQixDQUFwQztBQUNEO0FBQ0Qsa0JBQVU7QUFDUixlQUFLLE1BQU0sQ0FBTixDQURHO0FBRVIsZ0JBQU0sTUFBTSxDQUFOLEtBQVksZ0JBRlY7QUFHUixnQkFBTSxNQUFNLENBQU4sSUFBVyxNQUFNLENBQU4sRUFBUyxLQUFULENBQWUsR0FBZixDQUFYLEdBQWlDLEVBSC9CO0FBSVIsZ0JBQU0sTUFBTSxDQUFOLElBQVcsQ0FBQyxNQUFNLENBQU4sQ0FBWixHQUF1QixJQUpyQjtBQUtSLGtCQUFRLE1BQU0sQ0FBTixJQUFXLENBQUMsTUFBTSxDQUFOLENBQVosR0FBdUI7QUFMdkIsU0FBVjtBQU9ELE9BckJNLE1BcUJBO0FBQ0w7QUFDRDs7QUFFRCxVQUFJLENBQUMsUUFBUSxJQUFULElBQWlCLFFBQVEsSUFBN0IsRUFBbUM7QUFDakMsZ0JBQVEsSUFBUixHQUFlLGdCQUFmO0FBQ0Q7O0FBRUQsVUFBSSxRQUFRLEdBQVIsSUFBZSxRQUFRLEdBQVIsQ0FBWSxNQUFaLENBQW1CLENBQW5CLEVBQXNCLENBQXRCLE1BQTZCLE9BQWhELEVBQXlEO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFJLE1BQU0sSUFBSSxjQUFKLEVBQVY7QUFDQSxZQUFJLElBQUosQ0FBUyxLQUFULEVBQWdCLFFBQVEsR0FBeEIsRUFBNkIsS0FBN0I7QUFDQSxZQUFJLElBQUosQ0FBUyxJQUFUOztBQUVBO0FBQ0EsWUFBSSxJQUFJLE1BQUosS0FBZSxHQUFuQixFQUF3QjtBQUN0QixjQUFJLFNBQVMsSUFBSSxZQUFKLElBQW9CLEVBQWpDOztBQUVBO0FBQ0E7QUFDQSxtQkFBUyxPQUFPLEtBQVAsQ0FBYSxDQUFDLEdBQWQsQ0FBVDs7QUFFQTtBQUNBLGNBQUksYUFBYSxPQUFPLEtBQVAsQ0FBYSw4QkFBYixDQUFqQjs7QUFFQTtBQUNBLGNBQUksVUFBSixFQUFnQjtBQUNkLGdCQUFJLG1CQUFtQixXQUFXLENBQVgsQ0FBdkI7O0FBRUE7QUFDQTtBQUNBLGdCQUFJLGlCQUFpQixNQUFqQixDQUF3QixDQUF4QixNQUErQixHQUFuQyxFQUF3QztBQUN0QyxpQ0FBbUIsc0JBQXNCLGlCQUFpQixLQUFqQixDQUF1QixDQUF2QixDQUF6QztBQUNEOztBQUVEO0FBQ0E7QUFDQSxvQkFBUSxHQUFSLEdBQWMsaUJBQWlCLEtBQWpCLENBQXVCLENBQXZCLEVBQTBCLENBQUMsQ0FBM0IsQ0FBZDtBQUNEO0FBQ0Y7QUFDRjs7QUFFRCxZQUFNLElBQU4sQ0FBVyxPQUFYO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDLE1BQU0sTUFBWCxFQUFtQjtBQUNqQixhQUFPLElBQVA7QUFDRDs7QUFFRCxXQUFPO0FBQ0wsWUFBTSxHQUFHLElBREo7QUFFTCxlQUFTLEdBQUcsT0FGUDtBQUdMLFdBQUssaUJBSEE7QUFJTCxhQUFPO0FBSkYsS0FBUDtBQU1EOztBQUVEOzs7Ozs7Ozs7Ozs7O0FBYUEsV0FBUyxtQ0FBVCxDQUE2QyxTQUE3QyxFQUF3RCxHQUF4RCxFQUE2RCxNQUE3RCxFQUFxRSxPQUFyRSxFQUE4RTtBQUM1RSxRQUFJLFVBQVU7QUFDWixXQUFLLEdBRE87QUFFWixZQUFNO0FBRk0sS0FBZDs7QUFLQSxRQUFJLFFBQVEsR0FBUixJQUFlLFFBQVEsSUFBM0IsRUFBaUM7QUFDL0IsZ0JBQVUsVUFBVixHQUF1QixLQUF2Qjs7QUFFQSxVQUFJLENBQUMsUUFBUSxJQUFiLEVBQW1CO0FBQ2pCLGdCQUFRLElBQVIsR0FBZSxnQkFBZjtBQUNEOztBQUVELFVBQUksVUFBVSxLQUFWLENBQWdCLE1BQWhCLEdBQXlCLENBQTdCLEVBQWdDO0FBQzlCLFlBQUksVUFBVSxLQUFWLENBQWdCLENBQWhCLEVBQW1CLEdBQW5CLEtBQTJCLFFBQVEsR0FBdkMsRUFBNEM7QUFDMUMsY0FBSSxVQUFVLEtBQVYsQ0FBZ0IsQ0FBaEIsRUFBbUIsSUFBbkIsS0FBNEIsUUFBUSxJQUF4QyxFQUE4QztBQUM1QyxtQkFBTyxLQUFQLENBRDRDLENBQzlCO0FBQ2YsV0FGRCxNQUVPLElBQ0wsQ0FBQyxVQUFVLEtBQVYsQ0FBZ0IsQ0FBaEIsRUFBbUIsSUFBcEIsSUFDQSxVQUFVLEtBQVYsQ0FBZ0IsQ0FBaEIsRUFBbUIsSUFBbkIsS0FBNEIsUUFBUSxJQUYvQixFQUdMO0FBQ0Esc0JBQVUsS0FBVixDQUFnQixDQUFoQixFQUFtQixJQUFuQixHQUEwQixRQUFRLElBQWxDO0FBQ0EsbUJBQU8sS0FBUDtBQUNEO0FBQ0Y7QUFDRjs7QUFFRCxnQkFBVSxLQUFWLENBQWdCLE9BQWhCLENBQXdCLE9BQXhCO0FBQ0EsZ0JBQVUsT0FBVixHQUFvQixJQUFwQjtBQUNBLGFBQU8sSUFBUDtBQUNELEtBeEJELE1Bd0JPO0FBQ0wsZ0JBQVUsVUFBVixHQUF1QixJQUF2QjtBQUNEOztBQUVELFdBQU8sS0FBUDtBQUNEOztBQUVEOzs7Ozs7Ozs7QUFTQSxXQUFTLHFDQUFULENBQStDLEVBQS9DLEVBQW1ELEtBQW5ELEVBQTBEO0FBQ3hELFFBQUksZUFBZSxvRUFBbkI7QUFBQSxRQUNFLFFBQVEsRUFEVjtBQUFBLFFBRUUsUUFBUSxFQUZWO0FBQUEsUUFHRSxZQUFZLEtBSGQ7QUFBQSxRQUlFLEtBSkY7QUFBQSxRQUtFLElBTEY7QUFBQSxRQU1FLE1BTkY7O0FBUUEsU0FDRSxJQUFJLE9BQU8sc0NBQXNDLE1BRG5ELEVBRUUsUUFBUSxDQUFDLFNBRlgsRUFHRSxPQUFPLEtBQUssTUFIZCxFQUlFO0FBQ0EsVUFBSSxTQUFTLGlCQUFULElBQThCLFNBQVMsU0FBUyxNQUFwRCxFQUE0RDtBQUMxRDtBQUNBO0FBQ0Q7O0FBRUQsYUFBTztBQUNMLGFBQUssSUFEQTtBQUVMLGNBQU0sZ0JBRkQ7QUFHTCxjQUFNLElBSEQ7QUFJTCxnQkFBUTtBQUpILE9BQVA7O0FBT0EsVUFBSSxLQUFLLElBQVQsRUFBZTtBQUNiLGFBQUssSUFBTCxHQUFZLEtBQUssSUFBakI7QUFDRCxPQUZELE1BRU8sSUFBSyxRQUFRLGFBQWEsSUFBYixDQUFrQixLQUFLLFFBQUwsRUFBbEIsQ0FBYixFQUFrRDtBQUN2RCxhQUFLLElBQUwsR0FBWSxNQUFNLENBQU4sQ0FBWjtBQUNEOztBQUVELFVBQUksT0FBTyxLQUFLLElBQVosS0FBcUIsV0FBekIsRUFBc0M7QUFDcEMsWUFBSTtBQUNGLGVBQUssSUFBTCxHQUFZLE1BQU0sS0FBTixDQUFZLFNBQVosQ0FBc0IsQ0FBdEIsRUFBeUIsTUFBTSxLQUFOLENBQVksT0FBWixDQUFvQixHQUFwQixDQUF6QixDQUFaO0FBQ0QsU0FGRCxDQUVFLE9BQU8sQ0FBUCxFQUFVLENBQUU7QUFDZjs7QUFFRCxVQUFJLE1BQU0sS0FBSyxJQUFYLENBQUosRUFBc0I7QUFDcEIsb0JBQVksSUFBWjtBQUNELE9BRkQsTUFFTztBQUNMLGNBQU0sS0FBSyxJQUFYLElBQW1CLElBQW5CO0FBQ0Q7O0FBRUQsWUFBTSxJQUFOLENBQVcsSUFBWDtBQUNEOztBQUVELFFBQUksS0FBSixFQUFXO0FBQ1Q7QUFDQTtBQUNBLFlBQU0sTUFBTixDQUFhLENBQWIsRUFBZ0IsS0FBaEI7QUFDRDs7QUFFRCxRQUFJLFNBQVM7QUFDWCxZQUFNLEdBQUcsSUFERTtBQUVYLGVBQVMsR0FBRyxPQUZEO0FBR1gsV0FBSyxpQkFITTtBQUlYLGFBQU87QUFKSSxLQUFiO0FBTUEsd0NBQ0UsTUFERixFQUVFLEdBQUcsU0FBSCxJQUFnQixHQUFHLFFBRnJCLEVBR0UsR0FBRyxJQUFILElBQVcsR0FBRyxVQUhoQixFQUlFLEdBQUcsT0FBSCxJQUFjLEdBQUcsV0FKbkI7QUFNQSxXQUFPLE1BQVA7QUFDRDs7QUFFRDs7Ozs7QUFLQSxXQUFTLGlCQUFULENBQTJCLEVBQTNCLEVBQStCLEtBQS9CLEVBQXNDO0FBQ3BDLFFBQUksUUFBUSxJQUFaO0FBQ0EsWUFBUSxTQUFTLElBQVQsR0FBZ0IsQ0FBaEIsR0FBb0IsQ0FBQyxLQUE3Qjs7QUFFQSxRQUFJO0FBQ0YsY0FBUSwrQkFBK0IsRUFBL0IsQ0FBUjtBQUNBLFVBQUksS0FBSixFQUFXO0FBQ1QsZUFBTyxLQUFQO0FBQ0Q7QUFDRixLQUxELENBS0UsT0FBTyxDQUFQLEVBQVU7QUFDVixVQUFJLFNBQVMsS0FBYixFQUFvQjtBQUNsQixjQUFNLENBQU47QUFDRDtBQUNGOztBQUVELFFBQUk7QUFDRixjQUFRLHNDQUFzQyxFQUF0QyxFQUEwQyxRQUFRLENBQWxELENBQVI7QUFDQSxVQUFJLEtBQUosRUFBVztBQUNULGVBQU8sS0FBUDtBQUNEO0FBQ0YsS0FMRCxDQUtFLE9BQU8sQ0FBUCxFQUFVO0FBQ1YsVUFBSSxTQUFTLEtBQWIsRUFBb0I7QUFDbEIsY0FBTSxDQUFOO0FBQ0Q7QUFDRjtBQUNELFdBQU87QUFDTCxZQUFNLEdBQUcsSUFESjtBQUVMLGVBQVMsR0FBRyxPQUZQO0FBR0wsV0FBSztBQUhBLEtBQVA7QUFLRDs7QUFFRCxvQkFBa0IsbUNBQWxCLEdBQXdELG1DQUF4RDtBQUNBLG9CQUFrQiw4QkFBbEIsR0FBbUQsOEJBQW5EOztBQUVBLFNBQU8saUJBQVA7QUFDRCxDQWpWNEIsRUFBN0I7O0FBbVZBLE9BQU8sT0FBUCxHQUFpQixRQUFqQjs7Ozs7OztBQ2hyQkE7Ozs7Ozs7Ozs7O0FBV0EsVUFBVSxPQUFPLE9BQVAsR0FBaUIsU0FBM0I7QUFDQSxRQUFRLFlBQVIsR0FBdUIsVUFBdkI7O0FBRUEsU0FBUyxPQUFULENBQWlCLFFBQWpCLEVBQTJCLE1BQTNCLEVBQW1DO0FBQ2pDLE9BQUssSUFBSSxJQUFJLENBQWIsRUFBZ0IsSUFBSSxTQUFTLE1BQTdCLEVBQXFDLEVBQUUsQ0FBdkMsRUFBMEM7QUFDeEMsUUFBSSxTQUFTLENBQVQsTUFBZ0IsTUFBcEIsRUFBNEIsT0FBTyxDQUFQO0FBQzdCO0FBQ0QsU0FBTyxDQUFDLENBQVI7QUFDRDs7QUFFRCxTQUFTLFNBQVQsQ0FBbUIsR0FBbkIsRUFBd0IsUUFBeEIsRUFBa0MsTUFBbEMsRUFBMEMsYUFBMUMsRUFBeUQ7QUFDdkQsU0FBTyxLQUFLLFNBQUwsQ0FBZSxHQUFmLEVBQW9CLFdBQVcsUUFBWCxFQUFxQixhQUFyQixDQUFwQixFQUF5RCxNQUF6RCxDQUFQO0FBQ0Q7O0FBRUQ7QUFDQSxTQUFTLGNBQVQsQ0FBd0IsS0FBeEIsRUFBK0I7QUFDN0IsTUFBSSxNQUFNO0FBQ1I7QUFDQSxXQUFPLE1BQU0sS0FGTDtBQUdSLGFBQVMsTUFBTSxPQUhQO0FBSVIsVUFBTSxNQUFNO0FBSkosR0FBVjs7QUFPQSxPQUFLLElBQUksQ0FBVCxJQUFjLEtBQWQsRUFBcUI7QUFDbkIsUUFBSSxPQUFPLFNBQVAsQ0FBaUIsY0FBakIsQ0FBZ0MsSUFBaEMsQ0FBcUMsS0FBckMsRUFBNEMsQ0FBNUMsQ0FBSixFQUFvRDtBQUNsRCxVQUFJLENBQUosSUFBUyxNQUFNLENBQU4sQ0FBVDtBQUNEO0FBQ0Y7O0FBRUQsU0FBTyxHQUFQO0FBQ0Q7O0FBRUQsU0FBUyxVQUFULENBQW9CLFFBQXBCLEVBQThCLGFBQTlCLEVBQTZDO0FBQzNDLE1BQUksUUFBUSxFQUFaO0FBQ0EsTUFBSSxPQUFPLEVBQVg7O0FBRUEsTUFBSSxpQkFBaUIsSUFBckIsRUFBMkI7QUFDekIsb0JBQWdCLHVCQUFTLEdBQVQsRUFBYyxLQUFkLEVBQXFCO0FBQ25DLFVBQUksTUFBTSxDQUFOLE1BQWEsS0FBakIsRUFBd0I7QUFDdEIsZUFBTyxjQUFQO0FBQ0Q7QUFDRCxhQUFPLGlCQUFpQixLQUFLLEtBQUwsQ0FBVyxDQUFYLEVBQWMsUUFBUSxLQUFSLEVBQWUsS0FBZixDQUFkLEVBQXFDLElBQXJDLENBQTBDLEdBQTFDLENBQWpCLEdBQWtFLEdBQXpFO0FBQ0QsS0FMRDtBQU1EOztBQUVELFNBQU8sVUFBUyxHQUFULEVBQWMsS0FBZCxFQUFxQjtBQUMxQixRQUFJLE1BQU0sTUFBTixHQUFlLENBQW5CLEVBQXNCO0FBQ3BCLFVBQUksVUFBVSxRQUFRLEtBQVIsRUFBZSxJQUFmLENBQWQ7QUFDQSxPQUFDLE9BQUQsR0FBVyxNQUFNLE1BQU4sQ0FBYSxVQUFVLENBQXZCLENBQVgsR0FBdUMsTUFBTSxJQUFOLENBQVcsSUFBWCxDQUF2QztBQUNBLE9BQUMsT0FBRCxHQUFXLEtBQUssTUFBTCxDQUFZLE9BQVosRUFBcUIsUUFBckIsRUFBK0IsR0FBL0IsQ0FBWCxHQUFpRCxLQUFLLElBQUwsQ0FBVSxHQUFWLENBQWpEOztBQUVBLFVBQUksQ0FBQyxRQUFRLEtBQVIsRUFBZSxLQUFmLENBQUwsRUFBNEI7QUFDMUIsZ0JBQVEsY0FBYyxJQUFkLENBQW1CLElBQW5CLEVBQXlCLEdBQXpCLEVBQThCLEtBQTlCLENBQVI7QUFDRDtBQUNGLEtBUkQsTUFRTztBQUNMLFlBQU0sSUFBTixDQUFXLEtBQVg7QUFDRDs7QUFFRCxXQUFPLFlBQVksSUFBWixHQUNILGlCQUFpQixLQUFqQixHQUF5QixlQUFlLEtBQWYsQ0FBekIsR0FBaUQsS0FEOUMsR0FFSCxTQUFTLElBQVQsQ0FBYyxJQUFkLEVBQW9CLEdBQXBCLEVBQXlCLEtBQXpCLENBRko7QUFHRCxHQWhCRDtBQWlCRDs7Ozs7QUN6RUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtQkE7Ozs7QUFJQSxTQUFTLE9BQVQsQ0FBaUIsQ0FBakIsRUFBb0IsQ0FBcEIsRUFBdUI7QUFDckIsTUFBSSxNQUFNLENBQUMsSUFBSSxNQUFMLEtBQWdCLElBQUksTUFBcEIsQ0FBVjtBQUNBLE1BQUksTUFBTSxDQUFDLEtBQUssRUFBTixLQUFhLEtBQUssRUFBbEIsS0FBeUIsT0FBTyxFQUFoQyxDQUFWO0FBQ0EsU0FBUSxPQUFPLEVBQVIsR0FBZSxNQUFNLE1BQTVCO0FBQ0Q7O0FBRUQ7OztBQUdBLFNBQVMsYUFBVCxDQUF1QixHQUF2QixFQUE0QixHQUE1QixFQUFpQztBQUMvQixTQUFRLE9BQU8sR0FBUixHQUFnQixRQUFTLEtBQUssR0FBckM7QUFDRDs7QUFFRDs7O0FBR0EsU0FBUyxNQUFULENBQWdCLENBQWhCLEVBQW1CLENBQW5CLEVBQXNCLENBQXRCLEVBQXlCLENBQXpCLEVBQTRCLENBQTVCLEVBQStCLENBQS9CLEVBQWtDO0FBQ2hDLFNBQU8sUUFBUSxjQUFjLFFBQVEsUUFBUSxDQUFSLEVBQVcsQ0FBWCxDQUFSLEVBQXVCLFFBQVEsQ0FBUixFQUFXLENBQVgsQ0FBdkIsQ0FBZCxFQUFxRCxDQUFyRCxDQUFSLEVBQWlFLENBQWpFLENBQVA7QUFDRDtBQUNELFNBQVMsS0FBVCxDQUFlLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUIsQ0FBckIsRUFBd0IsQ0FBeEIsRUFBMkIsQ0FBM0IsRUFBOEIsQ0FBOUIsRUFBaUMsQ0FBakMsRUFBb0M7QUFDbEMsU0FBTyxPQUFRLElBQUksQ0FBTCxHQUFXLENBQUMsQ0FBRCxHQUFLLENBQXZCLEVBQTJCLENBQTNCLEVBQThCLENBQTlCLEVBQWlDLENBQWpDLEVBQW9DLENBQXBDLEVBQXVDLENBQXZDLENBQVA7QUFDRDtBQUNELFNBQVMsS0FBVCxDQUFlLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUIsQ0FBckIsRUFBd0IsQ0FBeEIsRUFBMkIsQ0FBM0IsRUFBOEIsQ0FBOUIsRUFBaUMsQ0FBakMsRUFBb0M7QUFDbEMsU0FBTyxPQUFRLElBQUksQ0FBTCxHQUFXLElBQUksQ0FBQyxDQUF2QixFQUEyQixDQUEzQixFQUE4QixDQUE5QixFQUFpQyxDQUFqQyxFQUFvQyxDQUFwQyxFQUF1QyxDQUF2QyxDQUFQO0FBQ0Q7QUFDRCxTQUFTLEtBQVQsQ0FBZSxDQUFmLEVBQWtCLENBQWxCLEVBQXFCLENBQXJCLEVBQXdCLENBQXhCLEVBQTJCLENBQTNCLEVBQThCLENBQTlCLEVBQWlDLENBQWpDLEVBQW9DO0FBQ2xDLFNBQU8sT0FBTyxJQUFJLENBQUosR0FBUSxDQUFmLEVBQWtCLENBQWxCLEVBQXFCLENBQXJCLEVBQXdCLENBQXhCLEVBQTJCLENBQTNCLEVBQThCLENBQTlCLENBQVA7QUFDRDtBQUNELFNBQVMsS0FBVCxDQUFlLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUIsQ0FBckIsRUFBd0IsQ0FBeEIsRUFBMkIsQ0FBM0IsRUFBOEIsQ0FBOUIsRUFBaUMsQ0FBakMsRUFBb0M7QUFDbEMsU0FBTyxPQUFPLEtBQUssSUFBSSxDQUFDLENBQVYsQ0FBUCxFQUFxQixDQUFyQixFQUF3QixDQUF4QixFQUEyQixDQUEzQixFQUE4QixDQUE5QixFQUFpQyxDQUFqQyxDQUFQO0FBQ0Q7O0FBRUQ7OztBQUdBLFNBQVMsT0FBVCxDQUFpQixDQUFqQixFQUFvQixHQUFwQixFQUF5QjtBQUN2QjtBQUNBLElBQUUsT0FBTyxDQUFULEtBQWUsUUFBUyxNQUFNLEVBQTlCO0FBQ0EsSUFBRSxDQUFHLE1BQU0sRUFBUCxLQUFlLENBQWhCLElBQXNCLENBQXZCLElBQTRCLEVBQTlCLElBQW9DLEdBQXBDOztBQUVBLE1BQUksQ0FBSjtBQUNBLE1BQUksSUFBSjtBQUNBLE1BQUksSUFBSjtBQUNBLE1BQUksSUFBSjtBQUNBLE1BQUksSUFBSjtBQUNBLE1BQUksSUFBSSxVQUFSO0FBQ0EsTUFBSSxJQUFJLENBQUMsU0FBVDtBQUNBLE1BQUksSUFBSSxDQUFDLFVBQVQ7QUFDQSxNQUFJLElBQUksU0FBUjs7QUFFQSxPQUFLLElBQUksQ0FBVCxFQUFZLElBQUksRUFBRSxNQUFsQixFQUEwQixLQUFLLEVBQS9CLEVBQW1DO0FBQ2pDLFdBQU8sQ0FBUDtBQUNBLFdBQU8sQ0FBUDtBQUNBLFdBQU8sQ0FBUDtBQUNBLFdBQU8sQ0FBUDs7QUFFQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLENBQUYsQ0FBbEIsRUFBd0IsQ0FBeEIsRUFBMkIsQ0FBQyxTQUE1QixDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLENBQU4sQ0FBbEIsRUFBNEIsRUFBNUIsRUFBZ0MsQ0FBQyxTQUFqQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLENBQU4sQ0FBbEIsRUFBNEIsRUFBNUIsRUFBZ0MsU0FBaEMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxDQUFOLENBQWxCLEVBQTRCLEVBQTVCLEVBQWdDLENBQUMsVUFBakMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxDQUFOLENBQWxCLEVBQTRCLENBQTVCLEVBQStCLENBQUMsU0FBaEMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxDQUFOLENBQWxCLEVBQTRCLEVBQTVCLEVBQWdDLFVBQWhDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixFQUE1QixFQUFnQyxDQUFDLFVBQWpDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixFQUE1QixFQUFnQyxDQUFDLFFBQWpDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixDQUE1QixFQUErQixVQUEvQixDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLENBQU4sQ0FBbEIsRUFBNEIsRUFBNUIsRUFBZ0MsQ0FBQyxVQUFqQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLEVBQU4sQ0FBbEIsRUFBNkIsRUFBN0IsRUFBaUMsQ0FBQyxLQUFsQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLEVBQU4sQ0FBbEIsRUFBNkIsRUFBN0IsRUFBaUMsQ0FBQyxVQUFsQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLEVBQU4sQ0FBbEIsRUFBNkIsQ0FBN0IsRUFBZ0MsVUFBaEMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxFQUFOLENBQWxCLEVBQTZCLEVBQTdCLEVBQWlDLENBQUMsUUFBbEMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxFQUFOLENBQWxCLEVBQTZCLEVBQTdCLEVBQWlDLENBQUMsVUFBbEMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxFQUFOLENBQWxCLEVBQTZCLEVBQTdCLEVBQWlDLFVBQWpDLENBQUo7O0FBRUEsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLENBQU4sQ0FBbEIsRUFBNEIsQ0FBNUIsRUFBK0IsQ0FBQyxTQUFoQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLENBQU4sQ0FBbEIsRUFBNEIsQ0FBNUIsRUFBK0IsQ0FBQyxVQUFoQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLEVBQU4sQ0FBbEIsRUFBNkIsRUFBN0IsRUFBaUMsU0FBakMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsQ0FBRixDQUFsQixFQUF3QixFQUF4QixFQUE0QixDQUFDLFNBQTdCLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixDQUE1QixFQUErQixDQUFDLFNBQWhDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksRUFBTixDQUFsQixFQUE2QixDQUE3QixFQUFnQyxRQUFoQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLEVBQU4sQ0FBbEIsRUFBNkIsRUFBN0IsRUFBaUMsQ0FBQyxTQUFsQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLENBQU4sQ0FBbEIsRUFBNEIsRUFBNUIsRUFBZ0MsQ0FBQyxTQUFqQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLENBQU4sQ0FBbEIsRUFBNEIsQ0FBNUIsRUFBK0IsU0FBL0IsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxFQUFOLENBQWxCLEVBQTZCLENBQTdCLEVBQWdDLENBQUMsVUFBakMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxDQUFOLENBQWxCLEVBQTRCLEVBQTVCLEVBQWdDLENBQUMsU0FBakMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxDQUFOLENBQWxCLEVBQTRCLEVBQTVCLEVBQWdDLFVBQWhDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksRUFBTixDQUFsQixFQUE2QixDQUE3QixFQUFnQyxDQUFDLFVBQWpDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixDQUE1QixFQUErQixDQUFDLFFBQWhDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixFQUE1QixFQUFnQyxVQUFoQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLEVBQU4sQ0FBbEIsRUFBNkIsRUFBN0IsRUFBaUMsQ0FBQyxVQUFsQyxDQUFKOztBQUVBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxDQUFOLENBQWxCLEVBQTRCLENBQTVCLEVBQStCLENBQUMsTUFBaEMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxDQUFOLENBQWxCLEVBQTRCLEVBQTVCLEVBQWdDLENBQUMsVUFBakMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxFQUFOLENBQWxCLEVBQTZCLEVBQTdCLEVBQWlDLFVBQWpDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksRUFBTixDQUFsQixFQUE2QixFQUE3QixFQUFpQyxDQUFDLFFBQWxDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixDQUE1QixFQUErQixDQUFDLFVBQWhDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixFQUE1QixFQUFnQyxVQUFoQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLENBQU4sQ0FBbEIsRUFBNEIsRUFBNUIsRUFBZ0MsQ0FBQyxTQUFqQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLEVBQU4sQ0FBbEIsRUFBNkIsRUFBN0IsRUFBaUMsQ0FBQyxVQUFsQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLEVBQU4sQ0FBbEIsRUFBNkIsQ0FBN0IsRUFBZ0MsU0FBaEMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsQ0FBRixDQUFsQixFQUF3QixFQUF4QixFQUE0QixDQUFDLFNBQTdCLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixFQUE1QixFQUFnQyxDQUFDLFNBQWpDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixFQUE1QixFQUFnQyxRQUFoQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLENBQU4sQ0FBbEIsRUFBNEIsQ0FBNUIsRUFBK0IsQ0FBQyxTQUFoQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLEVBQU4sQ0FBbEIsRUFBNkIsRUFBN0IsRUFBaUMsQ0FBQyxTQUFsQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLEVBQU4sQ0FBbEIsRUFBNkIsRUFBN0IsRUFBaUMsU0FBakMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxDQUFOLENBQWxCLEVBQTRCLEVBQTVCLEVBQWdDLENBQUMsU0FBakMsQ0FBSjs7QUFFQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLENBQUYsQ0FBbEIsRUFBd0IsQ0FBeEIsRUFBMkIsQ0FBQyxTQUE1QixDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLENBQU4sQ0FBbEIsRUFBNEIsRUFBNUIsRUFBZ0MsVUFBaEMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxFQUFOLENBQWxCLEVBQTZCLEVBQTdCLEVBQWlDLENBQUMsVUFBbEMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxDQUFOLENBQWxCLEVBQTRCLEVBQTVCLEVBQWdDLENBQUMsUUFBakMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxFQUFOLENBQWxCLEVBQTZCLENBQTdCLEVBQWdDLFVBQWhDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixFQUE1QixFQUFnQyxDQUFDLFVBQWpDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksRUFBTixDQUFsQixFQUE2QixFQUE3QixFQUFpQyxDQUFDLE9BQWxDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixFQUE1QixFQUFnQyxDQUFDLFVBQWpDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixDQUE1QixFQUErQixVQUEvQixDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLEVBQU4sQ0FBbEIsRUFBNkIsRUFBN0IsRUFBaUMsQ0FBQyxRQUFsQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLENBQU4sQ0FBbEIsRUFBNEIsRUFBNUIsRUFBZ0MsQ0FBQyxVQUFqQyxDQUFKO0FBQ0EsUUFBSSxNQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixFQUFlLENBQWYsRUFBa0IsRUFBRSxJQUFJLEVBQU4sQ0FBbEIsRUFBNkIsRUFBN0IsRUFBaUMsVUFBakMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxDQUFOLENBQWxCLEVBQTRCLENBQTVCLEVBQStCLENBQUMsU0FBaEMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxFQUFOLENBQWxCLEVBQTZCLEVBQTdCLEVBQWlDLENBQUMsVUFBbEMsQ0FBSjtBQUNBLFFBQUksTUFBTSxDQUFOLEVBQVMsQ0FBVCxFQUFZLENBQVosRUFBZSxDQUFmLEVBQWtCLEVBQUUsSUFBSSxDQUFOLENBQWxCLEVBQTRCLEVBQTVCLEVBQWdDLFNBQWhDLENBQUo7QUFDQSxRQUFJLE1BQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixFQUFFLElBQUksQ0FBTixDQUFsQixFQUE0QixFQUE1QixFQUFnQyxDQUFDLFNBQWpDLENBQUo7O0FBRUEsUUFBSSxRQUFRLENBQVIsRUFBVyxJQUFYLENBQUo7QUFDQSxRQUFJLFFBQVEsQ0FBUixFQUFXLElBQVgsQ0FBSjtBQUNBLFFBQUksUUFBUSxDQUFSLEVBQVcsSUFBWCxDQUFKO0FBQ0EsUUFBSSxRQUFRLENBQVIsRUFBVyxJQUFYLENBQUo7QUFDRDtBQUNELFNBQU8sQ0FBQyxDQUFELEVBQUksQ0FBSixFQUFPLENBQVAsRUFBVSxDQUFWLENBQVA7QUFDRDs7QUFFRDs7O0FBR0EsU0FBUyxTQUFULENBQW1CLEtBQW5CLEVBQTBCO0FBQ3hCLE1BQUksQ0FBSjtBQUNBLE1BQUksU0FBUyxFQUFiO0FBQ0EsTUFBSSxXQUFXLE1BQU0sTUFBTixHQUFlLEVBQTlCO0FBQ0EsT0FBSyxJQUFJLENBQVQsRUFBWSxJQUFJLFFBQWhCLEVBQTBCLEtBQUssQ0FBL0IsRUFBa0M7QUFDaEMsY0FBVSxPQUFPLFlBQVAsQ0FBcUIsTUFBTSxLQUFLLENBQVgsTUFBbUIsSUFBSSxFQUF4QixHQUErQixJQUFuRCxDQUFWO0FBQ0Q7QUFDRCxTQUFPLE1BQVA7QUFDRDs7QUFFRDs7OztBQUlBLFNBQVMsU0FBVCxDQUFtQixLQUFuQixFQUEwQjtBQUN4QixNQUFJLENBQUo7QUFDQSxNQUFJLFNBQVMsRUFBYjtBQUNBLFNBQU8sQ0FBQyxNQUFNLE1BQU4sSUFBZ0IsQ0FBakIsSUFBc0IsQ0FBN0IsSUFBa0MsU0FBbEM7QUFDQSxPQUFLLElBQUksQ0FBVCxFQUFZLElBQUksT0FBTyxNQUF2QixFQUErQixLQUFLLENBQXBDLEVBQXVDO0FBQ3JDLFdBQU8sQ0FBUCxJQUFZLENBQVo7QUFDRDtBQUNELE1BQUksVUFBVSxNQUFNLE1BQU4sR0FBZSxDQUE3QjtBQUNBLE9BQUssSUFBSSxDQUFULEVBQVksSUFBSSxPQUFoQixFQUF5QixLQUFLLENBQTlCLEVBQWlDO0FBQy9CLFdBQU8sS0FBSyxDQUFaLEtBQWtCLENBQUMsTUFBTSxVQUFOLENBQWlCLElBQUksQ0FBckIsSUFBMEIsSUFBM0IsS0FBcUMsSUFBSSxFQUEzRDtBQUNEO0FBQ0QsU0FBTyxNQUFQO0FBQ0Q7O0FBRUQ7OztBQUdBLFNBQVMsT0FBVCxDQUFpQixDQUFqQixFQUFvQjtBQUNsQixTQUFPLFVBQVUsUUFBUSxVQUFVLENBQVYsQ0FBUixFQUFzQixFQUFFLE1BQUYsR0FBVyxDQUFqQyxDQUFWLENBQVA7QUFDRDs7QUFFRDs7O0FBR0EsU0FBUyxXQUFULENBQXFCLEdBQXJCLEVBQTBCLElBQTFCLEVBQWdDO0FBQzlCLE1BQUksQ0FBSjtBQUNBLE1BQUksT0FBTyxVQUFVLEdBQVYsQ0FBWDtBQUNBLE1BQUksT0FBTyxFQUFYO0FBQ0EsTUFBSSxPQUFPLEVBQVg7QUFDQSxNQUFJLElBQUo7QUFDQSxPQUFLLEVBQUwsSUFBVyxLQUFLLEVBQUwsSUFBVyxTQUF0QjtBQUNBLE1BQUksS0FBSyxNQUFMLEdBQWMsRUFBbEIsRUFBc0I7QUFDcEIsV0FBTyxRQUFRLElBQVIsRUFBYyxJQUFJLE1BQUosR0FBYSxDQUEzQixDQUFQO0FBQ0Q7QUFDRCxPQUFLLElBQUksQ0FBVCxFQUFZLElBQUksRUFBaEIsRUFBb0IsS0FBSyxDQUF6QixFQUE0QjtBQUMxQixTQUFLLENBQUwsSUFBVSxLQUFLLENBQUwsSUFBVSxVQUFwQjtBQUNBLFNBQUssQ0FBTCxJQUFVLEtBQUssQ0FBTCxJQUFVLFVBQXBCO0FBQ0Q7QUFDRCxTQUFPLFFBQVEsS0FBSyxNQUFMLENBQVksVUFBVSxJQUFWLENBQVosQ0FBUixFQUFzQyxNQUFNLEtBQUssTUFBTCxHQUFjLENBQTFELENBQVA7QUFDQSxTQUFPLFVBQVUsUUFBUSxLQUFLLE1BQUwsQ0FBWSxJQUFaLENBQVIsRUFBMkIsTUFBTSxHQUFqQyxDQUFWLENBQVA7QUFDRDs7QUFFRDs7O0FBR0EsU0FBUyxRQUFULENBQWtCLEtBQWxCLEVBQXlCO0FBQ3ZCLE1BQUksU0FBUyxrQkFBYjtBQUNBLE1BQUksU0FBUyxFQUFiO0FBQ0EsTUFBSSxDQUFKO0FBQ0EsTUFBSSxDQUFKO0FBQ0EsT0FBSyxJQUFJLENBQVQsRUFBWSxJQUFJLE1BQU0sTUFBdEIsRUFBOEIsS0FBSyxDQUFuQyxFQUFzQztBQUNwQyxRQUFJLE1BQU0sVUFBTixDQUFpQixDQUFqQixDQUFKO0FBQ0EsY0FBVSxPQUFPLE1BQVAsQ0FBZSxNQUFNLENBQVAsR0FBWSxJQUExQixJQUFrQyxPQUFPLE1BQVAsQ0FBYyxJQUFJLElBQWxCLENBQTVDO0FBQ0Q7QUFDRCxTQUFPLE1BQVA7QUFDRDs7QUFFRDs7O0FBR0EsU0FBUyxZQUFULENBQXNCLEtBQXRCLEVBQTZCO0FBQzNCLFNBQU8sU0FBUyxtQkFBbUIsS0FBbkIsQ0FBVCxDQUFQO0FBQ0Q7O0FBRUQ7OztBQUdBLFNBQVMsTUFBVCxDQUFnQixDQUFoQixFQUFtQjtBQUNqQixTQUFPLFFBQVEsYUFBYSxDQUFiLENBQVIsQ0FBUDtBQUNEO0FBQ0QsU0FBUyxNQUFULENBQWdCLENBQWhCLEVBQW1CO0FBQ2pCLFNBQU8sU0FBUyxPQUFPLENBQVAsQ0FBVCxDQUFQO0FBQ0Q7QUFDRCxTQUFTLFVBQVQsQ0FBb0IsQ0FBcEIsRUFBdUIsQ0FBdkIsRUFBMEI7QUFDeEIsU0FBTyxZQUFZLGFBQWEsQ0FBYixDQUFaLEVBQTZCLGFBQWEsQ0FBYixDQUE3QixDQUFQO0FBQ0Q7QUFDRCxTQUFTLFVBQVQsQ0FBb0IsQ0FBcEIsRUFBdUIsQ0FBdkIsRUFBMEI7QUFDeEIsU0FBTyxTQUFTLFdBQVcsQ0FBWCxFQUFjLENBQWQsQ0FBVCxDQUFQO0FBQ0Q7O0FBRUQsU0FBUyxHQUFULENBQWEsTUFBYixFQUFxQixHQUFyQixFQUEwQixHQUExQixFQUErQjtBQUM3QixNQUFJLENBQUMsR0FBTCxFQUFVO0FBQ1IsUUFBSSxDQUFDLEdBQUwsRUFBVTtBQUNSLGFBQU8sT0FBTyxNQUFQLENBQVA7QUFDRDtBQUNELFdBQU8sT0FBTyxNQUFQLENBQVA7QUFDRDtBQUNELE1BQUksQ0FBQyxHQUFMLEVBQVU7QUFDUixXQUFPLFdBQVcsR0FBWCxFQUFnQixNQUFoQixDQUFQO0FBQ0Q7QUFDRCxTQUFPLFdBQVcsR0FBWCxFQUFnQixNQUFoQixDQUFQO0FBQ0Q7O0FBRUQsT0FBTyxPQUFQLEdBQWlCLEdBQWpCOzs7QUN6UUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7OztBQUVBLElBQUksV0FBVyxRQUFRLFVBQVIsQ0FBZjtBQUNBLElBQUksT0FBTyxRQUFRLFFBQVIsQ0FBWDs7QUFFQSxRQUFRLEtBQVIsR0FBZ0IsUUFBaEI7QUFDQSxRQUFRLE9BQVIsR0FBa0IsVUFBbEI7QUFDQSxRQUFRLGFBQVIsR0FBd0IsZ0JBQXhCO0FBQ0EsUUFBUSxNQUFSLEdBQWlCLFNBQWpCOztBQUVBLFFBQVEsR0FBUixHQUFjLEdBQWQ7O0FBRUEsU0FBUyxHQUFULEdBQWU7QUFDYixPQUFLLFFBQUwsR0FBZ0IsSUFBaEI7QUFDQSxPQUFLLE9BQUwsR0FBZSxJQUFmO0FBQ0EsT0FBSyxJQUFMLEdBQVksSUFBWjtBQUNBLE9BQUssSUFBTCxHQUFZLElBQVo7QUFDQSxPQUFLLElBQUwsR0FBWSxJQUFaO0FBQ0EsT0FBSyxRQUFMLEdBQWdCLElBQWhCO0FBQ0EsT0FBSyxJQUFMLEdBQVksSUFBWjtBQUNBLE9BQUssTUFBTCxHQUFjLElBQWQ7QUFDQSxPQUFLLEtBQUwsR0FBYSxJQUFiO0FBQ0EsT0FBSyxRQUFMLEdBQWdCLElBQWhCO0FBQ0EsT0FBSyxJQUFMLEdBQVksSUFBWjtBQUNBLE9BQUssSUFBTCxHQUFZLElBQVo7QUFDRDs7QUFFRDs7QUFFQTtBQUNBO0FBQ0EsSUFBSSxrQkFBa0IsbUJBQXRCO0FBQUEsSUFDSSxjQUFjLFVBRGxCOzs7QUFHSTtBQUNBLG9CQUFvQixvQ0FKeEI7OztBQU1JO0FBQ0E7QUFDQSxTQUFTLENBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxHQUFYLEVBQWdCLEdBQWhCLEVBQXFCLEdBQXJCLEVBQTBCLElBQTFCLEVBQWdDLElBQWhDLEVBQXNDLElBQXRDLENBUmI7OztBQVVJO0FBQ0EsU0FBUyxDQUFDLEdBQUQsRUFBTSxHQUFOLEVBQVcsR0FBWCxFQUFnQixJQUFoQixFQUFzQixHQUF0QixFQUEyQixHQUEzQixFQUFnQyxNQUFoQyxDQUF1QyxNQUF2QyxDQVhiOzs7QUFhSTtBQUNBLGFBQWEsQ0FBQyxJQUFELEVBQU8sTUFBUCxDQUFjLE1BQWQsQ0FkakI7O0FBZUk7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLENBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxHQUFYLEVBQWdCLEdBQWhCLEVBQXFCLEdBQXJCLEVBQTBCLE1BQTFCLENBQWlDLFVBQWpDLENBbkJuQjtBQUFBLElBb0JJLGtCQUFrQixDQUFDLEdBQUQsRUFBTSxHQUFOLEVBQVcsR0FBWCxDQXBCdEI7QUFBQSxJQXFCSSxpQkFBaUIsR0FyQnJCO0FBQUEsSUFzQkksc0JBQXNCLHdCQXRCMUI7QUFBQSxJQXVCSSxvQkFBb0IsOEJBdkJ4Qjs7QUF3Qkk7QUFDQSxpQkFBaUI7QUFDZixnQkFBYyxJQURDO0FBRWYsaUJBQWU7QUFGQSxDQXpCckI7O0FBNkJJO0FBQ0EsbUJBQW1CO0FBQ2pCLGdCQUFjLElBREc7QUFFakIsaUJBQWU7QUFGRSxDQTlCdkI7O0FBa0NJO0FBQ0Esa0JBQWtCO0FBQ2hCLFVBQVEsSUFEUTtBQUVoQixXQUFTLElBRk87QUFHaEIsU0FBTyxJQUhTO0FBSWhCLFlBQVUsSUFKTTtBQUtoQixVQUFRLElBTFE7QUFNaEIsV0FBUyxJQU5PO0FBT2hCLFlBQVUsSUFQTTtBQVFoQixVQUFRLElBUlE7QUFTaEIsYUFBVyxJQVRLO0FBVWhCLFdBQVM7QUFWTyxDQW5DdEI7QUFBQSxJQStDSSxjQUFjLFFBQVEsYUFBUixDQS9DbEI7O0FBaURBLFNBQVMsUUFBVCxDQUFrQixHQUFsQixFQUF1QixnQkFBdkIsRUFBeUMsaUJBQXpDLEVBQTREO0FBQzFELE1BQUksT0FBTyxLQUFLLFFBQUwsQ0FBYyxHQUFkLENBQVAsSUFBNkIsZUFBZSxHQUFoRCxFQUFxRCxPQUFPLEdBQVA7O0FBRXJELE1BQUksSUFBSSxJQUFJLEdBQUosRUFBUjtBQUNBLElBQUUsS0FBRixDQUFRLEdBQVIsRUFBYSxnQkFBYixFQUErQixpQkFBL0I7QUFDQSxTQUFPLENBQVA7QUFDRDs7QUFFRCxJQUFJLFNBQUosQ0FBYyxLQUFkLEdBQXNCLFVBQVMsR0FBVCxFQUFjLGdCQUFkLEVBQWdDLGlCQUFoQyxFQUFtRDtBQUN2RSxNQUFJLENBQUMsS0FBSyxRQUFMLENBQWMsR0FBZCxDQUFMLEVBQXlCO0FBQ3ZCLFVBQU0sSUFBSSxTQUFKLENBQWMsbURBQWtELEdBQWxELHlDQUFrRCxHQUFsRCxFQUFkLENBQU47QUFDRDs7QUFFRDtBQUNBO0FBQ0E7QUFDQSxNQUFJLGFBQWEsSUFBSSxPQUFKLENBQVksR0FBWixDQUFqQjtBQUFBLE1BQ0ksV0FDSyxlQUFlLENBQUMsQ0FBaEIsSUFBcUIsYUFBYSxJQUFJLE9BQUosQ0FBWSxHQUFaLENBQW5DLEdBQXVELEdBQXZELEdBQTZELEdBRnJFO0FBQUEsTUFHSSxTQUFTLElBQUksS0FBSixDQUFVLFFBQVYsQ0FIYjtBQUFBLE1BSUksYUFBYSxLQUpqQjtBQUtBLFNBQU8sQ0FBUCxJQUFZLE9BQU8sQ0FBUCxFQUFVLE9BQVYsQ0FBa0IsVUFBbEIsRUFBOEIsR0FBOUIsQ0FBWjtBQUNBLFFBQU0sT0FBTyxJQUFQLENBQVksUUFBWixDQUFOOztBQUVBLE1BQUksT0FBTyxHQUFYOztBQUVBO0FBQ0E7QUFDQSxTQUFPLEtBQUssSUFBTCxFQUFQOztBQUVBLE1BQUksQ0FBQyxpQkFBRCxJQUFzQixJQUFJLEtBQUosQ0FBVSxHQUFWLEVBQWUsTUFBZixLQUEwQixDQUFwRCxFQUF1RDtBQUNyRDtBQUNBLFFBQUksYUFBYSxrQkFBa0IsSUFBbEIsQ0FBdUIsSUFBdkIsQ0FBakI7QUFDQSxRQUFJLFVBQUosRUFBZ0I7QUFDZCxXQUFLLElBQUwsR0FBWSxJQUFaO0FBQ0EsV0FBSyxJQUFMLEdBQVksSUFBWjtBQUNBLFdBQUssUUFBTCxHQUFnQixXQUFXLENBQVgsQ0FBaEI7QUFDQSxVQUFJLFdBQVcsQ0FBWCxDQUFKLEVBQW1CO0FBQ2pCLGFBQUssTUFBTCxHQUFjLFdBQVcsQ0FBWCxDQUFkO0FBQ0EsWUFBSSxnQkFBSixFQUFzQjtBQUNwQixlQUFLLEtBQUwsR0FBYSxZQUFZLEtBQVosQ0FBa0IsS0FBSyxNQUFMLENBQVksTUFBWixDQUFtQixDQUFuQixDQUFsQixDQUFiO0FBQ0QsU0FGRCxNQUVPO0FBQ0wsZUFBSyxLQUFMLEdBQWEsS0FBSyxNQUFMLENBQVksTUFBWixDQUFtQixDQUFuQixDQUFiO0FBQ0Q7QUFDRixPQVBELE1BT08sSUFBSSxnQkFBSixFQUFzQjtBQUMzQixhQUFLLE1BQUwsR0FBYyxFQUFkO0FBQ0EsYUFBSyxLQUFMLEdBQWEsRUFBYjtBQUNEO0FBQ0QsYUFBTyxJQUFQO0FBQ0Q7QUFDRjs7QUFFRCxNQUFJLFFBQVEsZ0JBQWdCLElBQWhCLENBQXFCLElBQXJCLENBQVo7QUFDQSxNQUFJLEtBQUosRUFBVztBQUNULFlBQVEsTUFBTSxDQUFOLENBQVI7QUFDQSxRQUFJLGFBQWEsTUFBTSxXQUFOLEVBQWpCO0FBQ0EsU0FBSyxRQUFMLEdBQWdCLFVBQWhCO0FBQ0EsV0FBTyxLQUFLLE1BQUwsQ0FBWSxNQUFNLE1BQWxCLENBQVA7QUFDRDs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQUkscUJBQXFCLEtBQXJCLElBQThCLEtBQUssS0FBTCxDQUFXLHNCQUFYLENBQWxDLEVBQXNFO0FBQ3BFLFFBQUksVUFBVSxLQUFLLE1BQUwsQ0FBWSxDQUFaLEVBQWUsQ0FBZixNQUFzQixJQUFwQztBQUNBLFFBQUksV0FBVyxFQUFFLFNBQVMsaUJBQWlCLEtBQWpCLENBQVgsQ0FBZixFQUFvRDtBQUNsRCxhQUFPLEtBQUssTUFBTCxDQUFZLENBQVosQ0FBUDtBQUNBLFdBQUssT0FBTCxHQUFlLElBQWY7QUFDRDtBQUNGOztBQUVELE1BQUksQ0FBQyxpQkFBaUIsS0FBakIsQ0FBRCxLQUNDLFdBQVksU0FBUyxDQUFDLGdCQUFnQixLQUFoQixDQUR2QixDQUFKLEVBQ3FEOztBQUVuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSxRQUFJLFVBQVUsQ0FBQyxDQUFmO0FBQ0EsU0FBSyxJQUFJLElBQUksQ0FBYixFQUFnQixJQUFJLGdCQUFnQixNQUFwQyxFQUE0QyxHQUE1QyxFQUFpRDtBQUMvQyxVQUFJLE1BQU0sS0FBSyxPQUFMLENBQWEsZ0JBQWdCLENBQWhCLENBQWIsQ0FBVjtBQUNBLFVBQUksUUFBUSxDQUFDLENBQVQsS0FBZSxZQUFZLENBQUMsQ0FBYixJQUFrQixNQUFNLE9BQXZDLENBQUosRUFDRSxVQUFVLEdBQVY7QUFDSDs7QUFFRDtBQUNBO0FBQ0EsUUFBSSxJQUFKLEVBQVUsTUFBVjtBQUNBLFFBQUksWUFBWSxDQUFDLENBQWpCLEVBQW9CO0FBQ2xCO0FBQ0EsZUFBUyxLQUFLLFdBQUwsQ0FBaUIsR0FBakIsQ0FBVDtBQUNELEtBSEQsTUFHTztBQUNMO0FBQ0E7QUFDQSxlQUFTLEtBQUssV0FBTCxDQUFpQixHQUFqQixFQUFzQixPQUF0QixDQUFUO0FBQ0Q7O0FBRUQ7QUFDQTtBQUNBLFFBQUksV0FBVyxDQUFDLENBQWhCLEVBQW1CO0FBQ2pCLGFBQU8sS0FBSyxLQUFMLENBQVcsQ0FBWCxFQUFjLE1BQWQsQ0FBUDtBQUNBLGFBQU8sS0FBSyxLQUFMLENBQVcsU0FBUyxDQUFwQixDQUFQO0FBQ0EsV0FBSyxJQUFMLEdBQVksbUJBQW1CLElBQW5CLENBQVo7QUFDRDs7QUFFRDtBQUNBLGNBQVUsQ0FBQyxDQUFYO0FBQ0EsU0FBSyxJQUFJLElBQUksQ0FBYixFQUFnQixJQUFJLGFBQWEsTUFBakMsRUFBeUMsR0FBekMsRUFBOEM7QUFDNUMsVUFBSSxNQUFNLEtBQUssT0FBTCxDQUFhLGFBQWEsQ0FBYixDQUFiLENBQVY7QUFDQSxVQUFJLFFBQVEsQ0FBQyxDQUFULEtBQWUsWUFBWSxDQUFDLENBQWIsSUFBa0IsTUFBTSxPQUF2QyxDQUFKLEVBQ0UsVUFBVSxHQUFWO0FBQ0g7QUFDRDtBQUNBLFFBQUksWUFBWSxDQUFDLENBQWpCLEVBQ0UsVUFBVSxLQUFLLE1BQWY7O0FBRUYsU0FBSyxJQUFMLEdBQVksS0FBSyxLQUFMLENBQVcsQ0FBWCxFQUFjLE9BQWQsQ0FBWjtBQUNBLFdBQU8sS0FBSyxLQUFMLENBQVcsT0FBWCxDQUFQOztBQUVBO0FBQ0EsU0FBSyxTQUFMOztBQUVBO0FBQ0E7QUFDQSxTQUFLLFFBQUwsR0FBZ0IsS0FBSyxRQUFMLElBQWlCLEVBQWpDOztBQUVBO0FBQ0E7QUFDQSxRQUFJLGVBQWUsS0FBSyxRQUFMLENBQWMsQ0FBZCxNQUFxQixHQUFyQixJQUNmLEtBQUssUUFBTCxDQUFjLEtBQUssUUFBTCxDQUFjLE1BQWQsR0FBdUIsQ0FBckMsTUFBNEMsR0FEaEQ7O0FBR0E7QUFDQSxRQUFJLENBQUMsWUFBTCxFQUFtQjtBQUNqQixVQUFJLFlBQVksS0FBSyxRQUFMLENBQWMsS0FBZCxDQUFvQixJQUFwQixDQUFoQjtBQUNBLFdBQUssSUFBSSxJQUFJLENBQVIsRUFBVyxJQUFJLFVBQVUsTUFBOUIsRUFBc0MsSUFBSSxDQUExQyxFQUE2QyxHQUE3QyxFQUFrRDtBQUNoRCxZQUFJLE9BQU8sVUFBVSxDQUFWLENBQVg7QUFDQSxZQUFJLENBQUMsSUFBTCxFQUFXO0FBQ1gsWUFBSSxDQUFDLEtBQUssS0FBTCxDQUFXLG1CQUFYLENBQUwsRUFBc0M7QUFDcEMsY0FBSSxVQUFVLEVBQWQ7QUFDQSxlQUFLLElBQUksSUFBSSxDQUFSLEVBQVcsSUFBSSxLQUFLLE1BQXpCLEVBQWlDLElBQUksQ0FBckMsRUFBd0MsR0FBeEMsRUFBNkM7QUFDM0MsZ0JBQUksS0FBSyxVQUFMLENBQWdCLENBQWhCLElBQXFCLEdBQXpCLEVBQThCO0FBQzVCO0FBQ0E7QUFDQTtBQUNBLHlCQUFXLEdBQVg7QUFDRCxhQUxELE1BS087QUFDTCx5QkFBVyxLQUFLLENBQUwsQ0FBWDtBQUNEO0FBQ0Y7QUFDRDtBQUNBLGNBQUksQ0FBQyxRQUFRLEtBQVIsQ0FBYyxtQkFBZCxDQUFMLEVBQXlDO0FBQ3ZDLGdCQUFJLGFBQWEsVUFBVSxLQUFWLENBQWdCLENBQWhCLEVBQW1CLENBQW5CLENBQWpCO0FBQ0EsZ0JBQUksVUFBVSxVQUFVLEtBQVYsQ0FBZ0IsSUFBSSxDQUFwQixDQUFkO0FBQ0EsZ0JBQUksTUFBTSxLQUFLLEtBQUwsQ0FBVyxpQkFBWCxDQUFWO0FBQ0EsZ0JBQUksR0FBSixFQUFTO0FBQ1AseUJBQVcsSUFBWCxDQUFnQixJQUFJLENBQUosQ0FBaEI7QUFDQSxzQkFBUSxPQUFSLENBQWdCLElBQUksQ0FBSixDQUFoQjtBQUNEO0FBQ0QsZ0JBQUksUUFBUSxNQUFaLEVBQW9CO0FBQ2xCLHFCQUFPLE1BQU0sUUFBUSxJQUFSLENBQWEsR0FBYixDQUFOLEdBQTBCLElBQWpDO0FBQ0Q7QUFDRCxpQkFBSyxRQUFMLEdBQWdCLFdBQVcsSUFBWCxDQUFnQixHQUFoQixDQUFoQjtBQUNBO0FBQ0Q7QUFDRjtBQUNGO0FBQ0Y7O0FBRUQsUUFBSSxLQUFLLFFBQUwsQ0FBYyxNQUFkLEdBQXVCLGNBQTNCLEVBQTJDO0FBQ3pDLFdBQUssUUFBTCxHQUFnQixFQUFoQjtBQUNELEtBRkQsTUFFTztBQUNMO0FBQ0EsV0FBSyxRQUFMLEdBQWdCLEtBQUssUUFBTCxDQUFjLFdBQWQsRUFBaEI7QUFDRDs7QUFFRCxRQUFJLENBQUMsWUFBTCxFQUFtQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQUssUUFBTCxHQUFnQixTQUFTLE9BQVQsQ0FBaUIsS0FBSyxRQUF0QixDQUFoQjtBQUNEOztBQUVELFFBQUksSUFBSSxLQUFLLElBQUwsR0FBWSxNQUFNLEtBQUssSUFBdkIsR0FBOEIsRUFBdEM7QUFDQSxRQUFJLElBQUksS0FBSyxRQUFMLElBQWlCLEVBQXpCO0FBQ0EsU0FBSyxJQUFMLEdBQVksSUFBSSxDQUFoQjtBQUNBLFNBQUssSUFBTCxJQUFhLEtBQUssSUFBbEI7O0FBRUE7QUFDQTtBQUNBLFFBQUksWUFBSixFQUFrQjtBQUNoQixXQUFLLFFBQUwsR0FBZ0IsS0FBSyxRQUFMLENBQWMsTUFBZCxDQUFxQixDQUFyQixFQUF3QixLQUFLLFFBQUwsQ0FBYyxNQUFkLEdBQXVCLENBQS9DLENBQWhCO0FBQ0EsVUFBSSxLQUFLLENBQUwsTUFBWSxHQUFoQixFQUFxQjtBQUNuQixlQUFPLE1BQU0sSUFBYjtBQUNEO0FBQ0Y7QUFDRjs7QUFFRDtBQUNBO0FBQ0EsTUFBSSxDQUFDLGVBQWUsVUFBZixDQUFMLEVBQWlDOztBQUUvQjtBQUNBO0FBQ0E7QUFDQSxTQUFLLElBQUksSUFBSSxDQUFSLEVBQVcsSUFBSSxXQUFXLE1BQS9CLEVBQXVDLElBQUksQ0FBM0MsRUFBOEMsR0FBOUMsRUFBbUQ7QUFDakQsVUFBSSxLQUFLLFdBQVcsQ0FBWCxDQUFUO0FBQ0EsVUFBSSxLQUFLLE9BQUwsQ0FBYSxFQUFiLE1BQXFCLENBQUMsQ0FBMUIsRUFDRTtBQUNGLFVBQUksTUFBTSxtQkFBbUIsRUFBbkIsQ0FBVjtBQUNBLFVBQUksUUFBUSxFQUFaLEVBQWdCO0FBQ2QsY0FBTSxPQUFPLEVBQVAsQ0FBTjtBQUNEO0FBQ0QsYUFBTyxLQUFLLEtBQUwsQ0FBVyxFQUFYLEVBQWUsSUFBZixDQUFvQixHQUFwQixDQUFQO0FBQ0Q7QUFDRjs7QUFHRDtBQUNBLE1BQUksT0FBTyxLQUFLLE9BQUwsQ0FBYSxHQUFiLENBQVg7QUFDQSxNQUFJLFNBQVMsQ0FBQyxDQUFkLEVBQWlCO0FBQ2Y7QUFDQSxTQUFLLElBQUwsR0FBWSxLQUFLLE1BQUwsQ0FBWSxJQUFaLENBQVo7QUFDQSxXQUFPLEtBQUssS0FBTCxDQUFXLENBQVgsRUFBYyxJQUFkLENBQVA7QUFDRDtBQUNELE1BQUksS0FBSyxLQUFLLE9BQUwsQ0FBYSxHQUFiLENBQVQ7QUFDQSxNQUFJLE9BQU8sQ0FBQyxDQUFaLEVBQWU7QUFDYixTQUFLLE1BQUwsR0FBYyxLQUFLLE1BQUwsQ0FBWSxFQUFaLENBQWQ7QUFDQSxTQUFLLEtBQUwsR0FBYSxLQUFLLE1BQUwsQ0FBWSxLQUFLLENBQWpCLENBQWI7QUFDQSxRQUFJLGdCQUFKLEVBQXNCO0FBQ3BCLFdBQUssS0FBTCxHQUFhLFlBQVksS0FBWixDQUFrQixLQUFLLEtBQXZCLENBQWI7QUFDRDtBQUNELFdBQU8sS0FBSyxLQUFMLENBQVcsQ0FBWCxFQUFjLEVBQWQsQ0FBUDtBQUNELEdBUEQsTUFPTyxJQUFJLGdCQUFKLEVBQXNCO0FBQzNCO0FBQ0EsU0FBSyxNQUFMLEdBQWMsRUFBZDtBQUNBLFNBQUssS0FBTCxHQUFhLEVBQWI7QUFDRDtBQUNELE1BQUksSUFBSixFQUFVLEtBQUssUUFBTCxHQUFnQixJQUFoQjtBQUNWLE1BQUksZ0JBQWdCLFVBQWhCLEtBQ0EsS0FBSyxRQURMLElBQ2lCLENBQUMsS0FBSyxRQUQzQixFQUNxQztBQUNuQyxTQUFLLFFBQUwsR0FBZ0IsR0FBaEI7QUFDRDs7QUFFRDtBQUNBLE1BQUksS0FBSyxRQUFMLElBQWlCLEtBQUssTUFBMUIsRUFBa0M7QUFDaEMsUUFBSSxJQUFJLEtBQUssUUFBTCxJQUFpQixFQUF6QjtBQUNBLFFBQUksSUFBSSxLQUFLLE1BQUwsSUFBZSxFQUF2QjtBQUNBLFNBQUssSUFBTCxHQUFZLElBQUksQ0FBaEI7QUFDRDs7QUFFRDtBQUNBLE9BQUssSUFBTCxHQUFZLEtBQUssTUFBTCxFQUFaO0FBQ0EsU0FBTyxJQUFQO0FBQ0QsQ0FuUUQ7O0FBcVFBO0FBQ0EsU0FBUyxTQUFULENBQW1CLEdBQW5CLEVBQXdCO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBSSxLQUFLLFFBQUwsQ0FBYyxHQUFkLENBQUosRUFBd0IsTUFBTSxTQUFTLEdBQVQsQ0FBTjtBQUN4QixNQUFJLEVBQUUsZUFBZSxHQUFqQixDQUFKLEVBQTJCLE9BQU8sSUFBSSxTQUFKLENBQWMsTUFBZCxDQUFxQixJQUFyQixDQUEwQixHQUExQixDQUFQO0FBQzNCLFNBQU8sSUFBSSxNQUFKLEVBQVA7QUFDRDs7QUFFRCxJQUFJLFNBQUosQ0FBYyxNQUFkLEdBQXVCLFlBQVc7QUFDaEMsTUFBSSxPQUFPLEtBQUssSUFBTCxJQUFhLEVBQXhCO0FBQ0EsTUFBSSxJQUFKLEVBQVU7QUFDUixXQUFPLG1CQUFtQixJQUFuQixDQUFQO0FBQ0EsV0FBTyxLQUFLLE9BQUwsQ0FBYSxNQUFiLEVBQXFCLEdBQXJCLENBQVA7QUFDQSxZQUFRLEdBQVI7QUFDRDs7QUFFRCxNQUFJLFdBQVcsS0FBSyxRQUFMLElBQWlCLEVBQWhDO0FBQUEsTUFDSSxXQUFXLEtBQUssUUFBTCxJQUFpQixFQURoQztBQUFBLE1BRUksT0FBTyxLQUFLLElBQUwsSUFBYSxFQUZ4QjtBQUFBLE1BR0ksT0FBTyxLQUhYO0FBQUEsTUFJSSxRQUFRLEVBSlo7O0FBTUEsTUFBSSxLQUFLLElBQVQsRUFBZTtBQUNiLFdBQU8sT0FBTyxLQUFLLElBQW5CO0FBQ0QsR0FGRCxNQUVPLElBQUksS0FBSyxRQUFULEVBQW1CO0FBQ3hCLFdBQU8sUUFBUSxLQUFLLFFBQUwsQ0FBYyxPQUFkLENBQXNCLEdBQXRCLE1BQStCLENBQUMsQ0FBaEMsR0FDWCxLQUFLLFFBRE0sR0FFWCxNQUFNLEtBQUssUUFBWCxHQUFzQixHQUZuQixDQUFQO0FBR0EsUUFBSSxLQUFLLElBQVQsRUFBZTtBQUNiLGNBQVEsTUFBTSxLQUFLLElBQW5CO0FBQ0Q7QUFDRjs7QUFFRCxNQUFJLEtBQUssS0FBTCxJQUNBLEtBQUssUUFBTCxDQUFjLEtBQUssS0FBbkIsQ0FEQSxJQUVBLE9BQU8sSUFBUCxDQUFZLEtBQUssS0FBakIsRUFBd0IsTUFGNUIsRUFFb0M7QUFDbEMsWUFBUSxZQUFZLFNBQVosQ0FBc0IsS0FBSyxLQUEzQixDQUFSO0FBQ0Q7O0FBRUQsTUFBSSxTQUFTLEtBQUssTUFBTCxJQUFnQixTQUFVLE1BQU0sS0FBaEMsSUFBMkMsRUFBeEQ7O0FBRUEsTUFBSSxZQUFZLFNBQVMsTUFBVCxDQUFnQixDQUFDLENBQWpCLE1BQXdCLEdBQXhDLEVBQTZDLFlBQVksR0FBWjs7QUFFN0M7QUFDQTtBQUNBLE1BQUksS0FBSyxPQUFMLElBQ0EsQ0FBQyxDQUFDLFFBQUQsSUFBYSxnQkFBZ0IsUUFBaEIsQ0FBZCxLQUE0QyxTQUFTLEtBRHpELEVBQ2dFO0FBQzlELFdBQU8sUUFBUSxRQUFRLEVBQWhCLENBQVA7QUFDQSxRQUFJLFlBQVksU0FBUyxNQUFULENBQWdCLENBQWhCLE1BQXVCLEdBQXZDLEVBQTRDLFdBQVcsTUFBTSxRQUFqQjtBQUM3QyxHQUpELE1BSU8sSUFBSSxDQUFDLElBQUwsRUFBVztBQUNoQixXQUFPLEVBQVA7QUFDRDs7QUFFRCxNQUFJLFFBQVEsS0FBSyxNQUFMLENBQVksQ0FBWixNQUFtQixHQUEvQixFQUFvQyxPQUFPLE1BQU0sSUFBYjtBQUNwQyxNQUFJLFVBQVUsT0FBTyxNQUFQLENBQWMsQ0FBZCxNQUFxQixHQUFuQyxFQUF3QyxTQUFTLE1BQU0sTUFBZjs7QUFFeEMsYUFBVyxTQUFTLE9BQVQsQ0FBaUIsT0FBakIsRUFBMEIsVUFBUyxLQUFULEVBQWdCO0FBQ25ELFdBQU8sbUJBQW1CLEtBQW5CLENBQVA7QUFDRCxHQUZVLENBQVg7QUFHQSxXQUFTLE9BQU8sT0FBUCxDQUFlLEdBQWYsRUFBb0IsS0FBcEIsQ0FBVDs7QUFFQSxTQUFPLFdBQVcsSUFBWCxHQUFrQixRQUFsQixHQUE2QixNQUE3QixHQUFzQyxJQUE3QztBQUNELENBdEREOztBQXdEQSxTQUFTLFVBQVQsQ0FBb0IsTUFBcEIsRUFBNEIsUUFBNUIsRUFBc0M7QUFDcEMsU0FBTyxTQUFTLE1BQVQsRUFBaUIsS0FBakIsRUFBd0IsSUFBeEIsRUFBOEIsT0FBOUIsQ0FBc0MsUUFBdEMsQ0FBUDtBQUNEOztBQUVELElBQUksU0FBSixDQUFjLE9BQWQsR0FBd0IsVUFBUyxRQUFULEVBQW1CO0FBQ3pDLFNBQU8sS0FBSyxhQUFMLENBQW1CLFNBQVMsUUFBVCxFQUFtQixLQUFuQixFQUEwQixJQUExQixDQUFuQixFQUFvRCxNQUFwRCxFQUFQO0FBQ0QsQ0FGRDs7QUFJQSxTQUFTLGdCQUFULENBQTBCLE1BQTFCLEVBQWtDLFFBQWxDLEVBQTRDO0FBQzFDLE1BQUksQ0FBQyxNQUFMLEVBQWEsT0FBTyxRQUFQO0FBQ2IsU0FBTyxTQUFTLE1BQVQsRUFBaUIsS0FBakIsRUFBd0IsSUFBeEIsRUFBOEIsYUFBOUIsQ0FBNEMsUUFBNUMsQ0FBUDtBQUNEOztBQUVELElBQUksU0FBSixDQUFjLGFBQWQsR0FBOEIsVUFBUyxRQUFULEVBQW1CO0FBQy9DLE1BQUksS0FBSyxRQUFMLENBQWMsUUFBZCxDQUFKLEVBQTZCO0FBQzNCLFFBQUksTUFBTSxJQUFJLEdBQUosRUFBVjtBQUNBLFFBQUksS0FBSixDQUFVLFFBQVYsRUFBb0IsS0FBcEIsRUFBMkIsSUFBM0I7QUFDQSxlQUFXLEdBQVg7QUFDRDs7QUFFRCxNQUFJLFNBQVMsSUFBSSxHQUFKLEVBQWI7QUFDQSxNQUFJLFFBQVEsT0FBTyxJQUFQLENBQVksSUFBWixDQUFaO0FBQ0EsT0FBSyxJQUFJLEtBQUssQ0FBZCxFQUFpQixLQUFLLE1BQU0sTUFBNUIsRUFBb0MsSUFBcEMsRUFBMEM7QUFDeEMsUUFBSSxPQUFPLE1BQU0sRUFBTixDQUFYO0FBQ0EsV0FBTyxJQUFQLElBQWUsS0FBSyxJQUFMLENBQWY7QUFDRDs7QUFFRDtBQUNBO0FBQ0EsU0FBTyxJQUFQLEdBQWMsU0FBUyxJQUF2Qjs7QUFFQTtBQUNBLE1BQUksU0FBUyxJQUFULEtBQWtCLEVBQXRCLEVBQTBCO0FBQ3hCLFdBQU8sSUFBUCxHQUFjLE9BQU8sTUFBUCxFQUFkO0FBQ0EsV0FBTyxNQUFQO0FBQ0Q7O0FBRUQ7QUFDQSxNQUFJLFNBQVMsT0FBVCxJQUFvQixDQUFDLFNBQVMsUUFBbEMsRUFBNEM7QUFDMUM7QUFDQSxRQUFJLFFBQVEsT0FBTyxJQUFQLENBQVksUUFBWixDQUFaO0FBQ0EsU0FBSyxJQUFJLEtBQUssQ0FBZCxFQUFpQixLQUFLLE1BQU0sTUFBNUIsRUFBb0MsSUFBcEMsRUFBMEM7QUFDeEMsVUFBSSxPQUFPLE1BQU0sRUFBTixDQUFYO0FBQ0EsVUFBSSxTQUFTLFVBQWIsRUFDRSxPQUFPLElBQVAsSUFBZSxTQUFTLElBQVQsQ0FBZjtBQUNIOztBQUVEO0FBQ0EsUUFBSSxnQkFBZ0IsT0FBTyxRQUF2QixLQUNBLE9BQU8sUUFEUCxJQUNtQixDQUFDLE9BQU8sUUFEL0IsRUFDeUM7QUFDdkMsYUFBTyxJQUFQLEdBQWMsT0FBTyxRQUFQLEdBQWtCLEdBQWhDO0FBQ0Q7O0FBRUQsV0FBTyxJQUFQLEdBQWMsT0FBTyxNQUFQLEVBQWQ7QUFDQSxXQUFPLE1BQVA7QUFDRDs7QUFFRCxNQUFJLFNBQVMsUUFBVCxJQUFxQixTQUFTLFFBQVQsS0FBc0IsT0FBTyxRQUF0RCxFQUFnRTtBQUM5RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsUUFBSSxDQUFDLGdCQUFnQixTQUFTLFFBQXpCLENBQUwsRUFBeUM7QUFDdkMsVUFBSSxPQUFPLE9BQU8sSUFBUCxDQUFZLFFBQVosQ0FBWDtBQUNBLFdBQUssSUFBSSxJQUFJLENBQWIsRUFBZ0IsSUFBSSxLQUFLLE1BQXpCLEVBQWlDLEdBQWpDLEVBQXNDO0FBQ3BDLFlBQUksSUFBSSxLQUFLLENBQUwsQ0FBUjtBQUNBLGVBQU8sQ0FBUCxJQUFZLFNBQVMsQ0FBVCxDQUFaO0FBQ0Q7QUFDRCxhQUFPLElBQVAsR0FBYyxPQUFPLE1BQVAsRUFBZDtBQUNBLGFBQU8sTUFBUDtBQUNEOztBQUVELFdBQU8sUUFBUCxHQUFrQixTQUFTLFFBQTNCO0FBQ0EsUUFBSSxDQUFDLFNBQVMsSUFBVixJQUFrQixDQUFDLGlCQUFpQixTQUFTLFFBQTFCLENBQXZCLEVBQTREO0FBQzFELFVBQUksVUFBVSxDQUFDLFNBQVMsUUFBVCxJQUFxQixFQUF0QixFQUEwQixLQUExQixDQUFnQyxHQUFoQyxDQUFkO0FBQ0EsYUFBTyxRQUFRLE1BQVIsSUFBa0IsRUFBRSxTQUFTLElBQVQsR0FBZ0IsUUFBUSxLQUFSLEVBQWxCLENBQXpCO0FBQ0EsVUFBSSxDQUFDLFNBQVMsSUFBZCxFQUFvQixTQUFTLElBQVQsR0FBZ0IsRUFBaEI7QUFDcEIsVUFBSSxDQUFDLFNBQVMsUUFBZCxFQUF3QixTQUFTLFFBQVQsR0FBb0IsRUFBcEI7QUFDeEIsVUFBSSxRQUFRLENBQVIsTUFBZSxFQUFuQixFQUF1QixRQUFRLE9BQVIsQ0FBZ0IsRUFBaEI7QUFDdkIsVUFBSSxRQUFRLE1BQVIsR0FBaUIsQ0FBckIsRUFBd0IsUUFBUSxPQUFSLENBQWdCLEVBQWhCO0FBQ3hCLGFBQU8sUUFBUCxHQUFrQixRQUFRLElBQVIsQ0FBYSxHQUFiLENBQWxCO0FBQ0QsS0FSRCxNQVFPO0FBQ0wsYUFBTyxRQUFQLEdBQWtCLFNBQVMsUUFBM0I7QUFDRDtBQUNELFdBQU8sTUFBUCxHQUFnQixTQUFTLE1BQXpCO0FBQ0EsV0FBTyxLQUFQLEdBQWUsU0FBUyxLQUF4QjtBQUNBLFdBQU8sSUFBUCxHQUFjLFNBQVMsSUFBVCxJQUFpQixFQUEvQjtBQUNBLFdBQU8sSUFBUCxHQUFjLFNBQVMsSUFBdkI7QUFDQSxXQUFPLFFBQVAsR0FBa0IsU0FBUyxRQUFULElBQXFCLFNBQVMsSUFBaEQ7QUFDQSxXQUFPLElBQVAsR0FBYyxTQUFTLElBQXZCO0FBQ0E7QUFDQSxRQUFJLE9BQU8sUUFBUCxJQUFtQixPQUFPLE1BQTlCLEVBQXNDO0FBQ3BDLFVBQUksSUFBSSxPQUFPLFFBQVAsSUFBbUIsRUFBM0I7QUFDQSxVQUFJLElBQUksT0FBTyxNQUFQLElBQWlCLEVBQXpCO0FBQ0EsYUFBTyxJQUFQLEdBQWMsSUFBSSxDQUFsQjtBQUNEO0FBQ0QsV0FBTyxPQUFQLEdBQWlCLE9BQU8sT0FBUCxJQUFrQixTQUFTLE9BQTVDO0FBQ0EsV0FBTyxJQUFQLEdBQWMsT0FBTyxNQUFQLEVBQWQ7QUFDQSxXQUFPLE1BQVA7QUFDRDs7QUFFRCxNQUFJLGNBQWUsT0FBTyxRQUFQLElBQW1CLE9BQU8sUUFBUCxDQUFnQixNQUFoQixDQUF1QixDQUF2QixNQUE4QixHQUFwRTtBQUFBLE1BQ0ksV0FDSSxTQUFTLElBQVQsSUFDQSxTQUFTLFFBQVQsSUFBcUIsU0FBUyxRQUFULENBQWtCLE1BQWxCLENBQXlCLENBQXpCLE1BQWdDLEdBSDdEO0FBQUEsTUFLSSxhQUFjLFlBQVksV0FBWixJQUNDLE9BQU8sSUFBUCxJQUFlLFNBQVMsUUFOM0M7QUFBQSxNQU9JLGdCQUFnQixVQVBwQjtBQUFBLE1BUUksVUFBVSxPQUFPLFFBQVAsSUFBbUIsT0FBTyxRQUFQLENBQWdCLEtBQWhCLENBQXNCLEdBQXRCLENBQW5CLElBQWlELEVBUi9EO0FBQUEsTUFTSSxVQUFVLFNBQVMsUUFBVCxJQUFxQixTQUFTLFFBQVQsQ0FBa0IsS0FBbEIsQ0FBd0IsR0FBeEIsQ0FBckIsSUFBcUQsRUFUbkU7QUFBQSxNQVVJLFlBQVksT0FBTyxRQUFQLElBQW1CLENBQUMsZ0JBQWdCLE9BQU8sUUFBdkIsQ0FWcEM7O0FBWUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQUksU0FBSixFQUFlO0FBQ2IsV0FBTyxRQUFQLEdBQWtCLEVBQWxCO0FBQ0EsV0FBTyxJQUFQLEdBQWMsSUFBZDtBQUNBLFFBQUksT0FBTyxJQUFYLEVBQWlCO0FBQ2YsVUFBSSxRQUFRLENBQVIsTUFBZSxFQUFuQixFQUF1QixRQUFRLENBQVIsSUFBYSxPQUFPLElBQXBCLENBQXZCLEtBQ0ssUUFBUSxPQUFSLENBQWdCLE9BQU8sSUFBdkI7QUFDTjtBQUNELFdBQU8sSUFBUCxHQUFjLEVBQWQ7QUFDQSxRQUFJLFNBQVMsUUFBYixFQUF1QjtBQUNyQixlQUFTLFFBQVQsR0FBb0IsSUFBcEI7QUFDQSxlQUFTLElBQVQsR0FBZ0IsSUFBaEI7QUFDQSxVQUFJLFNBQVMsSUFBYixFQUFtQjtBQUNqQixZQUFJLFFBQVEsQ0FBUixNQUFlLEVBQW5CLEVBQXVCLFFBQVEsQ0FBUixJQUFhLFNBQVMsSUFBdEIsQ0FBdkIsS0FDSyxRQUFRLE9BQVIsQ0FBZ0IsU0FBUyxJQUF6QjtBQUNOO0FBQ0QsZUFBUyxJQUFULEdBQWdCLElBQWhCO0FBQ0Q7QUFDRCxpQkFBYSxlQUFlLFFBQVEsQ0FBUixNQUFlLEVBQWYsSUFBcUIsUUFBUSxDQUFSLE1BQWUsRUFBbkQsQ0FBYjtBQUNEOztBQUVELE1BQUksUUFBSixFQUFjO0FBQ1o7QUFDQSxXQUFPLElBQVAsR0FBZSxTQUFTLElBQVQsSUFBaUIsU0FBUyxJQUFULEtBQWtCLEVBQXBDLEdBQ0EsU0FBUyxJQURULEdBQ2dCLE9BQU8sSUFEckM7QUFFQSxXQUFPLFFBQVAsR0FBbUIsU0FBUyxRQUFULElBQXFCLFNBQVMsUUFBVCxLQUFzQixFQUE1QyxHQUNBLFNBQVMsUUFEVCxHQUNvQixPQUFPLFFBRDdDO0FBRUEsV0FBTyxNQUFQLEdBQWdCLFNBQVMsTUFBekI7QUFDQSxXQUFPLEtBQVAsR0FBZSxTQUFTLEtBQXhCO0FBQ0EsY0FBVSxPQUFWO0FBQ0E7QUFDRCxHQVZELE1BVU8sSUFBSSxRQUFRLE1BQVosRUFBb0I7QUFDekI7QUFDQTtBQUNBLFFBQUksQ0FBQyxPQUFMLEVBQWMsVUFBVSxFQUFWO0FBQ2QsWUFBUSxHQUFSO0FBQ0EsY0FBVSxRQUFRLE1BQVIsQ0FBZSxPQUFmLENBQVY7QUFDQSxXQUFPLE1BQVAsR0FBZ0IsU0FBUyxNQUF6QjtBQUNBLFdBQU8sS0FBUCxHQUFlLFNBQVMsS0FBeEI7QUFDRCxHQVJNLE1BUUEsSUFBSSxDQUFDLEtBQUssaUJBQUwsQ0FBdUIsU0FBUyxNQUFoQyxDQUFMLEVBQThDO0FBQ25EO0FBQ0E7QUFDQTtBQUNBLFFBQUksU0FBSixFQUFlO0FBQ2IsYUFBTyxRQUFQLEdBQWtCLE9BQU8sSUFBUCxHQUFjLFFBQVEsS0FBUixFQUFoQztBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQUksYUFBYSxPQUFPLElBQVAsSUFBZSxPQUFPLElBQVAsQ0FBWSxPQUFaLENBQW9CLEdBQXBCLElBQTJCLENBQTFDLEdBQ0EsT0FBTyxJQUFQLENBQVksS0FBWixDQUFrQixHQUFsQixDQURBLEdBQ3lCLEtBRDFDO0FBRUEsVUFBSSxVQUFKLEVBQWdCO0FBQ2QsZUFBTyxJQUFQLEdBQWMsV0FBVyxLQUFYLEVBQWQ7QUFDQSxlQUFPLElBQVAsR0FBYyxPQUFPLFFBQVAsR0FBa0IsV0FBVyxLQUFYLEVBQWhDO0FBQ0Q7QUFDRjtBQUNELFdBQU8sTUFBUCxHQUFnQixTQUFTLE1BQXpCO0FBQ0EsV0FBTyxLQUFQLEdBQWUsU0FBUyxLQUF4QjtBQUNBO0FBQ0EsUUFBSSxDQUFDLEtBQUssTUFBTCxDQUFZLE9BQU8sUUFBbkIsQ0FBRCxJQUFpQyxDQUFDLEtBQUssTUFBTCxDQUFZLE9BQU8sTUFBbkIsQ0FBdEMsRUFBa0U7QUFDaEUsYUFBTyxJQUFQLEdBQWMsQ0FBQyxPQUFPLFFBQVAsR0FBa0IsT0FBTyxRQUF6QixHQUFvQyxFQUFyQyxLQUNDLE9BQU8sTUFBUCxHQUFnQixPQUFPLE1BQXZCLEdBQWdDLEVBRGpDLENBQWQ7QUFFRDtBQUNELFdBQU8sSUFBUCxHQUFjLE9BQU8sTUFBUCxFQUFkO0FBQ0EsV0FBTyxNQUFQO0FBQ0Q7O0FBRUQsTUFBSSxDQUFDLFFBQVEsTUFBYixFQUFxQjtBQUNuQjtBQUNBO0FBQ0EsV0FBTyxRQUFQLEdBQWtCLElBQWxCO0FBQ0E7QUFDQSxRQUFJLE9BQU8sTUFBWCxFQUFtQjtBQUNqQixhQUFPLElBQVAsR0FBYyxNQUFNLE9BQU8sTUFBM0I7QUFDRCxLQUZELE1BRU87QUFDTCxhQUFPLElBQVAsR0FBYyxJQUFkO0FBQ0Q7QUFDRCxXQUFPLElBQVAsR0FBYyxPQUFPLE1BQVAsRUFBZDtBQUNBLFdBQU8sTUFBUDtBQUNEOztBQUVEO0FBQ0E7QUFDQTtBQUNBLE1BQUksT0FBTyxRQUFRLEtBQVIsQ0FBYyxDQUFDLENBQWYsRUFBa0IsQ0FBbEIsQ0FBWDtBQUNBLE1BQUksbUJBQ0EsQ0FBQyxPQUFPLElBQVAsSUFBZSxTQUFTLElBQXhCLElBQWdDLFFBQVEsTUFBUixHQUFpQixDQUFsRCxNQUNDLFNBQVMsR0FBVCxJQUFnQixTQUFTLElBRDFCLEtBQ21DLFNBQVMsRUFGaEQ7O0FBSUE7QUFDQTtBQUNBLE1BQUksS0FBSyxDQUFUO0FBQ0EsT0FBSyxJQUFJLElBQUksUUFBUSxNQUFyQixFQUE2QixLQUFLLENBQWxDLEVBQXFDLEdBQXJDLEVBQTBDO0FBQ3hDLFdBQU8sUUFBUSxDQUFSLENBQVA7QUFDQSxRQUFJLFNBQVMsR0FBYixFQUFrQjtBQUNoQixjQUFRLE1BQVIsQ0FBZSxDQUFmLEVBQWtCLENBQWxCO0FBQ0QsS0FGRCxNQUVPLElBQUksU0FBUyxJQUFiLEVBQW1CO0FBQ3hCLGNBQVEsTUFBUixDQUFlLENBQWYsRUFBa0IsQ0FBbEI7QUFDQTtBQUNELEtBSE0sTUFHQSxJQUFJLEVBQUosRUFBUTtBQUNiLGNBQVEsTUFBUixDQUFlLENBQWYsRUFBa0IsQ0FBbEI7QUFDQTtBQUNEO0FBQ0Y7O0FBRUQ7QUFDQSxNQUFJLENBQUMsVUFBRCxJQUFlLENBQUMsYUFBcEIsRUFBbUM7QUFDakMsV0FBTyxJQUFQLEVBQWEsRUFBYixFQUFpQjtBQUNmLGNBQVEsT0FBUixDQUFnQixJQUFoQjtBQUNEO0FBQ0Y7O0FBRUQsTUFBSSxjQUFjLFFBQVEsQ0FBUixNQUFlLEVBQTdCLEtBQ0MsQ0FBQyxRQUFRLENBQVIsQ0FBRCxJQUFlLFFBQVEsQ0FBUixFQUFXLE1BQVgsQ0FBa0IsQ0FBbEIsTUFBeUIsR0FEekMsQ0FBSixFQUNtRDtBQUNqRCxZQUFRLE9BQVIsQ0FBZ0IsRUFBaEI7QUFDRDs7QUFFRCxNQUFJLG9CQUFxQixRQUFRLElBQVIsQ0FBYSxHQUFiLEVBQWtCLE1BQWxCLENBQXlCLENBQUMsQ0FBMUIsTUFBaUMsR0FBMUQsRUFBZ0U7QUFDOUQsWUFBUSxJQUFSLENBQWEsRUFBYjtBQUNEOztBQUVELE1BQUksYUFBYSxRQUFRLENBQVIsTUFBZSxFQUFmLElBQ1osUUFBUSxDQUFSLEtBQWMsUUFBUSxDQUFSLEVBQVcsTUFBWCxDQUFrQixDQUFsQixNQUF5QixHQUQ1Qzs7QUFHQTtBQUNBLE1BQUksU0FBSixFQUFlO0FBQ2IsV0FBTyxRQUFQLEdBQWtCLE9BQU8sSUFBUCxHQUFjLGFBQWEsRUFBYixHQUNBLFFBQVEsTUFBUixHQUFpQixRQUFRLEtBQVIsRUFBakIsR0FBbUMsRUFEbkU7QUFFQTtBQUNBO0FBQ0E7QUFDQSxRQUFJLGFBQWEsT0FBTyxJQUFQLElBQWUsT0FBTyxJQUFQLENBQVksT0FBWixDQUFvQixHQUFwQixJQUEyQixDQUExQyxHQUNBLE9BQU8sSUFBUCxDQUFZLEtBQVosQ0FBa0IsR0FBbEIsQ0FEQSxHQUN5QixLQUQxQztBQUVBLFFBQUksVUFBSixFQUFnQjtBQUNkLGFBQU8sSUFBUCxHQUFjLFdBQVcsS0FBWCxFQUFkO0FBQ0EsYUFBTyxJQUFQLEdBQWMsT0FBTyxRQUFQLEdBQWtCLFdBQVcsS0FBWCxFQUFoQztBQUNEO0FBQ0Y7O0FBRUQsZUFBYSxjQUFlLE9BQU8sSUFBUCxJQUFlLFFBQVEsTUFBbkQ7O0FBRUEsTUFBSSxjQUFjLENBQUMsVUFBbkIsRUFBK0I7QUFDN0IsWUFBUSxPQUFSLENBQWdCLEVBQWhCO0FBQ0Q7O0FBRUQsTUFBSSxDQUFDLFFBQVEsTUFBYixFQUFxQjtBQUNuQixXQUFPLFFBQVAsR0FBa0IsSUFBbEI7QUFDQSxXQUFPLElBQVAsR0FBYyxJQUFkO0FBQ0QsR0FIRCxNQUdPO0FBQ0wsV0FBTyxRQUFQLEdBQWtCLFFBQVEsSUFBUixDQUFhLEdBQWIsQ0FBbEI7QUFDRDs7QUFFRDtBQUNBLE1BQUksQ0FBQyxLQUFLLE1BQUwsQ0FBWSxPQUFPLFFBQW5CLENBQUQsSUFBaUMsQ0FBQyxLQUFLLE1BQUwsQ0FBWSxPQUFPLE1BQW5CLENBQXRDLEVBQWtFO0FBQ2hFLFdBQU8sSUFBUCxHQUFjLENBQUMsT0FBTyxRQUFQLEdBQWtCLE9BQU8sUUFBekIsR0FBb0MsRUFBckMsS0FDQyxPQUFPLE1BQVAsR0FBZ0IsT0FBTyxNQUF2QixHQUFnQyxFQURqQyxDQUFkO0FBRUQ7QUFDRCxTQUFPLElBQVAsR0FBYyxTQUFTLElBQVQsSUFBaUIsT0FBTyxJQUF0QztBQUNBLFNBQU8sT0FBUCxHQUFpQixPQUFPLE9BQVAsSUFBa0IsU0FBUyxPQUE1QztBQUNBLFNBQU8sSUFBUCxHQUFjLE9BQU8sTUFBUCxFQUFkO0FBQ0EsU0FBTyxNQUFQO0FBQ0QsQ0E1UUQ7O0FBOFFBLElBQUksU0FBSixDQUFjLFNBQWQsR0FBMEIsWUFBVztBQUNuQyxNQUFJLE9BQU8sS0FBSyxJQUFoQjtBQUNBLE1BQUksT0FBTyxZQUFZLElBQVosQ0FBaUIsSUFBakIsQ0FBWDtBQUNBLE1BQUksSUFBSixFQUFVO0FBQ1IsV0FBTyxLQUFLLENBQUwsQ0FBUDtBQUNBLFFBQUksU0FBUyxHQUFiLEVBQWtCO0FBQ2hCLFdBQUssSUFBTCxHQUFZLEtBQUssTUFBTCxDQUFZLENBQVosQ0FBWjtBQUNEO0FBQ0QsV0FBTyxLQUFLLE1BQUwsQ0FBWSxDQUFaLEVBQWUsS0FBSyxNQUFMLEdBQWMsS0FBSyxNQUFsQyxDQUFQO0FBQ0Q7QUFDRCxNQUFJLElBQUosRUFBVSxLQUFLLFFBQUwsR0FBZ0IsSUFBaEI7QUFDWCxDQVhEOzs7QUNodEJBOzs7O0FBRUEsT0FBTyxPQUFQLEdBQWlCO0FBQ2YsWUFBVSxrQkFBUyxHQUFULEVBQWM7QUFDdEIsV0FBTyxPQUFPLEdBQVAsS0FBZ0IsUUFBdkI7QUFDRCxHQUhjO0FBSWYsWUFBVSxrQkFBUyxHQUFULEVBQWM7QUFDdEIsV0FBTyxRQUFPLEdBQVAseUNBQU8sR0FBUCxPQUFnQixRQUFoQixJQUE0QixRQUFRLElBQTNDO0FBQ0QsR0FOYztBQU9mLFVBQVEsZ0JBQVMsR0FBVCxFQUFjO0FBQ3BCLFdBQU8sUUFBUSxJQUFmO0FBQ0QsR0FUYztBQVVmLHFCQUFtQiwyQkFBUyxHQUFULEVBQWM7QUFDL0IsV0FBTyxPQUFPLElBQWQ7QUFDRDtBQVpjLENBQWpCOzs7OztBQ0ZBOzs7O0FBSUEsSUFBSSxZQUFZLEVBQWhCO0FBQ0EsS0FBSyxJQUFJLElBQUksQ0FBYixFQUFnQixJQUFJLEdBQXBCLEVBQXlCLEVBQUUsQ0FBM0IsRUFBOEI7QUFDNUIsWUFBVSxDQUFWLElBQWUsQ0FBQyxJQUFJLEtBQUwsRUFBWSxRQUFaLENBQXFCLEVBQXJCLEVBQXlCLE1BQXpCLENBQWdDLENBQWhDLENBQWY7QUFDRDs7QUFFRCxTQUFTLFdBQVQsQ0FBcUIsR0FBckIsRUFBMEIsTUFBMUIsRUFBa0M7QUFDaEMsTUFBSSxJQUFJLFVBQVUsQ0FBbEI7QUFDQSxNQUFJLE1BQU0sU0FBVjtBQUNBO0FBQ0EsU0FBUSxDQUFDLElBQUksSUFBSSxHQUFKLENBQUosQ0FBRCxFQUFnQixJQUFJLElBQUksR0FBSixDQUFKLENBQWhCLEVBQ1QsSUFBSSxJQUFJLEdBQUosQ0FBSixDQURTLEVBQ00sSUFBSSxJQUFJLEdBQUosQ0FBSixDQUROLEVBQ3FCLEdBRHJCLEVBRVQsSUFBSSxJQUFJLEdBQUosQ0FBSixDQUZTLEVBRU0sSUFBSSxJQUFJLEdBQUosQ0FBSixDQUZOLEVBRXFCLEdBRnJCLEVBR1QsSUFBSSxJQUFJLEdBQUosQ0FBSixDQUhTLEVBR00sSUFBSSxJQUFJLEdBQUosQ0FBSixDQUhOLEVBR3FCLEdBSHJCLEVBSVQsSUFBSSxJQUFJLEdBQUosQ0FBSixDQUpTLEVBSU0sSUFBSSxJQUFJLEdBQUosQ0FBSixDQUpOLEVBSXFCLEdBSnJCLEVBS1QsSUFBSSxJQUFJLEdBQUosQ0FBSixDQUxTLEVBS00sSUFBSSxJQUFJLEdBQUosQ0FBSixDQUxOLEVBTVQsSUFBSSxJQUFJLEdBQUosQ0FBSixDQU5TLEVBTU0sSUFBSSxJQUFJLEdBQUosQ0FBSixDQU5OLEVBT1QsSUFBSSxJQUFJLEdBQUosQ0FBSixDQVBTLEVBT00sSUFBSSxJQUFJLEdBQUosQ0FBSixDQVBOLENBQUQsQ0FPdUIsSUFQdkIsQ0FPNEIsRUFQNUIsQ0FBUDtBQVFEOztBQUVELE9BQU8sT0FBUCxHQUFpQixXQUFqQjs7Ozs7QUN2QkE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLElBQUksa0JBQW1CLE9BQU8sTUFBUCxJQUFrQixXQUFsQixJQUFpQyxPQUFPLGVBQXhDLElBQTJELE9BQU8sZUFBUCxDQUF1QixJQUF2QixDQUE0QixNQUE1QixDQUE1RCxJQUNDLE9BQU8sUUFBUCxJQUFvQixXQUFwQixJQUFtQyxPQUFPLE9BQU8sUUFBUCxDQUFnQixlQUF2QixJQUEwQyxVQUE3RSxJQUEyRixTQUFTLGVBQVQsQ0FBeUIsSUFBekIsQ0FBOEIsUUFBOUIsQ0FEbEg7O0FBR0EsSUFBSSxlQUFKLEVBQXFCO0FBQ25CO0FBQ0EsTUFBSSxRQUFRLElBQUksVUFBSixDQUFlLEVBQWYsQ0FBWixDQUZtQixDQUVhOztBQUVoQyxTQUFPLE9BQVAsR0FBaUIsU0FBUyxTQUFULEdBQXFCO0FBQ3BDLG9CQUFnQixLQUFoQjtBQUNBLFdBQU8sS0FBUDtBQUNELEdBSEQ7QUFJRCxDQVJELE1BUU87QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQUksT0FBTyxJQUFJLEtBQUosQ0FBVSxFQUFWLENBQVg7O0FBRUEsU0FBTyxPQUFQLEdBQWlCLFNBQVMsT0FBVCxHQUFtQjtBQUNsQyxTQUFLLElBQUksSUFBSSxDQUFSLEVBQVcsQ0FBaEIsRUFBbUIsSUFBSSxFQUF2QixFQUEyQixHQUEzQixFQUFnQztBQUM5QixVQUFJLENBQUMsSUFBSSxJQUFMLE1BQWUsQ0FBbkIsRUFBc0IsSUFBSSxLQUFLLE1BQUwsS0FBZ0IsV0FBcEI7QUFDdEIsV0FBSyxDQUFMLElBQVUsT0FBTyxDQUFDLElBQUksSUFBTCxLQUFjLENBQXJCLElBQTBCLElBQXBDO0FBQ0Q7O0FBRUQsV0FBTyxJQUFQO0FBQ0QsR0FQRDtBQVFEOzs7QUNqQ0Q7QUFDQTtBQUNBOztBQUVBLFNBQVMsQ0FBVCxDQUFXLENBQVgsRUFBYyxDQUFkLEVBQWlCLENBQWpCLEVBQW9CLENBQXBCLEVBQXVCO0FBQ3JCLFVBQVEsQ0FBUjtBQUNFLFNBQUssQ0FBTDtBQUFRLGFBQVEsSUFBSSxDQUFMLEdBQVcsQ0FBQyxDQUFELEdBQUssQ0FBdkI7QUFDUixTQUFLLENBQUw7QUFBUSxhQUFPLElBQUksQ0FBSixHQUFRLENBQWY7QUFDUixTQUFLLENBQUw7QUFBUSxhQUFRLElBQUksQ0FBTCxHQUFXLElBQUksQ0FBZixHQUFxQixJQUFJLENBQWhDO0FBQ1IsU0FBSyxDQUFMO0FBQVEsYUFBTyxJQUFJLENBQUosR0FBUSxDQUFmO0FBSlY7QUFNRDs7QUFFRCxTQUFTLElBQVQsQ0FBYyxDQUFkLEVBQWlCLENBQWpCLEVBQW9CO0FBQ2xCLFNBQVEsS0FBSyxDQUFOLEdBQVksTUFBTSxLQUFLLENBQTlCO0FBQ0Q7O0FBRUQsU0FBUyxJQUFULENBQWMsS0FBZCxFQUFxQjtBQUNuQixNQUFJLElBQUksQ0FBQyxVQUFELEVBQWEsVUFBYixFQUF5QixVQUF6QixFQUFxQyxVQUFyQyxDQUFSO0FBQ0EsTUFBSSxJQUFJLENBQUMsVUFBRCxFQUFhLFVBQWIsRUFBeUIsVUFBekIsRUFBcUMsVUFBckMsRUFBaUQsVUFBakQsQ0FBUjs7QUFFQSxNQUFJLE9BQU8sS0FBUCxJQUFpQixRQUFyQixFQUErQjtBQUM3QixRQUFJLE1BQU0sU0FBUyxtQkFBbUIsS0FBbkIsQ0FBVCxDQUFWLENBRDZCLENBQ2tCO0FBQy9DLFlBQVEsSUFBSSxLQUFKLENBQVUsSUFBSSxNQUFkLENBQVI7QUFDQSxTQUFLLElBQUksSUFBSSxDQUFiLEVBQWdCLElBQUksSUFBSSxNQUF4QixFQUFnQyxHQUFoQztBQUFxQyxZQUFNLENBQU4sSUFBVyxJQUFJLFVBQUosQ0FBZSxDQUFmLENBQVg7QUFBckM7QUFDRDs7QUFFRCxRQUFNLElBQU4sQ0FBVyxJQUFYOztBQUVBLE1BQUksSUFBSSxNQUFNLE1BQU4sR0FBYSxDQUFiLEdBQWlCLENBQXpCO0FBQ0EsTUFBSSxJQUFJLEtBQUssSUFBTCxDQUFVLElBQUUsRUFBWixDQUFSO0FBQ0EsTUFBSSxJQUFJLElBQUksS0FBSixDQUFVLENBQVYsQ0FBUjs7QUFFQSxPQUFLLElBQUksSUFBRSxDQUFYLEVBQWMsSUFBRSxDQUFoQixFQUFtQixHQUFuQixFQUF3QjtBQUN0QixNQUFFLENBQUYsSUFBTyxJQUFJLEtBQUosQ0FBVSxFQUFWLENBQVA7QUFDQSxTQUFLLElBQUksSUFBRSxDQUFYLEVBQWMsSUFBRSxFQUFoQixFQUFvQixHQUFwQixFQUF5QjtBQUN2QixRQUFFLENBQUYsRUFBSyxDQUFMLElBQ0UsTUFBTSxJQUFJLEVBQUosR0FBUyxJQUFJLENBQW5CLEtBQXlCLEVBQXpCLEdBQ0EsTUFBTSxJQUFJLEVBQUosR0FBUyxJQUFJLENBQWIsR0FBaUIsQ0FBdkIsS0FBNkIsRUFEN0IsR0FFQSxNQUFNLElBQUksRUFBSixHQUFTLElBQUksQ0FBYixHQUFpQixDQUF2QixLQUE2QixDQUY3QixHQUdBLE1BQU0sSUFBSSxFQUFKLEdBQVMsSUFBSSxDQUFiLEdBQWlCLENBQXZCLENBSkY7QUFLRDtBQUNGOztBQUVELElBQUUsSUFBSSxDQUFOLEVBQVMsRUFBVCxJQUFnQixDQUFDLE1BQU0sTUFBTixHQUFlLENBQWhCLElBQXFCLENBQXRCLEdBQ2IsS0FBSyxHQUFMLENBQVMsQ0FBVCxFQUFZLEVBQVosQ0FERixDQUNtQixFQUFFLElBQUksQ0FBTixFQUFTLEVBQVQsSUFBZSxLQUFLLEtBQUwsQ0FBVyxFQUFFLElBQUksQ0FBTixFQUFTLEVBQVQsQ0FBWCxDQUFmO0FBQ25CLElBQUUsSUFBSSxDQUFOLEVBQVMsRUFBVCxJQUFnQixDQUFDLE1BQU0sTUFBTixHQUFlLENBQWhCLElBQXFCLENBQXRCLEdBQTJCLFVBQTFDOztBQUVBLE9BQUssSUFBSSxJQUFFLENBQVgsRUFBYyxJQUFFLENBQWhCLEVBQW1CLEdBQW5CLEVBQXdCO0FBQ3RCLFFBQUksSUFBSSxJQUFJLEtBQUosQ0FBVSxFQUFWLENBQVI7O0FBRUEsU0FBSyxJQUFJLElBQUUsQ0FBWCxFQUFjLElBQUUsRUFBaEIsRUFBb0IsR0FBcEI7QUFBeUIsUUFBRSxDQUFGLElBQU8sRUFBRSxDQUFGLEVBQUssQ0FBTCxDQUFQO0FBQXpCLEtBQ0EsS0FBSyxJQUFJLElBQUUsRUFBWCxFQUFlLElBQUUsRUFBakIsRUFBcUIsR0FBckIsRUFBMEI7QUFDeEIsUUFBRSxDQUFGLElBQU8sS0FBSyxFQUFFLElBQUksQ0FBTixJQUFXLEVBQUUsSUFBSSxDQUFOLENBQVgsR0FBc0IsRUFBRSxJQUFJLEVBQU4sQ0FBdEIsR0FBa0MsRUFBRSxJQUFJLEVBQU4sQ0FBdkMsRUFBa0QsQ0FBbEQsQ0FBUDtBQUNEOztBQUVELFFBQUksSUFBSSxFQUFFLENBQUYsQ0FBUjtBQUNBLFFBQUksSUFBSSxFQUFFLENBQUYsQ0FBUjtBQUNBLFFBQUksSUFBSSxFQUFFLENBQUYsQ0FBUjtBQUNBLFFBQUksSUFBSSxFQUFFLENBQUYsQ0FBUjtBQUNBLFFBQUksSUFBSSxFQUFFLENBQUYsQ0FBUjs7QUFFQSxTQUFLLElBQUksSUFBRSxDQUFYLEVBQWMsSUFBRSxFQUFoQixFQUFvQixHQUFwQixFQUF5QjtBQUN2QixVQUFJLElBQUksS0FBSyxLQUFMLENBQVcsSUFBRSxFQUFiLENBQVI7QUFDQSxVQUFJLElBQUksS0FBSyxDQUFMLEVBQVEsQ0FBUixJQUFhLEVBQUUsQ0FBRixFQUFLLENBQUwsRUFBUSxDQUFSLEVBQVcsQ0FBWCxDQUFiLEdBQTZCLENBQTdCLEdBQWlDLEVBQUUsQ0FBRixDQUFqQyxHQUF3QyxFQUFFLENBQUYsQ0FBeEMsS0FBaUQsQ0FBekQ7QUFDQSxVQUFJLENBQUo7QUFDQSxVQUFJLENBQUo7QUFDQSxVQUFJLEtBQUssQ0FBTCxFQUFRLEVBQVIsTUFBZ0IsQ0FBcEI7QUFDQSxVQUFJLENBQUo7QUFDQSxVQUFJLENBQUo7QUFDRDs7QUFFRCxNQUFFLENBQUYsSUFBUSxFQUFFLENBQUYsSUFBTyxDQUFSLEtBQWUsQ0FBdEI7QUFDQSxNQUFFLENBQUYsSUFBUSxFQUFFLENBQUYsSUFBTyxDQUFSLEtBQWUsQ0FBdEI7QUFDQSxNQUFFLENBQUYsSUFBUSxFQUFFLENBQUYsSUFBTyxDQUFSLEtBQWUsQ0FBdEI7QUFDQSxNQUFFLENBQUYsSUFBUSxFQUFFLENBQUYsSUFBTyxDQUFSLEtBQWUsQ0FBdEI7QUFDQSxNQUFFLENBQUYsSUFBUSxFQUFFLENBQUYsSUFBTyxDQUFSLEtBQWUsQ0FBdEI7QUFDRDs7QUFFRCxTQUFPLENBQ0wsRUFBRSxDQUFGLEtBQVEsRUFBUixHQUFhLElBRFIsRUFDYyxFQUFFLENBQUYsS0FBUSxFQUFSLEdBQWEsSUFEM0IsRUFDaUMsRUFBRSxDQUFGLEtBQVEsQ0FBUixHQUFZLElBRDdDLEVBQ21ELEVBQUUsQ0FBRixJQUFPLElBRDFELEVBRUwsRUFBRSxDQUFGLEtBQVEsRUFBUixHQUFhLElBRlIsRUFFYyxFQUFFLENBQUYsS0FBUSxFQUFSLEdBQWEsSUFGM0IsRUFFaUMsRUFBRSxDQUFGLEtBQVEsQ0FBUixHQUFZLElBRjdDLEVBRW1ELEVBQUUsQ0FBRixJQUFPLElBRjFELEVBR0wsRUFBRSxDQUFGLEtBQVEsRUFBUixHQUFhLElBSFIsRUFHYyxFQUFFLENBQUYsS0FBUSxFQUFSLEdBQWEsSUFIM0IsRUFHaUMsRUFBRSxDQUFGLEtBQVEsQ0FBUixHQUFZLElBSDdDLEVBR21ELEVBQUUsQ0FBRixJQUFPLElBSDFELEVBSUwsRUFBRSxDQUFGLEtBQVEsRUFBUixHQUFhLElBSlIsRUFJYyxFQUFFLENBQUYsS0FBUSxFQUFSLEdBQWEsSUFKM0IsRUFJaUMsRUFBRSxDQUFGLEtBQVEsQ0FBUixHQUFZLElBSjdDLEVBSW1ELEVBQUUsQ0FBRixJQUFPLElBSjFELEVBS0wsRUFBRSxDQUFGLEtBQVEsRUFBUixHQUFhLElBTFIsRUFLYyxFQUFFLENBQUYsS0FBUSxFQUFSLEdBQWEsSUFMM0IsRUFLaUMsRUFBRSxDQUFGLEtBQVEsQ0FBUixHQUFZLElBTDdDLEVBS21ELEVBQUUsQ0FBRixJQUFPLElBTDFELENBQVA7QUFPRDs7QUFFRCxPQUFPLE9BQVAsR0FBaUIsSUFBakI7Ozs7O0FDeEZBLElBQUksY0FBYyxRQUFRLGVBQVIsQ0FBbEI7O0FBRUEsU0FBUyxXQUFULENBQXFCLElBQXJCLEVBQTJCO0FBQ3pCO0FBQ0EsTUFBSSxRQUFRLEVBQVo7QUFDQSxPQUFLLE9BQUwsQ0FBYSxpQkFBYixFQUFnQyxVQUFTLEdBQVQsRUFBYztBQUM1QyxVQUFNLElBQU4sQ0FBVyxTQUFTLEdBQVQsRUFBYyxFQUFkLENBQVg7QUFDRCxHQUZEOztBQUlBLFNBQU8sS0FBUDtBQUNEOztBQUVELFNBQVMsYUFBVCxDQUF1QixHQUF2QixFQUE0QjtBQUMxQixRQUFNLFNBQVMsbUJBQW1CLEdBQW5CLENBQVQsQ0FBTixDQUQwQixDQUNlO0FBQ3pDLE1BQUksUUFBUSxJQUFJLEtBQUosQ0FBVSxJQUFJLE1BQWQsQ0FBWjtBQUNBLE9BQUssSUFBSSxJQUFJLENBQWIsRUFBZ0IsSUFBSSxJQUFJLE1BQXhCLEVBQWdDLEdBQWhDLEVBQXFDO0FBQ25DLFVBQU0sQ0FBTixJQUFXLElBQUksVUFBSixDQUFlLENBQWYsQ0FBWDtBQUNEO0FBQ0QsU0FBTyxLQUFQO0FBQ0Q7O0FBRUQsT0FBTyxPQUFQLEdBQWlCLFVBQVMsSUFBVCxFQUFlLE9BQWYsRUFBd0IsUUFBeEIsRUFBa0M7QUFDakQsTUFBSSxlQUFlLFNBQWYsWUFBZSxDQUFTLEtBQVQsRUFBZ0IsU0FBaEIsRUFBMkIsR0FBM0IsRUFBZ0MsTUFBaEMsRUFBd0M7QUFDekQsUUFBSSxNQUFNLE9BQU8sTUFBUCxJQUFpQixDQUEzQjs7QUFFQSxRQUFJLE9BQU8sS0FBUCxJQUFpQixRQUFyQixFQUErQixRQUFRLGNBQWMsS0FBZCxDQUFSO0FBQy9CLFFBQUksT0FBTyxTQUFQLElBQXFCLFFBQXpCLEVBQW1DLFlBQVksWUFBWSxTQUFaLENBQVo7O0FBRW5DLFFBQUksQ0FBQyxNQUFNLE9BQU4sQ0FBYyxLQUFkLENBQUwsRUFBMkIsTUFBTSxVQUFVLGlDQUFWLENBQU47QUFDM0IsUUFBSSxDQUFDLE1BQU0sT0FBTixDQUFjLFNBQWQsQ0FBRCxJQUE2QixVQUFVLE1BQVYsS0FBcUIsRUFBdEQsRUFBMEQsTUFBTSxVQUFVLDZEQUFWLENBQU47O0FBRTFEO0FBQ0EsUUFBSSxRQUFRLFNBQVMsVUFBVSxNQUFWLENBQWlCLEtBQWpCLENBQVQsQ0FBWjtBQUNBLFVBQU0sQ0FBTixJQUFZLE1BQU0sQ0FBTixJQUFXLElBQVosR0FBb0IsT0FBL0I7QUFDQSxVQUFNLENBQU4sSUFBWSxNQUFNLENBQU4sSUFBVyxJQUFaLEdBQW9CLElBQS9COztBQUVBLFFBQUksR0FBSixFQUFTO0FBQ1AsV0FBSyxJQUFJLE1BQU0sQ0FBZixFQUFrQixNQUFNLEVBQXhCLEVBQTRCLEVBQUUsR0FBOUIsRUFBbUM7QUFDakMsWUFBSSxNQUFJLEdBQVIsSUFBZSxNQUFNLEdBQU4sQ0FBZjtBQUNEO0FBQ0Y7O0FBRUQsV0FBTyxPQUFPLFlBQVksS0FBWixDQUFkO0FBQ0QsR0FyQkQ7O0FBdUJBO0FBQ0EsTUFBSTtBQUNGLGlCQUFhLElBQWIsR0FBb0IsSUFBcEI7QUFDRCxHQUZELENBRUUsT0FBTyxHQUFQLEVBQVksQ0FDYjs7QUFFRDtBQUNBLGVBQWEsR0FBYixHQUFtQixzQ0FBbkI7QUFDQSxlQUFhLEdBQWIsR0FBbUIsc0NBQW5COztBQUVBLFNBQU8sWUFBUDtBQUNELENBbkNEOzs7OztBQ3JCQSxJQUFJLE1BQU0sUUFBUSxXQUFSLENBQVY7QUFDQSxJQUFJLGNBQWMsUUFBUSxtQkFBUixDQUFsQjs7QUFFQSxTQUFTLEVBQVQsQ0FBWSxPQUFaLEVBQXFCLEdBQXJCLEVBQTBCLE1BQTFCLEVBQWtDO0FBQ2hDLE1BQUksSUFBSSxPQUFPLE1BQVAsSUFBaUIsQ0FBekI7O0FBRUEsTUFBSSxPQUFPLE9BQVAsSUFBbUIsUUFBdkIsRUFBaUM7QUFDL0IsVUFBTSxZQUFZLFFBQVosR0FBdUIsSUFBSSxLQUFKLENBQVUsRUFBVixDQUF2QixHQUF1QyxJQUE3QztBQUNBLGNBQVUsSUFBVjtBQUNEO0FBQ0QsWUFBVSxXQUFXLEVBQXJCOztBQUVBLE1BQUksT0FBTyxRQUFRLE1BQVIsSUFBa0IsQ0FBQyxRQUFRLEdBQVIsSUFBZSxHQUFoQixHQUE3Qjs7QUFFQTtBQUNBLE9BQUssQ0FBTCxJQUFXLEtBQUssQ0FBTCxJQUFVLElBQVgsR0FBbUIsSUFBN0I7QUFDQSxPQUFLLENBQUwsSUFBVyxLQUFLLENBQUwsSUFBVSxJQUFYLEdBQW1CLElBQTdCOztBQUVBO0FBQ0EsTUFBSSxHQUFKLEVBQVM7QUFDUCxTQUFLLElBQUksS0FBSyxDQUFkLEVBQWlCLEtBQUssRUFBdEIsRUFBMEIsRUFBRSxFQUE1QixFQUFnQztBQUM5QixVQUFJLElBQUksRUFBUixJQUFjLEtBQUssRUFBTCxDQUFkO0FBQ0Q7QUFDRjs7QUFFRCxTQUFPLE9BQU8sWUFBWSxJQUFaLENBQWQ7QUFDRDs7QUFFRCxPQUFPLE9BQVAsR0FBaUIsRUFBakI7Ozs7O0FDNUJBLElBQUksTUFBTSxRQUFRLGNBQVIsQ0FBVjtBQUNBLElBQUksT0FBTyxRQUFRLFlBQVIsQ0FBWDtBQUNBLE9BQU8sT0FBUCxHQUFpQixJQUFJLElBQUosRUFBVSxJQUFWLEVBQWdCLElBQWhCLENBQWpCOzs7QUNGQTs7QUFFQSxJQUFNLEtBQUssUUFBUSxTQUFSLENBQVg7QUFBQSxJQUNNLEtBQUssUUFBUSxTQUFSLENBRFg7O0FBR0EsSUFBTSxTQUFTLFNBQVQsTUFBUyxHQUFZO0FBQ3pCLFNBQU8sSUFBUDtBQUNELENBRkQ7O0FBSUEsT0FBTyxLQUFQLEdBQWU7QUFDYixNQUFJLCtGQURTO0FBRWIsTUFBSTtBQUZTLENBQWY7O0FBS0EsT0FBTyxFQUFQLEdBQVksVUFBVSxLQUFWLEVBQWlCO0FBQzNCLE1BQUksQ0FBQyxLQUFMLEVBQVk7QUFDVixXQUFPLEtBQVA7QUFDRDs7QUFFRCxTQUFPLE9BQU8sS0FBUCxDQUFhLEVBQWIsQ0FBZ0IsSUFBaEIsQ0FBcUIsS0FBckIsS0FBK0IsT0FBTyxLQUFQLENBQWEsRUFBYixDQUFnQixJQUFoQixDQUFxQixLQUFyQixDQUF0QztBQUNELENBTkQ7O0FBUUEsT0FBTyxLQUFQLEdBQWUsWUFBWTtBQUN6QixTQUFPLHNDQUFQO0FBQ0QsQ0FGRDs7QUFJQSxPQUFPLFVBQVAsR0FBb0IsVUFBVSxJQUFWLEVBQWdCO0FBQ2xDLE1BQUksQ0FBQyxJQUFMLEVBQVc7QUFDVCxVQUFNLElBQUksS0FBSixDQUFVLGtCQUFWLENBQU47QUFDRDs7QUFFRCxNQUFNLFlBQVksc0NBQWxCOztBQUVBLE1BQU0saUJBQWlCLEdBQUcsSUFBSCxFQUFTLFNBQVQsQ0FBdkI7O0FBRUEsU0FBTyxjQUFQO0FBQ0QsQ0FWRDs7QUFZQSxPQUFPLE9BQVAsR0FBaUIsTUFBakI7OztBQ3RDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLElBQUksU0FBVSxhQUFRLFVBQUssTUFBZCxJQUF5QixVQUFVLENBQVYsRUFBYSxDQUFiLEVBQWdCO0FBQ2xELFFBQUksSUFBSSxPQUFPLE1BQVAsS0FBa0IsVUFBbEIsSUFBZ0MsRUFBRSxPQUFPLFFBQVQsQ0FBeEM7QUFDQSxRQUFJLENBQUMsQ0FBTCxFQUFRLE9BQU8sQ0FBUDtBQUNSLFFBQUksSUFBSSxFQUFFLElBQUYsQ0FBTyxDQUFQLENBQVI7QUFBQSxRQUFtQixDQUFuQjtBQUFBLFFBQXNCLEtBQUssRUFBM0I7QUFBQSxRQUErQixDQUEvQjtBQUNBLFFBQUk7QUFDQSxlQUFPLENBQUMsTUFBTSxLQUFLLENBQVgsSUFBZ0IsTUFBTSxDQUF2QixLQUE2QixDQUFDLENBQUMsSUFBSSxFQUFFLElBQUYsRUFBTCxFQUFlLElBQXBEO0FBQTBELGVBQUcsSUFBSCxDQUFRLEVBQUUsS0FBVjtBQUExRDtBQUNILEtBRkQsQ0FHQSxPQUFPLEtBQVAsRUFBYztBQUFFLFlBQUksRUFBRSxPQUFPLEtBQVQsRUFBSjtBQUF1QixLQUh2QyxTQUlRO0FBQ0osWUFBSTtBQUNBLGdCQUFJLEtBQUssQ0FBQyxFQUFFLElBQVIsS0FBaUIsSUFBSSxFQUFFLFFBQUYsQ0FBckIsQ0FBSixFQUF1QyxFQUFFLElBQUYsQ0FBTyxDQUFQO0FBQzFDLFNBRkQsU0FHUTtBQUFFLGdCQUFJLENBQUosRUFBTyxNQUFNLEVBQUUsS0FBUjtBQUFnQjtBQUNwQztBQUNELFdBQU8sRUFBUDtBQUNILENBZkQ7QUFnQkEsSUFBSSxXQUFZLGFBQVEsVUFBSyxRQUFkLElBQTJCLFlBQVk7QUFDbEQsU0FBSyxJQUFJLEtBQUssRUFBVCxFQUFhLElBQUksQ0FBdEIsRUFBeUIsSUFBSSxVQUFVLE1BQXZDLEVBQStDLEdBQS9DO0FBQW9ELGFBQUssR0FBRyxNQUFILENBQVUsT0FBTyxVQUFVLENBQVYsQ0FBUCxDQUFWLENBQUw7QUFBcEQsS0FDQSxPQUFPLEVBQVA7QUFDSCxDQUhEO0FBSUEsSUFBSSxXQUFZLGFBQVEsVUFBSyxRQUFkLElBQTJCLFVBQVUsQ0FBVixFQUFhO0FBQ25ELFFBQUksSUFBSSxPQUFPLE1BQVAsS0FBa0IsVUFBbEIsSUFBZ0MsRUFBRSxPQUFPLFFBQVQsQ0FBeEM7QUFBQSxRQUE0RCxJQUFJLENBQWhFO0FBQ0EsUUFBSSxDQUFKLEVBQU8sT0FBTyxFQUFFLElBQUYsQ0FBTyxDQUFQLENBQVA7QUFDUCxXQUFPO0FBQ0gsY0FBTSxnQkFBWTtBQUNkLGdCQUFJLEtBQUssS0FBSyxFQUFFLE1BQWhCLEVBQXdCLElBQUksS0FBSyxDQUFUO0FBQ3hCLG1CQUFPLEVBQUUsT0FBTyxLQUFLLEVBQUUsR0FBRixDQUFkLEVBQXNCLE1BQU0sQ0FBQyxDQUE3QixFQUFQO0FBQ0g7QUFKRSxLQUFQO0FBTUgsQ0FURDtBQVVBLE9BQU8sY0FBUCxDQUFzQixPQUF0QixFQUErQixZQUEvQixFQUE2QyxFQUFFLE9BQU8sSUFBVCxFQUE3QztBQUNBLElBQUksdUJBQXVCLFFBQVEsc0NBQVIsQ0FBM0I7QUFDQSxJQUFJLFNBQVMsUUFBUSxpQkFBUixDQUFiO0FBQ0EsSUFBSSxTQUFTLFFBQVEsaUJBQVIsQ0FBYjtBQUNBLElBQUksYUFBYSxRQUFRLFlBQVIsQ0FBakI7QUFDQTtBQUNBO0FBQ0EsU0FBUyxZQUFULENBQXNCLENBQXRCLEVBQXlCO0FBQ3JCLFFBQUk7QUFDQSxZQUFJLE1BQU0sSUFBSSxHQUFKLENBQVEsQ0FBUixDQUFWO0FBQ0EsWUFBSSxJQUFJLElBQVIsRUFBYztBQUNWLGdCQUFJLGtCQUFrQixtQkFBbUIsSUFBSSxJQUF2QixDQUF0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBSSx5QkFBeUIsZ0JBQWdCLFNBQWhCLENBQTBCLGdCQUFnQixPQUFoQixDQUF3QixPQUF4QixDQUExQixDQUE3QjtBQUNBLGdCQUFJLElBQUksR0FBSixDQUFRLHNCQUFSLEVBQWdDLFFBQWhDLEtBQTZDLEtBQWpELEVBQXdEO0FBQ3BELHVCQUFPLHNCQUFQO0FBQ0g7QUFDSjtBQUNKLEtBZEQsQ0FlQSxPQUFPLENBQVAsRUFBVTtBQUNOO0FBQ0E7QUFDSDtBQUNELFdBQU8sQ0FBUDtBQUNIO0FBQ0QsUUFBUSxZQUFSLEdBQXVCLFlBQXZCO0FBQ0EsSUFBSSxNQUFNLGFBQWUsWUFBWTtBQUNqQyxhQUFTLEdBQVQsQ0FBYSxVQUFiLEVBQXlCLFVBQXpCLEVBQXFDLE1BQXJDLEVBQTZDLFNBQTdDLEVBQXdELGNBQXhELEVBQXdFLFNBQXhFLEVBQW1GLGFBQW5GLEVBQWtHLFFBQWxHLEVBQTRHLGVBQTVHLEVBQTZILE9BQTdILEVBQXNJLGVBQXRJLEVBQXVKLFFBQXZKLEVBQWlLO0FBQzdKLFlBQUksYUFBYSxLQUFLLENBQXRCLEVBQXlCO0FBQUUsdUJBQVcsT0FBTyxRQUFsQjtBQUE2QjtBQUN4RCxhQUFLLFVBQUwsR0FBa0IsVUFBbEI7QUFDQSxhQUFLLFVBQUwsR0FBa0IsVUFBbEI7QUFDQSxhQUFLLE1BQUwsR0FBYyxNQUFkO0FBQ0EsYUFBSyxTQUFMLEdBQWlCLFNBQWpCO0FBQ0EsYUFBSyxTQUFMLEdBQWlCLFNBQWpCO0FBQ0EsYUFBSyxhQUFMLEdBQXFCLGFBQXJCO0FBQ0EsYUFBSyxRQUFMLEdBQWdCLFFBQWhCO0FBQ0EsYUFBSyxlQUFMLEdBQXVCLGVBQXZCO0FBQ0EsYUFBSyxPQUFMLEdBQWUsT0FBZjtBQUNBLGFBQUssZUFBTCxHQUF1QixlQUF2QjtBQUNBLGFBQUssaUJBQUwsR0FBeUIsRUFBekI7QUFDQSxhQUFLLFlBQUwsR0FBb0IsT0FBTyxDQUFQLENBQVMsV0FBVCxDQUFxQixDQUFyQixDQUF1QixVQUEzQztBQUNBLGFBQUssY0FBTCxHQUFzQixPQUFPLENBQVAsQ0FBUyxZQUEvQjtBQUNBLGFBQUssZUFBTDtBQUNBLGFBQUssa0NBQUw7QUFDQSxlQUFPLENBQVAsQ0FBUyxTQUFULENBQW1CLE9BQW5CLEdBQTZCLGdCQUFnQixXQUE3QztBQUNBLGFBQUssUUFBTCxHQUFnQixLQUFLLE1BQUwsQ0FBWSxRQUFaLENBQXFCLElBQXJCLENBQTBCLEtBQUssTUFBL0IsQ0FBaEI7QUFDQSxZQUFJLGNBQUosRUFBb0I7QUFDaEIsaUJBQUssK0JBQUwsQ0FBcUMsY0FBckM7QUFDSCxTQUZELE1BR0s7QUFDRCxvQkFBUSxJQUFSLENBQWEsdURBQWI7QUFDSDtBQUNELGFBQUssU0FBTCxDQUFlLFdBQWYsQ0FBMkIsS0FBSyxtQkFBTCxDQUF5QixJQUF6QixDQUE4QixJQUE5QixDQUEzQjtBQUNBLGFBQUssT0FBTCxDQUFhLFdBQWIsQ0FBeUIsS0FBSyxnQkFBTCxDQUFzQixJQUF0QixDQUEyQixJQUEzQixDQUF6QjtBQUNBO0FBQ0EsaUJBQVMsZ0JBQVQsQ0FBMEIsUUFBMUIsRUFBb0MsS0FBSyxrQ0FBTCxDQUF3QyxJQUF4QyxDQUE2QyxJQUE3QyxDQUFwQztBQUNBO0FBQ0EsYUFBSyxNQUFMLENBQVksZ0JBQVosQ0FBNkIsMEJBQTdCLEVBQXlELEtBQUssc0JBQUwsQ0FBNEIsSUFBNUIsQ0FBaUMsSUFBakMsQ0FBekQ7QUFDQSxhQUFLLE1BQUwsQ0FBWSxnQkFBWixDQUE2QixnQ0FBN0IsRUFBK0QsS0FBSyw0QkFBTCxDQUFrQyxJQUFsQyxDQUF1QyxJQUF2QyxDQUEvRDtBQUNBLGFBQUssTUFBTCxDQUFZLGdCQUFaLENBQTZCLG9CQUE3QixFQUFtRCxLQUFLLGdCQUFMLENBQXNCLElBQXRCLENBQTJCLElBQTNCLENBQW5EO0FBQ0EsYUFBSyxNQUFMLENBQVksZ0JBQVosQ0FBNkIsdUJBQTdCLEVBQXNELEtBQUssbUJBQUwsQ0FBeUIsSUFBekIsQ0FBOEIsSUFBOUIsQ0FBdEQ7QUFDQSxhQUFLLE1BQUwsQ0FBWSxnQkFBWixDQUE2QixnQkFBN0IsRUFBK0MsS0FBSyxhQUFMLENBQW1CLElBQW5CLENBQXdCLElBQXhCLENBQS9DO0FBQ0EsYUFBSyxNQUFMLENBQVksZ0JBQVosQ0FBNkIsbUJBQTdCLEVBQWtELEtBQUssZ0JBQUwsQ0FBc0IsSUFBdEIsQ0FBMkIsSUFBM0IsQ0FBbEQ7QUFDQSxhQUFLLE1BQUwsQ0FBWSxnQkFBWixDQUE2QixlQUE3QixFQUE4QyxLQUFLLFlBQUwsQ0FBa0IsSUFBbEIsQ0FBdUIsSUFBdkIsQ0FBOUM7QUFDQSxhQUFLLE1BQUwsQ0FBWSxnQkFBWixDQUE2QixpQkFBN0IsRUFBZ0QsS0FBSyxZQUFMLENBQWtCLElBQWxCLENBQXVCLElBQXZCLENBQWhEO0FBQ0EsYUFBSyxNQUFMLENBQVksZ0JBQVosQ0FBNkIsYUFBN0IsRUFBNEMsS0FBSyxlQUFMLENBQXFCLElBQXJCLENBQTBCLElBQTFCLENBQTVDO0FBQ0EsYUFBSyxNQUFMLENBQVksZ0JBQVosQ0FBNkIsNEJBQTdCLEVBQTJELEtBQUssMEJBQUwsQ0FBZ0MsSUFBaEMsQ0FBcUMsSUFBckMsQ0FBM0Q7QUFDQSxhQUFLLE1BQUwsQ0FBWSxnQkFBWixDQUE2QixrQkFBN0IsRUFBaUQsS0FBSyxNQUFMLENBQVksZ0JBQVosQ0FBNkIsSUFBN0IsQ0FBa0MsS0FBSyxNQUF2QyxDQUFqRDtBQUNBLGFBQUssY0FBTCxDQUFvQixDQUFwQixDQUFzQixZQUF0QixDQUFtQyxnQkFBbkMsQ0FBb0QsS0FBcEQsRUFBMkQsS0FBSyxjQUFMLENBQW9CLElBQXBCLENBQXlCLElBQXpCLENBQTNEO0FBQ0EsYUFBSyxNQUFMLENBQVksZ0JBQVosQ0FBNkIsbUJBQTdCLEVBQWtELEtBQUssZUFBTCxDQUFxQixJQUFyQixDQUEwQixJQUExQixDQUFsRDtBQUNBO0FBQ0EsYUFBSyxVQUFMLENBQWdCLFNBQWhCLENBQTBCLE9BQU8sV0FBakMsRUFBOEMsS0FBSyxlQUFMLENBQXFCLElBQXJCLENBQTBCLElBQTFCLENBQTlDO0FBQ0EsYUFBSyxVQUFMLENBQWdCLFNBQWhCLENBQTBCLE9BQU8sZUFBakMsRUFBa0QsS0FBSyxtQkFBTCxDQUF5QixJQUF6QixDQUE4QixJQUE5QixDQUFsRDtBQUNBLGFBQUssVUFBTCxDQUFnQixTQUFoQixDQUEwQixPQUFPLGFBQWpDLEVBQWdELEtBQUssaUJBQUwsQ0FBdUIsSUFBdkIsQ0FBNEIsSUFBNUIsQ0FBaEQ7QUFDQSxhQUFLLFVBQUwsQ0FBZ0IsU0FBaEIsQ0FBMEIsT0FBTyxrQkFBakMsRUFBcUQsS0FBSyxzQkFBTCxDQUE0QixJQUE1QixDQUFpQyxJQUFqQyxDQUFyRDtBQUNBLGFBQUssVUFBTCxDQUFnQixTQUFoQixDQUEwQixPQUFPLGVBQWpDLEVBQWtELEtBQUssbUJBQUwsQ0FBeUIsSUFBekIsQ0FBOEIsSUFBOUIsQ0FBbEQ7QUFDQSxhQUFLLFVBQUwsQ0FBZ0IsU0FBaEIsQ0FBMEIsT0FBTyxrQkFBakMsRUFBcUQsS0FBSyxzQkFBTCxDQUE0QixJQUE1QixDQUFpQyxJQUFqQyxDQUFyRDtBQUNBLGFBQUssVUFBTCxDQUFnQixTQUFoQixDQUEwQixPQUFPLGtCQUFqQyxFQUFxRCxLQUFLLHNCQUFMLENBQTRCLElBQTVCLENBQWlDLElBQWpDLENBQXJEO0FBQ0EsYUFBSyxVQUFMLENBQWdCLGVBQWhCO0FBQ0EsWUFBSSxDQUFDLEtBQUssb0JBQUwsRUFBTCxFQUFrQztBQUM5QixpQkFBSyxrQkFBTDtBQUNIO0FBQ0QsYUFBSyxrQkFBTDtBQUNBLGFBQUssaUJBQUw7QUFDSDtBQUNELFFBQUksU0FBSixDQUFjLGtCQUFkLEdBQW1DLFVBQVUsQ0FBVixFQUFhLGFBQWIsRUFBNEI7QUFDM0QsWUFBSSxRQUFRLElBQVo7QUFDQSxZQUFJLGtCQUFrQixLQUFLLENBQTNCLEVBQThCO0FBQUUsNEJBQWdCLEtBQWhCO0FBQXdCO0FBQ3hELFlBQUksVUFBSjtBQUNBLFlBQUksYUFBSjtBQUNBLFlBQUksU0FBSjtBQUNBLFlBQUksYUFBSjtBQUNBLFlBQUksVUFBSjtBQUNBLFlBQUksYUFBYSxPQUFPLHVCQUF4QixFQUFpRDtBQUM3Qyx5QkFBYSxpREFBYjtBQUNILFNBRkQsTUFHSyxJQUFJLGFBQWEsT0FBTyx3QkFBeEIsRUFBa0Q7QUFDbkQseUJBQWEsaURBQWI7QUFDSCxTQUZJLE1BR0EsSUFBSSxhQUFhLE9BQU8sMkJBQXhCLEVBQXFEO0FBQ3RELHlCQUFhLGlEQUFiO0FBQ0gsU0FGSSxNQUdBLElBQUksYUFBYSxPQUFPLGlCQUF4QixFQUEyQztBQUM1Qyx5QkFBYSx5Q0FBYjtBQUNILFNBRkksTUFHQSxJQUFJLGFBQWEsT0FBTyx1QkFBeEIsRUFBaUQ7QUFDbEQseUJBQWEsMkJBQWI7QUFDSCxTQUZJLE1BR0EsSUFBSSxhQUFhLE9BQU8sZ0JBQXhCLEVBQTBDO0FBQzNDLHlCQUFhLDBCQUFiO0FBQ0gsU0FGSSxNQUdBLElBQUksYUFBYSxPQUFPLGtCQUF4QixFQUE0QztBQUM3Qyx5QkFBYSwyQkFBYjtBQUNILFNBRkksTUFHQSxJQUFJLGFBQWEsT0FBTyxpQkFBeEIsRUFBMkM7QUFDNUMseUJBQWEsZUFBYjtBQUNILFNBRkksTUFHQSxJQUFJLGFBQWEsT0FBTyx1QkFBcEIsSUFBK0MsS0FBSyxTQUFMLEVBQW5ELEVBQXFFO0FBQ3RFO0FBQ0EseUJBQWEsZ0NBQWI7QUFDQSx3QkFBWSxVQUFaO0FBQ0EseUJBQWEsNEVBQWI7QUFDSCxTQUxJLE1BTUEsSUFBSSxhQUFhLE9BQU8sMkJBQXhCLEVBQXFEO0FBQ3RELHlCQUFhLHFDQUFiO0FBQ0Esd0JBQVkscUJBQVo7QUFDQSw0QkFBZ0IseUJBQVk7QUFDeEI7QUFDQSxzQkFBTSxNQUFOLENBQWEsVUFBYixDQUF3QixVQUF4QjtBQUNILGFBSEQ7QUFJSCxTQVBJLE1BUUEsSUFBSSxhQUFhLE9BQU8sa0JBQXhCLEVBQTRDO0FBQzdDLHlCQUFhLHdDQUFiO0FBQ0gsU0FGSSxNQUdBLElBQUksYUFBYSxPQUFPLHVCQUF4QixFQUFpRDtBQUNsRCx5QkFBYSxnREFBYjtBQUNILFNBRkksTUFHQSxJQUFJLGFBQWEsT0FBTyxrQkFBeEIsRUFBNEM7QUFDN0MseUJBQWEsNEJBQWI7QUFDQSw0QkFBZ0IsQ0FBQyxZQUFELEVBQWUsRUFBRSxNQUFGLENBQVMsSUFBeEIsQ0FBaEI7QUFDSCxTQUhJLE1BSUEsSUFBSSxhQUFhLE9BQU8sNEJBQXhCLEVBQXNEO0FBQ3ZELHlCQUFhLDJDQUFiO0FBQ0gsU0FGSSxNQUdBO0FBQ0QseUJBQWEsa0JBQWI7QUFDSDtBQUNELFlBQUksVUFBVSxnQkFBZ0IsS0FBSyxRQUFMLENBQWMsS0FBZCxDQUFvQixJQUFwQixFQUEwQixTQUFTLENBQUMsVUFBRCxDQUFULEVBQXVCLGFBQXZCLENBQTFCLENBQWhCLEdBQW1GLEtBQUssUUFBTCxDQUFjLFVBQWQsQ0FBakc7QUFDQTtBQUNBO0FBQ0EsWUFBSSxLQUFLLE1BQUwsSUFBZSxLQUFLLE1BQUwsQ0FBWSxLQUEvQixFQUFzQztBQUNsQyxpQkFBSyxNQUFMLENBQVksS0FBWixDQUFrQixZQUFZO0FBQzFCLHNCQUFNLE1BQU4sQ0FBYSxTQUFiLENBQXVCLE9BQXZCLEVBQWdDLGFBQWhDLEVBQStDLFlBQVksTUFBTSxRQUFOLENBQWUsU0FBZixDQUFaLEdBQXdDLFNBQXZGLEVBQWtHLGFBQWxHLEVBQWlILFVBQWpIO0FBQ0gsYUFGRCxFQUVHLEdBRkg7QUFHSDtBQUNKLEtBdEVEO0FBdUVBLFFBQUksU0FBSixDQUFjLGlCQUFkLEdBQWtDLFlBQVk7QUFDMUMsWUFBSSxRQUFRLElBQVo7QUFDQSxhQUFLLFNBQUwsQ0FBZSxXQUFmLEdBQTZCLElBQTdCLENBQWtDLFVBQVUsSUFBVixFQUFnQjtBQUM5QyxrQkFBTSxtQkFBTixDQUEwQixJQUExQjtBQUNILFNBRkQsRUFFRyxVQUFVLENBQVYsRUFBYTtBQUNaLG9CQUFRLElBQVIsQ0FBYSwwREFBYjtBQUNILFNBSkQ7QUFLSCxLQVBEO0FBUUEsUUFBSSxTQUFKLENBQWMsbUJBQWQsR0FBb0MsVUFBVSxLQUFWLEVBQWlCO0FBQ2pELGdCQUFRLEtBQVIsQ0FBYyxZQUFZLE1BQU0sTUFBTixDQUFhLEVBQXpCLEdBQThCLFlBQTVDO0FBQ0EsWUFBSSxPQUFPLEtBQUssWUFBTCxDQUFrQixhQUFsQixDQUFnQyxNQUFNLE1BQU4sQ0FBYSxFQUE3QyxDQUFYO0FBQ0EsYUFBSyxLQUFMLEdBQWEsV0FBYjtBQUNILEtBSkQ7QUFLQSxRQUFJLFNBQUosQ0FBYyxzQkFBZCxHQUF1QyxVQUFVLEtBQVYsRUFBaUI7QUFDcEQsZ0JBQVEsS0FBUixDQUFjLFlBQVksTUFBTSxNQUFOLENBQWEsRUFBekIsR0FBOEIsZUFBNUM7QUFDQSxZQUFJO0FBQ0EsaUJBQUssWUFBTCxDQUFrQixhQUFsQixDQUFnQyxNQUFNLE1BQU4sQ0FBYSxFQUE3QyxFQUFpRCxLQUFqRCxHQUF5RCxjQUF6RDtBQUNILFNBRkQsQ0FHQSxPQUFPLENBQVAsRUFBVTtBQUNOLG9CQUFRLElBQVIsQ0FBYSxxRUFBYjtBQUNIO0FBQ0osS0FSRDtBQVNBLFFBQUksU0FBSixDQUFjLHNCQUFkLEdBQXVDLFVBQVUsS0FBVixFQUFpQjtBQUNwRCxnQkFBUSxLQUFSLENBQWMsWUFBWSxNQUFNLE1BQU4sQ0FBYSxFQUF6QixHQUE4QixlQUE1QztBQUNBLFlBQUksT0FBTyxLQUFLLFlBQUwsQ0FBa0IsYUFBbEIsQ0FBZ0MsTUFBTSxNQUFOLENBQWEsRUFBN0MsQ0FBWDtBQUNBLGFBQUssS0FBTCxHQUFhLGNBQWI7QUFDSCxLQUpEO0FBS0EsUUFBSSxTQUFKLENBQWMsa0JBQWQsR0FBbUMsWUFBWTtBQUMzQyxZQUFJLEtBQUssTUFBTCxDQUFZLENBQVosQ0FBYyxXQUFkLENBQTBCLG1CQUE5QixFQUFtRDtBQUMvQyxpQkFBSyxNQUFMLENBQVksQ0FBWixDQUFjLGFBQWQsQ0FBNEIsa0JBQTVCO0FBQ0g7QUFDSixLQUpEO0FBS0EsUUFBSSxTQUFKLENBQWMsb0JBQWQsR0FBcUMsWUFBWTtBQUM3QyxZQUFJO0FBQ0EsZ0JBQUksS0FBSyxlQUFMLENBQXFCLFVBQXpCLEVBQXFDO0FBQ2pDLHVCQUFPLEtBQUssUUFBTCxDQUFjLEdBQWQsQ0FBa0IsV0FBVyxXQUFYLENBQXVCLFFBQXpDLE1BQXVELE1BQTlEO0FBQ0g7QUFDRCxtQkFBTyxLQUFLLFFBQUwsQ0FBYyxHQUFkLENBQWtCLFdBQVcsV0FBWCxDQUF1QixXQUF6QyxNQUEwRCxNQUFqRTtBQUNILFNBTEQsQ0FNQSxPQUFPLENBQVAsRUFBVTtBQUNOLG9CQUFRLEtBQVIsQ0FBYywyRUFBZDtBQUNIO0FBQ0QsZUFBTyxLQUFQO0FBQ0gsS0FYRDtBQVlBLFFBQUksU0FBSixDQUFjLGtCQUFkLEdBQW1DLFlBQVk7QUFDM0MsYUFBSyxNQUFMLENBQVksQ0FBWixDQUFjLFdBQWQsQ0FBMEIsTUFBMUIsR0FBbUMsSUFBbkM7QUFDQSxhQUFLLE1BQUwsQ0FBWSxDQUFaLENBQWMsV0FBZCxDQUEwQixhQUExQixHQUEwQyxLQUFLLGVBQUwsQ0FBcUIsVUFBL0Q7QUFDQSxhQUFLLE1BQUwsQ0FBWSxDQUFaLENBQWMsV0FBZCxDQUEwQixNQUExQixHQUFtQyxLQUFuQztBQUNILEtBSkQ7QUFLQSxRQUFJLFNBQUosQ0FBYyxlQUFkLEdBQWdDLFlBQVk7QUFDeEMsYUFBSyxNQUFMLENBQVksQ0FBWixDQUFjLFdBQWQsQ0FBMEIsTUFBMUIsR0FBbUMsS0FBbkM7QUFDQSxhQUFLLE1BQUwsQ0FBWSxDQUFaLENBQWMsV0FBZCxDQUEwQixNQUExQixHQUFtQyxJQUFuQztBQUNBLGFBQUssUUFBTCxDQUFjLEdBQWQsQ0FBa0IsS0FBSyxlQUFMLENBQXFCLFVBQXJCLEdBQWtDLFdBQVcsV0FBWCxDQUF1QixRQUF6RCxHQUFvRSxXQUFXLFdBQVgsQ0FBdUIsV0FBN0csRUFBMEgsTUFBMUg7QUFDSCxLQUpEO0FBS0EsUUFBSSxTQUFKLENBQWMsbUJBQWQsR0FBb0MsVUFBVSxJQUFWLEVBQWdCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBLGVBQU8sS0FBSyxTQUFMLENBQWUsQ0FBZixFQUFrQixJQUFsQixFQUF3QixJQUF4QixFQUFQO0FBQ0EsWUFBSTtBQUNBLGlCQUFLLGdCQUFMLENBQXNCLElBQXRCLEVBQTRCLElBQTVCO0FBQ0gsU0FGRCxDQUdBLE9BQU8sR0FBUCxFQUFZO0FBQ1I7QUFDSDtBQUNKLEtBWEQ7QUFZQSxRQUFJLFNBQUosQ0FBYyxnQkFBZCxHQUFpQyxZQUFZO0FBQ3pDLGFBQUssTUFBTCxDQUFZLFNBQVosQ0FBc0IsS0FBSyxRQUFMLENBQWMsbUJBQWQsQ0FBdEIsRUFBMEQsS0FBMUQ7QUFDSCxLQUZEO0FBR0EsUUFBSSxTQUFKLENBQWMsc0JBQWQsR0FBdUMsWUFBWTtBQUMvQyxhQUFLLE1BQUwsQ0FBWSxlQUFaO0FBQ0gsS0FGRDtBQUdBO0FBQ0EsUUFBSSxTQUFKLENBQWMsbUJBQWQsR0FBb0MsVUFBVSxLQUFWLEVBQWlCO0FBQ2pELFlBQUksWUFBWSxNQUFNLE1BQU4sQ0FBYSxTQUE3QjtBQUNBLGFBQUssaUJBQUwsQ0FBdUIsU0FBdkIsSUFBb0MsSUFBcEM7QUFDSCxLQUhEO0FBSUEsUUFBSSxTQUFKLENBQWMsZ0JBQWQsR0FBaUMsVUFBVSxLQUFWLEVBQWlCO0FBQzlDLFlBQUk7QUFDQSxpQkFBSyxVQUFMLENBQWdCLEdBQWhCLENBQW9CLE1BQU0sTUFBTixDQUFhLFlBQWpDO0FBQ0gsU0FGRCxDQUdBLE9BQU8sR0FBUCxFQUFZO0FBQ1IsaUJBQUssbUJBQUw7QUFDQSxpQkFBSyxrQkFBTCxDQUF3QixHQUF4QjtBQUNIO0FBQ0osS0FSRDtBQVNBLFFBQUksU0FBSixDQUFjLDRCQUFkLEdBQTZDLFVBQVUsS0FBVixFQUFpQjtBQUMxRCxZQUFJLFlBQVksTUFBTSxNQUFOLENBQWEsU0FBN0I7QUFDQSxnQkFBUSxLQUFSLENBQWMsNkNBQWQ7QUFDQSxZQUFJO0FBQ0EsaUJBQUssZ0JBQUwsQ0FBc0IsU0FBdEI7QUFDSCxTQUZELENBR0EsT0FBTyxHQUFQLEVBQVk7QUFDUixvQkFBUSxLQUFSLENBQWMsOEJBQWQsRUFBOEMsR0FBOUM7QUFDQSxnQkFBSSxnQkFBZ0IsS0FBSyxNQUFMLENBQVksQ0FBWixDQUFjLGFBQWxDO0FBQ0EsMEJBQWMsQ0FBZCxDQUFnQixjQUFoQixDQUErQixPQUEvQixHQUF5QyxJQUF6QztBQUNIO0FBQ0osS0FYRDtBQVlBLFFBQUksU0FBSixDQUFjLGdCQUFkLEdBQWlDLFVBQVUsU0FBVixFQUFxQixhQUFyQixFQUFvQztBQUNqRSxZQUFJLGtCQUFrQixLQUFLLENBQTNCLEVBQThCO0FBQUUsNEJBQWdCLEtBQWhCO0FBQXdCO0FBQ3hELFlBQUksZ0JBQWdCLEtBQUssTUFBTCxDQUFZLENBQVosQ0FBYyxhQUFsQztBQUNBLG9CQUFZLGFBQWEsU0FBYixDQUFaO0FBQ0EsWUFBSSxpQkFBaUIsYUFBYSxLQUFLLGlCQUF2QyxFQUEwRDtBQUN0RCxtQkFBTyxRQUFRLEtBQVIsQ0FBYyxxQkFBZCxDQUFQO0FBQ0gsU0FGRCxNQUdLLElBQUksaUJBQWlCLGNBQWMsY0FBZCxFQUFyQixFQUFxRDtBQUN0RCxtQkFBTyxRQUFRLEtBQVIsQ0FBYyx5QkFBZCxDQUFQO0FBQ0g7QUFDRDtBQUNBLFlBQUksb0JBQW9CLElBQXhCO0FBQ0EsWUFBSTtBQUNBLGdDQUFvQixxQkFBcUIsZUFBckIsQ0FBcUMsS0FBckMsQ0FBMkMsU0FBM0MsQ0FBcEI7QUFDSCxTQUZELENBR0EsT0FBTyxLQUFQLEVBQWM7QUFDVixnQkFBSSxVQUFVLENBQUMsQ0FBQyxNQUFNLE9BQVIsR0FBa0IsTUFBTSxPQUF4QixHQUFrQyw0QkFBaEQ7QUFDQSxrQkFBTSxJQUFJLE9BQU8sZ0JBQVgsQ0FBNEIsT0FBNUIsQ0FBTjtBQUNIO0FBQ0QsWUFBSSxrQkFBa0IsSUFBbEIsQ0FBdUIsTUFBM0IsRUFBbUM7QUFDL0Isa0JBQU0sSUFBSSxPQUFPLGtCQUFYLENBQThCLDZDQUE5QixDQUFOO0FBQ0g7QUFDRCxZQUFJLE9BQU8sa0JBQWtCLEtBQWxCLENBQXdCLE9BQXhCLEdBQ1AsS0FBSyxRQUFMLENBQWMsNkJBQWQsQ0FETyxHQUVQLGtCQUFrQixHQUFsQixDQUFzQixJQUF0QixHQUE2QixrQkFBa0IsR0FBbEIsQ0FBc0IsSUFBbkQsR0FDSSxLQUFLLFFBQUwsQ0FBYyxxQkFBZCxDQUhSO0FBSUEsWUFBSSxlQUFlO0FBQ2Ysa0JBQU0sa0JBQWtCLElBQWxCLENBQXVCLElBRGQ7QUFFZixrQkFBTSxrQkFBa0IsSUFBbEIsQ0FBdUIsSUFGZDtBQUdmLG9CQUFRLGtCQUFrQixNQUFsQixDQUF5QixJQUhsQjtBQUlmLHNCQUFVLGtCQUFrQixRQUFsQixDQUEyQixJQUp0QjtBQUtmLGtCQUFNO0FBTFMsU0FBbkI7QUFPQSxZQUFJLENBQUMsS0FBSyxVQUFMLENBQWdCLGNBQWhCLENBQStCLFlBQS9CLENBQUwsRUFBbUQ7QUFDL0M7QUFDQSxnQkFBSTtBQUNBLDhCQUFjLDhCQUFkLENBQTZDLFNBQTdDLEVBQXdELFlBQXhEO0FBQ0gsYUFGRCxDQUdBLE9BQU8sR0FBUCxFQUFZO0FBQ1Isd0JBQVEsS0FBUixDQUFjLDhDQUFkLEVBQThELElBQUksT0FBbEU7QUFDQSxvQkFBSSxDQUFDLGFBQUwsRUFDSSxLQUFLLGtCQUFMO0FBQ1A7QUFDSixTQVZELE1BV0ssSUFBSSxDQUFDLGFBQUwsRUFBb0I7QUFDckI7QUFDQSwwQkFBYyxLQUFkO0FBQ0EsaUJBQUssa0JBQUwsQ0FBd0IsSUFBSSxPQUFPLGtCQUFYLENBQThCLEtBQUssVUFBTCxDQUFnQixZQUFoQixDQUE2QixFQUE3QixFQUFpQyxZQUFqQyxFQUErQyxLQUFLLFVBQXBELENBQTlCLENBQXhCO0FBQ0g7QUFDSixLQWpERDtBQWtEQSxRQUFJLFNBQUosQ0FBYyxZQUFkLEdBQTZCLFVBQVUsS0FBVixFQUFpQjtBQUMxQyxZQUFJLFFBQVEsSUFBWjtBQUNBLFlBQUksV0FBVyxNQUFNLE1BQU4sQ0FBYSxRQUE1QjtBQUNBLFlBQUksU0FBUyxLQUFLLFVBQUwsQ0FBZ0IsT0FBaEIsQ0FBd0IsUUFBeEIsQ0FBYjtBQUNBLFlBQUksQ0FBQyxNQUFMLEVBQWE7QUFDVCxvQkFBUSxLQUFSLENBQWMsdUJBQXVCLFFBQXJDO0FBQ0EsbUJBQU8sS0FBSyxrQkFBTCxFQUFQO0FBQ0g7QUFDRCxZQUFJLGlCQUFpQixPQUFPLFlBQVAsR0FBc0IsSUFBdEIsQ0FBMkIsVUFBVSxTQUFWLEVBQXFCO0FBQ2pFLG1CQUFPLFlBQVksTUFBTSxnQkFBTixDQUF1QixLQUF2QixDQUFaLEdBQTRDLFFBQVEsT0FBUixFQUFuRDtBQUNILFNBRm9CLENBQXJCO0FBR0EsdUJBQWUsSUFBZixDQUFvQixZQUFZO0FBQzVCLGtCQUFNLFVBQU4sQ0FBaUIsTUFBakIsQ0FBd0IsUUFBeEI7QUFDSCxTQUZEO0FBR0gsS0FkRDtBQWVBLFFBQUksU0FBSixDQUFjLFlBQWQsR0FBNkIsVUFBVSxLQUFWLEVBQWlCO0FBQzFDLFlBQUksV0FBVyxNQUFNLE1BQU4sQ0FBYSxRQUE1QjtBQUNBLFlBQUksVUFBVSxNQUFNLE1BQU4sQ0FBYSxPQUEzQjtBQUNBLGFBQUssVUFBTCxDQUFnQixNQUFoQixDQUF1QixRQUF2QixFQUFpQyxPQUFqQztBQUNILEtBSkQ7QUFLQSxRQUFJLFNBQUosQ0FBYyxhQUFkLEdBQThCLFVBQVUsS0FBVixFQUFpQjtBQUMzQyxZQUFJLFFBQVEsSUFBWjtBQUNBLFlBQUksV0FBVyxNQUFNLE1BQU4sQ0FBYSxRQUE1QjtBQUNBLFlBQUksQ0FBQyxRQUFMLEVBQWU7QUFDWCxrQkFBTSxJQUFJLEtBQUosQ0FBVSxzQ0FBVixDQUFOO0FBQ0g7QUFDRCxZQUFJLFNBQVMsS0FBSyxtQkFBTCxDQUF5QixRQUF6QixDQUFiO0FBQ0EsWUFBSSxPQUFPLEtBQUssaUJBQUwsQ0FBdUIsUUFBdkIsQ0FBWDtBQUNBLGdCQUFRLEdBQVIsQ0FBWSwwQkFBMEIsUUFBdEM7QUFDQSxhQUFLLEtBQUwsR0FBYSxZQUFiO0FBQ0EsZUFBTyxPQUFQLEdBQWlCLElBQWpCLENBQXNCLFlBQVk7QUFDOUIsaUJBQUssS0FBTCxHQUFhLFdBQWI7QUFDQSxvQkFBUSxHQUFSLENBQVkseUJBQXlCLFFBQXJDO0FBQ0Esa0JBQU0sTUFBTixDQUFhLFNBQWIsQ0FBdUIsTUFBTSxRQUFOLENBQWUsa0JBQWYsRUFBbUMsWUFBbkMsRUFBaUQsT0FBTyxJQUF4RCxDQUF2QjtBQUNBLGtCQUFNLDBCQUFOO0FBQ0gsU0FMRCxFQUtHLFVBQVUsQ0FBVixFQUFhO0FBQ1osaUJBQUssS0FBTCxHQUFhLGNBQWI7QUFDQSxrQkFBTSxrQkFBTixDQUF5QixDQUF6QjtBQUNBLG9CQUFRLEtBQVIsQ0FBYyxpQ0FBaUMsUUFBakMsR0FBNEMsSUFBNUMsR0FBbUQsRUFBRSxJQUFuRTtBQUNBLGdCQUFJLEVBQUUsYUFBYSxPQUFPLGtCQUF0QixDQUFKLEVBQStDO0FBQzNDLHNCQUFNLGFBQU4sQ0FBb0IsTUFBcEIsQ0FBMkIseUJBQXlCLEVBQUUsSUFBdEQsRUFBNEQsb0JBQTVEO0FBQ0g7QUFDSixTQVpEO0FBYUgsS0F2QkQ7QUF3QkEsUUFBSSxTQUFKLENBQWMsMEJBQWQsR0FBMkMsWUFBWTtBQUNuRCxZQUFJLFlBQVksS0FBaEI7QUFDQSxZQUFJO0FBQ0Esd0JBQVksS0FBSyxRQUFMLENBQWMsR0FBZCxDQUFrQixXQUFXLFdBQVgsQ0FBdUIsNkJBQXpDLE1BQTRFLE1BQXhGO0FBQ0gsU0FGRCxDQUdBLE9BQU8sQ0FBUCxFQUFVO0FBQ04sb0JBQVEsS0FBUixDQUFjLHdFQUF3RSxDQUF0RjtBQUNIO0FBQ0QsWUFBSSxDQUFDLFNBQUwsRUFBZ0I7QUFDWixpQkFBSyxNQUFMLENBQVksQ0FBWixDQUFjLFdBQWQsQ0FBMEIsQ0FBMUIsQ0FBNEIsaUJBQTVCLENBQThDLElBQTlDO0FBQ0g7QUFDSixLQVhEO0FBWUEsUUFBSSxTQUFKLENBQWMsMEJBQWQsR0FBMkMsWUFBWTtBQUNuRCxhQUFLLFFBQUwsQ0FBYyxHQUFkLENBQWtCLFdBQVcsV0FBWCxDQUF1Qiw2QkFBekMsRUFBd0UsTUFBeEU7QUFDSCxLQUZEO0FBR0EsUUFBSSxTQUFKLENBQWMsZ0JBQWQsR0FBaUMsVUFBVSxLQUFWLEVBQWlCO0FBQzlDLFlBQUksUUFBUSxJQUFaO0FBQ0EsWUFBSSxXQUFXLE1BQU0sTUFBTixDQUFhLFFBQTVCO0FBQ0EsWUFBSSxDQUFDLFFBQUwsRUFBZTtBQUNYLGtCQUFNLElBQUksS0FBSixDQUFVLHlDQUFWLENBQU47QUFDSDtBQUNELFlBQUksU0FBUyxLQUFLLG1CQUFMLENBQXlCLFFBQXpCLENBQWI7QUFDQSxZQUFJLE9BQU8sS0FBSyxpQkFBTCxDQUF1QixRQUF2QixDQUFYO0FBQ0EsZ0JBQVEsR0FBUixDQUFZLCtCQUErQixRQUEzQztBQUNBLGFBQUssS0FBTCxHQUFhLGVBQWI7QUFDQSxlQUFPLFVBQVAsR0FBb0IsSUFBcEIsQ0FBeUIsWUFBWTtBQUNqQyxpQkFBSyxLQUFMLEdBQWEsY0FBYjtBQUNBLG9CQUFRLEdBQVIsQ0FBWSw4QkFBOEIsUUFBMUM7QUFDQSxrQkFBTSxNQUFOLENBQWEsU0FBYixDQUF1QixNQUFNLFFBQU4sQ0FBZSxxQkFBZixFQUFzQyxZQUF0QyxFQUFvRCxPQUFPLElBQTNELENBQXZCO0FBQ0gsU0FKRCxFQUlHLFVBQVUsQ0FBVixFQUFhO0FBQ1osaUJBQUssS0FBTCxHQUFhLFdBQWI7QUFDQSxrQkFBTSxrQkFBTixDQUF5QixDQUF6QjtBQUNBLG9CQUFRLElBQVIsQ0FBYSxzQ0FBc0MsUUFBdEMsR0FBaUQsSUFBakQsR0FBd0QsRUFBRSxJQUF2RTtBQUNILFNBUkQ7QUFTSCxLQW5CRDtBQW9CQSxRQUFJLFNBQUosQ0FBYyxjQUFkLEdBQStCLFVBQVUsS0FBVixFQUFpQjtBQUM1QyxZQUFJLFFBQVEsSUFBWjtBQUNBLFlBQUksV0FBVyxLQUFLLGNBQUwsQ0FBb0Isb0JBQXBCLEVBQWY7QUFDQSxZQUFJLENBQUMsUUFBTCxFQUFlO0FBQ1g7QUFDSDtBQUNELFlBQUksV0FBVyxTQUFTLFFBQXhCO0FBQUEsWUFBa0MsV0FBVyxTQUFTLFFBQXREO0FBQUEsWUFBZ0UsUUFBUSxTQUFTLEtBQWpGO0FBQ0EsYUFBSyxNQUFMLENBQVksQ0FBWixDQUFjLFlBQWQsQ0FBMkIsVUFBM0IsR0FBd0MsSUFBeEM7QUFDQSxhQUFLLGFBQUwsQ0FBbUIsTUFBbkIsQ0FBMEIsUUFBMUIsRUFBb0MsUUFBcEMsRUFBOEMsS0FBOUMsRUFDSyxJQURMLENBQ1UsWUFBWTtBQUNsQixrQkFBTSxNQUFOLENBQWEsQ0FBYixDQUFlLFlBQWYsQ0FBNEIsVUFBNUIsR0FBeUMsS0FBekM7QUFDQSxrQkFBTSxNQUFOLENBQWEsQ0FBYixDQUFlLFlBQWYsQ0FBNEIsU0FBNUI7QUFDQSxrQkFBTSxtQkFBTjtBQUNBLGtCQUFNLE1BQU4sQ0FBYSxTQUFiLENBQXVCLE1BQU0sTUFBTixDQUFhLFFBQWIsQ0FBc0IsaUJBQXRCLENBQXZCO0FBQ0gsU0FORCxFQU1HLFVBQVUsR0FBVixFQUFlO0FBQ2Qsa0JBQU0sTUFBTixDQUFhLENBQWIsQ0FBZSxZQUFmLENBQTRCLFVBQTVCLEdBQXlDLEtBQXpDO0FBQ0Esa0JBQU0sa0JBQU4sQ0FBeUIsSUFBSSxPQUFPLHVCQUFYLEVBQXpCO0FBQ0gsU0FURDtBQVVILEtBbEJEO0FBbUJBO0FBQ0EsUUFBSSxTQUFKLENBQWMsZUFBZCxHQUFnQyxVQUFVLEtBQVYsRUFBaUI7QUFDN0MsWUFBSSxTQUFTLE1BQU0sTUFBbkI7QUFDQSxnQkFBUSxLQUFSLENBQWMsY0FBZDtBQUNBLGFBQUssZUFBTDtBQUNBLGFBQUssMkJBQUwsQ0FBaUMsTUFBakM7QUFDQSxhQUFLLG1CQUFMO0FBQ0EsYUFBSyxNQUFMLENBQVksU0FBWixDQUFzQixLQUFLLFFBQUwsQ0FBYyxjQUFkLEVBQThCLFlBQTlCLEVBQTRDLE9BQU8sSUFBbkQsQ0FBdEI7QUFDSCxLQVBEO0FBUUEsUUFBSSxTQUFKLENBQWMsbUJBQWQsR0FBb0MsVUFBVSxLQUFWLEVBQWlCO0FBQ2pELFlBQUksUUFBUSxJQUFaO0FBQ0EsWUFBSSxTQUFTLE1BQU0sTUFBbkI7QUFDQSxnQkFBUSxLQUFSLENBQWMsa0JBQWQ7QUFDQSxhQUFLLGVBQUw7QUFDQSxhQUFLLE1BQUwsQ0FBWSxTQUFaLENBQXNCLEtBQUssUUFBTCxDQUFjLGtCQUFkLEVBQWtDLFlBQWxDLEVBQWdELE9BQU8sSUFBdkQsQ0FBdEIsRUFBb0YsS0FBcEYsRUFBMkYsS0FBSyxRQUFMLENBQWMsbUJBQWQsQ0FBM0YsRUFBK0gsWUFBWTtBQUN2SSxrQkFBTSxVQUFOLENBQWlCLFVBQWpCLENBQTRCLE9BQU8sRUFBbkM7QUFDSCxTQUZEO0FBR0gsS0FSRDtBQVNBLFFBQUksU0FBSixDQUFjLHNCQUFkLEdBQXVDLFVBQVUsS0FBVixFQUFpQjtBQUNwRCxhQUFLLGVBQUw7QUFDQSxZQUFJLFNBQVMsTUFBTSxNQUFuQjtBQUNBLGFBQUssTUFBTCxDQUFZLFNBQVosQ0FBc0IsS0FBSyxRQUFMLENBQWMsdUJBQWQsRUFBdUMsWUFBdkMsRUFBcUQsT0FBTyxJQUE1RCxDQUF0QjtBQUNILEtBSkQ7QUFLQSxRQUFJLFNBQUosQ0FBYyxpQkFBZCxHQUFrQyxVQUFVLEtBQVYsRUFBaUI7QUFDL0MsWUFBSSxTQUFTLE1BQU0sTUFBbkI7QUFDQSxnQkFBUSxLQUFSLENBQWMsZ0JBQWQ7QUFDQSxhQUFLLFlBQUwsQ0FBa0IsYUFBbEIsQ0FBZ0MsT0FBTyxFQUF2QyxFQUEyQyxVQUEzQyxHQUF3RCxPQUFPLElBQS9EO0FBQ0EsYUFBSyxNQUFMLENBQVksU0FBWixDQUFzQixLQUFLLFFBQUwsQ0FBYyx3QkFBZCxDQUF0QjtBQUNILEtBTEQ7QUFNQTtBQUNBLFFBQUksU0FBSixDQUFjLGVBQWQsR0FBZ0MsWUFBWTtBQUN4QyxhQUFLLE1BQUwsQ0FBWSxPQUFaLEdBQXNCLEtBQUssVUFBTCxDQUFnQixNQUFoQixFQUF0QjtBQUNILEtBRkQ7QUFHQSxRQUFJLFNBQUosQ0FBYyxrQ0FBZCxHQUFtRCxZQUFZO0FBQzNELFlBQUksR0FBSixFQUFTLEVBQVQ7QUFDQSxZQUFJO0FBQ0EsaUJBQUssSUFBSSxLQUFLLFNBQVMsS0FBSyxVQUFMLENBQWdCLE1BQWhCLEVBQVQsQ0FBVCxFQUE2QyxLQUFLLEdBQUcsSUFBSCxFQUF2RCxFQUFrRSxDQUFDLEdBQUcsSUFBdEUsRUFBNEUsS0FBSyxHQUFHLElBQUgsRUFBakYsRUFBNEY7QUFDeEYsb0JBQUksU0FBUyxHQUFHLEtBQWhCO0FBQ0EscUJBQUssMkJBQUwsQ0FBaUMsTUFBakM7QUFDSDtBQUNKLFNBTEQsQ0FNQSxPQUFPLEtBQVAsRUFBYztBQUFFLGtCQUFNLEVBQUUsT0FBTyxLQUFULEVBQU47QUFBeUIsU0FOekMsU0FPUTtBQUNKLGdCQUFJO0FBQ0Esb0JBQUksTUFBTSxDQUFDLEdBQUcsSUFBVixLQUFtQixLQUFLLEdBQUcsTUFBM0IsQ0FBSixFQUF3QyxHQUFHLElBQUgsQ0FBUSxFQUFSO0FBQzNDLGFBRkQsU0FHUTtBQUFFLG9CQUFJLEdBQUosRUFBUyxNQUFNLElBQUksS0FBVjtBQUFrQjtBQUN4QztBQUNKLEtBZkQ7QUFnQkEsUUFBSSxTQUFKLENBQWMsMkJBQWQsR0FBNEMsVUFBVSxNQUFWLEVBQWtCO0FBQzFELFlBQUksUUFBUSxJQUFaO0FBQ0EsZUFBTyxZQUFQLEdBQ0ssSUFETCxDQUNVLFVBQVUsU0FBVixFQUFxQjtBQUMzQixnQkFBSSxPQUFPLE1BQU0sWUFBTixDQUFtQixhQUFuQixDQUFpQyxPQUFPLEVBQXhDLENBQVg7QUFDQSxnQkFBSSxDQUFDLFNBQUwsRUFBZ0I7QUFDWixxQkFBSyxLQUFMLEdBQWEsY0FBYjtBQUNBO0FBQ0g7QUFDRCxtQkFBTyxjQUFQLEdBQXdCLElBQXhCLENBQTZCLFVBQVUsV0FBVixFQUF1QjtBQUNoRCxvQkFBSSxXQUFKLEVBQWlCO0FBQ2IseUJBQUssS0FBTCxHQUFhLFdBQWI7QUFDSCxpQkFGRCxNQUdLO0FBQ0QsNEJBQVEsR0FBUixDQUFZLFlBQVksT0FBTyxFQUFuQixHQUF3QixlQUFwQztBQUNBLHlCQUFLLEtBQUwsR0FBYSxjQUFiO0FBQ0g7QUFDSixhQVJEO0FBU0gsU0FoQkQsRUFpQkssS0FqQkwsQ0FpQlcsVUFBVSxDQUFWLEVBQWE7QUFDcEIsb0JBQVEsS0FBUixDQUFjLDBDQUFkLEVBQTBELENBQTFEO0FBQ0gsU0FuQkQ7QUFvQkgsS0F0QkQ7QUF1QkEsUUFBSSxTQUFKLENBQWMsK0JBQWQsR0FBZ0QsVUFBVSxjQUFWLEVBQTBCO0FBQ3RFLFlBQUksUUFBUSxJQUFaO0FBQ0EsdUJBQWUsZ0JBQWYsQ0FBZ0MsVUFBVSxHQUFWLEVBQWU7QUFDM0MsZ0JBQUksQ0FBQyxHQUFELElBQVEsQ0FBQyxhQUFhLEdBQWIsRUFBa0IsVUFBbEIsQ0FBNkIsT0FBN0IsQ0FBYixFQUFvRDtBQUNoRDtBQUNBO0FBQ0E7QUFDQSx1QkFBTyxRQUFRLEtBQVIsQ0FBYywwQ0FBZCxDQUFQO0FBQ0g7QUFDRCxnQkFBSTtBQUNBLHNCQUFNLGdCQUFOLENBQXVCLEdBQXZCO0FBQ0gsYUFGRCxDQUdBLE9BQU8sR0FBUCxFQUFZO0FBQ1Isc0JBQU0sK0JBQU4sQ0FBc0MsR0FBdEM7QUFDSDtBQUNKLFNBYkQ7QUFjSCxLQWhCRDtBQWlCQSxRQUFJLFNBQUosQ0FBYyxtQkFBZCxHQUFvQyxZQUFZO0FBQzVDLGFBQUssTUFBTCxDQUFZLFVBQVosQ0FBdUIsS0FBSyxNQUFMLENBQVksWUFBbkM7QUFDSCxLQUZEO0FBR0E7QUFDQSxRQUFJLFNBQUosQ0FBYyxtQkFBZCxHQUFvQyxVQUFVLFFBQVYsRUFBb0I7QUFDcEQsWUFBSSxTQUFTLEtBQUssVUFBTCxDQUFnQixPQUFoQixDQUF3QixRQUF4QixDQUFiO0FBQ0EsWUFBSSxDQUFDLE1BQUwsRUFBYTtBQUNULGtCQUFNLElBQUksS0FBSixDQUFVLG1DQUFtQyxRQUE3QyxDQUFOO0FBQ0g7QUFDRCxlQUFPLE1BQVA7QUFDSCxLQU5EO0FBT0E7QUFDQTtBQUNBLFFBQUksU0FBSixDQUFjLGlCQUFkLEdBQWtDLFVBQVUsUUFBVixFQUFvQjtBQUNsRCxlQUFPLEtBQUssWUFBTCxDQUFrQixhQUFsQixDQUFnQyxRQUFoQyxDQUFQO0FBQ0gsS0FGRDtBQUdBLFFBQUksU0FBSixDQUFjLCtCQUFkLEdBQWdELFVBQVUsR0FBVixFQUFlO0FBQzNELGFBQUssbUJBQUw7QUFDQSxhQUFLLGtCQUFMLENBQXdCLEdBQXhCO0FBQ0gsS0FIRDtBQUlBLFFBQUksU0FBSixDQUFjLFNBQWQsR0FBMEIsWUFBWTtBQUNsQyxlQUFPLEVBQUUsYUFBYSxNQUFmLENBQVA7QUFDSCxLQUZEO0FBR0EsV0FBTyxHQUFQO0FBQ0gsQ0F6ZXdCLEVBQXpCO0FBMGVBLFFBQVEsR0FBUixHQUFjLEdBQWQ7OztBQ3BqQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxPQUFPLGNBQVAsQ0FBc0IsT0FBdEIsRUFBK0IsWUFBL0IsRUFBNkMsRUFBRSxPQUFPLElBQVQsRUFBN0M7QUFDQTtBQUNBLElBQUksb0JBQW9CLGFBQWUsWUFBWTtBQUMvQyxhQUFTLGlCQUFULEdBQTZCO0FBQ3pCLGFBQUssUUFBTCxHQUFnQixJQUFoQjtBQUNIO0FBQ0Qsc0JBQWtCLFNBQWxCLENBQTRCLFdBQTVCLEdBQTBDLFlBQVk7QUFDbEQsZUFBTyxRQUFRLE1BQVIsQ0FBZSxJQUFJLEtBQUosQ0FBVSwrQkFBVixDQUFmLENBQVA7QUFDSCxLQUZEO0FBR0Esc0JBQWtCLFNBQWxCLENBQTRCLFdBQTVCLEdBQTBDLFVBQVUsUUFBVixFQUFvQjtBQUMxRCxhQUFLLFFBQUwsR0FBZ0IsUUFBaEI7QUFDSCxLQUZEO0FBR0Esc0JBQWtCLFNBQWxCLENBQTRCLFNBQTVCLEdBQXdDLFlBQVk7QUFDaEQsWUFBSSxLQUFLLFFBQVQsRUFBbUI7QUFDZixpQkFBSyxXQUFMLEdBQW1CLElBQW5CLENBQXdCLEtBQUssUUFBN0I7QUFDSDtBQUNKLEtBSkQ7QUFLQSxXQUFPLGlCQUFQO0FBQ0gsQ0FoQnNDLEVBQXZDO0FBaUJBLFFBQVEsaUJBQVIsR0FBNEIsaUJBQTVCOzs7QUNqQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxJQUFJLFlBQWEsYUFBUSxVQUFLLFNBQWQsSUFBNkIsWUFBWTtBQUNyRCxRQUFJLGlCQUFnQix1QkFBVSxDQUFWLEVBQWEsQ0FBYixFQUFnQjtBQUNoQyx5QkFBZ0IsT0FBTyxjQUFQLElBQ1gsRUFBRSxXQUFXLEVBQWIsY0FBNkIsS0FBN0IsSUFBc0MsVUFBVSxDQUFWLEVBQWEsQ0FBYixFQUFnQjtBQUFFLGNBQUUsU0FBRixHQUFjLENBQWQ7QUFBa0IsU0FEL0QsSUFFWixVQUFVLENBQVYsRUFBYSxDQUFiLEVBQWdCO0FBQUUsaUJBQUssSUFBSSxDQUFULElBQWMsQ0FBZDtBQUFpQixvQkFBSSxFQUFFLGNBQUYsQ0FBaUIsQ0FBakIsQ0FBSixFQUF5QixFQUFFLENBQUYsSUFBTyxFQUFFLENBQUYsQ0FBUDtBQUExQztBQUF3RCxTQUY5RTtBQUdBLGVBQU8sZUFBYyxDQUFkLEVBQWlCLENBQWpCLENBQVA7QUFDSCxLQUxEO0FBTUEsV0FBTyxVQUFVLENBQVYsRUFBYSxDQUFiLEVBQWdCO0FBQ25CLHVCQUFjLENBQWQsRUFBaUIsQ0FBakI7QUFDQSxpQkFBUyxFQUFULEdBQWM7QUFBRSxpQkFBSyxXQUFMLEdBQW1CLENBQW5CO0FBQXVCO0FBQ3ZDLFVBQUUsU0FBRixHQUFjLE1BQU0sSUFBTixHQUFhLE9BQU8sTUFBUCxDQUFjLENBQWQsQ0FBYixJQUFpQyxHQUFHLFNBQUgsR0FBZSxFQUFFLFNBQWpCLEVBQTRCLElBQUksRUFBSixFQUE3RCxDQUFkO0FBQ0gsS0FKRDtBQUtILENBWjJDLEVBQTVDO0FBYUEsT0FBTyxjQUFQLENBQXNCLE9BQXRCLEVBQStCLFlBQS9CLEVBQTZDLEVBQUUsT0FBTyxJQUFULEVBQTdDO0FBQ0E7QUFDQTtBQUNBLElBQUksUUFBUSxRQUFRLFVBQVIsQ0FBWjtBQUNBLElBQUksY0FBYyxRQUFRLGFBQVIsQ0FBbEI7QUFDQSxJQUFJLG1CQUFtQixRQUFRLGtCQUFSLENBQXZCO0FBQ0EsSUFBSSxvQkFBb0IsUUFBUSxtQkFBUixDQUF4QjtBQUNBLElBQUksU0FBUyxRQUFRLFFBQVIsQ0FBYjtBQUNBLElBQUksbUJBQW1CLFFBQVEsa0JBQVIsQ0FBdkI7QUFDQSxJQUFJLFlBQVksUUFBUSxXQUFSLENBQWhCO0FBQ0EsSUFBSSxlQUFlLFFBQVEsbUJBQVIsQ0FBbkI7QUFDQTtBQUNBLElBQUksbUJBQW1CLGFBQWUsVUFBVSxNQUFWLEVBQWtCO0FBQ3BELGNBQVUsZ0JBQVYsRUFBNEIsTUFBNUI7QUFDQSxhQUFTLGdCQUFULEdBQTRCO0FBQ3hCLFlBQUksUUFBUSxPQUFPLElBQVAsQ0FBWSxJQUFaLEtBQXFCLElBQWpDO0FBQ0EsaUJBQVMsZ0JBQVQsQ0FBMEIsUUFBMUIsRUFBb0MsTUFBTSxTQUFOLENBQWdCLElBQWhCLENBQXFCLEtBQXJCLENBQXBDO0FBQ0EsZUFBTyxLQUFQO0FBQ0g7QUFDRCxxQkFBaUIsU0FBakIsQ0FBMkIsV0FBM0IsR0FBeUMsWUFBWTtBQUNqRCxlQUFPLElBQUksT0FBSixDQUFZLFVBQVUsT0FBVixFQUFtQixNQUFuQixFQUEyQjtBQUMxQyxvQkFBUSxPQUFSLENBQWdCLFNBQWhCLENBQTBCLEtBQTFCLENBQWdDLE9BQWhDLEVBQXlDLE1BQXpDO0FBQ0gsU0FGTSxDQUFQO0FBR0gsS0FKRDtBQUtBLFdBQU8sZ0JBQVA7QUFDSCxDQWJxQyxDQWFwQyxZQUFZLGlCQWJ3QixDQUF0QztBQWNBO0FBQ0EsSUFBSSx1QkFBdUIsYUFBZSxVQUFVLE1BQVYsRUFBa0I7QUFDeEQsY0FBVSxvQkFBVixFQUFnQyxNQUFoQztBQUNBLGFBQVMsb0JBQVQsQ0FBOEIsVUFBOUIsRUFBMEMsY0FBMUMsRUFBMEQsR0FBMUQsRUFBK0QsU0FBL0QsRUFBMEU7QUFDdEUsWUFBSSxRQUFRLE9BQU8sSUFBUCxDQUFZLElBQVosRUFBa0IsVUFBbEIsRUFBOEIsR0FBOUIsRUFBbUMsRUFBRSxnQkFBZ0IsY0FBbEIsRUFBbkMsS0FBMEUsSUFBdEY7QUFDQSxnQkFBUSxPQUFSLENBQWdCLE9BQWhCLENBQXdCLEdBQXhCLENBQTRCLFVBQTVCLENBQXVDLFNBQXZDLEVBQWtELEtBQWxELENBQXdELFFBQVEsS0FBaEU7QUFDQSxlQUFPLEtBQVA7QUFDSDtBQUNELHlCQUFxQixTQUFyQixDQUErQixNQUEvQixHQUF3QyxVQUFVLFlBQVYsRUFBd0IsZ0JBQXhCLEVBQTBDLFNBQTFDLEVBQXFEO0FBQ3pGLGVBQU8sT0FBTyxTQUFQLENBQWlCLE1BQWpCLENBQXdCLElBQXhCLENBQTZCLElBQTdCLEVBQW1DLFlBQW5DLEVBQWlELGdCQUFqRCxFQUFtRSxTQUFuRSxFQUE4RSxJQUE5RSxDQUFtRixZQUFZO0FBQ2xHLG1CQUFPLFFBQVEsT0FBUixDQUFnQixPQUFoQixDQUF3QixHQUF4QixDQUE0QixJQUE1QixDQUFpQyxNQUFNLFdBQU4sRUFBakMsQ0FBUDtBQUNILFNBRk0sQ0FBUDtBQUdILEtBSkQ7QUFLQSxXQUFPLG9CQUFQO0FBQ0gsQ0FieUMsQ0FheEMsaUJBQWlCLG1CQWJ1QixDQUExQztBQWNBLFFBQVEsb0JBQVIsR0FBK0Isb0JBQS9CO0FBQ0E7QUFDQSxJQUFJLGtCQUFrQixhQUFlLFlBQVk7QUFDN0MsYUFBUyxlQUFULEdBQTJCLENBQzFCO0FBQ0Qsb0JBQWdCLFNBQWhCLEdBQTRCLFlBQVk7QUFDcEMsZUFBTyxPQUFPLFFBQVAsS0FBb0IsU0FBM0I7QUFDSCxLQUZEO0FBR0Esb0JBQWdCLFNBQWhCLENBQTBCLGdCQUExQixHQUE2QyxZQUFZO0FBQ3JELGVBQU8sQ0FBQyxnQkFBZ0IsU0FBaEIsRUFBUjtBQUNILEtBRkQ7QUFHQSxvQkFBZ0IsU0FBaEIsQ0FBMEIsMEJBQTFCLEdBQXVELFlBQVk7QUFDL0QsWUFBSSxRQUFRLElBQVo7QUFDQSxlQUFPLFVBQVUsUUFBVixFQUFvQixNQUFwQixFQUE0QixVQUE1QixFQUF3QztBQUMzQyxtQkFBTyxJQUFJLGlCQUFpQixhQUFyQixDQUFtQyxRQUFuQyxFQUE2QyxNQUE3QyxFQUFxRCxNQUFNLGdCQUFOLEtBQTJCLElBQUksUUFBUSxPQUFSLENBQWdCLE9BQWhCLENBQXdCLFVBQTVCLENBQXVDLE1BQXZDLEVBQStDLFFBQS9DLENBQTNCLEdBQ3hELElBQUksa0JBQWtCLHFCQUF0QixDQUE0QyxNQUE1QyxFQUFvRCxRQUFwRCxDQURHLEVBQzRELFVBRDVELENBQVA7QUFFSCxTQUhEO0FBSUgsS0FORDtBQU9BLG9CQUFnQixTQUFoQixDQUEwQixpQkFBMUIsR0FBOEMsWUFBWTtBQUN0RCxZQUFJLE9BQU8sUUFBUCxLQUFvQixLQUFwQixJQUE2QixPQUFPLFFBQVAsS0FBb0IsVUFBckQsRUFBaUU7QUFDN0QsbUJBQU8sSUFBSSxhQUFhLG1CQUFqQixDQUFxQyxjQUFyQyxDQUFQO0FBQ0gsU0FGRCxNQUdLLElBQUksT0FBTyxRQUFQLEtBQW9CLFNBQXhCLEVBQW1DO0FBQ3BDLG1CQUFPLElBQUksYUFBYSxxQkFBakIsRUFBUDtBQUNIO0FBQ0QsZ0JBQVEsSUFBUixDQUFhLGlDQUFiO0FBQ0EsZUFBTyxJQUFJLGFBQWEsY0FBakIsRUFBUDtBQUNILEtBVEQ7QUFVQSxvQkFBZ0IsU0FBaEIsQ0FBMEIsWUFBMUIsR0FBeUMsWUFBWTtBQUNqRCxlQUFPLElBQUksZ0JBQUosRUFBUDtBQUNILEtBRkQ7QUFHQSxvQkFBZ0IsU0FBaEIsQ0FBMEIsZ0JBQTFCLEdBQTZDLFVBQVUsR0FBVixFQUFlO0FBQ3hELGVBQU8sS0FBSyxnQkFBTCxLQUNILElBQUksb0JBQUosQ0FBeUIsSUFBSSxXQUE3QixFQUEwQyxJQUFJLGdCQUE5QyxFQUFnRSxJQUFJLFVBQXBFLEVBQWdGLElBQUksaUJBQXBGLENBREcsR0FFSCxJQUFJLGlCQUFpQixtQkFBckIsQ0FBeUMsSUFBSSxXQUE3QyxFQUEwRCxJQUFJLFVBQTlELEVBQTBFLEVBQTFFLENBRko7QUFHSCxLQUpEO0FBS0Esb0JBQWdCLFNBQWhCLENBQTBCLFVBQTFCLEdBQXVDLFlBQVk7QUFDL0MsZUFBTyxJQUFJLFVBQVUsZUFBZCxFQUFQO0FBQ0gsS0FGRDtBQUdBLG9CQUFnQixTQUFoQixDQUEwQixlQUExQixHQUE0QyxZQUFZO0FBQ3BEO0FBQ0EsZ0JBQVEsT0FBUixDQUFnQixPQUFoQixDQUF3QixlQUF4QjtBQUNILEtBSEQ7QUFJQSxXQUFPLGVBQVA7QUFDSCxDQTFDb0MsRUFBckM7QUEyQ0E7QUFDQSxJQUFJLGtCQUFrQixJQUFJLE9BQUosQ0FBWSxVQUFVLE9BQVYsRUFBbUI7QUFDakQsYUFBUyxnQkFBVCxDQUEwQixhQUExQixFQUF5QyxPQUF6QztBQUNILENBRnFCLENBQXRCO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLGNBQUo7QUFDQSxPQUFPLGFBQVAsR0FBdUIsVUFBVSxHQUFWLEVBQWU7QUFDbEMscUJBQWlCLEdBQWpCO0FBQ0gsQ0FGRDtBQUdBLGdCQUFnQixJQUFoQixDQUFxQixZQUFZO0FBQzdCLFdBQU8sSUFBUCxDQUFZLElBQUksZUFBSixFQUFaO0FBQ0gsQ0FGRDs7O0FDN0hBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxjQUFQLENBQXNCLE9BQXRCLEVBQStCLFlBQS9CLEVBQTZDLEVBQUUsT0FBTyxJQUFULEVBQTdDO0FBQ0E7QUFDQSxJQUFJLFdBQVc7QUFDWCxpQkFBYSxhQURGO0FBRVgsc0JBQWtCLGtCQUZQO0FBR1gsZ0JBQVksWUFIRDtBQUlYLGdCQUFZLFlBSkQ7QUFLWCx1QkFBbUI7QUFMUixDQUFmO0FBT0EsU0FBUyxlQUFULENBQXlCLElBQXpCLEVBQStCO0FBQzNCLFNBQUssSUFBSSxHQUFULElBQWdCLFFBQWhCLEVBQTBCO0FBQ3RCLFlBQUksQ0FBQyxLQUFLLGNBQUwsQ0FBb0IsR0FBcEIsQ0FBTCxFQUErQjtBQUMzQixrQkFBTSxJQUFJLEtBQUosQ0FBVSxtQ0FBbUMsR0FBN0MsQ0FBTjtBQUNIO0FBQ0o7QUFDSjtBQUNEO0FBQ0E7QUFDQSxRQUFRLFdBQVIsR0FBc0IsSUFBSSxPQUFKLENBQVksVUFBVSxPQUFWLEVBQW1CLE1BQW5CLEVBQTJCO0FBQ3pELFFBQUksTUFBTSxJQUFJLGNBQUosRUFBVjtBQUNBLFFBQUksTUFBSixHQUFhLFlBQVk7QUFDckIsWUFBSTtBQUNBLGdCQUFJLE9BQU8sS0FBSyxLQUFMLENBQVcsSUFBSSxZQUFmLENBQVg7QUFDQSw0QkFBZ0IsSUFBaEI7QUFDQSxvQkFBUSxLQUFSLENBQWMseUJBQWQsRUFBeUMsSUFBekM7QUFDQSxvQkFBUSxJQUFSO0FBQ0gsU0FMRCxDQU1BLE9BQU8sR0FBUCxFQUFZO0FBQ1IsbUJBQU8sR0FBUDtBQUNIO0FBQ0osS0FWRDtBQVdBLFFBQUksSUFBSixDQUFTLEtBQVQsRUFBZ0Isa0JBQWhCLEVBQW9DLElBQXBDO0FBQ0EsUUFBSSxJQUFKO0FBQ0gsQ0FmcUIsQ0FBdEI7OztBQ2hDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLE9BQU8sY0FBUCxDQUFzQixPQUF0QixFQUErQixZQUEvQixFQUE2QyxFQUFFLE9BQU8sSUFBVCxFQUE3QztBQUNBLElBQUksUUFBUSxRQUFRLFVBQVIsQ0FBWjtBQUNBLElBQUksc0JBQXNCLGFBQWUsWUFBWTtBQUNqRCxhQUFTLG1CQUFULENBQTZCLFVBQTdCLEVBQXlDLEdBQXpDLEVBQThDLElBQTlDLEVBQW9EO0FBQ2hELGNBQU0sTUFBTixDQUFhLEdBQWIsRUFBa0IsRUFBRSxTQUFTLFVBQVgsRUFBdUIsUUFBUSxJQUEvQixFQUFsQixFQUF5RCxPQUF6RDtBQUNBLGFBQUssK0JBQUw7QUFDSDtBQUNELHdCQUFvQixTQUFwQixDQUE4QixNQUE5QixHQUF1QyxVQUFVLFlBQVYsRUFBd0IsZ0JBQXhCLEVBQTBDLFNBQTFDLEVBQXFEO0FBQ3hGLGNBQU0sY0FBTixDQUFxQixFQUFFLE9BQU8sYUFBYSxFQUF0QixFQUFyQjtBQUNBLGNBQU0sY0FBTixDQUFxQixZQUFyQixFQUFtQyxFQUFFLE1BQU0sRUFBRSxVQUFVLGdCQUFaLEVBQVIsRUFBbkM7QUFDQSxjQUFNLGNBQU4sR0FId0YsQ0FHaEU7QUFDeEIsZUFBTyxRQUFRLE9BQVIsRUFBUDtBQUNILEtBTEQ7QUFNQSx3QkFBb0IsU0FBcEIsQ0FBOEIsK0JBQTlCLEdBQWdFLFlBQVk7QUFDeEU7QUFDQTtBQUNBLFlBQUkscUJBQXFCLG9CQUF6QjtBQUNBLGVBQU8sZ0JBQVAsQ0FBd0Isa0JBQXhCLEVBQTRDLFVBQVUsS0FBVixFQUFpQjtBQUN6RCxnQkFBSSxTQUFTLE1BQU0sTUFBbkI7QUFDQSxnQkFBSSxNQUFNLE9BQU8sS0FBUCxHQUFlLE9BQU8sS0FBdEIsR0FBOEIsTUFBeEM7QUFDQSxrQkFBTSxpQkFBTixDQUF3QixFQUFFLFNBQVMsR0FBWCxFQUFnQixVQUFVLGtCQUExQixFQUF4QjtBQUNILFNBSkQ7QUFLSCxLQVREO0FBVUEsV0FBTyxtQkFBUDtBQUNILENBdEJ3QyxFQUF6QztBQXVCQSxRQUFRLG1CQUFSLEdBQThCLG1CQUE5Qjs7O0FDdkNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxjQUFQLENBQXNCLE9BQXRCLEVBQStCLFlBQS9CLEVBQTZDLEVBQUUsT0FBTyxJQUFULEVBQTdDO0FBQ0E7QUFDQSxJQUFJLFNBQVMsUUFBUSxpQkFBUixDQUFiO0FBQ0E7QUFDQTtBQUNBLElBQUksd0JBQXdCLGFBQWUsWUFBWTtBQUNuRCxhQUFTLHFCQUFULENBQStCLE1BQS9CLEVBQXVDLEVBQXZDLEVBQTJDO0FBQ3ZDLGFBQUssTUFBTCxHQUFjLE1BQWQ7QUFDQSxhQUFLLEVBQUwsR0FBVSxFQUFWO0FBQ0EsYUFBSyxPQUFMLEdBQWUsS0FBZjtBQUNIO0FBQ0QsMEJBQXNCLFNBQXRCLENBQWdDLFVBQWhDLEdBQTZDLFlBQVk7QUFDckQsZUFBTyxLQUFLLE1BQUwsQ0FBWSxJQUFaLElBQW9CLEtBQUssTUFBTCxDQUFZLElBQVosQ0FBaUIsV0FBakIsR0FBK0IsUUFBL0IsQ0FBd0MsUUFBeEMsQ0FBM0I7QUFDSCxLQUZEO0FBR0EsMEJBQXNCLFNBQXRCLENBQWdDLGVBQWhDLEdBQWtELFlBQVk7QUFDMUQsZUFBTyxFQUFFLEtBQUssTUFBTCxDQUFZLElBQVosSUFBb0IsS0FBSyxNQUFMLENBQVksSUFBWixDQUFpQixXQUFqQixHQUErQixRQUEvQixDQUF3QyxhQUF4QyxDQUF0QixDQUFQO0FBQ0gsS0FGRDtBQUdBLDBCQUFzQixTQUF0QixDQUFnQyxLQUFoQyxHQUF3QyxZQUFZO0FBQ2hELFlBQUksS0FBSyxPQUFULEVBQWtCO0FBQ2QsbUJBQU8sUUFBUSxPQUFSLEVBQVA7QUFDSDtBQUNELFlBQUksQ0FBQyxLQUFLLGVBQUwsRUFBTCxFQUE2QjtBQUN6QixtQkFBTyxRQUFRLE1BQVIsQ0FBZSxJQUFJLE9BQU8sa0JBQVgsQ0FBOEIsQ0FBOUIsQ0FBZ0Msd0JBQWhDLENBQWYsQ0FBUDtBQUNILFNBRkQsTUFHSyxJQUFJLEtBQUssVUFBTCxFQUFKLEVBQXVCO0FBQ3hCLG1CQUFPLFFBQVEsTUFBUixDQUFlLElBQUksT0FBTyxrQkFBWCxDQUE4QixDQUE5QixDQUFnQywrQkFBaEMsQ0FBZixDQUFQO0FBQ0gsU0FGSSxNQUdBO0FBQ0QsaUJBQUssT0FBTCxHQUFlLElBQWY7QUFDQSxtQkFBTyxRQUFRLE9BQVIsRUFBUDtBQUNIO0FBQ0osS0FkRDtBQWVBLDBCQUFzQixTQUF0QixDQUFnQyxJQUFoQyxHQUF1QyxZQUFZO0FBQy9DLFlBQUksQ0FBQyxLQUFLLE9BQVYsRUFBbUI7QUFDZixtQkFBTyxRQUFRLE9BQVIsRUFBUDtBQUNIO0FBQ0QsYUFBSyxPQUFMLEdBQWUsS0FBZjtBQUNBLGVBQU8sUUFBUSxPQUFSLEVBQVA7QUFDSCxLQU5EO0FBT0EsMEJBQXNCLFNBQXRCLENBQWdDLFNBQWhDLEdBQTRDLFlBQVk7QUFDcEQsZUFBTyxRQUFRLE9BQVIsQ0FBZ0IsS0FBSyxPQUFyQixDQUFQO0FBQ0gsS0FGRDtBQUdBLDBCQUFzQixTQUF0QixDQUFnQyxXQUFoQyxHQUE4QyxZQUFZO0FBQ3RELGVBQU8sUUFBUSxPQUFSLENBQWdCLENBQUMsS0FBSyxlQUFMLEVBQWpCLENBQVA7QUFDSCxLQUZEO0FBR0EsMEJBQXNCLFNBQXRCLENBQWdDLGNBQWhDLEdBQWlELFVBQVUsUUFBVixFQUFvQjtBQUNqRTtBQUNILEtBRkQ7QUFHQSxXQUFPLHFCQUFQO0FBQ0gsQ0E1QzBDLEVBQTNDO0FBNkNBLFFBQVEscUJBQVIsR0FBZ0MscUJBQWhDOzs7QUNoRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxJQUFJLFNBQVUsYUFBUSxVQUFLLE1BQWQsSUFBeUIsVUFBVSxDQUFWLEVBQWEsQ0FBYixFQUFnQjtBQUNsRCxRQUFJLElBQUksT0FBTyxNQUFQLEtBQWtCLFVBQWxCLElBQWdDLEVBQUUsT0FBTyxRQUFULENBQXhDO0FBQ0EsUUFBSSxDQUFDLENBQUwsRUFBUSxPQUFPLENBQVA7QUFDUixRQUFJLElBQUksRUFBRSxJQUFGLENBQU8sQ0FBUCxDQUFSO0FBQUEsUUFBbUIsQ0FBbkI7QUFBQSxRQUFzQixLQUFLLEVBQTNCO0FBQUEsUUFBK0IsQ0FBL0I7QUFDQSxRQUFJO0FBQ0EsZUFBTyxDQUFDLE1BQU0sS0FBSyxDQUFYLElBQWdCLE1BQU0sQ0FBdkIsS0FBNkIsQ0FBQyxDQUFDLElBQUksRUFBRSxJQUFGLEVBQUwsRUFBZSxJQUFwRDtBQUEwRCxlQUFHLElBQUgsQ0FBUSxFQUFFLEtBQVY7QUFBMUQ7QUFDSCxLQUZELENBR0EsT0FBTyxLQUFQLEVBQWM7QUFBRSxZQUFJLEVBQUUsT0FBTyxLQUFULEVBQUo7QUFBdUIsS0FIdkMsU0FJUTtBQUNKLFlBQUk7QUFDQSxnQkFBSSxLQUFLLENBQUMsRUFBRSxJQUFSLEtBQWlCLElBQUksRUFBRSxRQUFGLENBQXJCLENBQUosRUFBdUMsRUFBRSxJQUFGLENBQU8sQ0FBUDtBQUMxQyxTQUZELFNBR1E7QUFBRSxnQkFBSSxDQUFKLEVBQU8sTUFBTSxFQUFFLEtBQVI7QUFBZ0I7QUFDcEM7QUFDRCxXQUFPLEVBQVA7QUFDSCxDQWZEO0FBZ0JBLE9BQU8sY0FBUCxDQUFzQixPQUF0QixFQUErQixZQUEvQixFQUE2QyxFQUFFLE9BQU8sSUFBVCxFQUE3QztBQUNBLElBQUksTUFBTSxRQUFRLEtBQVIsQ0FBVjtBQUNBLElBQUksV0FBVyxRQUFRLGlCQUFSLENBQWY7QUFDQSxJQUFJLFFBQVEsUUFBUSxPQUFSLENBQVo7QUFDQSxJQUFJLGdCQUFnQixRQUFRLGVBQVIsQ0FBcEI7QUFDQSxJQUFJLHNCQUFzQixRQUFRLHFCQUFSLENBQTFCO0FBQ0EsSUFBSSxhQUFhLFFBQVEsWUFBUixDQUFqQjtBQUNBO0FBQ0EsSUFBSSx3QkFBd0IsS0FBNUI7QUFDQSxTQUFTLGdCQUFULENBQTBCLG9CQUExQixFQUFnRCxZQUFZO0FBQ3hELFlBQVEsS0FBUixDQUFjLG1DQUFkO0FBQ0EsNEJBQXdCLElBQXhCO0FBQ0gsQ0FIRDtBQUlBO0FBQ0E7QUFDQSxJQUFJLHFCQUFxQixJQUFJLE9BQUosQ0FBWSxVQUFVLE9BQVYsRUFBbUI7QUFDcEQsYUFBUyxnQkFBVCxDQUEwQiwrQkFBMUIsRUFBMkQsWUFBWTtBQUNuRSxnQkFBUSxLQUFSLENBQWMsOENBQWQ7QUFDQTtBQUNILEtBSEQ7QUFJSCxDQUx3QixDQUF6QjtBQU1BO0FBQ0E7QUFDQSxTQUFTLFNBQVQsR0FBcUI7QUFDakIsV0FBTyxTQUFTLGFBQVQsQ0FBdUIsVUFBdkIsQ0FBUDtBQUNIO0FBQ0QsU0FBUyxnQkFBVCxDQUEwQixVQUExQixFQUFzQyxPQUF0QyxFQUErQyxhQUEvQyxFQUE4RCxjQUE5RCxFQUE4RTtBQUMxRSxRQUFJLE9BQU8sSUFBSSxvQkFBb0IsMEJBQXhCLENBQW1ELGNBQW5ELEVBQW1FLFVBQW5FLEVBQStFLE9BQS9FLENBQVg7QUFDQSxRQUFJLENBQUMsYUFBTCxFQUFvQjtBQUNoQixnQkFBUSxLQUFSLENBQWMsdURBQWQ7QUFDQSxZQUFJLEtBQUssTUFBTCxHQUFjLE1BQWQsS0FBeUIsQ0FBN0IsRUFBZ0M7QUFDNUIsaUJBQUssR0FBTCxDQUFTLEVBQUUsTUFBTSxxQkFBUixFQUErQixNQUFNLFdBQXJDLEVBQWtELE1BQU0sR0FBeEQsRUFBVDtBQUNBLGlCQUFLLEdBQUwsQ0FBUyxFQUFFLE1BQU0sb0JBQVIsRUFBOEIsTUFBTSxXQUFwQyxFQUFpRCxNQUFNLEdBQXZELEVBQVQ7QUFDQSxpQkFBSyxHQUFMLENBQVMsRUFBRSxNQUFNLHlCQUFSLEVBQW1DLE1BQU0sV0FBekMsRUFBc0QsTUFBTSxHQUE1RCxFQUFUO0FBQ0g7QUFDSjtBQUNELFdBQU8sSUFBUDtBQUNIO0FBQ0QsU0FBUyxJQUFULENBQWMsUUFBZCxFQUF3QjtBQUNwQixXQUFPLFFBQVEsR0FBUixDQUFZLENBQUMsY0FBYyxXQUFmLEVBQTRCLGtCQUE1QixDQUFaLEVBQ0YsSUFERSxDQUNHLFVBQVUsRUFBVixFQUFjO0FBQ3BCLFlBQUksS0FBSyxPQUFPLEVBQVAsRUFBVyxDQUFYLENBQVQ7QUFBQSxZQUF3QixrQkFBa0IsR0FBRyxDQUFILENBQTFDO0FBQ0EsZ0JBQVEsS0FBUixDQUFjLHlCQUFkO0FBQ0EsWUFBSSxjQUFjLElBQUksS0FBSixDQUFVLFNBQVMsR0FBbkIsRUFBd0IsSUFBeEIsRUFBOEIsS0FBaEQ7QUFDQSxZQUFJLFlBQVksWUFBWSxLQUFaLEtBQXNCLE1BQXRDO0FBQ0EsWUFBSSxhQUFhLElBQUksU0FBUyxVQUFiLEVBQWpCO0FBQ0EsWUFBSSxhQUFhLGlCQUFpQixVQUFqQixFQUE2QixPQUFPLFlBQXBDLEVBQWtELFNBQVMsZ0JBQVQsRUFBbEQsRUFBK0UsU0FBUywwQkFBVCxFQUEvRSxDQUFqQjtBQUNBLFlBQUksV0FBVyxJQUFJLFdBQVcsUUFBZixFQUFmO0FBQ0EsWUFBSSxNQUFNLElBQUksTUFBTSxHQUFWLENBQWMsVUFBZCxFQUEwQixVQUExQixFQUFzQyxXQUF0QyxFQUFtRCxTQUFuRCxFQUE4RCxTQUFTLGlCQUFULEVBQTlELEVBQTRGLFNBQVMsWUFBVCxFQUE1RixFQUFxSCxTQUFTLGdCQUFULENBQTBCLGVBQTFCLENBQXJILEVBQWlLLFFBQWpLLEVBQTJLLGVBQTNLLEVBQTRMLFNBQVMsVUFBVCxFQUE1TCxFQUFtTixTQUFTLGVBQTVOLENBQVY7QUFDSCxLQVZNLEVBVUosVUFBVSxDQUFWLEVBQWE7QUFDWiwwQkFBa0IsQ0FBbEI7QUFDQSxjQUFNLENBQU47QUFDSCxLQWJNLENBQVA7QUFjSDtBQUNELFFBQVEsSUFBUixHQUFlLElBQWY7QUFDQSxTQUFTLGlCQUFULENBQTJCLEtBQTNCLEVBQWtDO0FBQzlCLFFBQUksU0FBUyxXQUFiO0FBQ0EsUUFBSSx5QkFBeUIsTUFBekIsSUFBbUMsT0FBTyxRQUE5QyxFQUF3RDtBQUNwRCxZQUFJLFdBQVcsT0FBTyxRQUFQLENBQWdCLElBQWhCLENBQXFCLE1BQXJCLENBQWY7QUFDQSxlQUFPLFNBQVAsQ0FBaUIsU0FBUyxrQkFBVCxDQUFqQixFQUErQyxNQUEvQztBQUNILEtBSEQsTUFJSztBQUNEO0FBQ0E7QUFDQTtBQUNBLGNBQU0sK0JBQU47QUFDSDtBQUNELFlBQVEsS0FBUixDQUFjLEtBQWQ7QUFDSDtBQUNEO0FBQ0EsU0FBUyx1QkFBVCxHQUFtQztBQUMvQixRQUFJLFNBQVMsV0FBYjtBQUNBLFFBQUksQ0FBQyxNQUFMLEVBQWE7QUFDVCxlQUFPLElBQVA7QUFDSDtBQUNELFdBQU8sT0FBTyxRQUFkO0FBQ0g7QUFDRCxRQUFRLHVCQUFSLEdBQWtDLHVCQUFsQzs7O0FDM0dBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxjQUFQLENBQXNCLE9BQXRCLEVBQStCLFlBQS9CLEVBQTZDLEVBQUUsT0FBTyxJQUFULEVBQTdDO0FBQ0E7QUFDQSxJQUFJLFNBQVMsUUFBUSxpQkFBUixDQUFiO0FBQ0EsSUFBSSxTQUFTLFFBQVEsaUJBQVIsQ0FBYjtBQUNBLElBQUksZ0JBQWdCLGFBQWUsWUFBWTtBQUMzQyxhQUFTLGFBQVQsQ0FBdUIsRUFBdkIsRUFBMkIsTUFBM0IsRUFBbUMsVUFBbkMsRUFBK0MsVUFBL0MsRUFBMkQ7QUFDdkQsWUFBSSxRQUFRLElBQVo7QUFDQSxhQUFLLEVBQUwsR0FBVSxFQUFWO0FBQ0EsYUFBSyxNQUFMLEdBQWMsTUFBZDtBQUNBLGFBQUssVUFBTCxHQUFrQixVQUFsQjtBQUNBLGFBQUssVUFBTCxHQUFrQixVQUFsQjtBQUNBLGFBQUssVUFBTCxDQUFnQixjQUFoQixDQUErQixVQUFVLE1BQVYsRUFBa0I7QUFDN0MsZ0JBQUksV0FBSjtBQUNBLG9CQUFRLE1BQVI7QUFDSSxxQkFBSyxDQUFMLENBQU8sZUFBUDtBQUNJLGtDQUFjLElBQUksT0FBTyxlQUFYLENBQTJCLEtBQTNCLENBQWQ7QUFDQTtBQUNKLHFCQUFLLENBQUwsQ0FBTyxrQkFBUDtBQUNJLGtDQUFjLElBQUksT0FBTyxrQkFBWCxDQUE4QixLQUE5QixDQUFkO0FBQ0E7QUFDSixxQkFBSyxDQUFMLENBQU8sa0JBQVA7QUFDSSxrQ0FBYyxJQUFJLE9BQU8sa0JBQVgsQ0FBOEIsS0FBOUIsQ0FBZDtBQUNBO0FBQ0o7QUFDSSw0QkFBUSxJQUFSLENBQWEsd0NBQXdDLE1BQXJEO0FBQ0E7QUFaUjtBQWNBLHVCQUFXLE9BQVgsQ0FBbUIsV0FBbkI7QUFDSCxTQWpCRDtBQWtCSDtBQUNELFdBQU8sY0FBUCxDQUFzQixjQUFjLFNBQXBDLEVBQStDLE1BQS9DLEVBQXVEO0FBQ25ELGFBQUssZUFBWTtBQUNiLG1CQUFPLEtBQUssTUFBTCxDQUFZLElBQVosSUFBb0IsS0FBSyxNQUFMLENBQVksSUFBaEMsSUFBd0MsRUFBL0M7QUFDSCxTQUhrRDtBQUluRCxhQUFLLGFBQVUsT0FBVixFQUFtQjtBQUNwQixpQkFBSyxNQUFMLENBQVksSUFBWixHQUFtQixPQUFuQjtBQUNILFNBTmtEO0FBT25ELG9CQUFZLElBUHVDO0FBUW5ELHNCQUFjO0FBUnFDLEtBQXZEO0FBVUEsV0FBTyxjQUFQLENBQXNCLGNBQWMsU0FBcEMsRUFBK0MsTUFBL0MsRUFBdUQ7QUFDbkQsYUFBSyxlQUFZO0FBQ2IsbUJBQU8sS0FBSyxNQUFMLENBQVksSUFBbkI7QUFDSCxTQUhrRDtBQUluRCxvQkFBWSxJQUp1QztBQUtuRCxzQkFBYztBQUxxQyxLQUF2RDtBQU9BLGtCQUFjLFNBQWQsQ0FBd0IsT0FBeEIsR0FBa0MsWUFBWTtBQUMxQyxlQUFPLEtBQUssVUFBTCxDQUFnQixLQUFoQixHQUF3QixLQUF4QixDQUE4QixVQUFVLENBQVYsRUFBYTtBQUM5QztBQUNBO0FBQ0EsZ0JBQUksRUFBRSxTQUFOLEVBQWlCO0FBQ2Isc0JBQU0sT0FBTyxhQUFQLENBQXFCLEVBQUUsU0FBdkIsQ0FBTjtBQUNIO0FBQ0Qsa0JBQU0sQ0FBTjtBQUNILFNBUE0sQ0FBUDtBQVFILEtBVEQ7QUFVQSxrQkFBYyxTQUFkLENBQXdCLFVBQXhCLEdBQXFDLFlBQVk7QUFDN0MsZUFBTyxLQUFLLFVBQUwsQ0FBZ0IsSUFBaEIsR0FBdUIsS0FBdkIsQ0FBNkIsVUFBVSxDQUFWLEVBQWE7QUFDN0M7QUFDQSxrQkFBTSxJQUFJLE9BQU8sa0JBQVgsRUFBTjtBQUNILFNBSE0sQ0FBUDtBQUlILEtBTEQ7QUFNQSxrQkFBYyxTQUFkLENBQXdCLFlBQXhCLEdBQXVDLFlBQVk7QUFDL0MsZUFBTyxLQUFLLFVBQUwsQ0FBZ0IsU0FBaEIsRUFBUDtBQUNILEtBRkQ7QUFHQSxrQkFBYyxTQUFkLENBQXdCLGNBQXhCLEdBQXlDLFlBQVk7QUFDakQsZUFBTyxLQUFLLFVBQUwsQ0FBZ0IsV0FBaEIsRUFBUDtBQUNILEtBRkQ7QUFHQSxXQUFPLGFBQVA7QUFDSCxDQWxFa0MsRUFBbkM7QUFtRUEsUUFBUSxhQUFSLEdBQXdCLGFBQXhCOzs7QUNyRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxJQUFJLFdBQVksYUFBUSxVQUFLLFFBQWQsSUFBMkIsVUFBVSxDQUFWLEVBQWE7QUFDbkQsUUFBSSxJQUFJLE9BQU8sTUFBUCxLQUFrQixVQUFsQixJQUFnQyxFQUFFLE9BQU8sUUFBVCxDQUF4QztBQUFBLFFBQTRELElBQUksQ0FBaEU7QUFDQSxRQUFJLENBQUosRUFBTyxPQUFPLEVBQUUsSUFBRixDQUFPLENBQVAsQ0FBUDtBQUNQLFdBQU87QUFDSCxjQUFNLGdCQUFZO0FBQ2QsZ0JBQUksS0FBSyxLQUFLLEVBQUUsTUFBaEIsRUFBd0IsSUFBSSxLQUFLLENBQVQ7QUFDeEIsbUJBQU8sRUFBRSxPQUFPLEtBQUssRUFBRSxHQUFGLENBQWQsRUFBc0IsTUFBTSxDQUFDLENBQTdCLEVBQVA7QUFDSDtBQUpFLEtBQVA7QUFNSCxDQVREO0FBVUEsT0FBTyxjQUFQLENBQXNCLE9BQXRCLEVBQStCLFlBQS9CLEVBQTZDLEVBQUUsT0FBTyxJQUFULEVBQTdDO0FBQ0EsSUFBSSxTQUFTLFFBQVEsUUFBUixDQUFiO0FBQ0EsSUFBSSxXQUFXLFFBQVEsaUJBQVIsQ0FBZjtBQUNBLElBQUksU0FBUyxRQUFRLGlCQUFSLENBQWI7QUFDQTtBQUNBLElBQUksNkJBQTZCLGFBQWUsWUFBWTtBQUN4RCxhQUFTLDBCQUFULENBQW9DLFlBQXBDLEVBQWtELFVBQWxELEVBQThELE9BQTlELEVBQXVFO0FBQ25FLGFBQUssWUFBTCxHQUFvQixZQUFwQjtBQUNBLGFBQUssVUFBTCxHQUFrQixVQUFsQjtBQUNBLGFBQUssT0FBTCxHQUFlLE9BQWY7QUFDQSxhQUFLLG1CQUFMLEdBQTJCLElBQTNCO0FBQ0EsYUFBSyxXQUFMO0FBQ0g7QUFDRCwrQkFBMkIsU0FBM0IsQ0FBcUMsTUFBckMsR0FBOEMsWUFBWTtBQUN0RCxlQUFPLE1BQU0sSUFBTixDQUFXLEtBQUssVUFBTCxDQUFnQixNQUFoQixFQUFYLENBQVA7QUFDSCxLQUZEO0FBR0EsK0JBQTJCLFNBQTNCLENBQXFDLE9BQXJDLEdBQStDLFVBQVUsUUFBVixFQUFvQjtBQUMvRCxlQUFPLEtBQUssVUFBTCxDQUFnQixHQUFoQixDQUFvQixRQUFwQixDQUFQO0FBQ0gsS0FGRDtBQUdBLCtCQUEyQixTQUEzQixDQUFxQyxHQUFyQyxHQUEyQyxVQUFVLFlBQVYsRUFBd0I7QUFDL0QsWUFBSSxxQkFBcUIsS0FBSyxnQkFBTCxDQUFzQixZQUF0QixDQUF6QjtBQUNBLFlBQUksa0JBQUosRUFBd0I7QUFDcEIsa0JBQU0sSUFBSSxTQUFTLGtCQUFiLENBQWdDLGtCQUFoQyxDQUFOO0FBQ0g7QUFDRCxZQUFJLFNBQVMsS0FBSyxZQUFMLENBQWtCLFFBQWxCLEVBQTRCLFlBQTVCLEVBQTBDLEtBQUssVUFBL0MsQ0FBYjtBQUNBLGFBQUssVUFBTCxDQUFnQixHQUFoQixDQUFvQixPQUFPLEVBQTNCLEVBQStCLE1BQS9CO0FBQ0EsYUFBSyxZQUFMO0FBQ0EsYUFBSyxVQUFMLENBQWdCLE9BQWhCLENBQXdCLElBQUksT0FBTyxXQUFYLENBQXVCLE1BQXZCLENBQXhCO0FBQ0gsS0FURDtBQVVBLCtCQUEyQixTQUEzQixDQUFxQyxNQUFyQyxHQUE4QyxVQUFVLFFBQVYsRUFBb0IsT0FBcEIsRUFBNkI7QUFDdkUsWUFBSSxTQUFTLEtBQUssVUFBTCxDQUFnQixHQUFoQixDQUFvQixRQUFwQixDQUFiO0FBQ0EsWUFBSSxDQUFDLE1BQUwsRUFBYTtBQUNULG9CQUFRLElBQVIsQ0FBYSxzQ0FBc0MsUUFBbkQ7QUFDQTtBQUNIO0FBQ0QsZUFBTyxJQUFQLEdBQWMsT0FBZDtBQUNBLGFBQUssWUFBTDtBQUNBLGFBQUssVUFBTCxDQUFnQixPQUFoQixDQUF3QixJQUFJLE9BQU8sYUFBWCxDQUF5QixNQUF6QixDQUF4QjtBQUNILEtBVEQ7QUFVQSwrQkFBMkIsU0FBM0IsQ0FBcUMsTUFBckMsR0FBOEMsVUFBVSxRQUFWLEVBQW9CO0FBQzlELFlBQUksU0FBUyxLQUFLLFVBQUwsQ0FBZ0IsR0FBaEIsQ0FBb0IsUUFBcEIsQ0FBYjtBQUNBLFlBQUksQ0FBQyxNQUFMLEVBQWE7QUFDVCxvQkFBUSxJQUFSLENBQWEsc0NBQXNDLFFBQW5EO0FBQ0E7QUFDSDtBQUNELGFBQUssVUFBTCxDQUFnQixNQUFoQixDQUF1QixRQUF2QjtBQUNBLGFBQUssbUJBQUwsR0FBMkIsTUFBM0I7QUFDQSxhQUFLLFlBQUw7QUFDQSxhQUFLLFVBQUwsQ0FBZ0IsT0FBaEIsQ0FBd0IsSUFBSSxPQUFPLGVBQVgsQ0FBMkIsTUFBM0IsQ0FBeEI7QUFDSCxLQVZEO0FBV0EsK0JBQTJCLFNBQTNCLENBQXFDLFVBQXJDLEdBQWtELFVBQVUsUUFBVixFQUFvQjtBQUNsRSxZQUFJLENBQUMsS0FBSyxtQkFBVixFQUErQjtBQUMzQixvQkFBUSxJQUFSLENBQWEsaUNBQWI7QUFDQTtBQUNILFNBSEQsTUFJSyxJQUFJLEtBQUssbUJBQUwsQ0FBeUIsRUFBekIsS0FBZ0MsUUFBcEMsRUFBOEM7QUFDL0Msb0JBQVEsSUFBUixDQUFhLHdCQUFiLEVBQXVDLEtBQUssbUJBQTVDLEVBQWlFLGdCQUFqRSxFQUFtRixRQUFuRjtBQUNBO0FBQ0g7QUFDRCxhQUFLLFVBQUwsQ0FBZ0IsR0FBaEIsQ0FBb0IsS0FBSyxtQkFBTCxDQUF5QixFQUE3QyxFQUFpRCxLQUFLLG1CQUF0RDtBQUNBLGFBQUssWUFBTDtBQUNBLGFBQUssVUFBTCxDQUFnQixPQUFoQixDQUF3QixJQUFJLE9BQU8sa0JBQVgsQ0FBOEIsS0FBSyxtQkFBbkMsQ0FBeEI7QUFDQSxhQUFLLG1CQUFMLEdBQTJCLElBQTNCO0FBQ0gsS0FiRDtBQWNBLCtCQUEyQixTQUEzQixDQUFxQyxjQUFyQyxHQUFzRCxVQUFVLE1BQVYsRUFBa0I7QUFDcEUsZUFBTyxDQUFDLENBQUMsS0FBSyxnQkFBTCxDQUFzQixNQUF0QixDQUFUO0FBQ0gsS0FGRDtBQUdBLCtCQUEyQixTQUEzQixDQUFxQyxnQkFBckMsR0FBd0QsVUFBVSxNQUFWLEVBQWtCO0FBQ3RFLFlBQUksR0FBSixFQUFTLEVBQVQ7QUFDQSxZQUFJO0FBQ0EsaUJBQUssSUFBSSxLQUFLLFNBQVMsS0FBSyxNQUFMLEVBQVQsQ0FBVCxFQUFrQyxLQUFLLEdBQUcsSUFBSCxFQUE1QyxFQUF1RCxDQUFDLEdBQUcsSUFBM0QsRUFBaUUsS0FBSyxHQUFHLElBQUgsRUFBdEUsRUFBaUY7QUFDN0Usb0JBQUksU0FBUyxHQUFHLEtBQWhCO0FBQ0Esb0JBQUksYUFBYSxPQUFPLE1BQXBCLEVBQTRCLE1BQTVCLENBQUosRUFBeUM7QUFDckMsMkJBQU8sTUFBUDtBQUNIO0FBQ0o7QUFDSixTQVBELENBUUEsT0FBTyxLQUFQLEVBQWM7QUFBRSxrQkFBTSxFQUFFLE9BQU8sS0FBVCxFQUFOO0FBQXlCLFNBUnpDLFNBU1E7QUFDSixnQkFBSTtBQUNBLG9CQUFJLE1BQU0sQ0FBQyxHQUFHLElBQVYsS0FBbUIsS0FBSyxHQUFHLE1BQTNCLENBQUosRUFBd0MsR0FBRyxJQUFILENBQVEsRUFBUjtBQUMzQyxhQUZELFNBR1E7QUFBRSxvQkFBSSxHQUFKLEVBQVMsTUFBTSxJQUFJLEtBQVY7QUFBa0I7QUFDeEM7QUFDSixLQWpCRDtBQWtCQSwrQkFBMkIsU0FBM0IsQ0FBcUMsWUFBckMsR0FBb0QsWUFBWTtBQUM1RCxZQUFJLEdBQUosRUFBUyxFQUFUO0FBQ0EsWUFBSSxhQUFhLEVBQWpCO0FBQ0EsWUFBSTtBQUNBLGlCQUFLLElBQUksS0FBSyxTQUFTLEtBQUssVUFBTCxDQUFnQixNQUFoQixFQUFULENBQVQsRUFBNkMsS0FBSyxHQUFHLElBQUgsRUFBdkQsRUFBa0UsQ0FBQyxHQUFHLElBQXRFLEVBQTRFLEtBQUssR0FBRyxJQUFILEVBQWpGLEVBQTRGO0FBQ3hGLG9CQUFJLFNBQVMsR0FBRyxLQUFoQjtBQUNBLDJCQUFXLE9BQU8sRUFBbEIsSUFBd0IsT0FBTyxNQUEvQjtBQUNIO0FBQ0osU0FMRCxDQU1BLE9BQU8sS0FBUCxFQUFjO0FBQUUsa0JBQU0sRUFBRSxPQUFPLEtBQVQsRUFBTjtBQUF5QixTQU56QyxTQU9RO0FBQ0osZ0JBQUk7QUFDQSxvQkFBSSxNQUFNLENBQUMsR0FBRyxJQUFWLEtBQW1CLEtBQUssR0FBRyxNQUEzQixDQUFKLEVBQXdDLEdBQUcsSUFBSCxDQUFRLEVBQVI7QUFDM0MsYUFGRCxTQUdRO0FBQUUsb0JBQUksR0FBSixFQUFTLE1BQU0sSUFBSSxLQUFWO0FBQWtCO0FBQ3hDO0FBQ0QsWUFBSSxPQUFPLEtBQUssU0FBTCxDQUFlLFVBQWYsQ0FBWDtBQUNBLGFBQUssT0FBTCxDQUFhLE9BQWIsQ0FBcUIsMkJBQTJCLG1CQUFoRCxFQUFxRSxJQUFyRTtBQUNILEtBbEJEO0FBbUJBO0FBQ0E7QUFDQSwrQkFBMkIsU0FBM0IsQ0FBcUMsV0FBckMsR0FBbUQsWUFBWTtBQUMzRCxhQUFLLFVBQUwsR0FBa0IsSUFBSSxHQUFKLEVBQWxCO0FBQ0EsWUFBSSxjQUFjLEtBQUssT0FBTCxDQUFhLE9BQWIsQ0FBcUIsMkJBQTJCLG1CQUFoRCxDQUFsQjtBQUNBLFlBQUksQ0FBQyxXQUFMLEVBQWtCO0FBQ2Qsb0JBQVEsS0FBUixDQUFjLDZCQUFkO0FBQ0E7QUFDSDtBQUNELFlBQUksYUFBYSxFQUFqQjtBQUNBLFlBQUk7QUFDQSx5QkFBYSxLQUFLLEtBQUwsQ0FBVyxXQUFYLENBQWI7QUFDSCxTQUZELENBR0EsT0FBTyxDQUFQLEVBQVU7QUFDTixrQkFBTSxJQUFJLEtBQUosQ0FBVSxvQ0FBb0MsRUFBRSxPQUFoRCxDQUFOO0FBQ0g7QUFDRCxhQUFLLElBQUksUUFBVCxJQUFxQixVQUFyQixFQUFpQztBQUM3QixnQkFBSSxXQUFXLGNBQVgsQ0FBMEIsUUFBMUIsQ0FBSixFQUF5QztBQUNyQyxvQkFBSSxTQUFTLFdBQVcsUUFBWCxDQUFiO0FBQ0Esb0JBQUk7QUFDQSx3QkFBSSxTQUFTLEtBQUssWUFBTCxDQUFrQixRQUFsQixFQUE0QixNQUE1QixFQUFvQyxLQUFLLFVBQXpDLENBQWI7QUFDQSx5QkFBSyxVQUFMLENBQWdCLEdBQWhCLENBQW9CLFFBQXBCLEVBQThCLE1BQTlCO0FBQ0gsaUJBSEQsQ0FJQSxPQUFPLENBQVAsRUFBVTtBQUNOO0FBQ0EsNEJBQVEsS0FBUixDQUFjLENBQWQ7QUFDSDtBQUNKO0FBQ0o7QUFDSixLQTNCRDtBQTRCQTtBQUNBLCtCQUEyQixtQkFBM0IsR0FBaUQsU0FBakQ7QUFDQSxXQUFPLDBCQUFQO0FBQ0gsQ0FwSStDLEVBQWhEO0FBcUlBLFFBQVEsMEJBQVIsR0FBcUMsMEJBQXJDO0FBQ0EsU0FBUyxZQUFULENBQXNCLElBQXRCLEVBQTRCLEtBQTVCLEVBQW1DO0FBQy9CLFdBQU8sS0FBSyxJQUFMLEtBQWMsTUFBTSxJQUFwQixJQUE0QixLQUFLLElBQUwsS0FBYyxNQUFNLElBQWhELElBQXdELEtBQUssTUFBTCxLQUFnQixNQUFNLE1BQTlFLElBQ0gsS0FBSyxRQUFMLEtBQWtCLE1BQU0sUUFENUI7QUFFSDs7O0FDdEtEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsSUFBSSxXQUFZLGFBQVEsVUFBSyxRQUFkLElBQTJCLFVBQVUsQ0FBVixFQUFhO0FBQ25ELFFBQUksSUFBSSxPQUFPLE1BQVAsS0FBa0IsVUFBbEIsSUFBZ0MsRUFBRSxPQUFPLFFBQVQsQ0FBeEM7QUFBQSxRQUE0RCxJQUFJLENBQWhFO0FBQ0EsUUFBSSxDQUFKLEVBQU8sT0FBTyxFQUFFLElBQUYsQ0FBTyxDQUFQLENBQVA7QUFDUCxXQUFPO0FBQ0gsY0FBTSxnQkFBWTtBQUNkLGdCQUFJLEtBQUssS0FBSyxFQUFFLE1BQWhCLEVBQXdCLElBQUksS0FBSyxDQUFUO0FBQ3hCLG1CQUFPLEVBQUUsT0FBTyxLQUFLLEVBQUUsR0FBRixDQUFkLEVBQXNCLE1BQU0sQ0FBQyxDQUE3QixFQUFQO0FBQ0g7QUFKRSxLQUFQO0FBTUgsQ0FURDtBQVVBLElBQUksU0FBVSxhQUFRLFVBQUssTUFBZCxJQUF5QixVQUFVLENBQVYsRUFBYSxDQUFiLEVBQWdCO0FBQ2xELFFBQUksSUFBSSxPQUFPLE1BQVAsS0FBa0IsVUFBbEIsSUFBZ0MsRUFBRSxPQUFPLFFBQVQsQ0FBeEM7QUFDQSxRQUFJLENBQUMsQ0FBTCxFQUFRLE9BQU8sQ0FBUDtBQUNSLFFBQUksSUFBSSxFQUFFLElBQUYsQ0FBTyxDQUFQLENBQVI7QUFBQSxRQUFtQixDQUFuQjtBQUFBLFFBQXNCLEtBQUssRUFBM0I7QUFBQSxRQUErQixDQUEvQjtBQUNBLFFBQUk7QUFDQSxlQUFPLENBQUMsTUFBTSxLQUFLLENBQVgsSUFBZ0IsTUFBTSxDQUF2QixLQUE2QixDQUFDLENBQUMsSUFBSSxFQUFFLElBQUYsRUFBTCxFQUFlLElBQXBEO0FBQTBELGVBQUcsSUFBSCxDQUFRLEVBQUUsS0FBVjtBQUExRDtBQUNILEtBRkQsQ0FHQSxPQUFPLEtBQVAsRUFBYztBQUFFLFlBQUksRUFBRSxPQUFPLEtBQVQsRUFBSjtBQUF1QixLQUh2QyxTQUlRO0FBQ0osWUFBSTtBQUNBLGdCQUFJLEtBQUssQ0FBQyxFQUFFLElBQVIsS0FBaUIsSUFBSSxFQUFFLFFBQUYsQ0FBckIsQ0FBSixFQUF1QyxFQUFFLElBQUYsQ0FBTyxDQUFQO0FBQzFDLFNBRkQsU0FHUTtBQUFFLGdCQUFJLENBQUosRUFBTyxNQUFNLEVBQUUsS0FBUjtBQUFnQjtBQUNwQztBQUNELFdBQU8sRUFBUDtBQUNILENBZkQ7QUFnQkEsT0FBTyxjQUFQLENBQXNCLE9BQXRCLEVBQStCLFlBQS9CLEVBQTZDLEVBQUUsT0FBTyxJQUFULEVBQTdDO0FBQ0E7QUFDQSxJQUFJLFdBQUo7QUFDQSxDQUFDLFVBQVUsV0FBVixFQUF1QjtBQUNwQixnQkFBWSx1QkFBWixJQUF1Qyx1QkFBdkM7QUFDQSxnQkFBWSwrQkFBWixJQUErQywrQkFBL0M7QUFDQSxnQkFBWSxhQUFaLElBQTZCLGFBQTdCO0FBQ0EsZ0JBQVksVUFBWixJQUEwQixVQUExQjtBQUNILENBTEQsRUFLRyxjQUFjLFFBQVEsV0FBUixLQUF3QixRQUFRLFdBQVIsR0FBc0IsRUFBOUMsQ0FMakI7QUFNQTtBQUNBLElBQUksV0FBVyxhQUFlLFlBQVk7QUFDdEMsYUFBUyxRQUFULENBQWtCLE9BQWxCLEVBQTJCLFNBQTNCLEVBQXNDO0FBQ2xDLFlBQUksWUFBWSxLQUFLLENBQXJCLEVBQXdCO0FBQUUsc0JBQVUsT0FBTyxZQUFqQjtBQUFnQztBQUMxRCxZQUFJLGNBQWMsS0FBSyxDQUF2QixFQUEwQjtBQUFFLHdCQUFZLE9BQU8sTUFBUCxDQUFjLFdBQWQsQ0FBWjtBQUF5QztBQUNyRSxhQUFLLE9BQUwsR0FBZSxPQUFmO0FBQ0EsYUFBSyxTQUFMLEdBQWlCLFNBQWpCO0FBQ0EsYUFBSyxRQUFMLEdBQWdCLElBQUksR0FBSixFQUFoQjtBQUNBLGFBQUssWUFBTDtBQUNIO0FBQ0QsYUFBUyxTQUFULENBQW1CLEdBQW5CLEdBQXlCLFVBQVUsR0FBVixFQUFlO0FBQ3BDLGVBQU8sS0FBSyxRQUFMLENBQWMsR0FBZCxDQUFrQixHQUFsQixDQUFQO0FBQ0gsS0FGRDtBQUdBLGFBQVMsU0FBVCxDQUFtQixHQUFuQixHQUF5QixVQUFVLEdBQVYsRUFBZSxLQUFmLEVBQXNCO0FBQzNDLFlBQUksQ0FBQyxLQUFLLGNBQUwsQ0FBb0IsR0FBcEIsQ0FBTCxFQUErQjtBQUMzQixrQkFBTSxJQUFJLEtBQUosQ0FBVSw0QkFBNEIsR0FBdEMsQ0FBTjtBQUNIO0FBQ0QsYUFBSyxRQUFMLENBQWMsR0FBZCxDQUFrQixHQUFsQixFQUF1QixLQUF2QjtBQUNBLGFBQUssYUFBTDtBQUNILEtBTkQ7QUFPQSxhQUFTLFNBQVQsQ0FBbUIsTUFBbkIsR0FBNEIsVUFBVSxHQUFWLEVBQWU7QUFDdkMsYUFBSyxRQUFMLENBQWMsTUFBZCxDQUFxQixHQUFyQjtBQUNBLGFBQUssYUFBTDtBQUNILEtBSEQ7QUFJQSxhQUFTLFNBQVQsQ0FBbUIsY0FBbkIsR0FBb0MsVUFBVSxHQUFWLEVBQWU7QUFDL0MsZUFBTyxLQUFLLFNBQUwsQ0FBZSxRQUFmLENBQXdCLEdBQXhCLENBQVA7QUFDSCxLQUZEO0FBR0EsYUFBUyxTQUFULENBQW1CLFlBQW5CLEdBQWtDLFlBQVk7QUFDMUMsWUFBSSxlQUFlLEtBQUssT0FBTCxDQUFhLE9BQWIsQ0FBcUIsU0FBUyxXQUE5QixDQUFuQjtBQUNBLFlBQUksQ0FBQyxZQUFMLEVBQW1CO0FBQ2Ysb0JBQVEsS0FBUixDQUFjLDhCQUFkO0FBQ0E7QUFDSDtBQUNELFlBQUksa0JBQWtCLEtBQUssS0FBTCxDQUFXLFlBQVgsQ0FBdEI7QUFDQSxhQUFLLElBQUksR0FBVCxJQUFnQixlQUFoQixFQUFpQztBQUM3QixnQkFBSSxnQkFBZ0IsY0FBaEIsQ0FBK0IsR0FBL0IsQ0FBSixFQUF5QztBQUNyQyxxQkFBSyxRQUFMLENBQWMsR0FBZCxDQUFrQixHQUFsQixFQUF1QixnQkFBZ0IsR0FBaEIsQ0FBdkI7QUFDSDtBQUNKO0FBQ0osS0FaRDtBQWFBLGFBQVMsU0FBVCxDQUFtQixhQUFuQixHQUFtQyxZQUFZO0FBQzNDLFlBQUksR0FBSixFQUFTLEVBQVQ7QUFDQSxZQUFJLGtCQUFrQixFQUF0QjtBQUNBLFlBQUk7QUFDQSxpQkFBSyxJQUFJLEtBQUssU0FBUyxLQUFLLFFBQWQsQ0FBVCxFQUFrQyxLQUFLLEdBQUcsSUFBSCxFQUE1QyxFQUF1RCxDQUFDLEdBQUcsSUFBM0QsRUFBaUUsS0FBSyxHQUFHLElBQUgsRUFBdEUsRUFBaUY7QUFDN0Usb0JBQUksS0FBSyxPQUFPLEdBQUcsS0FBVixFQUFpQixDQUFqQixDQUFUO0FBQUEsb0JBQThCLE1BQU0sR0FBRyxDQUFILENBQXBDO0FBQUEsb0JBQTJDLFFBQVEsR0FBRyxDQUFILENBQW5EO0FBQ0EsZ0NBQWdCLEdBQWhCLElBQXVCLEtBQXZCO0FBQ0g7QUFDSixTQUxELENBTUEsT0FBTyxLQUFQLEVBQWM7QUFBRSxrQkFBTSxFQUFFLE9BQU8sS0FBVCxFQUFOO0FBQXlCLFNBTnpDLFNBT1E7QUFDSixnQkFBSTtBQUNBLG9CQUFJLE1BQU0sQ0FBQyxHQUFHLElBQVYsS0FBbUIsS0FBSyxHQUFHLE1BQTNCLENBQUosRUFBd0MsR0FBRyxJQUFILENBQVEsRUFBUjtBQUMzQyxhQUZELFNBR1E7QUFBRSxvQkFBSSxHQUFKLEVBQVMsTUFBTSxJQUFJLEtBQVY7QUFBa0I7QUFDeEM7QUFDRCxZQUFJLHNCQUFzQixLQUFLLFNBQUwsQ0FBZSxlQUFmLENBQTFCO0FBQ0EsYUFBSyxPQUFMLENBQWEsT0FBYixDQUFxQixTQUFTLFdBQTlCLEVBQTJDLG1CQUEzQztBQUNILEtBbEJEO0FBbUJBLGFBQVMsV0FBVCxHQUF1QixVQUF2QjtBQUNBLFdBQU8sUUFBUDtBQUNILENBNUQ2QixFQUE5QjtBQTZEQSxRQUFRLFFBQVIsR0FBbUIsUUFBbkI7OztBQy9HQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLE9BQU8sY0FBUCxDQUFzQixPQUF0QixFQUErQixZQUEvQixFQUE2QyxFQUFFLE9BQU8sSUFBVCxFQUE3QztBQUNBLElBQUksa0JBQWtCLGFBQWUsWUFBWTtBQUM3QyxhQUFTLGVBQVQsR0FBMkI7QUFDdkIsYUFBSyxRQUFMLEdBQWdCLElBQWhCO0FBQ0g7QUFDRCxvQkFBZ0IsU0FBaEIsQ0FBMEIsV0FBMUIsR0FBd0MsVUFBVSxRQUFWLEVBQW9CO0FBQ3hELGFBQUssUUFBTCxHQUFnQixRQUFoQjtBQUNILEtBRkQ7QUFHQSxvQkFBZ0IsU0FBaEIsQ0FBMEIsU0FBMUIsR0FBc0MsWUFBWTtBQUM5QyxZQUFJLEtBQUssUUFBVCxFQUFtQjtBQUNmLGlCQUFLLFFBQUw7QUFDSDtBQUNKLEtBSkQ7QUFLQSxXQUFPLGVBQVA7QUFDSCxDQWJvQyxFQUFyQztBQWNBLFFBQVEsZUFBUixHQUEwQixlQUExQjs7O0FDN0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsSUFBSSxZQUFhLGFBQVEsVUFBSyxTQUFkLElBQTZCLFlBQVk7QUFDckQsUUFBSSxpQkFBZ0IsdUJBQVUsQ0FBVixFQUFhLENBQWIsRUFBZ0I7QUFDaEMseUJBQWdCLE9BQU8sY0FBUCxJQUNYLEVBQUUsV0FBVyxFQUFiLGNBQTZCLEtBQTdCLElBQXNDLFVBQVUsQ0FBVixFQUFhLENBQWIsRUFBZ0I7QUFBRSxjQUFFLFNBQUYsR0FBYyxDQUFkO0FBQWtCLFNBRC9ELElBRVosVUFBVSxDQUFWLEVBQWEsQ0FBYixFQUFnQjtBQUFFLGlCQUFLLElBQUksQ0FBVCxJQUFjLENBQWQ7QUFBaUIsb0JBQUksRUFBRSxjQUFGLENBQWlCLENBQWpCLENBQUosRUFBeUIsRUFBRSxDQUFGLElBQU8sRUFBRSxDQUFGLENBQVA7QUFBMUM7QUFBd0QsU0FGOUU7QUFHQSxlQUFPLGVBQWMsQ0FBZCxFQUFpQixDQUFqQixDQUFQO0FBQ0gsS0FMRDtBQU1BLFdBQU8sVUFBVSxDQUFWLEVBQWEsQ0FBYixFQUFnQjtBQUNuQix1QkFBYyxDQUFkLEVBQWlCLENBQWpCO0FBQ0EsaUJBQVMsRUFBVCxHQUFjO0FBQUUsaUJBQUssV0FBTCxHQUFtQixDQUFuQjtBQUF1QjtBQUN2QyxVQUFFLFNBQUYsR0FBYyxNQUFNLElBQU4sR0FBYSxPQUFPLE1BQVAsQ0FBYyxDQUFkLENBQWIsSUFBaUMsR0FBRyxTQUFILEdBQWUsRUFBRSxTQUFqQixFQUE0QixJQUFJLEVBQUosRUFBN0QsQ0FBZDtBQUNILEtBSkQ7QUFLSCxDQVoyQyxFQUE1QztBQWFBLElBQUksV0FBWSxhQUFRLFVBQUssUUFBZCxJQUEyQixVQUFVLENBQVYsRUFBYTtBQUNuRCxRQUFJLElBQUksT0FBTyxNQUFQLEtBQWtCLFVBQWxCLElBQWdDLEVBQUUsT0FBTyxRQUFULENBQXhDO0FBQUEsUUFBNEQsSUFBSSxDQUFoRTtBQUNBLFFBQUksQ0FBSixFQUFPLE9BQU8sRUFBRSxJQUFGLENBQU8sQ0FBUCxDQUFQO0FBQ1AsV0FBTztBQUNILGNBQU0sZ0JBQVk7QUFDZCxnQkFBSSxLQUFLLEtBQUssRUFBRSxNQUFoQixFQUF3QixJQUFJLEtBQUssQ0FBVDtBQUN4QixtQkFBTyxFQUFFLE9BQU8sS0FBSyxFQUFFLEdBQUYsQ0FBZCxFQUFzQixNQUFNLENBQUMsQ0FBN0IsRUFBUDtBQUNIO0FBSkUsS0FBUDtBQU1ILENBVEQ7QUFVQSxPQUFPLGNBQVAsQ0FBc0IsT0FBdEIsRUFBK0IsWUFBL0IsRUFBNkMsRUFBRSxPQUFPLElBQVQsRUFBN0M7QUFDQTtBQUNBLElBQUksaUJBQWlCLGFBQWUsWUFBWTtBQUM1QyxhQUFTLGNBQVQsR0FBMEI7QUFDdEIsYUFBSyxTQUFMLEdBQWlCLEVBQWpCO0FBQ0g7QUFDRCxtQkFBZSxTQUFmLENBQXlCLGdCQUF6QixHQUE0QyxVQUFVLFFBQVYsRUFBb0I7QUFDNUQsYUFBSyxTQUFMLENBQWUsSUFBZixDQUFvQixRQUFwQjtBQUNBLFlBQUksS0FBSyxTQUFULEVBQW9CO0FBQ2hCLHFCQUFTLEtBQUssU0FBZDtBQUNBLGlCQUFLLFNBQUwsR0FBaUIsU0FBakI7QUFDSDtBQUNKLEtBTkQ7QUFPQSxtQkFBZSxTQUFmLENBQXlCLGdCQUF6QixHQUE0QyxVQUFVLEdBQVYsRUFBZTtBQUN2RCxZQUFJLEdBQUosRUFBUyxFQUFUO0FBQ0EsWUFBSSxDQUFDLEdBQUwsRUFBVTtBQUNOO0FBQ0g7QUFDRCxZQUFJLENBQUMsS0FBSyxTQUFMLENBQWUsTUFBcEIsRUFBNEI7QUFDeEIsb0JBQVEsR0FBUixDQUFZLHNEQUFaO0FBQ0EsaUJBQUssU0FBTCxHQUFpQixHQUFqQjtBQUNBO0FBQ0g7QUFDRCxZQUFJO0FBQ0EsaUJBQUssSUFBSSxLQUFLLFNBQVMsS0FBSyxTQUFkLENBQVQsRUFBbUMsS0FBSyxHQUFHLElBQUgsRUFBN0MsRUFBd0QsQ0FBQyxHQUFHLElBQTVELEVBQWtFLEtBQUssR0FBRyxJQUFILEVBQXZFLEVBQWtGO0FBQzlFLG9CQUFJLFdBQVcsR0FBRyxLQUFsQjtBQUNBLHlCQUFTLEdBQVQ7QUFDSDtBQUNKLFNBTEQsQ0FNQSxPQUFPLEtBQVAsRUFBYztBQUFFLGtCQUFNLEVBQUUsT0FBTyxLQUFULEVBQU47QUFBeUIsU0FOekMsU0FPUTtBQUNKLGdCQUFJO0FBQ0Esb0JBQUksTUFBTSxDQUFDLEdBQUcsSUFBVixLQUFtQixLQUFLLEdBQUcsTUFBM0IsQ0FBSixFQUF3QyxHQUFHLElBQUgsQ0FBUSxFQUFSO0FBQzNDLGFBRkQsU0FHUTtBQUFFLG9CQUFJLEdBQUosRUFBUyxNQUFNLElBQUksS0FBVjtBQUFrQjtBQUN4QztBQUNKLEtBdkJEO0FBd0JBLFdBQU8sY0FBUDtBQUNILENBcENtQyxFQUFwQztBQXFDQSxRQUFRLGNBQVIsR0FBeUIsY0FBekI7QUFDQSxJQUFJLHdCQUF3QixhQUFlLFVBQVUsTUFBVixFQUFrQjtBQUN6RCxjQUFVLHFCQUFWLEVBQWlDLE1BQWpDO0FBQ0EsYUFBUyxxQkFBVCxHQUFpQztBQUM3QixZQUFJLFFBQVEsT0FBTyxJQUFQLENBQVksSUFBWixLQUFxQixJQUFqQztBQUNBLGVBQU8sU0FBUCxDQUFpQixNQUFqQixDQUF3QixVQUFVLFNBQVYsRUFBcUI7QUFDekMsbUJBQU8sU0FBUCxDQUFpQixXQUFqQixDQUE2QixNQUFNLGdCQUFOLENBQXVCLElBQXZCLENBQTRCLEtBQTVCLENBQTdCO0FBQ0Esa0JBQU0sZ0JBQU4sQ0FBdUIsU0FBdkI7QUFDSCxTQUhEO0FBSUEsZUFBTyxLQUFQO0FBQ0g7QUFDRCxXQUFPLHFCQUFQO0FBQ0gsQ0FYMEMsQ0FXekMsY0FYeUMsQ0FBM0M7QUFZQSxRQUFRLHFCQUFSLEdBQWdDLHFCQUFoQztBQUNBLElBQUksc0JBQXNCLGFBQWUsVUFBVSxNQUFWLEVBQWtCO0FBQ3ZELGNBQVUsbUJBQVYsRUFBK0IsTUFBL0I7QUFDQSxhQUFTLG1CQUFULENBQTZCLFNBQTdCLEVBQXdDO0FBQ3BDLFlBQUksUUFBUSxPQUFPLElBQVAsQ0FBWSxJQUFaLEtBQXFCLElBQWpDO0FBQ0E7QUFDQTtBQUNBLGVBQU8sYUFBUCxHQUF1QixVQUFVLEdBQVYsRUFBZTtBQUNsQyxrQkFBTSxnQkFBTixDQUF1QixHQUF2QjtBQUNILFNBRkQ7QUFHQSxZQUFJLFNBQUosRUFBZTtBQUNYLGtCQUFNLGdCQUFOLENBQXVCLFNBQXZCO0FBQ0g7QUFDRCxlQUFPLEtBQVA7QUFDSDtBQUNELFdBQU8sbUJBQVA7QUFDSCxDQWZ3QyxDQWV2QyxjQWZ1QyxDQUF6QztBQWdCQSxRQUFRLG1CQUFSLEdBQThCLG1CQUE5Qjs7O0FDMUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsSUFBSSxZQUFhLGFBQVEsVUFBSyxTQUFkLElBQTZCLFlBQVk7QUFDckQsUUFBSSxpQkFBZ0IsdUJBQVUsQ0FBVixFQUFhLENBQWIsRUFBZ0I7QUFDaEMseUJBQWdCLE9BQU8sY0FBUCxJQUNYLEVBQUUsV0FBVyxFQUFiLGNBQTZCLEtBQTdCLElBQXNDLFVBQVUsQ0FBVixFQUFhLENBQWIsRUFBZ0I7QUFBRSxjQUFFLFNBQUYsR0FBYyxDQUFkO0FBQWtCLFNBRC9ELElBRVosVUFBVSxDQUFWLEVBQWEsQ0FBYixFQUFnQjtBQUFFLGlCQUFLLElBQUksQ0FBVCxJQUFjLENBQWQ7QUFBaUIsb0JBQUksRUFBRSxjQUFGLENBQWlCLENBQWpCLENBQUosRUFBeUIsRUFBRSxDQUFGLElBQU8sRUFBRSxDQUFGLENBQVA7QUFBMUM7QUFBd0QsU0FGOUU7QUFHQSxlQUFPLGVBQWMsQ0FBZCxFQUFpQixDQUFqQixDQUFQO0FBQ0gsS0FMRDtBQU1BLFdBQU8sVUFBVSxDQUFWLEVBQWEsQ0FBYixFQUFnQjtBQUNuQix1QkFBYyxDQUFkLEVBQWlCLENBQWpCO0FBQ0EsaUJBQVMsRUFBVCxHQUFjO0FBQUUsaUJBQUssV0FBTCxHQUFtQixDQUFuQjtBQUF1QjtBQUN2QyxVQUFFLFNBQUYsR0FBYyxNQUFNLElBQU4sR0FBYSxPQUFPLE1BQVAsQ0FBYyxDQUFkLENBQWIsSUFBaUMsR0FBRyxTQUFILEdBQWUsRUFBRSxTQUFqQixFQUE0QixJQUFJLEVBQUosRUFBN0QsQ0FBZDtBQUNILEtBSkQ7QUFLSCxDQVoyQyxFQUE1QztBQWFBLE9BQU8sY0FBUCxDQUFzQixPQUF0QixFQUErQixZQUEvQixFQUE2QyxFQUFFLE9BQU8sSUFBVCxFQUE3QztBQUNBLElBQUksZUFBZSxhQUFlLFVBQVUsTUFBVixFQUFrQjtBQUNoRCxjQUFVLFlBQVYsRUFBd0IsTUFBeEI7QUFDQSxhQUFTLFlBQVQsQ0FBc0IsT0FBdEIsRUFBK0I7QUFDM0IsWUFBSSxhQUFhLEtBQUssV0FBdEI7QUFDQSxZQUFJO0FBQ0o7QUFDQTtBQUNBLGVBQU8sSUFBUCxDQUFZLElBQVosRUFBa0IsT0FBbEIsS0FBOEIsSUFIOUI7QUFJQSxlQUFPLGNBQVAsQ0FBc0IsS0FBdEIsRUFBNkIsV0FBVyxTQUF4QyxFQU4yQixDQU15QjtBQUNwRCxjQUFNLElBQU4sR0FBYSxXQUFXLElBQXhCO0FBQ0EsZUFBTyxLQUFQO0FBQ0g7QUFDRCxXQUFPLFlBQVA7QUFDSCxDQWJpQyxDQWFoQyxLQWJnQyxDQUFsQztBQWNBLFFBQVEsWUFBUixHQUF1QixZQUF2QjtBQUNBLElBQUkscUJBQXFCLGFBQWUsVUFBVSxNQUFWLEVBQWtCO0FBQ3RELGNBQVUsa0JBQVYsRUFBOEIsTUFBOUI7QUFDQSxhQUFTLGtCQUFULENBQTRCLE1BQTVCLEVBQW9DO0FBQ2hDLFlBQUksUUFBUSxPQUFPLElBQVAsQ0FBWSxJQUFaLEtBQXFCLElBQWpDO0FBQ0EsY0FBTSxNQUFOLEdBQWUsTUFBZjtBQUNBLGVBQU8sS0FBUDtBQUNIO0FBQ0QsV0FBTyxrQkFBUDtBQUNILENBUnVDLENBUXRDLFlBUnNDLENBQXhDO0FBU0EsUUFBUSxrQkFBUixHQUE2QixrQkFBN0I7QUFDQSxJQUFJLHFCQUFxQixhQUFlLFVBQVUsTUFBVixFQUFrQjtBQUN0RCxjQUFVLGtCQUFWLEVBQThCLE1BQTlCO0FBQ0EsYUFBUyxrQkFBVCxDQUE0QixPQUE1QixFQUFxQztBQUNqQyxlQUFPLE9BQU8sSUFBUCxDQUFZLElBQVosRUFBa0IsT0FBbEIsS0FBOEIsSUFBckM7QUFDSDtBQUNELFdBQU8sa0JBQVA7QUFDSCxDQU51QyxDQU10QyxZQU5zQyxDQUF4QztBQU9BLFFBQVEsa0JBQVIsR0FBNkIsa0JBQTdCO0FBQ0EsSUFBSSxtQkFBbUIsYUFBZSxVQUFVLE1BQVYsRUFBa0I7QUFDcEQsY0FBVSxnQkFBVixFQUE0QixNQUE1QjtBQUNBLGFBQVMsZ0JBQVQsQ0FBMEIsT0FBMUIsRUFBbUM7QUFDL0IsZUFBTyxPQUFPLElBQVAsQ0FBWSxJQUFaLEVBQWtCLE9BQWxCLEtBQThCLElBQXJDO0FBQ0g7QUFDRCxXQUFPLGdCQUFQO0FBQ0gsQ0FOcUMsQ0FNcEMsWUFOb0MsQ0FBdEM7QUFPQSxRQUFRLGdCQUFSLEdBQTJCLGdCQUEzQjtBQUNBLElBQUksb0JBQW9CLGFBQWUsVUFBVSxNQUFWLEVBQWtCO0FBQ3JELGNBQVUsaUJBQVYsRUFBNkIsTUFBN0I7QUFDQSxhQUFTLGlCQUFULENBQTJCLFNBQTNCLEVBQXNDLGFBQXRDLEVBQXFEO0FBQ2pELFlBQUksUUFBUSxPQUFPLElBQVAsQ0FBWSxJQUFaLEtBQXFCLElBQWpDO0FBQ0EsY0FBTSxTQUFOLEdBQWtCLFNBQWxCO0FBQ0EsY0FBTSxhQUFOLEdBQXNCLGFBQXRCO0FBQ0EsZUFBTyxLQUFQO0FBQ0g7QUFDRCxXQUFPLGlCQUFQO0FBQ0gsQ0FUc0MsQ0FTckMsWUFUcUMsQ0FBdkM7QUFVQSxRQUFRLGlCQUFSLEdBQTRCLGlCQUE1QjtBQUNBLElBQUksMEJBQTBCLGFBQWUsVUFBVSxNQUFWLEVBQWtCO0FBQzNELGNBQVUsdUJBQVYsRUFBbUMsTUFBbkM7QUFDQSxhQUFTLHVCQUFULEdBQW1DO0FBQy9CLGVBQU8sT0FBTyxJQUFQLENBQVksSUFBWixLQUFxQixJQUE1QjtBQUNIO0FBQ0QsV0FBTyx1QkFBUDtBQUNILENBTjRDLENBTTNDLFlBTjJDLENBQTdDO0FBT0EsUUFBUSx1QkFBUixHQUFrQyx1QkFBbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLHFCQUFxQixhQUFlLFVBQVUsTUFBVixFQUFrQjtBQUN0RCxjQUFVLGtCQUFWLEVBQThCLE1BQTlCO0FBQ0EsYUFBUyxrQkFBVCxDQUE0QixTQUE1QixFQUF1QztBQUNuQyxZQUFJLFFBQVEsT0FBTyxJQUFQLENBQVksSUFBWixLQUFxQixJQUFqQztBQUNBLGNBQU0sU0FBTixHQUFrQixTQUFsQjtBQUNBLGVBQU8sS0FBUDtBQUNIO0FBQ0QsV0FBTyxrQkFBUDtBQUNILENBUnVDLENBUXRDLFlBUnNDLENBQXhDO0FBU0EsUUFBUSxrQkFBUixHQUE2QixrQkFBN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksY0FBYyxhQUFlLFVBQVUsTUFBVixFQUFrQjtBQUMvQyxjQUFVLFdBQVYsRUFBdUIsTUFBdkI7QUFDQSxhQUFTLFdBQVQsR0FBdUI7QUFDbkIsZUFBTyxXQUFXLElBQVgsSUFBbUIsT0FBTyxLQUFQLENBQWEsSUFBYixFQUFtQixTQUFuQixDQUFuQixJQUFvRCxJQUEzRDtBQUNIO0FBQ0QsV0FBTyxXQUFQO0FBQ0gsQ0FOZ0MsQ0FNL0IsWUFOK0IsQ0FBakM7QUFPQSxRQUFRLFdBQVIsR0FBc0IsV0FBdEI7QUFDQSxJQUFJLHFCQUFxQixhQUFlLFVBQVUsTUFBVixFQUFrQjtBQUN0RCxjQUFVLGtCQUFWLEVBQThCLE1BQTlCO0FBQ0EsYUFBUyxrQkFBVCxHQUE4QjtBQUMxQixlQUFPLFdBQVcsSUFBWCxJQUFtQixPQUFPLEtBQVAsQ0FBYSxJQUFiLEVBQW1CLFNBQW5CLENBQW5CLElBQW9ELElBQTNEO0FBQ0g7QUFDRCxXQUFPLGtCQUFQO0FBQ0gsQ0FOdUMsQ0FNdEMsV0FOc0MsQ0FBeEM7QUFPQSxRQUFRLGtCQUFSLEdBQTZCLGtCQUE3QjtBQUNBLElBQUkscUJBQXFCLGFBQWUsVUFBVSxNQUFWLEVBQWtCO0FBQ3RELGNBQVUsa0JBQVYsRUFBOEIsTUFBOUI7QUFDQSxhQUFTLGtCQUFULEdBQThCO0FBQzFCLGVBQU8sV0FBVyxJQUFYLElBQW1CLE9BQU8sS0FBUCxDQUFhLElBQWIsRUFBbUIsU0FBbkIsQ0FBbkIsSUFBb0QsSUFBM0Q7QUFDSDtBQUNELFdBQU8sa0JBQVA7QUFDSCxDQU51QyxDQU10QyxXQU5zQyxDQUF4QztBQU9BLFFBQVEsa0JBQVIsR0FBNkIsa0JBQTdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSx3QkFBd0IsYUFBZSxVQUFVLE1BQVYsRUFBa0I7QUFDekQsY0FBVSxxQkFBVixFQUFpQyxNQUFqQztBQUNBLGFBQVMscUJBQVQsR0FBaUM7QUFDN0IsZUFBTyxXQUFXLElBQVgsSUFBbUIsT0FBTyxLQUFQLENBQWEsSUFBYixFQUFtQixTQUFuQixDQUFuQixJQUFvRCxJQUEzRDtBQUNIO0FBQ0QsV0FBTyxxQkFBUDtBQUNILENBTjBDLENBTXpDLGtCQU55QyxDQUEzQztBQU9BLFFBQVEscUJBQVIsR0FBZ0MscUJBQWhDO0FBQ0EsSUFBSSwwQkFBMEIsYUFBZSxVQUFVLE1BQVYsRUFBa0I7QUFDM0QsY0FBVSx1QkFBVixFQUFtQyxNQUFuQztBQUNBLGFBQVMsdUJBQVQsR0FBbUM7QUFDL0IsZUFBTyxXQUFXLElBQVgsSUFBbUIsT0FBTyxLQUFQLENBQWEsSUFBYixFQUFtQixTQUFuQixDQUFuQixJQUFvRCxJQUEzRDtBQUNIO0FBQ0QsV0FBTyx1QkFBUDtBQUNILENBTjRDLENBTTNDLGtCQU4yQyxDQUE3QztBQU9BLFFBQVEsdUJBQVIsR0FBa0MsdUJBQWxDO0FBQ0EsSUFBSSwyQkFBMkIsYUFBZSxVQUFVLE1BQVYsRUFBa0I7QUFDNUQsY0FBVSx3QkFBVixFQUFvQyxNQUFwQztBQUNBLGFBQVMsd0JBQVQsR0FBb0M7QUFDaEMsZUFBTyxXQUFXLElBQVgsSUFBbUIsT0FBTyxLQUFQLENBQWEsSUFBYixFQUFtQixTQUFuQixDQUFuQixJQUFvRCxJQUEzRDtBQUNIO0FBQ0QsV0FBTyx3QkFBUDtBQUNILENBTjZDLENBTTVDLGtCQU40QyxDQUE5QztBQU9BLFFBQVEsd0JBQVIsR0FBbUMsd0JBQW5DO0FBQ0EsSUFBSSw4QkFBOEIsYUFBZSxVQUFVLE1BQVYsRUFBa0I7QUFDL0QsY0FBVSwyQkFBVixFQUF1QyxNQUF2QztBQUNBLGFBQVMsMkJBQVQsR0FBdUM7QUFDbkMsZUFBTyxXQUFXLElBQVgsSUFBbUIsT0FBTyxLQUFQLENBQWEsSUFBYixFQUFtQixTQUFuQixDQUFuQixJQUFvRCxJQUEzRDtBQUNIO0FBQ0QsV0FBTywyQkFBUDtBQUNILENBTmdELENBTS9DLGtCQU4rQyxDQUFqRDtBQU9BLFFBQVEsMkJBQVIsR0FBc0MsMkJBQXRDO0FBQ0EsSUFBSSxvQkFBb0IsYUFBZSxVQUFVLE1BQVYsRUFBa0I7QUFDckQsY0FBVSxpQkFBVixFQUE2QixNQUE3QjtBQUNBLGFBQVMsaUJBQVQsR0FBNkI7QUFDekIsZUFBTyxXQUFXLElBQVgsSUFBbUIsT0FBTyxLQUFQLENBQWEsSUFBYixFQUFtQixTQUFuQixDQUFuQixJQUFvRCxJQUEzRDtBQUNIO0FBQ0QsV0FBTyxpQkFBUDtBQUNILENBTnNDLENBTXJDLGtCQU5xQyxDQUF2QztBQU9BLFFBQVEsaUJBQVIsR0FBNEIsaUJBQTVCO0FBQ0EsSUFBSSw2QkFBNkIsYUFBZSxVQUFVLE1BQVYsRUFBa0I7QUFDOUQsY0FBVSwwQkFBVixFQUFzQyxNQUF0QztBQUNBLGFBQVMsMEJBQVQsR0FBc0M7QUFDbEMsZUFBTyxXQUFXLElBQVgsSUFBbUIsT0FBTyxLQUFQLENBQWEsSUFBYixFQUFtQixTQUFuQixDQUFuQixJQUFvRCxJQUEzRDtBQUNIO0FBQ0QsV0FBTywwQkFBUDtBQUNILENBTitDLENBTTlDLGtCQU44QyxDQUFoRDtBQU9BLFFBQVEsMEJBQVIsR0FBcUMsMEJBQXJDO0FBQ0EsSUFBSSxxQkFBcUIsYUFBZSxVQUFVLE1BQVYsRUFBa0I7QUFDdEQsY0FBVSxrQkFBVixFQUE4QixNQUE5QjtBQUNBLGFBQVMsa0JBQVQsR0FBOEI7QUFDMUIsZUFBTyxXQUFXLElBQVgsSUFBbUIsT0FBTyxLQUFQLENBQWEsSUFBYixFQUFtQixTQUFuQixDQUFuQixJQUFvRCxJQUEzRDtBQUNIO0FBQ0QsV0FBTyxrQkFBUDtBQUNILENBTnVDLENBTXRDLGtCQU5zQyxDQUF4QztBQU9BLFFBQVEsa0JBQVIsR0FBNkIsa0JBQTdCO0FBQ0EsSUFBSSwrQkFBK0IsYUFBZSxVQUFVLE1BQVYsRUFBa0I7QUFDaEUsY0FBVSw0QkFBVixFQUF3QyxNQUF4QztBQUNBLGFBQVMsNEJBQVQsR0FBd0M7QUFDcEMsZUFBTyxXQUFXLElBQVgsSUFBbUIsT0FBTyxLQUFQLENBQWEsSUFBYixFQUFtQixTQUFuQixDQUFuQixJQUFvRCxJQUEzRDtBQUNIO0FBQ0QsV0FBTyw0QkFBUDtBQUNILENBTmlELENBTWhELGtCQU5nRCxDQUFsRDtBQU9BLFFBQVEsNEJBQVIsR0FBdUMsNEJBQXZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksMEJBQTBCLGFBQWUsVUFBVSxNQUFWLEVBQWtCO0FBQzNELGNBQVUsdUJBQVYsRUFBbUMsTUFBbkM7QUFDQSxhQUFTLHVCQUFULEdBQW1DO0FBQy9CLGVBQU8sV0FBVyxJQUFYLElBQW1CLE9BQU8sS0FBUCxDQUFhLElBQWIsRUFBbUIsU0FBbkIsQ0FBbkIsSUFBb0QsSUFBM0Q7QUFDSDtBQUNELFdBQU8sdUJBQVA7QUFDSCxDQU40QyxDQU0zQyxrQkFOMkMsQ0FBN0M7QUFPQSxRQUFRLHVCQUFSLEdBQWtDLHVCQUFsQztBQUNBLElBQUksOEJBQThCLGFBQWUsVUFBVSxNQUFWLEVBQWtCO0FBQy9ELGNBQVUsMkJBQVYsRUFBdUMsTUFBdkM7QUFDQSxhQUFTLDJCQUFULEdBQXVDO0FBQ25DLGVBQU8sV0FBVyxJQUFYLElBQW1CLE9BQU8sS0FBUCxDQUFhLElBQWIsRUFBbUIsU0FBbkIsQ0FBbkIsSUFBb0QsSUFBM0Q7QUFDSDtBQUNELFdBQU8sMkJBQVA7QUFDSCxDQU5nRCxDQU0vQyxrQkFOK0MsQ0FBakQ7QUFPQSxRQUFRLDJCQUFSLEdBQXNDLDJCQUF0QztBQUNBLElBQUksMEJBQTBCLGFBQWUsVUFBVSxNQUFWLEVBQWtCO0FBQzNELGNBQVUsdUJBQVYsRUFBbUMsTUFBbkM7QUFDQSxhQUFTLHVCQUFULEdBQW1DO0FBQy9CLGVBQU8sV0FBVyxJQUFYLElBQW1CLE9BQU8sS0FBUCxDQUFhLElBQWIsRUFBbUIsU0FBbkIsQ0FBbkIsSUFBb0QsSUFBM0Q7QUFDSDtBQUNELFdBQU8sdUJBQVA7QUFDSCxDQU40QyxDQU0zQyxrQkFOMkMsQ0FBN0M7QUFPQSxRQUFRLHVCQUFSLEdBQWtDLHVCQUFsQztBQUNBO0FBQ0EsSUFBSSxrQkFBa0IsYUFBZSxVQUFVLE1BQVYsRUFBa0I7QUFDbkQsY0FBVSxlQUFWLEVBQTJCLE1BQTNCO0FBQ0EsYUFBUyxlQUFULEdBQTJCO0FBQ3ZCLGVBQU8sV0FBVyxJQUFYLElBQW1CLE9BQU8sS0FBUCxDQUFhLElBQWIsRUFBbUIsU0FBbkIsQ0FBbkIsSUFBb0QsSUFBM0Q7QUFDSDtBQUNELFdBQU8sZUFBUDtBQUNILENBTm9DLENBTW5DLGtCQU5tQyxDQUFyQztBQU9BLFFBQVEsZUFBUixHQUEwQixlQUExQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsYUFBVCxDQUF1QixTQUF2QixFQUFrQztBQUM5QixZQUFRLFNBQVI7QUFDSSxhQUFLLENBQUwsQ0FBTyxnQkFBUDtBQUNJLG1CQUFPLElBQUkscUJBQUosRUFBUDtBQUNKLGFBQUssQ0FBTCxDQUFPLGdDQUFQO0FBQ0ksbUJBQU8sSUFBSSx1QkFBSixFQUFQO0FBQ0osYUFBSyxDQUFMLENBQU8sZ0NBQVA7QUFDSSxtQkFBTyxJQUFJLHdCQUFKLEVBQVA7QUFDSixhQUFLLENBQUwsQ0FBTywyQkFBUDtBQUNJLG1CQUFPLElBQUksMkJBQUosRUFBUDtBQUNKLGFBQUssQ0FBTCxDQUFPLHdCQUFQO0FBQ0ksbUJBQU8sSUFBSSxpQkFBSixFQUFQO0FBQ0osYUFBSyxDQUFMLENBQU8sdUJBQVA7QUFDSSxtQkFBTyxJQUFJLGVBQUosRUFBUDtBQUNKLGFBQUssQ0FBTCxDQUFPLGtDQUFQO0FBQ0ksbUJBQU8sSUFBSSwwQkFBSixFQUFQO0FBQ0osYUFBSyxDQUFMLENBQU8sK0JBQVA7QUFDSSxtQkFBTyxJQUFJLHVCQUFKLEVBQVA7QUFDSixhQUFLLENBQUwsQ0FBTyxvQ0FBUDtBQUNJLG1CQUFPLElBQUksMkJBQUosRUFBUDtBQUNKLGFBQUssRUFBTCxDQUFRLDBCQUFSO0FBQ0ksbUJBQU8sSUFBSSxrQkFBSixFQUFQO0FBQ0osYUFBSyxFQUFMLENBQVEsK0JBQVI7QUFDSSxtQkFBTyxJQUFJLHVCQUFKLEVBQVA7QUFDSixhQUFLLEVBQUwsQ0FBUSwwQkFBUjtBQUNJLG1CQUFPLElBQUksNEJBQUosRUFBUDtBQUNKO0FBQ0ksa0JBQU0sSUFBSSxLQUFKLENBQVUsdUJBQXVCLFNBQWpDLENBQU47QUExQlI7QUE0Qkg7QUFDRCxRQUFRLGFBQVIsR0FBd0IsYUFBeEI7QUFDQTtBQUNBO0FBQ0EsU0FBUyxXQUFULENBQXFCLENBQXJCLEVBQXdCO0FBQ3BCLFFBQUksYUFBYSxxQkFBakIsRUFBd0M7QUFDcEMsZUFBTyxDQUFQLENBQVMsZ0JBQVQ7QUFDSCxLQUZELE1BR0ssSUFBSSxhQUFhLHVCQUFqQixFQUEwQztBQUMzQyxlQUFPLENBQVAsQ0FBUyxnQ0FBVDtBQUNILEtBRkksTUFHQSxJQUFJLGFBQWEsd0JBQWpCLEVBQTJDO0FBQzVDLGVBQU8sQ0FBUCxDQUFTLGdDQUFUO0FBQ0gsS0FGSSxNQUdBLElBQUksYUFBYSwyQkFBakIsRUFBOEM7QUFDL0MsZUFBTyxDQUFQLENBQVMsMkJBQVQ7QUFDSCxLQUZJLE1BR0EsSUFBSSxhQUFhLGlCQUFqQixFQUFvQztBQUNyQyxlQUFPLENBQVAsQ0FBUyx3QkFBVDtBQUNILEtBRkksTUFHQSxJQUFJLGFBQWEsZUFBakIsRUFBa0M7QUFDbkMsZUFBTyxDQUFQLENBQVMsdUJBQVQ7QUFDSCxLQUZJLE1BR0EsSUFBSSxhQUFhLDBCQUFqQixFQUE2QztBQUM5QyxlQUFPLENBQVAsQ0FBUyxrQ0FBVDtBQUNILEtBRkksTUFHQSxJQUFJLGFBQWEsdUJBQWpCLEVBQTBDO0FBQzNDLGVBQU8sQ0FBUCxDQUFTLCtCQUFUO0FBQ0gsS0FGSSxNQUdBLElBQUksYUFBYSwyQkFBakIsRUFBOEM7QUFDL0MsZUFBTyxDQUFQLENBQVMsb0NBQVQ7QUFDSCxLQUZJLE1BR0EsSUFBSSxhQUFhLHVCQUFqQixFQUEwQztBQUMzQyxlQUFPLEVBQVAsQ0FBVSwrQkFBVjtBQUNILEtBRkksTUFHQSxJQUFJLGFBQWEsa0JBQWpCLEVBQXFDO0FBQ3RDLGVBQU8sRUFBUCxDQUFVLDBCQUFWO0FBQ0gsS0FGSSxNQUdBLElBQUksYUFBYSw0QkFBakIsRUFBK0M7QUFDaEQsZUFBTyxFQUFQLENBQVUsMEJBQVY7QUFDSDtBQUNELFVBQU0sSUFBSSxLQUFKLENBQVUseUJBQXlCLEVBQUUsSUFBckMsQ0FBTjtBQUNIO0FBQ0QsUUFBUSxXQUFSLEdBQXNCLFdBQXRCOzs7QUN4VEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxJQUFJLFdBQVksYUFBUSxVQUFLLFFBQWQsSUFBMkIsVUFBVSxDQUFWLEVBQWE7QUFDbkQsUUFBSSxJQUFJLE9BQU8sTUFBUCxLQUFrQixVQUFsQixJQUFnQyxFQUFFLE9BQU8sUUFBVCxDQUF4QztBQUFBLFFBQTRELElBQUksQ0FBaEU7QUFDQSxRQUFJLENBQUosRUFBTyxPQUFPLEVBQUUsSUFBRixDQUFPLENBQVAsQ0FBUDtBQUNQLFdBQU87QUFDSCxjQUFNLGdCQUFZO0FBQ2QsZ0JBQUksS0FBSyxLQUFLLEVBQUUsTUFBaEIsRUFBd0IsSUFBSSxLQUFLLENBQVQ7QUFDeEIsbUJBQU8sRUFBRSxPQUFPLEtBQUssRUFBRSxHQUFGLENBQWQsRUFBc0IsTUFBTSxDQUFDLENBQTdCLEVBQVA7QUFDSDtBQUpFLEtBQVA7QUFNSCxDQVREO0FBVUEsT0FBTyxjQUFQLENBQXNCLE9BQXRCLEVBQStCLFlBQS9CLEVBQTZDLEVBQUUsT0FBTyxJQUFULEVBQTdDO0FBQ0EsSUFBSSxjQUFjLGFBQWUsWUFBWTtBQUN6QyxhQUFTLFdBQVQsQ0FBcUIsTUFBckIsRUFBNkI7QUFDekIsYUFBSyxNQUFMLEdBQWMsTUFBZDtBQUNIO0FBQ0QsV0FBTyxXQUFQO0FBQ0gsQ0FMZ0MsRUFBakM7QUFNQSxRQUFRLFdBQVIsR0FBc0IsV0FBdEI7QUFDQSxJQUFJLHFCQUFxQixhQUFlLFlBQVk7QUFDaEQsYUFBUyxrQkFBVCxDQUE0QixNQUE1QixFQUFvQztBQUNoQyxhQUFLLE1BQUwsR0FBYyxNQUFkO0FBQ0g7QUFDRCxXQUFPLGtCQUFQO0FBQ0gsQ0FMdUMsRUFBeEM7QUFNQSxRQUFRLGtCQUFSLEdBQTZCLGtCQUE3QjtBQUNBLElBQUksa0JBQWtCLGFBQWUsWUFBWTtBQUM3QyxhQUFTLGVBQVQsQ0FBeUIsTUFBekIsRUFBaUM7QUFDN0IsYUFBSyxNQUFMLEdBQWMsTUFBZDtBQUNIO0FBQ0QsV0FBTyxlQUFQO0FBQ0gsQ0FMb0MsRUFBckM7QUFNQSxRQUFRLGVBQVIsR0FBMEIsZUFBMUI7QUFDQSxJQUFJLHFCQUFxQixhQUFlLFlBQVk7QUFDaEQsYUFBUyxrQkFBVCxDQUE0QixNQUE1QixFQUFvQztBQUNoQyxhQUFLLE1BQUwsR0FBYyxNQUFkO0FBQ0g7QUFDRCxXQUFPLGtCQUFQO0FBQ0gsQ0FMdUMsRUFBeEM7QUFNQSxRQUFRLGtCQUFSLEdBQTZCLGtCQUE3QjtBQUNBLElBQUksZ0JBQWdCLGFBQWUsWUFBWTtBQUMzQyxhQUFTLGFBQVQsQ0FBdUIsTUFBdkIsRUFBK0I7QUFDM0IsYUFBSyxNQUFMLEdBQWMsTUFBZDtBQUNIO0FBQ0QsV0FBTyxhQUFQO0FBQ0gsQ0FMa0MsRUFBbkM7QUFNQSxRQUFRLGFBQVIsR0FBd0IsYUFBeEI7QUFDQSxJQUFJLG1CQUFtQixhQUFlLFlBQVk7QUFDOUMsYUFBUyxnQkFBVCxDQUEwQixTQUExQixFQUFxQztBQUNqQyxhQUFLLFNBQUwsR0FBaUIsU0FBakI7QUFDSDtBQUNELFdBQU8sZ0JBQVA7QUFDSCxDQUxxQyxFQUF0QztBQU1BLFFBQVEsZ0JBQVIsR0FBMkIsZ0JBQTNCO0FBQ0EsSUFBSSxrQkFBa0IsYUFBZSxZQUFZO0FBQzdDLGFBQVMsZUFBVCxDQUF5QixNQUF6QixFQUFpQztBQUM3QixhQUFLLE1BQUwsR0FBYyxNQUFkO0FBQ0g7QUFDRCxXQUFPLGVBQVA7QUFDSCxDQUxvQyxFQUFyQztBQU1BLFFBQVEsZUFBUixHQUEwQixlQUExQjtBQUNBLElBQUkscUJBQXFCLGFBQWUsWUFBWTtBQUNoRCxhQUFTLGtCQUFULENBQTRCLE1BQTVCLEVBQW9DO0FBQ2hDLGFBQUssTUFBTCxHQUFjLE1BQWQ7QUFDSDtBQUNELFdBQU8sa0JBQVA7QUFDSCxDQUx1QyxFQUF4QztBQU1BLFFBQVEsa0JBQVIsR0FBNkIsa0JBQTdCO0FBQ0EsSUFBSSxxQkFBcUIsYUFBZSxZQUFZO0FBQ2hELGFBQVMsa0JBQVQsQ0FBNEIsTUFBNUIsRUFBb0M7QUFDaEMsYUFBSyxNQUFMLEdBQWMsTUFBZDtBQUNIO0FBQ0QsV0FBTyxrQkFBUDtBQUNILENBTHVDLEVBQXhDO0FBTUEsUUFBUSxrQkFBUixHQUE2QixrQkFBN0I7QUFDQTtBQUNBLElBQUksYUFBYSxhQUFlLFlBQVk7QUFDeEMsYUFBUyxVQUFULEdBQXNCO0FBQ2xCLGFBQUssWUFBTCxHQUFvQixFQUFwQjtBQUNBLGFBQUssb0JBQUwsR0FBNEIsSUFBSSxHQUFKLEVBQTVCO0FBQ0EsYUFBSyxTQUFMLEdBQWlCLEtBQWpCO0FBQ0EsYUFBSyxZQUFMLEdBQW9CLEtBQXBCO0FBQ0g7QUFDRCxlQUFXLFNBQVgsQ0FBcUIsZUFBckIsR0FBdUMsWUFBWTtBQUMvQyxhQUFLLFNBQUwsR0FBaUIsSUFBakI7QUFDQSxhQUFLLG1CQUFMO0FBQ0gsS0FIRDtBQUlBO0FBQ0EsZUFBVyxTQUFYLENBQXFCLFNBQXJCLEdBQWlDLFVBQVUsU0FBVixFQUFxQixRQUFyQixFQUErQjtBQUM1RCxZQUFJLFlBQVksS0FBSyxvQkFBTCxDQUEwQixHQUExQixDQUE4QixTQUE5QixDQUFoQjtBQUNBLFlBQUksQ0FBQyxTQUFMLEVBQWdCO0FBQ1osd0JBQVksRUFBWjtBQUNBLGlCQUFLLG9CQUFMLENBQTBCLEdBQTFCLENBQThCLFNBQTlCLEVBQXlDLFNBQXpDO0FBQ0g7QUFDRCxrQkFBVSxJQUFWLENBQWUsUUFBZjtBQUNILEtBUEQ7QUFRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFXLFNBQVgsQ0FBcUIsT0FBckIsR0FBK0IsVUFBVSxLQUFWLEVBQWlCO0FBQzVDLGFBQUssWUFBTCxDQUFrQixJQUFsQixDQUF1QixLQUF2QjtBQUNBLFlBQUksS0FBSyxTQUFULEVBQW9CO0FBQ2hCLGlCQUFLLG1CQUFMO0FBQ0g7QUFDSixLQUxEO0FBTUE7QUFDQSxlQUFXLFNBQVgsQ0FBcUIsbUJBQXJCLEdBQTJDLFlBQVk7QUFDbkQsWUFBSSxHQUFKLEVBQVMsRUFBVDtBQUNBLFlBQUksS0FBSyxZQUFULEVBQ0k7QUFDSixhQUFLLFlBQUwsR0FBb0IsSUFBcEI7QUFDQSxlQUFPLEtBQUssWUFBTCxDQUFrQixNQUFsQixHQUEyQixDQUFsQyxFQUFxQztBQUNqQyxnQkFBSSxVQUFVLEtBQUssWUFBTCxDQUFrQixLQUFsQixFQUFkO0FBQ0EsZ0JBQUksWUFBWSxLQUFLLG9CQUFMLENBQTBCLEdBQTFCLENBQThCLFFBQVEsV0FBdEMsQ0FBaEI7QUFDQSxnQkFBSSxDQUFDLFNBQUwsRUFBZ0I7QUFDWix3QkFBUSxJQUFSLENBQWEsbUNBQWIsRUFBa0QsT0FBbEQ7QUFDQTtBQUNIO0FBQ0QsZ0JBQUk7QUFDQSxxQkFBSyxJQUFJLGNBQWMsU0FBUyxTQUFULENBQWxCLEVBQXVDLGdCQUFnQixZQUFZLElBQVosRUFBNUQsRUFBZ0YsQ0FBQyxjQUFjLElBQS9GLEVBQXFHLGdCQUFnQixZQUFZLElBQVosRUFBckgsRUFBeUk7QUFDckksd0JBQUksV0FBVyxjQUFjLEtBQTdCO0FBQ0EsNkJBQVMsT0FBVDtBQUNIO0FBQ0osYUFMRCxDQU1BLE9BQU8sS0FBUCxFQUFjO0FBQUUsc0JBQU0sRUFBRSxPQUFPLEtBQVQsRUFBTjtBQUF5QixhQU56QyxTQU9RO0FBQ0osb0JBQUk7QUFDQSx3QkFBSSxpQkFBaUIsQ0FBQyxjQUFjLElBQWhDLEtBQXlDLEtBQUssWUFBWSxNQUExRCxDQUFKLEVBQXVFLEdBQUcsSUFBSCxDQUFRLFdBQVI7QUFDMUUsaUJBRkQsU0FHUTtBQUFFLHdCQUFJLEdBQUosRUFBUyxNQUFNLElBQUksS0FBVjtBQUFrQjtBQUN4QztBQUNKO0FBQ0QsYUFBSyxZQUFMLEdBQW9CLEtBQXBCO0FBQ0gsS0EzQkQ7QUE0QkEsV0FBTyxVQUFQO0FBQ0gsQ0FwRStCLEVBQWhDO0FBcUVBLFFBQVEsVUFBUixHQUFxQixVQUFyQiIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uKCl7ZnVuY3Rpb24gcihlLG4sdCl7ZnVuY3Rpb24gbyhpLGYpe2lmKCFuW2ldKXtpZighZVtpXSl7dmFyIGM9XCJmdW5jdGlvblwiPT10eXBlb2YgcmVxdWlyZSYmcmVxdWlyZTtpZighZiYmYylyZXR1cm4gYyhpLCEwKTtpZih1KXJldHVybiB1KGksITApO3ZhciBhPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIraStcIidcIik7dGhyb3cgYS5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGF9dmFyIHA9bltpXT17ZXhwb3J0czp7fX07ZVtpXVswXS5jYWxsKHAuZXhwb3J0cyxmdW5jdGlvbihyKXt2YXIgbj1lW2ldWzFdW3JdO3JldHVybiBvKG58fHIpfSxwLHAuZXhwb3J0cyxyLGUsbix0KX1yZXR1cm4gbltpXS5leHBvcnRzfWZvcih2YXIgdT1cImZ1bmN0aW9uXCI9PXR5cGVvZiByZXF1aXJlJiZyZXF1aXJlLGk9MDtpPHQubGVuZ3RoO2krKylvKHRbaV0pO3JldHVybiBvfXJldHVybiByfSkoKSIsIi8vIENvcHlyaWdodCAyMDE4IFRoZSBPdXRsaW5lIEF1dGhvcnNcbi8vXG4vLyBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuLy8geW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuLy8gWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4vL1xuLy8gICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbi8vXG4vLyBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4vLyBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4vLyBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbi8vIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbi8vIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuXG4vKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuY29uc3QgaXNCcm93c2VyID0gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCc7XG5jb25zdCBiNjRFbmNvZGUgPSBpc0Jyb3dzZXIgPyBidG9hIDogcmVxdWlyZSgnYmFzZS02NCcpLmVuY29kZTtcbmNvbnN0IGI2NERlY29kZSA9IGlzQnJvd3NlciA/IGF0b2IgOiByZXF1aXJlKCdiYXNlLTY0JykuZGVjb2RlO1xuY29uc3QgVVJMID0gaXNCcm93c2VyID8gd2luZG93LlVSTCA6IHJlcXVpcmUoJ3VybCcpLlVSTDtcbmNvbnN0IHB1bnljb2RlID0gaXNCcm93c2VyID8gKHdpbmRvdyBhcyBhbnkpLnB1bnljb2RlIDogcmVxdWlyZSgncHVueWNvZGUnKTtcbmlmICghcHVueWNvZGUpIHtcbiAgdGhyb3cgbmV3IEVycm9yKGBDb3VsZCBub3QgZmluZCBwdW55Y29kZS4gRGlkIHlvdSBmb3JnZXQgdG8gYWRkIGUuZy5cbiAgPHNjcmlwdCBzcmM9XCJib3dlcl9jb21wb25lbnRzL3B1bnljb2RlL3B1bnljb2RlLm1pbi5qc1wiPjwvc2NyaXB0Pj9gKTtcbn1cbi8qIHRzbGludDplbmFibGUgKi9cblxuLy8gQ3VzdG9tIGVycm9yIGJhc2UgY2xhc3NcbmV4cG9ydCBjbGFzcyBTaGFkb3dzb2Nrc0NvbmZpZ0Vycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihtZXNzYWdlOiBzdHJpbmcpIHtcbiAgICBzdXBlcihtZXNzYWdlKTsgIC8vICdFcnJvcicgYnJlYWtzIHByb3RvdHlwZSBjaGFpbiBoZXJlIGlmIHRoaXMgaXMgdHJhbnNwaWxlZCB0byBlczVcbiAgICBPYmplY3Quc2V0UHJvdG90eXBlT2YodGhpcywgbmV3LnRhcmdldC5wcm90b3R5cGUpOyAgLy8gcmVzdG9yZSBwcm90b3R5cGUgY2hhaW5cbiAgICB0aGlzLm5hbWUgPSBuZXcudGFyZ2V0Lm5hbWU7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIEludmFsaWRDb25maWdGaWVsZCBleHRlbmRzIFNoYWRvd3NvY2tzQ29uZmlnRXJyb3Ige31cblxuZXhwb3J0IGNsYXNzIEludmFsaWRVcmkgZXh0ZW5kcyBTaGFkb3dzb2Nrc0NvbmZpZ0Vycm9yIHt9XG5cbi8vIFNlbGYtdmFsaWRhdGluZy9ub3JtYWxpemluZyBjb25maWcgZGF0YSB0eXBlcyBpbXBsZW1lbnQgdGhpcyBWYWxpZGF0ZWRDb25maWdGaWVsZCBpbnRlcmZhY2UuXG4vLyBDb25zdHJ1Y3RvcnMgdGFrZSBzb21lIGRhdGEsIHZhbGlkYXRlLCBub3JtYWxpemUsIGFuZCBzdG9yZSBpZiB2YWxpZCwgb3IgdGhyb3cgb3RoZXJ3aXNlLlxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIFZhbGlkYXRlZENvbmZpZ0ZpZWxkIHt9XG5cbmZ1bmN0aW9uIHRocm93RXJyb3JGb3JJbnZhbGlkRmllbGQobmFtZTogc3RyaW5nLCB2YWx1ZToge30sIHJlYXNvbj86IHN0cmluZykge1xuICB0aHJvdyBuZXcgSW52YWxpZENvbmZpZ0ZpZWxkKGBJbnZhbGlkICR7bmFtZX06ICR7dmFsdWV9ICR7cmVhc29uIHx8ICcnfWApO1xufVxuXG5leHBvcnQgY2xhc3MgSG9zdCBleHRlbmRzIFZhbGlkYXRlZENvbmZpZ0ZpZWxkIHtcbiAgcHVibGljIHN0YXRpYyBJUFY0X1BBVFRFUk4gPSAvXig/OlswLTldezEsM31cXC4pezN9WzAtOV17MSwzfSQvO1xuICBwdWJsaWMgc3RhdGljIElQVjZfUEFUVEVSTiA9IC9eKD86W0EtRjAtOV17MSw0fTopezd9W0EtRjAtOV17MSw0fSQvaTtcbiAgcHVibGljIHN0YXRpYyBIT1NUTkFNRV9QQVRURVJOID0gL15bQS16MC05XStbQS16MC05Xy4tXSokLztcbiAgcHVibGljIHJlYWRvbmx5IGRhdGE6IHN0cmluZztcbiAgcHVibGljIHJlYWRvbmx5IGlzSVB2NDogYm9vbGVhbjtcbiAgcHVibGljIHJlYWRvbmx5IGlzSVB2NjogYm9vbGVhbjtcbiAgcHVibGljIHJlYWRvbmx5IGlzSG9zdG5hbWU6IGJvb2xlYW47XG5cbiAgY29uc3RydWN0b3IoaG9zdDogSG9zdCB8IHN0cmluZykge1xuICAgIHN1cGVyKCk7XG4gICAgaWYgKCFob3N0KSB7XG4gICAgICB0aHJvd0Vycm9yRm9ySW52YWxpZEZpZWxkKCdob3N0JywgaG9zdCk7XG4gICAgfVxuICAgIGlmIChob3N0IGluc3RhbmNlb2YgSG9zdCkge1xuICAgICAgaG9zdCA9IGhvc3QuZGF0YTtcbiAgICB9XG4gICAgaG9zdCA9IHB1bnljb2RlLnRvQVNDSUkoaG9zdCkgYXMgc3RyaW5nO1xuICAgIHRoaXMuaXNJUHY0ID0gSG9zdC5JUFY0X1BBVFRFUk4udGVzdChob3N0KTtcbiAgICB0aGlzLmlzSVB2NiA9IHRoaXMuaXNJUHY0ID8gZmFsc2UgOiBIb3N0LklQVjZfUEFUVEVSTi50ZXN0KGhvc3QpO1xuICAgIHRoaXMuaXNIb3N0bmFtZSA9IHRoaXMuaXNJUHY0IHx8IHRoaXMuaXNJUHY2ID8gZmFsc2UgOiBIb3N0LkhPU1ROQU1FX1BBVFRFUk4udGVzdChob3N0KTtcbiAgICBpZiAoISh0aGlzLmlzSVB2NCB8fCB0aGlzLmlzSVB2NiB8fCB0aGlzLmlzSG9zdG5hbWUpKSB7XG4gICAgICB0aHJvd0Vycm9yRm9ySW52YWxpZEZpZWxkKCdob3N0JywgaG9zdCk7XG4gICAgfVxuICAgIHRoaXMuZGF0YSA9IGhvc3Q7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIFBvcnQgZXh0ZW5kcyBWYWxpZGF0ZWRDb25maWdGaWVsZCB7XG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgUEFUVEVSTiA9IC9eWzAtOV17MSw1fSQvO1xuICBwdWJsaWMgcmVhZG9ubHkgZGF0YTogbnVtYmVyO1xuXG4gIGNvbnN0cnVjdG9yKHBvcnQ6IFBvcnQgfCBzdHJpbmcgfCBudW1iZXIpIHtcbiAgICBzdXBlcigpO1xuICAgIGlmIChwb3J0IGluc3RhbmNlb2YgUG9ydCkge1xuICAgICAgcG9ydCA9IHBvcnQuZGF0YTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBwb3J0ID09PSAnbnVtYmVyJykge1xuICAgICAgLy8gU3RyaW5naWZ5IGluIGNhc2UgbmVnYXRpdmUgb3IgZmxvYXRpbmcgcG9pbnQgLT4gdGhlIHJlZ2V4IHRlc3QgYmVsb3cgd2lsbCBjYXRjaC5cbiAgICAgIHBvcnQgPSBwb3J0LnRvU3RyaW5nKCk7XG4gICAgfVxuICAgIGlmICghUG9ydC5QQVRURVJOLnRlc3QocG9ydCkpIHtcbiAgICAgIHRocm93RXJyb3JGb3JJbnZhbGlkRmllbGQoJ3BvcnQnLCBwb3J0KTtcbiAgICB9XG4gICAgLy8gQ291bGQgZXhjZWVkIHRoZSBtYXhpbXVtIHBvcnQgbnVtYmVyLCBzbyBjb252ZXJ0IHRvIE51bWJlciB0byBjaGVjay4gQ291bGQgYWxzbyBoYXZlIGxlYWRpbmdcbiAgICAvLyB6ZXJvcy4gQ29udmVydGluZyB0byBOdW1iZXIgZHJvcHMgdGhvc2UsIHNvIHdlIGdldCBub3JtYWxpemF0aW9uIGZvciBmcmVlLiA6KVxuICAgIHBvcnQgPSBOdW1iZXIocG9ydCk7XG4gICAgaWYgKHBvcnQgPiA2NTUzNSkge1xuICAgICAgdGhyb3dFcnJvckZvckludmFsaWRGaWVsZCgncG9ydCcsIHBvcnQpO1xuICAgIH1cbiAgICB0aGlzLmRhdGEgPSBwb3J0O1xuICB9XG59XG5cbi8vIEEgbWV0aG9kIHZhbHVlIG11c3QgZXhhY3RseSBtYXRjaCBhbiBlbGVtZW50IGluIHRoZSBzZXQgb2Yga25vd24gY2lwaGVycy5cbi8vIHJlZjogaHR0cHM6Ly9naXRodWIuY29tL3NoYWRvd3NvY2tzL3NoYWRvd3NvY2tzLWxpYmV2L2Jsb2IvMTBhMmQzZTMvY29tcGxldGlvbnMvYmFzaC9zcy1yZWRpciNMNVxuZXhwb3J0IGNvbnN0IE1FVEhPRFMgPSBuZXcgU2V0KFtcbiAgJ3JjNC1tZDUnLFxuICAnYWVzLTEyOC1nY20nLFxuICAnYWVzLTE5Mi1nY20nLFxuICAnYWVzLTI1Ni1nY20nLFxuICAnYWVzLTEyOC1jZmInLFxuICAnYWVzLTE5Mi1jZmInLFxuICAnYWVzLTI1Ni1jZmInLFxuICAnYWVzLTEyOC1jdHInLFxuICAnYWVzLTE5Mi1jdHInLFxuICAnYWVzLTI1Ni1jdHInLFxuICAnY2FtZWxsaWEtMTI4LWNmYicsXG4gICdjYW1lbGxpYS0xOTItY2ZiJyxcbiAgJ2NhbWVsbGlhLTI1Ni1jZmInLFxuICAnYmYtY2ZiJyxcbiAgJ2NoYWNoYTIwLWlldGYtcG9seTEzMDUnLFxuICAnc2Fsc2EyMCcsXG4gICdjaGFjaGEyMCcsXG4gICdjaGFjaGEyMC1pZXRmJyxcbiAgJ3hjaGFjaGEyMC1pZXRmLXBvbHkxMzA1Jyxcbl0pO1xuXG5leHBvcnQgY2xhc3MgTWV0aG9kIGV4dGVuZHMgVmFsaWRhdGVkQ29uZmlnRmllbGQge1xuICBwdWJsaWMgcmVhZG9ubHkgZGF0YTogc3RyaW5nO1xuICBjb25zdHJ1Y3RvcihtZXRob2Q6IE1ldGhvZCB8IHN0cmluZykge1xuICAgIHN1cGVyKCk7XG4gICAgaWYgKG1ldGhvZCBpbnN0YW5jZW9mIE1ldGhvZCkge1xuICAgICAgbWV0aG9kID0gbWV0aG9kLmRhdGE7XG4gICAgfVxuICAgIGlmICghTUVUSE9EUy5oYXMobWV0aG9kKSkge1xuICAgICAgdGhyb3dFcnJvckZvckludmFsaWRGaWVsZCgnbWV0aG9kJywgbWV0aG9kKTtcbiAgICB9XG4gICAgdGhpcy5kYXRhID0gbWV0aG9kO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBQYXNzd29yZCBleHRlbmRzIFZhbGlkYXRlZENvbmZpZ0ZpZWxkIHtcbiAgcHVibGljIHJlYWRvbmx5IGRhdGE6IHN0cmluZztcblxuICBjb25zdHJ1Y3RvcihwYXNzd29yZDogUGFzc3dvcmQgfCBzdHJpbmcpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuZGF0YSA9IHBhc3N3b3JkIGluc3RhbmNlb2YgUGFzc3dvcmQgPyBwYXNzd29yZC5kYXRhIDogcGFzc3dvcmQ7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIFRhZyBleHRlbmRzIFZhbGlkYXRlZENvbmZpZ0ZpZWxkIHtcbiAgcHVibGljIHJlYWRvbmx5IGRhdGE6IHN0cmluZztcblxuICBjb25zdHJ1Y3Rvcih0YWc6IFRhZyB8IHN0cmluZyA9ICcnKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLmRhdGEgPSB0YWcgaW5zdGFuY2VvZiBUYWcgPyB0YWcuZGF0YSA6IHRhZztcbiAgfVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZyB7XG4gIGhvc3Q6IEhvc3Q7XG4gIHBvcnQ6IFBvcnQ7XG4gIG1ldGhvZDogTWV0aG9kO1xuICBwYXNzd29yZDogUGFzc3dvcmQ7XG4gIHRhZzogVGFnO1xuICAvLyBBbnkgYWRkaXRpb25hbCBjb25maWd1cmF0aW9uIChlLmcuIGB0aW1lb3V0YCwgU0lQMDAzIGBwbHVnaW5gLCBldGMuKSBtYXkgYmUgc3RvcmVkIGhlcmUuXG4gIGV4dHJhOiB7W2tleTogc3RyaW5nXTogc3RyaW5nfTtcbn1cblxuLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOm5vLWFueVxuZXhwb3J0IGZ1bmN0aW9uIG1ha2VDb25maWcoaW5wdXQ6IHtba2V5OiBzdHJpbmddOiBhbnl9KTogQ29uZmlnIHtcbiAgLy8gVXNlIFwiIVwiIGZvciB0aGUgcmVxdWlyZWQgZmllbGRzIHRvIHRlbGwgdHNjIHRoYXQgd2UgaGFuZGxlIHVuZGVmaW5lZCBpbiB0aGVcbiAgLy8gVmFsaWRhdGVkQ29uZmlnRmllbGRzIHdlIGNhbGw7IHRzYyBjYW4ndCBmaWd1cmUgdGhhdCBvdXQgb3RoZXJ3aXNlLlxuICBjb25zdCBjb25maWcgPSB7XG4gICAgaG9zdDogbmV3IEhvc3QoaW5wdXQuaG9zdCEpLFxuICAgIHBvcnQ6IG5ldyBQb3J0KGlucHV0LnBvcnQhKSxcbiAgICBtZXRob2Q6IG5ldyBNZXRob2QoaW5wdXQubWV0aG9kISksXG4gICAgcGFzc3dvcmQ6IG5ldyBQYXNzd29yZChpbnB1dC5wYXNzd29yZCEpLFxuICAgIHRhZzogbmV3IFRhZyhpbnB1dC50YWcpLCAgLy8gaW5wdXQudGFnIG1pZ2h0IGJlIHVuZGVmaW5lZCBidXQgVGFnKCkgaGFuZGxlcyB0aGF0IGZpbmUuXG4gICAgZXh0cmE6IHt9IGFzIHtba2V5OiBzdHJpbmddOiBzdHJpbmd9LFxuICB9O1xuICAvLyBQdXQgYW55IHJlbWFpbmluZyBmaWVsZHMgaW4gYGlucHV0YCBpbnRvIGBjb25maWcuZXh0cmFgLlxuICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhpbnB1dCkpIHtcbiAgICBpZiAoIS9eKGhvc3R8cG9ydHxtZXRob2R8cGFzc3dvcmR8dGFnKSQvLnRlc3Qoa2V5KSkge1xuICAgICAgY29uZmlnLmV4dHJhW2tleV0gPSBpbnB1dFtrZXldICYmIGlucHV0W2tleV0udG9TdHJpbmcoKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGNvbmZpZztcbn1cblxuZXhwb3J0IGNvbnN0IFNIQURPV1NPQ0tTX1VSSSA9IHtcbiAgUFJPVE9DT0w6ICdzczonLFxuXG4gIGdldFVyaUZvcm1hdHRlZEhvc3Q6IChob3N0OiBIb3N0KSA9PiB7XG4gICAgcmV0dXJuIGhvc3QuaXNJUHY2ID8gYFske2hvc3QuZGF0YX1dYCA6IGhvc3QuZGF0YTtcbiAgfSxcblxuICBnZXRIYXNoOiAodGFnOiBUYWcpID0+IHtcbiAgICByZXR1cm4gdGFnLmRhdGEgPyBgIyR7ZW5jb2RlVVJJQ29tcG9uZW50KHRhZy5kYXRhKX1gIDogJyc7XG4gIH0sXG5cbiAgdmFsaWRhdGVQcm90b2NvbDogKHVyaTogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCF1cmkuc3RhcnRzV2l0aChTSEFET1dTT0NLU19VUkkuUFJPVE9DT0wpKSB7XG4gICAgICB0aHJvdyBuZXcgSW52YWxpZFVyaShgVVJJIG11c3Qgc3RhcnQgd2l0aCBcIiR7U0hBRE9XU09DS1NfVVJJLlBST1RPQ09MfVwiYCk7XG4gICAgfVxuICB9LFxuXG4gIHBhcnNlOiAodXJpOiBzdHJpbmcpOiBDb25maWcgPT4ge1xuICAgIGxldCBlcnJvcjogRXJyb3IgfCB1bmRlZmluZWQ7XG4gICAgZm9yIChjb25zdCB1cmlUeXBlIG9mIFtTSVAwMDJfVVJJLCBMRUdBQ1lfQkFTRTY0X1VSSV0pIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiB1cmlUeXBlLnBhcnNlKHVyaSk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGVycm9yID0gZTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCEoZXJyb3IgaW5zdGFuY2VvZiBJbnZhbGlkVXJpKSkge1xuICAgICAgY29uc3Qgb3JpZ2luYWxFcnJvck5hbWUgPSBlcnJvciEubmFtZSEgfHwgJyhVbm5hbWVkIEVycm9yKSc7XG4gICAgICBjb25zdCBvcmlnaW5hbEVycm9yTWVzc2FnZSA9IGVycm9yIS5tZXNzYWdlISB8fCAnKG5vIGVycm9yIG1lc3NhZ2UgcHJvdmlkZWQpJztcbiAgICAgIGNvbnN0IG9yaWdpbmFsRXJyb3JTdHJpbmcgPSBgJHtvcmlnaW5hbEVycm9yTmFtZX06ICR7b3JpZ2luYWxFcnJvck1lc3NhZ2V9YDtcbiAgICAgIGNvbnN0IG5ld0Vycm9yTWVzc2FnZSA9IGBJbnZhbGlkIGlucHV0OiAke29yaWdpbmFsRXJyb3JTdHJpbmd9YDtcbiAgICAgIGVycm9yID0gbmV3IEludmFsaWRVcmkobmV3RXJyb3JNZXNzYWdlKTtcbiAgICB9XG4gICAgdGhyb3cgZXJyb3I7XG4gIH0sXG59O1xuXG4vLyBSZWY6IGh0dHBzOi8vc2hhZG93c29ja3Mub3JnL2VuL2NvbmZpZy9xdWljay1ndWlkZS5odG1sXG5leHBvcnQgY29uc3QgTEVHQUNZX0JBU0U2NF9VUkkgPSB7XG4gIHBhcnNlOiAodXJpOiBzdHJpbmcpOiBDb25maWcgPT4ge1xuICAgIFNIQURPV1NPQ0tTX1VSSS52YWxpZGF0ZVByb3RvY29sKHVyaSk7XG4gICAgY29uc3QgaGFzaEluZGV4ID0gdXJpLmluZGV4T2YoJyMnKTtcbiAgICBjb25zdCBoYXNUYWcgPSBoYXNoSW5kZXggIT09IC0xO1xuICAgIGNvbnN0IGI2NEVuZEluZGV4ID0gaGFzVGFnID8gaGFzaEluZGV4IDogdXJpLmxlbmd0aDtcbiAgICBjb25zdCB0YWdTdGFydEluZGV4ID0gaGFzVGFnID8gaGFzaEluZGV4ICsgMSA6IHVyaS5sZW5ndGg7XG4gICAgY29uc3QgdGFnID0gbmV3IFRhZyhkZWNvZGVVUklDb21wb25lbnQodXJpLnN1YnN0cmluZyh0YWdTdGFydEluZGV4KSkpO1xuICAgIGNvbnN0IGI2NEVuY29kZWREYXRhID0gdXJpLnN1YnN0cmluZygnc3M6Ly8nLmxlbmd0aCwgYjY0RW5kSW5kZXgpO1xuICAgIGNvbnN0IGI2NERlY29kZWREYXRhID0gYjY0RGVjb2RlKGI2NEVuY29kZWREYXRhKTtcbiAgICBjb25zdCBhdFNpZ25JbmRleCA9IGI2NERlY29kZWREYXRhLmxhc3RJbmRleE9mKCdAJyk7XG4gICAgaWYgKGF0U2lnbkluZGV4ID09PSAtMSkge1xuICAgICAgdGhyb3cgbmV3IEludmFsaWRVcmkoYE1pc3NpbmcgXCJAXCJgKTtcbiAgICB9XG4gICAgY29uc3QgbWV0aG9kQW5kUGFzc3dvcmQgPSBiNjREZWNvZGVkRGF0YS5zdWJzdHJpbmcoMCwgYXRTaWduSW5kZXgpO1xuICAgIGNvbnN0IG1ldGhvZEVuZEluZGV4ID0gbWV0aG9kQW5kUGFzc3dvcmQuaW5kZXhPZignOicpO1xuICAgIGlmIChtZXRob2RFbmRJbmRleCA9PT0gLTEpIHtcbiAgICAgIHRocm93IG5ldyBJbnZhbGlkVXJpKGBNaXNzaW5nIHBhc3N3b3JkYCk7XG4gICAgfVxuICAgIGNvbnN0IG1ldGhvZFN0cmluZyA9IG1ldGhvZEFuZFBhc3N3b3JkLnN1YnN0cmluZygwLCBtZXRob2RFbmRJbmRleCk7XG4gICAgY29uc3QgbWV0aG9kID0gbmV3IE1ldGhvZChtZXRob2RTdHJpbmcpO1xuICAgIGNvbnN0IHBhc3N3b3JkU3RhcnRJbmRleCA9IG1ldGhvZEVuZEluZGV4ICsgMTtcbiAgICBjb25zdCBwYXNzd29yZFN0cmluZyA9IG1ldGhvZEFuZFBhc3N3b3JkLnN1YnN0cmluZyhwYXNzd29yZFN0YXJ0SW5kZXgpO1xuICAgIGNvbnN0IHBhc3N3b3JkID0gbmV3IFBhc3N3b3JkKHBhc3N3b3JkU3RyaW5nKTtcbiAgICBjb25zdCBob3N0U3RhcnRJbmRleCA9IGF0U2lnbkluZGV4ICsgMTtcbiAgICBjb25zdCBob3N0QW5kUG9ydCA9IGI2NERlY29kZWREYXRhLnN1YnN0cmluZyhob3N0U3RhcnRJbmRleCk7XG4gICAgY29uc3QgaG9zdEVuZEluZGV4ID0gaG9zdEFuZFBvcnQubGFzdEluZGV4T2YoJzonKTtcbiAgICBpZiAoaG9zdEVuZEluZGV4ID09PSAtMSkge1xuICAgICAgdGhyb3cgbmV3IEludmFsaWRVcmkoYE1pc3NpbmcgcG9ydGApO1xuICAgIH1cbiAgICBjb25zdCB1cmlGb3JtYXR0ZWRIb3N0ID0gaG9zdEFuZFBvcnQuc3Vic3RyaW5nKDAsIGhvc3RFbmRJbmRleCk7XG4gICAgbGV0IGhvc3Q6IEhvc3Q7XG4gICAgdHJ5IHtcbiAgICAgIGhvc3QgPSBuZXcgSG9zdCh1cmlGb3JtYXR0ZWRIb3N0KTtcbiAgICB9IGNhdGNoIChfKSB7XG4gICAgICAvLyBDb3VsZCBiZSBJUHY2IGhvc3QgZm9ybWF0dGVkIHdpdGggc3Vycm91bmRpbmcgYnJhY2tldHMsIHNvIHRyeSBzdHJpcHBpbmcgZmlyc3QgYW5kIGxhc3RcbiAgICAgIC8vIGNoYXJhY3RlcnMuIElmIHRoaXMgdGhyb3dzLCBnaXZlIHVwIGFuZCBsZXQgdGhlIGV4Y2VwdGlvbiBwcm9wYWdhdGUuXG4gICAgICBob3N0ID0gbmV3IEhvc3QodXJpRm9ybWF0dGVkSG9zdC5zdWJzdHJpbmcoMSwgdXJpRm9ybWF0dGVkSG9zdC5sZW5ndGggLSAxKSk7XG4gICAgfVxuICAgIGNvbnN0IHBvcnRTdGFydEluZGV4ID0gaG9zdEVuZEluZGV4ICsgMTtcbiAgICBjb25zdCBwb3J0U3RyaW5nID0gaG9zdEFuZFBvcnQuc3Vic3RyaW5nKHBvcnRTdGFydEluZGV4KTtcbiAgICBjb25zdCBwb3J0ID0gbmV3IFBvcnQocG9ydFN0cmluZyk7XG4gICAgY29uc3QgZXh0cmEgPSB7fSBhcyB7W2tleTogc3RyaW5nXTogc3RyaW5nfTsgIC8vIGVtcHR5IGJlY2F1c2UgTGVnYWN5QmFzZTY0VXJpIGNhbid0IGhvbGQgZXh0cmFcbiAgICByZXR1cm4ge21ldGhvZCwgcGFzc3dvcmQsIGhvc3QsIHBvcnQsIHRhZywgZXh0cmF9O1xuICB9LFxuXG4gIHN0cmluZ2lmeTogKGNvbmZpZzogQ29uZmlnKSA9PiB7XG4gICAgY29uc3Qge2hvc3QsIHBvcnQsIG1ldGhvZCwgcGFzc3dvcmQsIHRhZ30gPSBjb25maWc7XG4gICAgY29uc3QgaGFzaCA9IFNIQURPV1NPQ0tTX1VSSS5nZXRIYXNoKHRhZyk7XG4gICAgbGV0IGI2NEVuY29kZWREYXRhID0gYjY0RW5jb2RlKGAke21ldGhvZC5kYXRhfToke3Bhc3N3b3JkLmRhdGF9QCR7aG9zdC5kYXRhfToke3BvcnQuZGF0YX1gKTtcbiAgICBjb25zdCBkYXRhTGVuZ3RoID0gYjY0RW5jb2RlZERhdGEubGVuZ3RoO1xuICAgIGxldCBwYWRkaW5nTGVuZ3RoID0gMDtcbiAgICBmb3IgKDsgYjY0RW5jb2RlZERhdGFbZGF0YUxlbmd0aCAtIDEgLSBwYWRkaW5nTGVuZ3RoXSA9PT0gJz0nOyBwYWRkaW5nTGVuZ3RoKyspO1xuICAgIGI2NEVuY29kZWREYXRhID0gcGFkZGluZ0xlbmd0aCA9PT0gMCA/IGI2NEVuY29kZWREYXRhIDpcbiAgICAgICAgYjY0RW5jb2RlZERhdGEuc3Vic3RyaW5nKDAsIGRhdGFMZW5ndGggLSBwYWRkaW5nTGVuZ3RoKTtcbiAgICByZXR1cm4gYHNzOi8vJHtiNjRFbmNvZGVkRGF0YX0ke2hhc2h9YDtcbiAgfSxcbn07XG5cbi8vIFJlZjogaHR0cHM6Ly9zaGFkb3dzb2Nrcy5vcmcvZW4vc3BlYy9TSVAwMDItVVJJLVNjaGVtZS5odG1sXG5leHBvcnQgY29uc3QgU0lQMDAyX1VSSSA9IHtcbiAgcGFyc2U6ICh1cmk6IHN0cmluZyk6IENvbmZpZyA9PiB7XG4gICAgU0hBRE9XU09DS1NfVVJJLnZhbGlkYXRlUHJvdG9jb2wodXJpKTtcbiAgICAvLyBDYW4gdXNlIGJ1aWx0LWluIFVSTCBwYXJzZXIgZm9yIGV4cGVkaWVuY2UuIEp1c3QgaGF2ZSB0byByZXBsYWNlIFwic3NcIiB3aXRoIFwiaHR0cFwiIHRvIGVuc3VyZVxuICAgIC8vIGNvcnJlY3QgcmVzdWx0cywgb3RoZXJ3aXNlIGJyb3dzZXJzIGxpa2UgU2FmYXJpIGZhaWwgdG8gcGFyc2UgaXQuXG4gICAgY29uc3QgaW5wdXRGb3JVcmxQYXJzZXIgPSBgaHR0cCR7dXJpLnN1YnN0cmluZygyKX1gO1xuICAgIC8vIFRoZSBidWlsdC1pbiBVUkwgcGFyc2VyIHRocm93cyBhcyBkZXNpcmVkIHdoZW4gZ2l2ZW4gVVJJcyB3aXRoIGludmFsaWQgc3ludGF4LlxuICAgIGNvbnN0IHVybFBhcnNlclJlc3VsdCA9IG5ldyBVUkwoaW5wdXRGb3JVcmxQYXJzZXIpO1xuICAgIGNvbnN0IHVyaUZvcm1hdHRlZEhvc3QgPSB1cmxQYXJzZXJSZXN1bHQuaG9zdG5hbWU7XG4gICAgLy8gVVJJLWZvcm1hdHRlZCBJUHY2IGhvc3RuYW1lcyBoYXZlIHN1cnJvdW5kaW5nIGJyYWNrZXRzLlxuICAgIGNvbnN0IGxhc3QgPSB1cmlGb3JtYXR0ZWRIb3N0Lmxlbmd0aCAtIDE7XG4gICAgY29uc3QgYnJhY2tldHMgPSB1cmlGb3JtYXR0ZWRIb3N0WzBdID09PSAnWycgJiYgdXJpRm9ybWF0dGVkSG9zdFtsYXN0XSA9PT0gJ10nO1xuICAgIGNvbnN0IGhvc3RTdHJpbmcgPSBicmFja2V0cyA/IHVyaUZvcm1hdHRlZEhvc3Quc3Vic3RyaW5nKDEsIGxhc3QpIDogdXJpRm9ybWF0dGVkSG9zdDtcbiAgICBjb25zdCBob3N0ID0gbmV3IEhvc3QoaG9zdFN0cmluZyk7XG4gICAgbGV0IHBhcnNlZFBvcnQgPSB1cmxQYXJzZXJSZXN1bHQucG9ydDtcbiAgICBpZiAoIXBhcnNlZFBvcnQgJiYgdXJpLm1hdGNoKC86ODAoJHxcXC8pL2cpKSB7XG4gICAgICAvLyBUaGUgZGVmYXVsdCBVUkwgcGFyc2VyIGZhaWxzIHRvIHJlY29nbml6ZSB0aGUgZGVmYXVsdCBwb3J0ICg4MCkgd2hlbiB0aGUgVVJJIGJlaW5nIHBhcnNlZFxuICAgICAgLy8gaXMgSFRUUC4gQ2hlY2sgaWYgdGhlIHBvcnQgaXMgcHJlc2VudCBhdCB0aGUgZW5kIG9mIHRoZSBzdHJpbmcgb3IgYmVmb3JlIHRoZSBwYXJhbWV0ZXJzLlxuICAgICAgcGFyc2VkUG9ydCA9IDgwO1xuICAgIH1cbiAgICBjb25zdCBwb3J0ID0gbmV3IFBvcnQocGFyc2VkUG9ydCk7XG4gICAgY29uc3QgdGFnID0gbmV3IFRhZyhkZWNvZGVVUklDb21wb25lbnQodXJsUGFyc2VyUmVzdWx0Lmhhc2guc3Vic3RyaW5nKDEpKSk7XG4gICAgY29uc3QgYjY0RW5jb2RlZFVzZXJJbmZvID0gdXJsUGFyc2VyUmVzdWx0LnVzZXJuYW1lLnJlcGxhY2UoLyUzRC9nLCAnPScpO1xuICAgIC8vIGJhc2U2NC5kZWNvZGUgdGhyb3dzIGFzIGRlc2lyZWQgd2hlbiBnaXZlbiBpbnZhbGlkIGJhc2U2NCBpbnB1dC5cbiAgICBjb25zdCBiNjREZWNvZGVkVXNlckluZm8gPSBiNjREZWNvZGUoYjY0RW5jb2RlZFVzZXJJbmZvKTtcbiAgICBjb25zdCBjb2xvbklkeCA9IGI2NERlY29kZWRVc2VySW5mby5pbmRleE9mKCc6Jyk7XG4gICAgaWYgKGNvbG9uSWR4ID09PSAtMSkge1xuICAgICAgdGhyb3cgbmV3IEludmFsaWRVcmkoYE1pc3NpbmcgcGFzc3dvcmRgKTtcbiAgICB9XG4gICAgY29uc3QgbWV0aG9kU3RyaW5nID0gYjY0RGVjb2RlZFVzZXJJbmZvLnN1YnN0cmluZygwLCBjb2xvbklkeCk7XG4gICAgY29uc3QgbWV0aG9kID0gbmV3IE1ldGhvZChtZXRob2RTdHJpbmcpO1xuICAgIGNvbnN0IHBhc3N3b3JkU3RyaW5nID0gYjY0RGVjb2RlZFVzZXJJbmZvLnN1YnN0cmluZyhjb2xvbklkeCArIDEpO1xuICAgIGNvbnN0IHBhc3N3b3JkID0gbmV3IFBhc3N3b3JkKHBhc3N3b3JkU3RyaW5nKTtcbiAgICBjb25zdCBxdWVyeVBhcmFtcyA9IHVybFBhcnNlclJlc3VsdC5zZWFyY2guc3Vic3RyaW5nKDEpLnNwbGl0KCcmJyk7XG4gICAgY29uc3QgZXh0cmEgPSB7fSBhcyB7W2tleTogc3RyaW5nXTogc3RyaW5nfTtcbiAgICBmb3IgKGNvbnN0IHBhaXIgb2YgcXVlcnlQYXJhbXMpIHtcbiAgICAgIGNvbnN0IFtrZXksIHZhbHVlXSA9IHBhaXIuc3BsaXQoJz0nLCAyKTtcbiAgICAgIGlmICgha2V5KSBjb250aW51ZTtcbiAgICAgIGV4dHJhW2tleV0gPSBkZWNvZGVVUklDb21wb25lbnQodmFsdWUgfHwgJycpO1xuICAgIH1cbiAgICByZXR1cm4ge21ldGhvZCwgcGFzc3dvcmQsIGhvc3QsIHBvcnQsIHRhZywgZXh0cmF9O1xuICB9LFxuXG4gIHN0cmluZ2lmeTogKGNvbmZpZzogQ29uZmlnKSA9PiB7XG4gICAgY29uc3Qge2hvc3QsIHBvcnQsIG1ldGhvZCwgcGFzc3dvcmQsIHRhZywgZXh0cmF9ID0gY29uZmlnO1xuICAgIGNvbnN0IHVzZXJJbmZvID0gYjY0RW5jb2RlKGAke21ldGhvZC5kYXRhfToke3Bhc3N3b3JkLmRhdGF9YCk7XG4gICAgY29uc3QgdXJpSG9zdCA9IFNIQURPV1NPQ0tTX1VSSS5nZXRVcmlGb3JtYXR0ZWRIb3N0KGhvc3QpO1xuICAgIGNvbnN0IGhhc2ggPSBTSEFET1dTT0NLU19VUkkuZ2V0SGFzaCh0YWcpO1xuICAgIGxldCBxdWVyeVN0cmluZyA9ICcnO1xuICAgIGZvciAoY29uc3Qga2V5IGluIGV4dHJhKSB7XG4gICAgICBpZiAoIWtleSkgY29udGludWU7XG4gICAgICBxdWVyeVN0cmluZyArPSAocXVlcnlTdHJpbmcgPyAnJicgOiAnPycpICsgYCR7a2V5fT0ke2VuY29kZVVSSUNvbXBvbmVudChleHRyYVtrZXldKX1gO1xuICAgIH1cbiAgICByZXR1cm4gYHNzOi8vJHt1c2VySW5mb31AJHt1cmlIb3N0fToke3BvcnQuZGF0YX0vJHtxdWVyeVN0cmluZ30ke2hhc2h9YDtcbiAgfSxcbn07XG4iLCIvKiEgaHR0cDovL210aHMuYmUvYmFzZTY0IHYwLjEuMCBieSBAbWF0aGlhcyB8IE1JVCBsaWNlbnNlICovXG47KGZ1bmN0aW9uKHJvb3QpIHtcblxuXHQvLyBEZXRlY3QgZnJlZSB2YXJpYWJsZXMgYGV4cG9ydHNgLlxuXHR2YXIgZnJlZUV4cG9ydHMgPSB0eXBlb2YgZXhwb3J0cyA9PSAnb2JqZWN0JyAmJiBleHBvcnRzO1xuXG5cdC8vIERldGVjdCBmcmVlIHZhcmlhYmxlIGBtb2R1bGVgLlxuXHR2YXIgZnJlZU1vZHVsZSA9IHR5cGVvZiBtb2R1bGUgPT0gJ29iamVjdCcgJiYgbW9kdWxlICYmXG5cdFx0bW9kdWxlLmV4cG9ydHMgPT0gZnJlZUV4cG9ydHMgJiYgbW9kdWxlO1xuXG5cdC8vIERldGVjdCBmcmVlIHZhcmlhYmxlIGBnbG9iYWxgLCBmcm9tIE5vZGUuanMgb3IgQnJvd3NlcmlmaWVkIGNvZGUsIGFuZCB1c2Vcblx0Ly8gaXQgYXMgYHJvb3RgLlxuXHR2YXIgZnJlZUdsb2JhbCA9IHR5cGVvZiBnbG9iYWwgPT0gJ29iamVjdCcgJiYgZ2xvYmFsO1xuXHRpZiAoZnJlZUdsb2JhbC5nbG9iYWwgPT09IGZyZWVHbG9iYWwgfHwgZnJlZUdsb2JhbC53aW5kb3cgPT09IGZyZWVHbG9iYWwpIHtcblx0XHRyb290ID0gZnJlZUdsb2JhbDtcblx0fVxuXG5cdC8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5cdHZhciBJbnZhbGlkQ2hhcmFjdGVyRXJyb3IgPSBmdW5jdGlvbihtZXNzYWdlKSB7XG5cdFx0dGhpcy5tZXNzYWdlID0gbWVzc2FnZTtcblx0fTtcblx0SW52YWxpZENoYXJhY3RlckVycm9yLnByb3RvdHlwZSA9IG5ldyBFcnJvcjtcblx0SW52YWxpZENoYXJhY3RlckVycm9yLnByb3RvdHlwZS5uYW1lID0gJ0ludmFsaWRDaGFyYWN0ZXJFcnJvcic7XG5cblx0dmFyIGVycm9yID0gZnVuY3Rpb24obWVzc2FnZSkge1xuXHRcdC8vIE5vdGU6IHRoZSBlcnJvciBtZXNzYWdlcyB1c2VkIHRocm91Z2hvdXQgdGhpcyBmaWxlIG1hdGNoIHRob3NlIHVzZWQgYnlcblx0XHQvLyB0aGUgbmF0aXZlIGBhdG9iYC9gYnRvYWAgaW1wbGVtZW50YXRpb24gaW4gQ2hyb21pdW0uXG5cdFx0dGhyb3cgbmV3IEludmFsaWRDaGFyYWN0ZXJFcnJvcihtZXNzYWdlKTtcblx0fTtcblxuXHR2YXIgVEFCTEUgPSAnQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLyc7XG5cdC8vIGh0dHA6Ly93aGF0d2cub3JnL2h0bWwvY29tbW9uLW1pY3Jvc3ludGF4ZXMuaHRtbCNzcGFjZS1jaGFyYWN0ZXJcblx0dmFyIFJFR0VYX1NQQUNFX0NIQVJBQ1RFUlMgPSAvW1xcdFxcblxcZlxcciBdL2c7XG5cblx0Ly8gYGRlY29kZWAgaXMgZGVzaWduZWQgdG8gYmUgZnVsbHkgY29tcGF0aWJsZSB3aXRoIGBhdG9iYCBhcyBkZXNjcmliZWQgaW4gdGhlXG5cdC8vIEhUTUwgU3RhbmRhcmQuIGh0dHA6Ly93aGF0d2cub3JnL2h0bWwvd2ViYXBwYXBpcy5odG1sI2RvbS13aW5kb3diYXNlNjQtYXRvYlxuXHQvLyBUaGUgb3B0aW1pemVkIGJhc2U2NC1kZWNvZGluZyBhbGdvcml0aG0gdXNlZCBpcyBiYXNlZCBvbiBAYXRr4oCZcyBleGNlbGxlbnRcblx0Ly8gaW1wbGVtZW50YXRpb24uIGh0dHBzOi8vZ2lzdC5naXRodWIuY29tL2F0ay8xMDIwMzk2XG5cdHZhciBkZWNvZGUgPSBmdW5jdGlvbihpbnB1dCkge1xuXHRcdGlucHV0ID0gU3RyaW5nKGlucHV0KVxuXHRcdFx0LnJlcGxhY2UoUkVHRVhfU1BBQ0VfQ0hBUkFDVEVSUywgJycpO1xuXHRcdHZhciBsZW5ndGggPSBpbnB1dC5sZW5ndGg7XG5cdFx0aWYgKGxlbmd0aCAlIDQgPT0gMCkge1xuXHRcdFx0aW5wdXQgPSBpbnB1dC5yZXBsYWNlKC89PT8kLywgJycpO1xuXHRcdFx0bGVuZ3RoID0gaW5wdXQubGVuZ3RoO1xuXHRcdH1cblx0XHRpZiAoXG5cdFx0XHRsZW5ndGggJSA0ID09IDEgfHxcblx0XHRcdC8vIGh0dHA6Ly93aGF0d2cub3JnL0MjYWxwaGFudW1lcmljLWFzY2lpLWNoYXJhY3RlcnNcblx0XHRcdC9bXithLXpBLVowLTkvXS8udGVzdChpbnB1dClcblx0XHQpIHtcblx0XHRcdGVycm9yKFxuXHRcdFx0XHQnSW52YWxpZCBjaGFyYWN0ZXI6IHRoZSBzdHJpbmcgdG8gYmUgZGVjb2RlZCBpcyBub3QgY29ycmVjdGx5IGVuY29kZWQuJ1xuXHRcdFx0KTtcblx0XHR9XG5cdFx0dmFyIGJpdENvdW50ZXIgPSAwO1xuXHRcdHZhciBiaXRTdG9yYWdlO1xuXHRcdHZhciBidWZmZXI7XG5cdFx0dmFyIG91dHB1dCA9ICcnO1xuXHRcdHZhciBwb3NpdGlvbiA9IC0xO1xuXHRcdHdoaWxlICgrK3Bvc2l0aW9uIDwgbGVuZ3RoKSB7XG5cdFx0XHRidWZmZXIgPSBUQUJMRS5pbmRleE9mKGlucHV0LmNoYXJBdChwb3NpdGlvbikpO1xuXHRcdFx0Yml0U3RvcmFnZSA9IGJpdENvdW50ZXIgJSA0ID8gYml0U3RvcmFnZSAqIDY0ICsgYnVmZmVyIDogYnVmZmVyO1xuXHRcdFx0Ly8gVW5sZXNzIHRoaXMgaXMgdGhlIGZpcnN0IG9mIGEgZ3JvdXAgb2YgNCBjaGFyYWN0ZXJz4oCmXG5cdFx0XHRpZiAoYml0Q291bnRlcisrICUgNCkge1xuXHRcdFx0XHQvLyDigKZjb252ZXJ0IHRoZSBmaXJzdCA4IGJpdHMgdG8gYSBzaW5nbGUgQVNDSUkgY2hhcmFjdGVyLlxuXHRcdFx0XHRvdXRwdXQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShcblx0XHRcdFx0XHQweEZGICYgYml0U3RvcmFnZSA+PiAoLTIgKiBiaXRDb3VudGVyICYgNilcblx0XHRcdFx0KTtcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIG91dHB1dDtcblx0fTtcblxuXHQvLyBgZW5jb2RlYCBpcyBkZXNpZ25lZCB0byBiZSBmdWxseSBjb21wYXRpYmxlIHdpdGggYGJ0b2FgIGFzIGRlc2NyaWJlZCBpbiB0aGVcblx0Ly8gSFRNTCBTdGFuZGFyZDogaHR0cDovL3doYXR3Zy5vcmcvaHRtbC93ZWJhcHBhcGlzLmh0bWwjZG9tLXdpbmRvd2Jhc2U2NC1idG9hXG5cdHZhciBlbmNvZGUgPSBmdW5jdGlvbihpbnB1dCkge1xuXHRcdGlucHV0ID0gU3RyaW5nKGlucHV0KTtcblx0XHRpZiAoL1teXFwwLVxceEZGXS8udGVzdChpbnB1dCkpIHtcblx0XHRcdC8vIE5vdGU6IG5vIG5lZWQgdG8gc3BlY2lhbC1jYXNlIGFzdHJhbCBzeW1ib2xzIGhlcmUsIGFzIHN1cnJvZ2F0ZXMgYXJlXG5cdFx0XHQvLyBtYXRjaGVkLCBhbmQgdGhlIGlucHV0IGlzIHN1cHBvc2VkIHRvIG9ubHkgY29udGFpbiBBU0NJSSBhbnl3YXkuXG5cdFx0XHRlcnJvcihcblx0XHRcdFx0J1RoZSBzdHJpbmcgdG8gYmUgZW5jb2RlZCBjb250YWlucyBjaGFyYWN0ZXJzIG91dHNpZGUgb2YgdGhlICcgK1xuXHRcdFx0XHQnTGF0aW4xIHJhbmdlLidcblx0XHRcdCk7XG5cdFx0fVxuXHRcdHZhciBwYWRkaW5nID0gaW5wdXQubGVuZ3RoICUgMztcblx0XHR2YXIgb3V0cHV0ID0gJyc7XG5cdFx0dmFyIHBvc2l0aW9uID0gLTE7XG5cdFx0dmFyIGE7XG5cdFx0dmFyIGI7XG5cdFx0dmFyIGM7XG5cdFx0dmFyIGQ7XG5cdFx0dmFyIGJ1ZmZlcjtcblx0XHQvLyBNYWtlIHN1cmUgYW55IHBhZGRpbmcgaXMgaGFuZGxlZCBvdXRzaWRlIG9mIHRoZSBsb29wLlxuXHRcdHZhciBsZW5ndGggPSBpbnB1dC5sZW5ndGggLSBwYWRkaW5nO1xuXG5cdFx0d2hpbGUgKCsrcG9zaXRpb24gPCBsZW5ndGgpIHtcblx0XHRcdC8vIFJlYWQgdGhyZWUgYnl0ZXMsIGkuZS4gMjQgYml0cy5cblx0XHRcdGEgPSBpbnB1dC5jaGFyQ29kZUF0KHBvc2l0aW9uKSA8PCAxNjtcblx0XHRcdGIgPSBpbnB1dC5jaGFyQ29kZUF0KCsrcG9zaXRpb24pIDw8IDg7XG5cdFx0XHRjID0gaW5wdXQuY2hhckNvZGVBdCgrK3Bvc2l0aW9uKTtcblx0XHRcdGJ1ZmZlciA9IGEgKyBiICsgYztcblx0XHRcdC8vIFR1cm4gdGhlIDI0IGJpdHMgaW50byBmb3VyIGNodW5rcyBvZiA2IGJpdHMgZWFjaCwgYW5kIGFwcGVuZCB0aGVcblx0XHRcdC8vIG1hdGNoaW5nIGNoYXJhY3RlciBmb3IgZWFjaCBvZiB0aGVtIHRvIHRoZSBvdXRwdXQuXG5cdFx0XHRvdXRwdXQgKz0gKFxuXHRcdFx0XHRUQUJMRS5jaGFyQXQoYnVmZmVyID4+IDE4ICYgMHgzRikgK1xuXHRcdFx0XHRUQUJMRS5jaGFyQXQoYnVmZmVyID4+IDEyICYgMHgzRikgK1xuXHRcdFx0XHRUQUJMRS5jaGFyQXQoYnVmZmVyID4+IDYgJiAweDNGKSArXG5cdFx0XHRcdFRBQkxFLmNoYXJBdChidWZmZXIgJiAweDNGKVxuXHRcdFx0KTtcblx0XHR9XG5cblx0XHRpZiAocGFkZGluZyA9PSAyKSB7XG5cdFx0XHRhID0gaW5wdXQuY2hhckNvZGVBdChwb3NpdGlvbikgPDwgODtcblx0XHRcdGIgPSBpbnB1dC5jaGFyQ29kZUF0KCsrcG9zaXRpb24pO1xuXHRcdFx0YnVmZmVyID0gYSArIGI7XG5cdFx0XHRvdXRwdXQgKz0gKFxuXHRcdFx0XHRUQUJMRS5jaGFyQXQoYnVmZmVyID4+IDEwKSArXG5cdFx0XHRcdFRBQkxFLmNoYXJBdCgoYnVmZmVyID4+IDQpICYgMHgzRikgK1xuXHRcdFx0XHRUQUJMRS5jaGFyQXQoKGJ1ZmZlciA8PCAyKSAmIDB4M0YpICtcblx0XHRcdFx0Jz0nXG5cdFx0XHQpO1xuXHRcdH0gZWxzZSBpZiAocGFkZGluZyA9PSAxKSB7XG5cdFx0XHRidWZmZXIgPSBpbnB1dC5jaGFyQ29kZUF0KHBvc2l0aW9uKTtcblx0XHRcdG91dHB1dCArPSAoXG5cdFx0XHRcdFRBQkxFLmNoYXJBdChidWZmZXIgPj4gMikgK1xuXHRcdFx0XHRUQUJMRS5jaGFyQXQoKGJ1ZmZlciA8PCA0KSAmIDB4M0YpICtcblx0XHRcdFx0Jz09J1xuXHRcdFx0KTtcblx0XHR9XG5cblx0XHRyZXR1cm4gb3V0cHV0O1xuXHR9O1xuXG5cdHZhciBiYXNlNjQgPSB7XG5cdFx0J2VuY29kZSc6IGVuY29kZSxcblx0XHQnZGVjb2RlJzogZGVjb2RlLFxuXHRcdCd2ZXJzaW9uJzogJzAuMS4wJ1xuXHR9O1xuXG5cdC8vIFNvbWUgQU1EIGJ1aWxkIG9wdGltaXplcnMsIGxpa2Ugci5qcywgY2hlY2sgZm9yIHNwZWNpZmljIGNvbmRpdGlvbiBwYXR0ZXJuc1xuXHQvLyBsaWtlIHRoZSBmb2xsb3dpbmc6XG5cdGlmIChcblx0XHR0eXBlb2YgZGVmaW5lID09ICdmdW5jdGlvbicgJiZcblx0XHR0eXBlb2YgZGVmaW5lLmFtZCA9PSAnb2JqZWN0JyAmJlxuXHRcdGRlZmluZS5hbWRcblx0KSB7XG5cdFx0ZGVmaW5lKGZ1bmN0aW9uKCkge1xuXHRcdFx0cmV0dXJuIGJhc2U2NDtcblx0XHR9KTtcblx0fVx0ZWxzZSBpZiAoZnJlZUV4cG9ydHMgJiYgIWZyZWVFeHBvcnRzLm5vZGVUeXBlKSB7XG5cdFx0aWYgKGZyZWVNb2R1bGUpIHsgLy8gaW4gTm9kZS5qcyBvciBSaW5nb0pTIHYwLjguMCtcblx0XHRcdGZyZWVNb2R1bGUuZXhwb3J0cyA9IGJhc2U2NDtcblx0XHR9IGVsc2UgeyAvLyBpbiBOYXJ3aGFsIG9yIFJpbmdvSlMgdjAuNy4wLVxuXHRcdFx0Zm9yICh2YXIga2V5IGluIGJhc2U2NCkge1xuXHRcdFx0XHRiYXNlNjQuaGFzT3duUHJvcGVydHkoa2V5KSAmJiAoZnJlZUV4cG9ydHNba2V5XSA9IGJhc2U2NFtrZXldKTtcblx0XHRcdH1cblx0XHR9XG5cdH0gZWxzZSB7IC8vIGluIFJoaW5vIG9yIGEgd2ViIGJyb3dzZXJcblx0XHRyb290LmJhc2U2NCA9IGJhc2U2NDtcblx0fVxuXG59KHRoaXMpKTtcbiIsIi8qISBodHRwczovL210aHMuYmUvcHVueWNvZGUgdjEuNC4xIGJ5IEBtYXRoaWFzICovXG47KGZ1bmN0aW9uKHJvb3QpIHtcblxuXHQvKiogRGV0ZWN0IGZyZWUgdmFyaWFibGVzICovXG5cdHZhciBmcmVlRXhwb3J0cyA9IHR5cGVvZiBleHBvcnRzID09ICdvYmplY3QnICYmIGV4cG9ydHMgJiZcblx0XHQhZXhwb3J0cy5ub2RlVHlwZSAmJiBleHBvcnRzO1xuXHR2YXIgZnJlZU1vZHVsZSA9IHR5cGVvZiBtb2R1bGUgPT0gJ29iamVjdCcgJiYgbW9kdWxlICYmXG5cdFx0IW1vZHVsZS5ub2RlVHlwZSAmJiBtb2R1bGU7XG5cdHZhciBmcmVlR2xvYmFsID0gdHlwZW9mIGdsb2JhbCA9PSAnb2JqZWN0JyAmJiBnbG9iYWw7XG5cdGlmIChcblx0XHRmcmVlR2xvYmFsLmdsb2JhbCA9PT0gZnJlZUdsb2JhbCB8fFxuXHRcdGZyZWVHbG9iYWwud2luZG93ID09PSBmcmVlR2xvYmFsIHx8XG5cdFx0ZnJlZUdsb2JhbC5zZWxmID09PSBmcmVlR2xvYmFsXG5cdCkge1xuXHRcdHJvb3QgPSBmcmVlR2xvYmFsO1xuXHR9XG5cblx0LyoqXG5cdCAqIFRoZSBgcHVueWNvZGVgIG9iamVjdC5cblx0ICogQG5hbWUgcHVueWNvZGVcblx0ICogQHR5cGUgT2JqZWN0XG5cdCAqL1xuXHR2YXIgcHVueWNvZGUsXG5cblx0LyoqIEhpZ2hlc3QgcG9zaXRpdmUgc2lnbmVkIDMyLWJpdCBmbG9hdCB2YWx1ZSAqL1xuXHRtYXhJbnQgPSAyMTQ3NDgzNjQ3LCAvLyBha2EuIDB4N0ZGRkZGRkYgb3IgMl4zMS0xXG5cblx0LyoqIEJvb3RzdHJpbmcgcGFyYW1ldGVycyAqL1xuXHRiYXNlID0gMzYsXG5cdHRNaW4gPSAxLFxuXHR0TWF4ID0gMjYsXG5cdHNrZXcgPSAzOCxcblx0ZGFtcCA9IDcwMCxcblx0aW5pdGlhbEJpYXMgPSA3Mixcblx0aW5pdGlhbE4gPSAxMjgsIC8vIDB4ODBcblx0ZGVsaW1pdGVyID0gJy0nLCAvLyAnXFx4MkQnXG5cblx0LyoqIFJlZ3VsYXIgZXhwcmVzc2lvbnMgKi9cblx0cmVnZXhQdW55Y29kZSA9IC9eeG4tLS8sXG5cdHJlZ2V4Tm9uQVNDSUkgPSAvW15cXHgyMC1cXHg3RV0vLCAvLyB1bnByaW50YWJsZSBBU0NJSSBjaGFycyArIG5vbi1BU0NJSSBjaGFyc1xuXHRyZWdleFNlcGFyYXRvcnMgPSAvW1xceDJFXFx1MzAwMlxcdUZGMEVcXHVGRjYxXS9nLCAvLyBSRkMgMzQ5MCBzZXBhcmF0b3JzXG5cblx0LyoqIEVycm9yIG1lc3NhZ2VzICovXG5cdGVycm9ycyA9IHtcblx0XHQnb3ZlcmZsb3cnOiAnT3ZlcmZsb3c6IGlucHV0IG5lZWRzIHdpZGVyIGludGVnZXJzIHRvIHByb2Nlc3MnLFxuXHRcdCdub3QtYmFzaWMnOiAnSWxsZWdhbCBpbnB1dCA+PSAweDgwIChub3QgYSBiYXNpYyBjb2RlIHBvaW50KScsXG5cdFx0J2ludmFsaWQtaW5wdXQnOiAnSW52YWxpZCBpbnB1dCdcblx0fSxcblxuXHQvKiogQ29udmVuaWVuY2Ugc2hvcnRjdXRzICovXG5cdGJhc2VNaW51c1RNaW4gPSBiYXNlIC0gdE1pbixcblx0Zmxvb3IgPSBNYXRoLmZsb29yLFxuXHRzdHJpbmdGcm9tQ2hhckNvZGUgPSBTdHJpbmcuZnJvbUNoYXJDb2RlLFxuXG5cdC8qKiBUZW1wb3JhcnkgdmFyaWFibGUgKi9cblx0a2V5O1xuXG5cdC8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5cdC8qKlxuXHQgKiBBIGdlbmVyaWMgZXJyb3IgdXRpbGl0eSBmdW5jdGlvbi5cblx0ICogQHByaXZhdGVcblx0ICogQHBhcmFtIHtTdHJpbmd9IHR5cGUgVGhlIGVycm9yIHR5cGUuXG5cdCAqIEByZXR1cm5zIHtFcnJvcn0gVGhyb3dzIGEgYFJhbmdlRXJyb3JgIHdpdGggdGhlIGFwcGxpY2FibGUgZXJyb3IgbWVzc2FnZS5cblx0ICovXG5cdGZ1bmN0aW9uIGVycm9yKHR5cGUpIHtcblx0XHR0aHJvdyBuZXcgUmFuZ2VFcnJvcihlcnJvcnNbdHlwZV0pO1xuXHR9XG5cblx0LyoqXG5cdCAqIEEgZ2VuZXJpYyBgQXJyYXkjbWFwYCB1dGlsaXR5IGZ1bmN0aW9uLlxuXHQgKiBAcHJpdmF0ZVxuXHQgKiBAcGFyYW0ge0FycmF5fSBhcnJheSBUaGUgYXJyYXkgdG8gaXRlcmF0ZSBvdmVyLlxuXHQgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayBUaGUgZnVuY3Rpb24gdGhhdCBnZXRzIGNhbGxlZCBmb3IgZXZlcnkgYXJyYXlcblx0ICogaXRlbS5cblx0ICogQHJldHVybnMge0FycmF5fSBBIG5ldyBhcnJheSBvZiB2YWx1ZXMgcmV0dXJuZWQgYnkgdGhlIGNhbGxiYWNrIGZ1bmN0aW9uLlxuXHQgKi9cblx0ZnVuY3Rpb24gbWFwKGFycmF5LCBmbikge1xuXHRcdHZhciBsZW5ndGggPSBhcnJheS5sZW5ndGg7XG5cdFx0dmFyIHJlc3VsdCA9IFtdO1xuXHRcdHdoaWxlIChsZW5ndGgtLSkge1xuXHRcdFx0cmVzdWx0W2xlbmd0aF0gPSBmbihhcnJheVtsZW5ndGhdKTtcblx0XHR9XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fVxuXG5cdC8qKlxuXHQgKiBBIHNpbXBsZSBgQXJyYXkjbWFwYC1saWtlIHdyYXBwZXIgdG8gd29yayB3aXRoIGRvbWFpbiBuYW1lIHN0cmluZ3Mgb3IgZW1haWxcblx0ICogYWRkcmVzc2VzLlxuXHQgKiBAcHJpdmF0ZVxuXHQgKiBAcGFyYW0ge1N0cmluZ30gZG9tYWluIFRoZSBkb21haW4gbmFtZSBvciBlbWFpbCBhZGRyZXNzLlxuXHQgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayBUaGUgZnVuY3Rpb24gdGhhdCBnZXRzIGNhbGxlZCBmb3IgZXZlcnlcblx0ICogY2hhcmFjdGVyLlxuXHQgKiBAcmV0dXJucyB7QXJyYXl9IEEgbmV3IHN0cmluZyBvZiBjaGFyYWN0ZXJzIHJldHVybmVkIGJ5IHRoZSBjYWxsYmFja1xuXHQgKiBmdW5jdGlvbi5cblx0ICovXG5cdGZ1bmN0aW9uIG1hcERvbWFpbihzdHJpbmcsIGZuKSB7XG5cdFx0dmFyIHBhcnRzID0gc3RyaW5nLnNwbGl0KCdAJyk7XG5cdFx0dmFyIHJlc3VsdCA9ICcnO1xuXHRcdGlmIChwYXJ0cy5sZW5ndGggPiAxKSB7XG5cdFx0XHQvLyBJbiBlbWFpbCBhZGRyZXNzZXMsIG9ubHkgdGhlIGRvbWFpbiBuYW1lIHNob3VsZCBiZSBwdW55Y29kZWQuIExlYXZlXG5cdFx0XHQvLyB0aGUgbG9jYWwgcGFydCAoaS5lLiBldmVyeXRoaW5nIHVwIHRvIGBAYCkgaW50YWN0LlxuXHRcdFx0cmVzdWx0ID0gcGFydHNbMF0gKyAnQCc7XG5cdFx0XHRzdHJpbmcgPSBwYXJ0c1sxXTtcblx0XHR9XG5cdFx0Ly8gQXZvaWQgYHNwbGl0KHJlZ2V4KWAgZm9yIElFOCBjb21wYXRpYmlsaXR5LiBTZWUgIzE3LlxuXHRcdHN0cmluZyA9IHN0cmluZy5yZXBsYWNlKHJlZ2V4U2VwYXJhdG9ycywgJ1xceDJFJyk7XG5cdFx0dmFyIGxhYmVscyA9IHN0cmluZy5zcGxpdCgnLicpO1xuXHRcdHZhciBlbmNvZGVkID0gbWFwKGxhYmVscywgZm4pLmpvaW4oJy4nKTtcblx0XHRyZXR1cm4gcmVzdWx0ICsgZW5jb2RlZDtcblx0fVxuXG5cdC8qKlxuXHQgKiBDcmVhdGVzIGFuIGFycmF5IGNvbnRhaW5pbmcgdGhlIG51bWVyaWMgY29kZSBwb2ludHMgb2YgZWFjaCBVbmljb2RlXG5cdCAqIGNoYXJhY3RlciBpbiB0aGUgc3RyaW5nLiBXaGlsZSBKYXZhU2NyaXB0IHVzZXMgVUNTLTIgaW50ZXJuYWxseSxcblx0ICogdGhpcyBmdW5jdGlvbiB3aWxsIGNvbnZlcnQgYSBwYWlyIG9mIHN1cnJvZ2F0ZSBoYWx2ZXMgKGVhY2ggb2Ygd2hpY2hcblx0ICogVUNTLTIgZXhwb3NlcyBhcyBzZXBhcmF0ZSBjaGFyYWN0ZXJzKSBpbnRvIGEgc2luZ2xlIGNvZGUgcG9pbnQsXG5cdCAqIG1hdGNoaW5nIFVURi0xNi5cblx0ICogQHNlZSBgcHVueWNvZGUudWNzMi5lbmNvZGVgXG5cdCAqIEBzZWUgPGh0dHBzOi8vbWF0aGlhc2J5bmVucy5iZS9ub3Rlcy9qYXZhc2NyaXB0LWVuY29kaW5nPlxuXHQgKiBAbWVtYmVyT2YgcHVueWNvZGUudWNzMlxuXHQgKiBAbmFtZSBkZWNvZGVcblx0ICogQHBhcmFtIHtTdHJpbmd9IHN0cmluZyBUaGUgVW5pY29kZSBpbnB1dCBzdHJpbmcgKFVDUy0yKS5cblx0ICogQHJldHVybnMge0FycmF5fSBUaGUgbmV3IGFycmF5IG9mIGNvZGUgcG9pbnRzLlxuXHQgKi9cblx0ZnVuY3Rpb24gdWNzMmRlY29kZShzdHJpbmcpIHtcblx0XHR2YXIgb3V0cHV0ID0gW10sXG5cdFx0ICAgIGNvdW50ZXIgPSAwLFxuXHRcdCAgICBsZW5ndGggPSBzdHJpbmcubGVuZ3RoLFxuXHRcdCAgICB2YWx1ZSxcblx0XHQgICAgZXh0cmE7XG5cdFx0d2hpbGUgKGNvdW50ZXIgPCBsZW5ndGgpIHtcblx0XHRcdHZhbHVlID0gc3RyaW5nLmNoYXJDb2RlQXQoY291bnRlcisrKTtcblx0XHRcdGlmICh2YWx1ZSA+PSAweEQ4MDAgJiYgdmFsdWUgPD0gMHhEQkZGICYmIGNvdW50ZXIgPCBsZW5ndGgpIHtcblx0XHRcdFx0Ly8gaGlnaCBzdXJyb2dhdGUsIGFuZCB0aGVyZSBpcyBhIG5leHQgY2hhcmFjdGVyXG5cdFx0XHRcdGV4dHJhID0gc3RyaW5nLmNoYXJDb2RlQXQoY291bnRlcisrKTtcblx0XHRcdFx0aWYgKChleHRyYSAmIDB4RkMwMCkgPT0gMHhEQzAwKSB7IC8vIGxvdyBzdXJyb2dhdGVcblx0XHRcdFx0XHRvdXRwdXQucHVzaCgoKHZhbHVlICYgMHgzRkYpIDw8IDEwKSArIChleHRyYSAmIDB4M0ZGKSArIDB4MTAwMDApO1xuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdC8vIHVubWF0Y2hlZCBzdXJyb2dhdGU7IG9ubHkgYXBwZW5kIHRoaXMgY29kZSB1bml0LCBpbiBjYXNlIHRoZSBuZXh0XG5cdFx0XHRcdFx0Ly8gY29kZSB1bml0IGlzIHRoZSBoaWdoIHN1cnJvZ2F0ZSBvZiBhIHN1cnJvZ2F0ZSBwYWlyXG5cdFx0XHRcdFx0b3V0cHV0LnB1c2godmFsdWUpO1xuXHRcdFx0XHRcdGNvdW50ZXItLTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0b3V0cHV0LnB1c2godmFsdWUpO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRyZXR1cm4gb3V0cHV0O1xuXHR9XG5cblx0LyoqXG5cdCAqIENyZWF0ZXMgYSBzdHJpbmcgYmFzZWQgb24gYW4gYXJyYXkgb2YgbnVtZXJpYyBjb2RlIHBvaW50cy5cblx0ICogQHNlZSBgcHVueWNvZGUudWNzMi5kZWNvZGVgXG5cdCAqIEBtZW1iZXJPZiBwdW55Y29kZS51Y3MyXG5cdCAqIEBuYW1lIGVuY29kZVxuXHQgKiBAcGFyYW0ge0FycmF5fSBjb2RlUG9pbnRzIFRoZSBhcnJheSBvZiBudW1lcmljIGNvZGUgcG9pbnRzLlxuXHQgKiBAcmV0dXJucyB7U3RyaW5nfSBUaGUgbmV3IFVuaWNvZGUgc3RyaW5nIChVQ1MtMikuXG5cdCAqL1xuXHRmdW5jdGlvbiB1Y3MyZW5jb2RlKGFycmF5KSB7XG5cdFx0cmV0dXJuIG1hcChhcnJheSwgZnVuY3Rpb24odmFsdWUpIHtcblx0XHRcdHZhciBvdXRwdXQgPSAnJztcblx0XHRcdGlmICh2YWx1ZSA+IDB4RkZGRikge1xuXHRcdFx0XHR2YWx1ZSAtPSAweDEwMDAwO1xuXHRcdFx0XHRvdXRwdXQgKz0gc3RyaW5nRnJvbUNoYXJDb2RlKHZhbHVlID4+PiAxMCAmIDB4M0ZGIHwgMHhEODAwKTtcblx0XHRcdFx0dmFsdWUgPSAweERDMDAgfCB2YWx1ZSAmIDB4M0ZGO1xuXHRcdFx0fVxuXHRcdFx0b3V0cHV0ICs9IHN0cmluZ0Zyb21DaGFyQ29kZSh2YWx1ZSk7XG5cdFx0XHRyZXR1cm4gb3V0cHV0O1xuXHRcdH0pLmpvaW4oJycpO1xuXHR9XG5cblx0LyoqXG5cdCAqIENvbnZlcnRzIGEgYmFzaWMgY29kZSBwb2ludCBpbnRvIGEgZGlnaXQvaW50ZWdlci5cblx0ICogQHNlZSBgZGlnaXRUb0Jhc2ljKClgXG5cdCAqIEBwcml2YXRlXG5cdCAqIEBwYXJhbSB7TnVtYmVyfSBjb2RlUG9pbnQgVGhlIGJhc2ljIG51bWVyaWMgY29kZSBwb2ludCB2YWx1ZS5cblx0ICogQHJldHVybnMge051bWJlcn0gVGhlIG51bWVyaWMgdmFsdWUgb2YgYSBiYXNpYyBjb2RlIHBvaW50IChmb3IgdXNlIGluXG5cdCAqIHJlcHJlc2VudGluZyBpbnRlZ2VycykgaW4gdGhlIHJhbmdlIGAwYCB0byBgYmFzZSAtIDFgLCBvciBgYmFzZWAgaWZcblx0ICogdGhlIGNvZGUgcG9pbnQgZG9lcyBub3QgcmVwcmVzZW50IGEgdmFsdWUuXG5cdCAqL1xuXHRmdW5jdGlvbiBiYXNpY1RvRGlnaXQoY29kZVBvaW50KSB7XG5cdFx0aWYgKGNvZGVQb2ludCAtIDQ4IDwgMTApIHtcblx0XHRcdHJldHVybiBjb2RlUG9pbnQgLSAyMjtcblx0XHR9XG5cdFx0aWYgKGNvZGVQb2ludCAtIDY1IDwgMjYpIHtcblx0XHRcdHJldHVybiBjb2RlUG9pbnQgLSA2NTtcblx0XHR9XG5cdFx0aWYgKGNvZGVQb2ludCAtIDk3IDwgMjYpIHtcblx0XHRcdHJldHVybiBjb2RlUG9pbnQgLSA5Nztcblx0XHR9XG5cdFx0cmV0dXJuIGJhc2U7XG5cdH1cblxuXHQvKipcblx0ICogQ29udmVydHMgYSBkaWdpdC9pbnRlZ2VyIGludG8gYSBiYXNpYyBjb2RlIHBvaW50LlxuXHQgKiBAc2VlIGBiYXNpY1RvRGlnaXQoKWBcblx0ICogQHByaXZhdGVcblx0ICogQHBhcmFtIHtOdW1iZXJ9IGRpZ2l0IFRoZSBudW1lcmljIHZhbHVlIG9mIGEgYmFzaWMgY29kZSBwb2ludC5cblx0ICogQHJldHVybnMge051bWJlcn0gVGhlIGJhc2ljIGNvZGUgcG9pbnQgd2hvc2UgdmFsdWUgKHdoZW4gdXNlZCBmb3Jcblx0ICogcmVwcmVzZW50aW5nIGludGVnZXJzKSBpcyBgZGlnaXRgLCB3aGljaCBuZWVkcyB0byBiZSBpbiB0aGUgcmFuZ2Vcblx0ICogYDBgIHRvIGBiYXNlIC0gMWAuIElmIGBmbGFnYCBpcyBub24temVybywgdGhlIHVwcGVyY2FzZSBmb3JtIGlzXG5cdCAqIHVzZWQ7IGVsc2UsIHRoZSBsb3dlcmNhc2UgZm9ybSBpcyB1c2VkLiBUaGUgYmVoYXZpb3IgaXMgdW5kZWZpbmVkXG5cdCAqIGlmIGBmbGFnYCBpcyBub24temVybyBhbmQgYGRpZ2l0YCBoYXMgbm8gdXBwZXJjYXNlIGZvcm0uXG5cdCAqL1xuXHRmdW5jdGlvbiBkaWdpdFRvQmFzaWMoZGlnaXQsIGZsYWcpIHtcblx0XHQvLyAgMC4uMjUgbWFwIHRvIEFTQ0lJIGEuLnogb3IgQS4uWlxuXHRcdC8vIDI2Li4zNSBtYXAgdG8gQVNDSUkgMC4uOVxuXHRcdHJldHVybiBkaWdpdCArIDIyICsgNzUgKiAoZGlnaXQgPCAyNikgLSAoKGZsYWcgIT0gMCkgPDwgNSk7XG5cdH1cblxuXHQvKipcblx0ICogQmlhcyBhZGFwdGF0aW9uIGZ1bmN0aW9uIGFzIHBlciBzZWN0aW9uIDMuNCBvZiBSRkMgMzQ5Mi5cblx0ICogaHR0cHM6Ly90b29scy5pZXRmLm9yZy9odG1sL3JmYzM0OTIjc2VjdGlvbi0zLjRcblx0ICogQHByaXZhdGVcblx0ICovXG5cdGZ1bmN0aW9uIGFkYXB0KGRlbHRhLCBudW1Qb2ludHMsIGZpcnN0VGltZSkge1xuXHRcdHZhciBrID0gMDtcblx0XHRkZWx0YSA9IGZpcnN0VGltZSA/IGZsb29yKGRlbHRhIC8gZGFtcCkgOiBkZWx0YSA+PiAxO1xuXHRcdGRlbHRhICs9IGZsb29yKGRlbHRhIC8gbnVtUG9pbnRzKTtcblx0XHRmb3IgKC8qIG5vIGluaXRpYWxpemF0aW9uICovOyBkZWx0YSA+IGJhc2VNaW51c1RNaW4gKiB0TWF4ID4+IDE7IGsgKz0gYmFzZSkge1xuXHRcdFx0ZGVsdGEgPSBmbG9vcihkZWx0YSAvIGJhc2VNaW51c1RNaW4pO1xuXHRcdH1cblx0XHRyZXR1cm4gZmxvb3IoayArIChiYXNlTWludXNUTWluICsgMSkgKiBkZWx0YSAvIChkZWx0YSArIHNrZXcpKTtcblx0fVxuXG5cdC8qKlxuXHQgKiBDb252ZXJ0cyBhIFB1bnljb2RlIHN0cmluZyBvZiBBU0NJSS1vbmx5IHN5bWJvbHMgdG8gYSBzdHJpbmcgb2YgVW5pY29kZVxuXHQgKiBzeW1ib2xzLlxuXHQgKiBAbWVtYmVyT2YgcHVueWNvZGVcblx0ICogQHBhcmFtIHtTdHJpbmd9IGlucHV0IFRoZSBQdW55Y29kZSBzdHJpbmcgb2YgQVNDSUktb25seSBzeW1ib2xzLlxuXHQgKiBAcmV0dXJucyB7U3RyaW5nfSBUaGUgcmVzdWx0aW5nIHN0cmluZyBvZiBVbmljb2RlIHN5bWJvbHMuXG5cdCAqL1xuXHRmdW5jdGlvbiBkZWNvZGUoaW5wdXQpIHtcblx0XHQvLyBEb24ndCB1c2UgVUNTLTJcblx0XHR2YXIgb3V0cHV0ID0gW10sXG5cdFx0ICAgIGlucHV0TGVuZ3RoID0gaW5wdXQubGVuZ3RoLFxuXHRcdCAgICBvdXQsXG5cdFx0ICAgIGkgPSAwLFxuXHRcdCAgICBuID0gaW5pdGlhbE4sXG5cdFx0ICAgIGJpYXMgPSBpbml0aWFsQmlhcyxcblx0XHQgICAgYmFzaWMsXG5cdFx0ICAgIGosXG5cdFx0ICAgIGluZGV4LFxuXHRcdCAgICBvbGRpLFxuXHRcdCAgICB3LFxuXHRcdCAgICBrLFxuXHRcdCAgICBkaWdpdCxcblx0XHQgICAgdCxcblx0XHQgICAgLyoqIENhY2hlZCBjYWxjdWxhdGlvbiByZXN1bHRzICovXG5cdFx0ICAgIGJhc2VNaW51c1Q7XG5cblx0XHQvLyBIYW5kbGUgdGhlIGJhc2ljIGNvZGUgcG9pbnRzOiBsZXQgYGJhc2ljYCBiZSB0aGUgbnVtYmVyIG9mIGlucHV0IGNvZGVcblx0XHQvLyBwb2ludHMgYmVmb3JlIHRoZSBsYXN0IGRlbGltaXRlciwgb3IgYDBgIGlmIHRoZXJlIGlzIG5vbmUsIHRoZW4gY29weVxuXHRcdC8vIHRoZSBmaXJzdCBiYXNpYyBjb2RlIHBvaW50cyB0byB0aGUgb3V0cHV0LlxuXG5cdFx0YmFzaWMgPSBpbnB1dC5sYXN0SW5kZXhPZihkZWxpbWl0ZXIpO1xuXHRcdGlmIChiYXNpYyA8IDApIHtcblx0XHRcdGJhc2ljID0gMDtcblx0XHR9XG5cblx0XHRmb3IgKGogPSAwOyBqIDwgYmFzaWM7ICsraikge1xuXHRcdFx0Ly8gaWYgaXQncyBub3QgYSBiYXNpYyBjb2RlIHBvaW50XG5cdFx0XHRpZiAoaW5wdXQuY2hhckNvZGVBdChqKSA+PSAweDgwKSB7XG5cdFx0XHRcdGVycm9yKCdub3QtYmFzaWMnKTtcblx0XHRcdH1cblx0XHRcdG91dHB1dC5wdXNoKGlucHV0LmNoYXJDb2RlQXQoaikpO1xuXHRcdH1cblxuXHRcdC8vIE1haW4gZGVjb2RpbmcgbG9vcDogc3RhcnQganVzdCBhZnRlciB0aGUgbGFzdCBkZWxpbWl0ZXIgaWYgYW55IGJhc2ljIGNvZGVcblx0XHQvLyBwb2ludHMgd2VyZSBjb3BpZWQ7IHN0YXJ0IGF0IHRoZSBiZWdpbm5pbmcgb3RoZXJ3aXNlLlxuXG5cdFx0Zm9yIChpbmRleCA9IGJhc2ljID4gMCA/IGJhc2ljICsgMSA6IDA7IGluZGV4IDwgaW5wdXRMZW5ndGg7IC8qIG5vIGZpbmFsIGV4cHJlc3Npb24gKi8pIHtcblxuXHRcdFx0Ly8gYGluZGV4YCBpcyB0aGUgaW5kZXggb2YgdGhlIG5leHQgY2hhcmFjdGVyIHRvIGJlIGNvbnN1bWVkLlxuXHRcdFx0Ly8gRGVjb2RlIGEgZ2VuZXJhbGl6ZWQgdmFyaWFibGUtbGVuZ3RoIGludGVnZXIgaW50byBgZGVsdGFgLFxuXHRcdFx0Ly8gd2hpY2ggZ2V0cyBhZGRlZCB0byBgaWAuIFRoZSBvdmVyZmxvdyBjaGVja2luZyBpcyBlYXNpZXJcblx0XHRcdC8vIGlmIHdlIGluY3JlYXNlIGBpYCBhcyB3ZSBnbywgdGhlbiBzdWJ0cmFjdCBvZmYgaXRzIHN0YXJ0aW5nXG5cdFx0XHQvLyB2YWx1ZSBhdCB0aGUgZW5kIHRvIG9idGFpbiBgZGVsdGFgLlxuXHRcdFx0Zm9yIChvbGRpID0gaSwgdyA9IDEsIGsgPSBiYXNlOyAvKiBubyBjb25kaXRpb24gKi87IGsgKz0gYmFzZSkge1xuXG5cdFx0XHRcdGlmIChpbmRleCA+PSBpbnB1dExlbmd0aCkge1xuXHRcdFx0XHRcdGVycm9yKCdpbnZhbGlkLWlucHV0Jyk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRkaWdpdCA9IGJhc2ljVG9EaWdpdChpbnB1dC5jaGFyQ29kZUF0KGluZGV4KyspKTtcblxuXHRcdFx0XHRpZiAoZGlnaXQgPj0gYmFzZSB8fCBkaWdpdCA+IGZsb29yKChtYXhJbnQgLSBpKSAvIHcpKSB7XG5cdFx0XHRcdFx0ZXJyb3IoJ292ZXJmbG93Jyk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRpICs9IGRpZ2l0ICogdztcblx0XHRcdFx0dCA9IGsgPD0gYmlhcyA/IHRNaW4gOiAoayA+PSBiaWFzICsgdE1heCA/IHRNYXggOiBrIC0gYmlhcyk7XG5cblx0XHRcdFx0aWYgKGRpZ2l0IDwgdCkge1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0YmFzZU1pbnVzVCA9IGJhc2UgLSB0O1xuXHRcdFx0XHRpZiAodyA+IGZsb29yKG1heEludCAvIGJhc2VNaW51c1QpKSB7XG5cdFx0XHRcdFx0ZXJyb3IoJ292ZXJmbG93Jyk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHR3ICo9IGJhc2VNaW51c1Q7XG5cblx0XHRcdH1cblxuXHRcdFx0b3V0ID0gb3V0cHV0Lmxlbmd0aCArIDE7XG5cdFx0XHRiaWFzID0gYWRhcHQoaSAtIG9sZGksIG91dCwgb2xkaSA9PSAwKTtcblxuXHRcdFx0Ly8gYGlgIHdhcyBzdXBwb3NlZCB0byB3cmFwIGFyb3VuZCBmcm9tIGBvdXRgIHRvIGAwYCxcblx0XHRcdC8vIGluY3JlbWVudGluZyBgbmAgZWFjaCB0aW1lLCBzbyB3ZSdsbCBmaXggdGhhdCBub3c6XG5cdFx0XHRpZiAoZmxvb3IoaSAvIG91dCkgPiBtYXhJbnQgLSBuKSB7XG5cdFx0XHRcdGVycm9yKCdvdmVyZmxvdycpO1xuXHRcdFx0fVxuXG5cdFx0XHRuICs9IGZsb29yKGkgLyBvdXQpO1xuXHRcdFx0aSAlPSBvdXQ7XG5cblx0XHRcdC8vIEluc2VydCBgbmAgYXQgcG9zaXRpb24gYGlgIG9mIHRoZSBvdXRwdXRcblx0XHRcdG91dHB1dC5zcGxpY2UoaSsrLCAwLCBuKTtcblxuXHRcdH1cblxuXHRcdHJldHVybiB1Y3MyZW5jb2RlKG91dHB1dCk7XG5cdH1cblxuXHQvKipcblx0ICogQ29udmVydHMgYSBzdHJpbmcgb2YgVW5pY29kZSBzeW1ib2xzIChlLmcuIGEgZG9tYWluIG5hbWUgbGFiZWwpIHRvIGFcblx0ICogUHVueWNvZGUgc3RyaW5nIG9mIEFTQ0lJLW9ubHkgc3ltYm9scy5cblx0ICogQG1lbWJlck9mIHB1bnljb2RlXG5cdCAqIEBwYXJhbSB7U3RyaW5nfSBpbnB1dCBUaGUgc3RyaW5nIG9mIFVuaWNvZGUgc3ltYm9scy5cblx0ICogQHJldHVybnMge1N0cmluZ30gVGhlIHJlc3VsdGluZyBQdW55Y29kZSBzdHJpbmcgb2YgQVNDSUktb25seSBzeW1ib2xzLlxuXHQgKi9cblx0ZnVuY3Rpb24gZW5jb2RlKGlucHV0KSB7XG5cdFx0dmFyIG4sXG5cdFx0ICAgIGRlbHRhLFxuXHRcdCAgICBoYW5kbGVkQ1BDb3VudCxcblx0XHQgICAgYmFzaWNMZW5ndGgsXG5cdFx0ICAgIGJpYXMsXG5cdFx0ICAgIGosXG5cdFx0ICAgIG0sXG5cdFx0ICAgIHEsXG5cdFx0ICAgIGssXG5cdFx0ICAgIHQsXG5cdFx0ICAgIGN1cnJlbnRWYWx1ZSxcblx0XHQgICAgb3V0cHV0ID0gW10sXG5cdFx0ICAgIC8qKiBgaW5wdXRMZW5ndGhgIHdpbGwgaG9sZCB0aGUgbnVtYmVyIG9mIGNvZGUgcG9pbnRzIGluIGBpbnB1dGAuICovXG5cdFx0ICAgIGlucHV0TGVuZ3RoLFxuXHRcdCAgICAvKiogQ2FjaGVkIGNhbGN1bGF0aW9uIHJlc3VsdHMgKi9cblx0XHQgICAgaGFuZGxlZENQQ291bnRQbHVzT25lLFxuXHRcdCAgICBiYXNlTWludXNULFxuXHRcdCAgICBxTWludXNUO1xuXG5cdFx0Ly8gQ29udmVydCB0aGUgaW5wdXQgaW4gVUNTLTIgdG8gVW5pY29kZVxuXHRcdGlucHV0ID0gdWNzMmRlY29kZShpbnB1dCk7XG5cblx0XHQvLyBDYWNoZSB0aGUgbGVuZ3RoXG5cdFx0aW5wdXRMZW5ndGggPSBpbnB1dC5sZW5ndGg7XG5cblx0XHQvLyBJbml0aWFsaXplIHRoZSBzdGF0ZVxuXHRcdG4gPSBpbml0aWFsTjtcblx0XHRkZWx0YSA9IDA7XG5cdFx0YmlhcyA9IGluaXRpYWxCaWFzO1xuXG5cdFx0Ly8gSGFuZGxlIHRoZSBiYXNpYyBjb2RlIHBvaW50c1xuXHRcdGZvciAoaiA9IDA7IGogPCBpbnB1dExlbmd0aDsgKytqKSB7XG5cdFx0XHRjdXJyZW50VmFsdWUgPSBpbnB1dFtqXTtcblx0XHRcdGlmIChjdXJyZW50VmFsdWUgPCAweDgwKSB7XG5cdFx0XHRcdG91dHB1dC5wdXNoKHN0cmluZ0Zyb21DaGFyQ29kZShjdXJyZW50VmFsdWUpKTtcblx0XHRcdH1cblx0XHR9XG5cblx0XHRoYW5kbGVkQ1BDb3VudCA9IGJhc2ljTGVuZ3RoID0gb3V0cHV0Lmxlbmd0aDtcblxuXHRcdC8vIGBoYW5kbGVkQ1BDb3VudGAgaXMgdGhlIG51bWJlciBvZiBjb2RlIHBvaW50cyB0aGF0IGhhdmUgYmVlbiBoYW5kbGVkO1xuXHRcdC8vIGBiYXNpY0xlbmd0aGAgaXMgdGhlIG51bWJlciBvZiBiYXNpYyBjb2RlIHBvaW50cy5cblxuXHRcdC8vIEZpbmlzaCB0aGUgYmFzaWMgc3RyaW5nIC0gaWYgaXQgaXMgbm90IGVtcHR5IC0gd2l0aCBhIGRlbGltaXRlclxuXHRcdGlmIChiYXNpY0xlbmd0aCkge1xuXHRcdFx0b3V0cHV0LnB1c2goZGVsaW1pdGVyKTtcblx0XHR9XG5cblx0XHQvLyBNYWluIGVuY29kaW5nIGxvb3A6XG5cdFx0d2hpbGUgKGhhbmRsZWRDUENvdW50IDwgaW5wdXRMZW5ndGgpIHtcblxuXHRcdFx0Ly8gQWxsIG5vbi1iYXNpYyBjb2RlIHBvaW50cyA8IG4gaGF2ZSBiZWVuIGhhbmRsZWQgYWxyZWFkeS4gRmluZCB0aGUgbmV4dFxuXHRcdFx0Ly8gbGFyZ2VyIG9uZTpcblx0XHRcdGZvciAobSA9IG1heEludCwgaiA9IDA7IGogPCBpbnB1dExlbmd0aDsgKytqKSB7XG5cdFx0XHRcdGN1cnJlbnRWYWx1ZSA9IGlucHV0W2pdO1xuXHRcdFx0XHRpZiAoY3VycmVudFZhbHVlID49IG4gJiYgY3VycmVudFZhbHVlIDwgbSkge1xuXHRcdFx0XHRcdG0gPSBjdXJyZW50VmFsdWU7XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0Ly8gSW5jcmVhc2UgYGRlbHRhYCBlbm91Z2ggdG8gYWR2YW5jZSB0aGUgZGVjb2RlcidzIDxuLGk+IHN0YXRlIHRvIDxtLDA+LFxuXHRcdFx0Ly8gYnV0IGd1YXJkIGFnYWluc3Qgb3ZlcmZsb3dcblx0XHRcdGhhbmRsZWRDUENvdW50UGx1c09uZSA9IGhhbmRsZWRDUENvdW50ICsgMTtcblx0XHRcdGlmIChtIC0gbiA+IGZsb29yKChtYXhJbnQgLSBkZWx0YSkgLyBoYW5kbGVkQ1BDb3VudFBsdXNPbmUpKSB7XG5cdFx0XHRcdGVycm9yKCdvdmVyZmxvdycpO1xuXHRcdFx0fVxuXG5cdFx0XHRkZWx0YSArPSAobSAtIG4pICogaGFuZGxlZENQQ291bnRQbHVzT25lO1xuXHRcdFx0biA9IG07XG5cblx0XHRcdGZvciAoaiA9IDA7IGogPCBpbnB1dExlbmd0aDsgKytqKSB7XG5cdFx0XHRcdGN1cnJlbnRWYWx1ZSA9IGlucHV0W2pdO1xuXG5cdFx0XHRcdGlmIChjdXJyZW50VmFsdWUgPCBuICYmICsrZGVsdGEgPiBtYXhJbnQpIHtcblx0XHRcdFx0XHRlcnJvcignb3ZlcmZsb3cnKTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlmIChjdXJyZW50VmFsdWUgPT0gbikge1xuXHRcdFx0XHRcdC8vIFJlcHJlc2VudCBkZWx0YSBhcyBhIGdlbmVyYWxpemVkIHZhcmlhYmxlLWxlbmd0aCBpbnRlZ2VyXG5cdFx0XHRcdFx0Zm9yIChxID0gZGVsdGEsIGsgPSBiYXNlOyAvKiBubyBjb25kaXRpb24gKi87IGsgKz0gYmFzZSkge1xuXHRcdFx0XHRcdFx0dCA9IGsgPD0gYmlhcyA/IHRNaW4gOiAoayA+PSBiaWFzICsgdE1heCA/IHRNYXggOiBrIC0gYmlhcyk7XG5cdFx0XHRcdFx0XHRpZiAocSA8IHQpIHtcblx0XHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRxTWludXNUID0gcSAtIHQ7XG5cdFx0XHRcdFx0XHRiYXNlTWludXNUID0gYmFzZSAtIHQ7XG5cdFx0XHRcdFx0XHRvdXRwdXQucHVzaChcblx0XHRcdFx0XHRcdFx0c3RyaW5nRnJvbUNoYXJDb2RlKGRpZ2l0VG9CYXNpYyh0ICsgcU1pbnVzVCAlIGJhc2VNaW51c1QsIDApKVxuXHRcdFx0XHRcdFx0KTtcblx0XHRcdFx0XHRcdHEgPSBmbG9vcihxTWludXNUIC8gYmFzZU1pbnVzVCk7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0b3V0cHV0LnB1c2goc3RyaW5nRnJvbUNoYXJDb2RlKGRpZ2l0VG9CYXNpYyhxLCAwKSkpO1xuXHRcdFx0XHRcdGJpYXMgPSBhZGFwdChkZWx0YSwgaGFuZGxlZENQQ291bnRQbHVzT25lLCBoYW5kbGVkQ1BDb3VudCA9PSBiYXNpY0xlbmd0aCk7XG5cdFx0XHRcdFx0ZGVsdGEgPSAwO1xuXHRcdFx0XHRcdCsraGFuZGxlZENQQ291bnQ7XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0KytkZWx0YTtcblx0XHRcdCsrbjtcblxuXHRcdH1cblx0XHRyZXR1cm4gb3V0cHV0LmpvaW4oJycpO1xuXHR9XG5cblx0LyoqXG5cdCAqIENvbnZlcnRzIGEgUHVueWNvZGUgc3RyaW5nIHJlcHJlc2VudGluZyBhIGRvbWFpbiBuYW1lIG9yIGFuIGVtYWlsIGFkZHJlc3Ncblx0ICogdG8gVW5pY29kZS4gT25seSB0aGUgUHVueWNvZGVkIHBhcnRzIG9mIHRoZSBpbnB1dCB3aWxsIGJlIGNvbnZlcnRlZCwgaS5lLlxuXHQgKiBpdCBkb2Vzbid0IG1hdHRlciBpZiB5b3UgY2FsbCBpdCBvbiBhIHN0cmluZyB0aGF0IGhhcyBhbHJlYWR5IGJlZW5cblx0ICogY29udmVydGVkIHRvIFVuaWNvZGUuXG5cdCAqIEBtZW1iZXJPZiBwdW55Y29kZVxuXHQgKiBAcGFyYW0ge1N0cmluZ30gaW5wdXQgVGhlIFB1bnljb2RlZCBkb21haW4gbmFtZSBvciBlbWFpbCBhZGRyZXNzIHRvXG5cdCAqIGNvbnZlcnQgdG8gVW5pY29kZS5cblx0ICogQHJldHVybnMge1N0cmluZ30gVGhlIFVuaWNvZGUgcmVwcmVzZW50YXRpb24gb2YgdGhlIGdpdmVuIFB1bnljb2RlXG5cdCAqIHN0cmluZy5cblx0ICovXG5cdGZ1bmN0aW9uIHRvVW5pY29kZShpbnB1dCkge1xuXHRcdHJldHVybiBtYXBEb21haW4oaW5wdXQsIGZ1bmN0aW9uKHN0cmluZykge1xuXHRcdFx0cmV0dXJuIHJlZ2V4UHVueWNvZGUudGVzdChzdHJpbmcpXG5cdFx0XHRcdD8gZGVjb2RlKHN0cmluZy5zbGljZSg0KS50b0xvd2VyQ2FzZSgpKVxuXHRcdFx0XHQ6IHN0cmluZztcblx0XHR9KTtcblx0fVxuXG5cdC8qKlxuXHQgKiBDb252ZXJ0cyBhIFVuaWNvZGUgc3RyaW5nIHJlcHJlc2VudGluZyBhIGRvbWFpbiBuYW1lIG9yIGFuIGVtYWlsIGFkZHJlc3MgdG9cblx0ICogUHVueWNvZGUuIE9ubHkgdGhlIG5vbi1BU0NJSSBwYXJ0cyBvZiB0aGUgZG9tYWluIG5hbWUgd2lsbCBiZSBjb252ZXJ0ZWQsXG5cdCAqIGkuZS4gaXQgZG9lc24ndCBtYXR0ZXIgaWYgeW91IGNhbGwgaXQgd2l0aCBhIGRvbWFpbiB0aGF0J3MgYWxyZWFkeSBpblxuXHQgKiBBU0NJSS5cblx0ICogQG1lbWJlck9mIHB1bnljb2RlXG5cdCAqIEBwYXJhbSB7U3RyaW5nfSBpbnB1dCBUaGUgZG9tYWluIG5hbWUgb3IgZW1haWwgYWRkcmVzcyB0byBjb252ZXJ0LCBhcyBhXG5cdCAqIFVuaWNvZGUgc3RyaW5nLlxuXHQgKiBAcmV0dXJucyB7U3RyaW5nfSBUaGUgUHVueWNvZGUgcmVwcmVzZW50YXRpb24gb2YgdGhlIGdpdmVuIGRvbWFpbiBuYW1lIG9yXG5cdCAqIGVtYWlsIGFkZHJlc3MuXG5cdCAqL1xuXHRmdW5jdGlvbiB0b0FTQ0lJKGlucHV0KSB7XG5cdFx0cmV0dXJuIG1hcERvbWFpbihpbnB1dCwgZnVuY3Rpb24oc3RyaW5nKSB7XG5cdFx0XHRyZXR1cm4gcmVnZXhOb25BU0NJSS50ZXN0KHN0cmluZylcblx0XHRcdFx0PyAneG4tLScgKyBlbmNvZGUoc3RyaW5nKVxuXHRcdFx0XHQ6IHN0cmluZztcblx0XHR9KTtcblx0fVxuXG5cdC8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuXG5cdC8qKiBEZWZpbmUgdGhlIHB1YmxpYyBBUEkgKi9cblx0cHVueWNvZGUgPSB7XG5cdFx0LyoqXG5cdFx0ICogQSBzdHJpbmcgcmVwcmVzZW50aW5nIHRoZSBjdXJyZW50IFB1bnljb2RlLmpzIHZlcnNpb24gbnVtYmVyLlxuXHRcdCAqIEBtZW1iZXJPZiBwdW55Y29kZVxuXHRcdCAqIEB0eXBlIFN0cmluZ1xuXHRcdCAqL1xuXHRcdCd2ZXJzaW9uJzogJzEuNC4xJyxcblx0XHQvKipcblx0XHQgKiBBbiBvYmplY3Qgb2YgbWV0aG9kcyB0byBjb252ZXJ0IGZyb20gSmF2YVNjcmlwdCdzIGludGVybmFsIGNoYXJhY3RlclxuXHRcdCAqIHJlcHJlc2VudGF0aW9uIChVQ1MtMikgdG8gVW5pY29kZSBjb2RlIHBvaW50cywgYW5kIGJhY2suXG5cdFx0ICogQHNlZSA8aHR0cHM6Ly9tYXRoaWFzYnluZW5zLmJlL25vdGVzL2phdmFzY3JpcHQtZW5jb2Rpbmc+XG5cdFx0ICogQG1lbWJlck9mIHB1bnljb2RlXG5cdFx0ICogQHR5cGUgT2JqZWN0XG5cdFx0ICovXG5cdFx0J3VjczInOiB7XG5cdFx0XHQnZGVjb2RlJzogdWNzMmRlY29kZSxcblx0XHRcdCdlbmNvZGUnOiB1Y3MyZW5jb2RlXG5cdFx0fSxcblx0XHQnZGVjb2RlJzogZGVjb2RlLFxuXHRcdCdlbmNvZGUnOiBlbmNvZGUsXG5cdFx0J3RvQVNDSUknOiB0b0FTQ0lJLFxuXHRcdCd0b1VuaWNvZGUnOiB0b1VuaWNvZGVcblx0fTtcblxuXHQvKiogRXhwb3NlIGBwdW55Y29kZWAgKi9cblx0Ly8gU29tZSBBTUQgYnVpbGQgb3B0aW1pemVycywgbGlrZSByLmpzLCBjaGVjayBmb3Igc3BlY2lmaWMgY29uZGl0aW9uIHBhdHRlcm5zXG5cdC8vIGxpa2UgdGhlIGZvbGxvd2luZzpcblx0aWYgKFxuXHRcdHR5cGVvZiBkZWZpbmUgPT0gJ2Z1bmN0aW9uJyAmJlxuXHRcdHR5cGVvZiBkZWZpbmUuYW1kID09ICdvYmplY3QnICYmXG5cdFx0ZGVmaW5lLmFtZFxuXHQpIHtcblx0XHRkZWZpbmUoJ3B1bnljb2RlJywgZnVuY3Rpb24oKSB7XG5cdFx0XHRyZXR1cm4gcHVueWNvZGU7XG5cdFx0fSk7XG5cdH0gZWxzZSBpZiAoZnJlZUV4cG9ydHMgJiYgZnJlZU1vZHVsZSkge1xuXHRcdGlmIChtb2R1bGUuZXhwb3J0cyA9PSBmcmVlRXhwb3J0cykge1xuXHRcdFx0Ly8gaW4gTm9kZS5qcywgaW8uanMsIG9yIFJpbmdvSlMgdjAuOC4wK1xuXHRcdFx0ZnJlZU1vZHVsZS5leHBvcnRzID0gcHVueWNvZGU7XG5cdFx0fSBlbHNlIHtcblx0XHRcdC8vIGluIE5hcndoYWwgb3IgUmluZ29KUyB2MC43LjAtXG5cdFx0XHRmb3IgKGtleSBpbiBwdW55Y29kZSkge1xuXHRcdFx0XHRwdW55Y29kZS5oYXNPd25Qcm9wZXJ0eShrZXkpICYmIChmcmVlRXhwb3J0c1trZXldID0gcHVueWNvZGVba2V5XSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9IGVsc2Uge1xuXHRcdC8vIGluIFJoaW5vIG9yIGEgd2ViIGJyb3dzZXJcblx0XHRyb290LnB1bnljb2RlID0gcHVueWNvZGU7XG5cdH1cblxufSh0aGlzKSk7XG4iLCIvLyBDb3B5cmlnaHQgSm95ZW50LCBJbmMuIGFuZCBvdGhlciBOb2RlIGNvbnRyaWJ1dG9ycy5cbi8vXG4vLyBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYVxuLy8gY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZVxuLy8gXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nXG4vLyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsXG4vLyBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0XG4vLyBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGVcbi8vIGZvbGxvd2luZyBjb25kaXRpb25zOlxuLy9cbi8vIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkXG4vLyBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbi8vXG4vLyBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTXG4vLyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GXG4vLyBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOXG4vLyBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSxcbi8vIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUlxuLy8gT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRVxuLy8gVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cblxuJ3VzZSBzdHJpY3QnO1xuXG4vLyBJZiBvYmouaGFzT3duUHJvcGVydHkgaGFzIGJlZW4gb3ZlcnJpZGRlbiwgdGhlbiBjYWxsaW5nXG4vLyBvYmouaGFzT3duUHJvcGVydHkocHJvcCkgd2lsbCBicmVhay5cbi8vIFNlZTogaHR0cHM6Ly9naXRodWIuY29tL2pveWVudC9ub2RlL2lzc3Vlcy8xNzA3XG5mdW5jdGlvbiBoYXNPd25Qcm9wZXJ0eShvYmosIHByb3ApIHtcbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uKHFzLCBzZXAsIGVxLCBvcHRpb25zKSB7XG4gIHNlcCA9IHNlcCB8fCAnJic7XG4gIGVxID0gZXEgfHwgJz0nO1xuICB2YXIgb2JqID0ge307XG5cbiAgaWYgKHR5cGVvZiBxcyAhPT0gJ3N0cmluZycgfHwgcXMubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIG9iajtcbiAgfVxuXG4gIHZhciByZWdleHAgPSAvXFwrL2c7XG4gIHFzID0gcXMuc3BsaXQoc2VwKTtcblxuICB2YXIgbWF4S2V5cyA9IDEwMDA7XG4gIGlmIChvcHRpb25zICYmIHR5cGVvZiBvcHRpb25zLm1heEtleXMgPT09ICdudW1iZXInKSB7XG4gICAgbWF4S2V5cyA9IG9wdGlvbnMubWF4S2V5cztcbiAgfVxuXG4gIHZhciBsZW4gPSBxcy5sZW5ndGg7XG4gIC8vIG1heEtleXMgPD0gMCBtZWFucyB0aGF0IHdlIHNob3VsZCBub3QgbGltaXQga2V5cyBjb3VudFxuICBpZiAobWF4S2V5cyA+IDAgJiYgbGVuID4gbWF4S2V5cykge1xuICAgIGxlbiA9IG1heEtleXM7XG4gIH1cblxuICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgKytpKSB7XG4gICAgdmFyIHggPSBxc1tpXS5yZXBsYWNlKHJlZ2V4cCwgJyUyMCcpLFxuICAgICAgICBpZHggPSB4LmluZGV4T2YoZXEpLFxuICAgICAgICBrc3RyLCB2c3RyLCBrLCB2O1xuXG4gICAgaWYgKGlkeCA+PSAwKSB7XG4gICAgICBrc3RyID0geC5zdWJzdHIoMCwgaWR4KTtcbiAgICAgIHZzdHIgPSB4LnN1YnN0cihpZHggKyAxKTtcbiAgICB9IGVsc2Uge1xuICAgICAga3N0ciA9IHg7XG4gICAgICB2c3RyID0gJyc7XG4gICAgfVxuXG4gICAgayA9IGRlY29kZVVSSUNvbXBvbmVudChrc3RyKTtcbiAgICB2ID0gZGVjb2RlVVJJQ29tcG9uZW50KHZzdHIpO1xuXG4gICAgaWYgKCFoYXNPd25Qcm9wZXJ0eShvYmosIGspKSB7XG4gICAgICBvYmpba10gPSB2O1xuICAgIH0gZWxzZSBpZiAoaXNBcnJheShvYmpba10pKSB7XG4gICAgICBvYmpba10ucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgb2JqW2tdID0gW29ialtrXSwgdl07XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIG9iajtcbn07XG5cbnZhciBpc0FycmF5ID0gQXJyYXkuaXNBcnJheSB8fCBmdW5jdGlvbiAoeHMpIHtcbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh4cykgPT09ICdbb2JqZWN0IEFycmF5XSc7XG59O1xuIiwiLy8gQ29weXJpZ2h0IEpveWVudCwgSW5jLiBhbmQgb3RoZXIgTm9kZSBjb250cmlidXRvcnMuXG4vL1xuLy8gUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGFcbi8vIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGVcbi8vIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZ1xuLy8gd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLFxuLy8gZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvIHBlcm1pdFxuLy8gcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sIHN1YmplY3QgdG8gdGhlXG4vLyBmb2xsb3dpbmcgY29uZGl0aW9uczpcbi8vXG4vLyBUaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZSBpbmNsdWRlZFxuLy8gaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXG4vL1xuLy8gVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTU1xuLy8gT1IgSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRlxuLy8gTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTlxuLy8gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sXG4vLyBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1Jcbi8vIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEVcbi8vIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG5cbid1c2Ugc3RyaWN0JztcblxudmFyIHN0cmluZ2lmeVByaW1pdGl2ZSA9IGZ1bmN0aW9uKHYpIHtcbiAgc3dpdGNoICh0eXBlb2Ygdikge1xuICAgIGNhc2UgJ3N0cmluZyc6XG4gICAgICByZXR1cm4gdjtcblxuICAgIGNhc2UgJ2Jvb2xlYW4nOlxuICAgICAgcmV0dXJuIHYgPyAndHJ1ZScgOiAnZmFsc2UnO1xuXG4gICAgY2FzZSAnbnVtYmVyJzpcbiAgICAgIHJldHVybiBpc0Zpbml0ZSh2KSA/IHYgOiAnJztcblxuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gJyc7XG4gIH1cbn07XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24ob2JqLCBzZXAsIGVxLCBuYW1lKSB7XG4gIHNlcCA9IHNlcCB8fCAnJic7XG4gIGVxID0gZXEgfHwgJz0nO1xuICBpZiAob2JqID09PSBudWxsKSB7XG4gICAgb2JqID0gdW5kZWZpbmVkO1xuICB9XG5cbiAgaWYgKHR5cGVvZiBvYmogPT09ICdvYmplY3QnKSB7XG4gICAgcmV0dXJuIG1hcChvYmplY3RLZXlzKG9iaiksIGZ1bmN0aW9uKGspIHtcbiAgICAgIHZhciBrcyA9IGVuY29kZVVSSUNvbXBvbmVudChzdHJpbmdpZnlQcmltaXRpdmUoaykpICsgZXE7XG4gICAgICBpZiAoaXNBcnJheShvYmpba10pKSB7XG4gICAgICAgIHJldHVybiBtYXAob2JqW2tdLCBmdW5jdGlvbih2KSB7XG4gICAgICAgICAgcmV0dXJuIGtzICsgZW5jb2RlVVJJQ29tcG9uZW50KHN0cmluZ2lmeVByaW1pdGl2ZSh2KSk7XG4gICAgICAgIH0pLmpvaW4oc2VwKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBrcyArIGVuY29kZVVSSUNvbXBvbmVudChzdHJpbmdpZnlQcmltaXRpdmUob2JqW2tdKSk7XG4gICAgICB9XG4gICAgfSkuam9pbihzZXApO1xuXG4gIH1cblxuICBpZiAoIW5hbWUpIHJldHVybiAnJztcbiAgcmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudChzdHJpbmdpZnlQcmltaXRpdmUobmFtZSkpICsgZXEgK1xuICAgICAgICAgZW5jb2RlVVJJQ29tcG9uZW50KHN0cmluZ2lmeVByaW1pdGl2ZShvYmopKTtcbn07XG5cbnZhciBpc0FycmF5ID0gQXJyYXkuaXNBcnJheSB8fCBmdW5jdGlvbiAoeHMpIHtcbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh4cykgPT09ICdbb2JqZWN0IEFycmF5XSc7XG59O1xuXG5mdW5jdGlvbiBtYXAgKHhzLCBmKSB7XG4gIGlmICh4cy5tYXApIHJldHVybiB4cy5tYXAoZik7XG4gIHZhciByZXMgPSBbXTtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCB4cy5sZW5ndGg7IGkrKykge1xuICAgIHJlcy5wdXNoKGYoeHNbaV0sIGkpKTtcbiAgfVxuICByZXR1cm4gcmVzO1xufVxuXG52YXIgb2JqZWN0S2V5cyA9IE9iamVjdC5rZXlzIHx8IGZ1bmN0aW9uIChvYmopIHtcbiAgdmFyIHJlcyA9IFtdO1xuICBmb3IgKHZhciBrZXkgaW4gb2JqKSB7XG4gICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIGtleSkpIHJlcy5wdXNoKGtleSk7XG4gIH1cbiAgcmV0dXJuIHJlcztcbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbmV4cG9ydHMuZGVjb2RlID0gZXhwb3J0cy5wYXJzZSA9IHJlcXVpcmUoJy4vZGVjb2RlJyk7XG5leHBvcnRzLmVuY29kZSA9IGV4cG9ydHMuc3RyaW5naWZ5ID0gcmVxdWlyZSgnLi9lbmNvZGUnKTtcbiIsImZ1bmN0aW9uIFJhdmVuQ29uZmlnRXJyb3IobWVzc2FnZSkge1xuICB0aGlzLm5hbWUgPSAnUmF2ZW5Db25maWdFcnJvcic7XG4gIHRoaXMubWVzc2FnZSA9IG1lc3NhZ2U7XG59XG5SYXZlbkNvbmZpZ0Vycm9yLnByb3RvdHlwZSA9IG5ldyBFcnJvcigpO1xuUmF2ZW5Db25maWdFcnJvci5wcm90b3R5cGUuY29uc3RydWN0b3IgPSBSYXZlbkNvbmZpZ0Vycm9yO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFJhdmVuQ29uZmlnRXJyb3I7XG4iLCJ2YXIgdXRpbHMgPSByZXF1aXJlKCcuL3V0aWxzJyk7XG5cbnZhciB3cmFwTWV0aG9kID0gZnVuY3Rpb24oY29uc29sZSwgbGV2ZWwsIGNhbGxiYWNrKSB7XG4gIHZhciBvcmlnaW5hbENvbnNvbGVMZXZlbCA9IGNvbnNvbGVbbGV2ZWxdO1xuICB2YXIgb3JpZ2luYWxDb25zb2xlID0gY29uc29sZTtcblxuICBpZiAoIShsZXZlbCBpbiBjb25zb2xlKSkge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIHZhciBzZW50cnlMZXZlbCA9IGxldmVsID09PSAnd2FybicgPyAnd2FybmluZycgOiBsZXZlbDtcblxuICBjb25zb2xlW2xldmVsXSA9IGZ1bmN0aW9uKCkge1xuICAgIHZhciBhcmdzID0gW10uc2xpY2UuY2FsbChhcmd1bWVudHMpO1xuXG4gICAgdmFyIG1zZyA9IHV0aWxzLnNhZmVKb2luKGFyZ3MsICcgJyk7XG4gICAgdmFyIGRhdGEgPSB7bGV2ZWw6IHNlbnRyeUxldmVsLCBsb2dnZXI6ICdjb25zb2xlJywgZXh0cmE6IHthcmd1bWVudHM6IGFyZ3N9fTtcblxuICAgIGlmIChsZXZlbCA9PT0gJ2Fzc2VydCcpIHtcbiAgICAgIGlmIChhcmdzWzBdID09PSBmYWxzZSkge1xuICAgICAgICAvLyBEZWZhdWx0IGJyb3dzZXJzIG1lc3NhZ2VcbiAgICAgICAgbXNnID1cbiAgICAgICAgICAnQXNzZXJ0aW9uIGZhaWxlZDogJyArICh1dGlscy5zYWZlSm9pbihhcmdzLnNsaWNlKDEpLCAnICcpIHx8ICdjb25zb2xlLmFzc2VydCcpO1xuICAgICAgICBkYXRhLmV4dHJhLmFyZ3VtZW50cyA9IGFyZ3Muc2xpY2UoMSk7XG4gICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKG1zZywgZGF0YSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKG1zZywgZGF0YSk7XG4gICAgfVxuXG4gICAgLy8gdGhpcyBmYWlscyBmb3Igc29tZSBicm93c2Vycy4gOihcbiAgICBpZiAob3JpZ2luYWxDb25zb2xlTGV2ZWwpIHtcbiAgICAgIC8vIElFOSBkb2Vzbid0IGFsbG93IGNhbGxpbmcgYXBwbHkgb24gY29uc29sZSBmdW5jdGlvbnMgZGlyZWN0bHlcbiAgICAgIC8vIFNlZTogaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvNTQ3MjkzOC9kb2VzLWllOS1zdXBwb3J0LWNvbnNvbGUtbG9nLWFuZC1pcy1pdC1hLXJlYWwtZnVuY3Rpb24jYW5zd2VyLTU0NzMxOTNcbiAgICAgIEZ1bmN0aW9uLnByb3RvdHlwZS5hcHBseS5jYWxsKG9yaWdpbmFsQ29uc29sZUxldmVsLCBvcmlnaW5hbENvbnNvbGUsIGFyZ3MpO1xuICAgIH1cbiAgfTtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICB3cmFwTWV0aG9kOiB3cmFwTWV0aG9kXG59O1xuIiwiLypnbG9iYWwgWERvbWFpblJlcXVlc3Q6ZmFsc2UgKi9cblxudmFyIFRyYWNlS2l0ID0gcmVxdWlyZSgnLi4vdmVuZG9yL1RyYWNlS2l0L3RyYWNla2l0Jyk7XG52YXIgc3RyaW5naWZ5ID0gcmVxdWlyZSgnLi4vdmVuZG9yL2pzb24tc3RyaW5naWZ5LXNhZmUvc3RyaW5naWZ5Jyk7XG52YXIgbWQ1ID0gcmVxdWlyZSgnLi4vdmVuZG9yL21kNS9tZDUnKTtcbnZhciBSYXZlbkNvbmZpZ0Vycm9yID0gcmVxdWlyZSgnLi9jb25maWdFcnJvcicpO1xuXG52YXIgdXRpbHMgPSByZXF1aXJlKCcuL3V0aWxzJyk7XG52YXIgaXNFcnJvckV2ZW50ID0gdXRpbHMuaXNFcnJvckV2ZW50O1xudmFyIGlzRE9NRXJyb3IgPSB1dGlscy5pc0RPTUVycm9yO1xudmFyIGlzRE9NRXhjZXB0aW9uID0gdXRpbHMuaXNET01FeGNlcHRpb247XG52YXIgaXNFcnJvciA9IHV0aWxzLmlzRXJyb3I7XG52YXIgaXNPYmplY3QgPSB1dGlscy5pc09iamVjdDtcbnZhciBpc1BsYWluT2JqZWN0ID0gdXRpbHMuaXNQbGFpbk9iamVjdDtcbnZhciBpc1VuZGVmaW5lZCA9IHV0aWxzLmlzVW5kZWZpbmVkO1xudmFyIGlzRnVuY3Rpb24gPSB1dGlscy5pc0Z1bmN0aW9uO1xudmFyIGlzU3RyaW5nID0gdXRpbHMuaXNTdHJpbmc7XG52YXIgaXNBcnJheSA9IHV0aWxzLmlzQXJyYXk7XG52YXIgaXNFbXB0eU9iamVjdCA9IHV0aWxzLmlzRW1wdHlPYmplY3Q7XG52YXIgZWFjaCA9IHV0aWxzLmVhY2g7XG52YXIgb2JqZWN0TWVyZ2UgPSB1dGlscy5vYmplY3RNZXJnZTtcbnZhciB0cnVuY2F0ZSA9IHV0aWxzLnRydW5jYXRlO1xudmFyIG9iamVjdEZyb3plbiA9IHV0aWxzLm9iamVjdEZyb3plbjtcbnZhciBoYXNLZXkgPSB1dGlscy5oYXNLZXk7XG52YXIgam9pblJlZ0V4cCA9IHV0aWxzLmpvaW5SZWdFeHA7XG52YXIgdXJsZW5jb2RlID0gdXRpbHMudXJsZW5jb2RlO1xudmFyIHV1aWQ0ID0gdXRpbHMudXVpZDQ7XG52YXIgaHRtbFRyZWVBc1N0cmluZyA9IHV0aWxzLmh0bWxUcmVlQXNTdHJpbmc7XG52YXIgaXNTYW1lRXhjZXB0aW9uID0gdXRpbHMuaXNTYW1lRXhjZXB0aW9uO1xudmFyIGlzU2FtZVN0YWNrdHJhY2UgPSB1dGlscy5pc1NhbWVTdGFja3RyYWNlO1xudmFyIHBhcnNlVXJsID0gdXRpbHMucGFyc2VVcmw7XG52YXIgZmlsbCA9IHV0aWxzLmZpbGw7XG52YXIgc3VwcG9ydHNGZXRjaCA9IHV0aWxzLnN1cHBvcnRzRmV0Y2g7XG52YXIgc3VwcG9ydHNSZWZlcnJlclBvbGljeSA9IHV0aWxzLnN1cHBvcnRzUmVmZXJyZXJQb2xpY3k7XG52YXIgc2VyaWFsaXplS2V5c0Zvck1lc3NhZ2UgPSB1dGlscy5zZXJpYWxpemVLZXlzRm9yTWVzc2FnZTtcbnZhciBzZXJpYWxpemVFeGNlcHRpb24gPSB1dGlscy5zZXJpYWxpemVFeGNlcHRpb247XG52YXIgc2FuaXRpemUgPSB1dGlscy5zYW5pdGl6ZTtcblxudmFyIHdyYXBDb25zb2xlTWV0aG9kID0gcmVxdWlyZSgnLi9jb25zb2xlJykud3JhcE1ldGhvZDtcblxudmFyIGRzbktleXMgPSAnc291cmNlIHByb3RvY29sIHVzZXIgcGFzcyBob3N0IHBvcnQgcGF0aCcuc3BsaXQoJyAnKSxcbiAgZHNuUGF0dGVybiA9IC9eKD86KFxcdyspOik/XFwvXFwvKD86KFxcdyspKDpcXHcrKT9AKT8oW1xcd1xcLi1dKykoPzo6KFxcZCspKT8oXFwvLiopLztcblxuZnVuY3Rpb24gbm93KCkge1xuICByZXR1cm4gK25ldyBEYXRlKCk7XG59XG5cbi8vIFRoaXMgaXMgdG8gYmUgZGVmZW5zaXZlIGluIGVudmlyb25tZW50cyB3aGVyZSB3aW5kb3cgZG9lcyBub3QgZXhpc3QgKHNlZSBodHRwczovL2dpdGh1Yi5jb20vZ2V0c2VudHJ5L3JhdmVuLWpzL3B1bGwvNzg1KVxudmFyIF93aW5kb3cgPVxuICB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJ1xuICAgID8gd2luZG93XG4gICAgOiB0eXBlb2YgZ2xvYmFsICE9PSAndW5kZWZpbmVkJyA/IGdsb2JhbCA6IHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyA/IHNlbGYgOiB7fTtcbnZhciBfZG9jdW1lbnQgPSBfd2luZG93LmRvY3VtZW50O1xudmFyIF9uYXZpZ2F0b3IgPSBfd2luZG93Lm5hdmlnYXRvcjtcblxuZnVuY3Rpb24ga2VlcE9yaWdpbmFsQ2FsbGJhY2sob3JpZ2luYWwsIGNhbGxiYWNrKSB7XG4gIHJldHVybiBpc0Z1bmN0aW9uKGNhbGxiYWNrKVxuICAgID8gZnVuY3Rpb24oZGF0YSkge1xuICAgICAgICByZXR1cm4gY2FsbGJhY2soZGF0YSwgb3JpZ2luYWwpO1xuICAgICAgfVxuICAgIDogY2FsbGJhY2s7XG59XG5cbi8vIEZpcnN0LCBjaGVjayBmb3IgSlNPTiBzdXBwb3J0XG4vLyBJZiB0aGVyZSBpcyBubyBKU09OLCB3ZSBuby1vcCB0aGUgY29yZSBmZWF0dXJlcyBvZiBSYXZlblxuLy8gc2luY2UgSlNPTiBpcyByZXF1aXJlZCB0byBlbmNvZGUgdGhlIHBheWxvYWRcbmZ1bmN0aW9uIFJhdmVuKCkge1xuICB0aGlzLl9oYXNKU09OID0gISEodHlwZW9mIEpTT04gPT09ICdvYmplY3QnICYmIEpTT04uc3RyaW5naWZ5KTtcbiAgLy8gUmF2ZW4gY2FuIHJ1biBpbiBjb250ZXh0cyB3aGVyZSB0aGVyZSdzIG5vIGRvY3VtZW50IChyZWFjdC1uYXRpdmUpXG4gIHRoaXMuX2hhc0RvY3VtZW50ID0gIWlzVW5kZWZpbmVkKF9kb2N1bWVudCk7XG4gIHRoaXMuX2hhc05hdmlnYXRvciA9ICFpc1VuZGVmaW5lZChfbmF2aWdhdG9yKTtcbiAgdGhpcy5fbGFzdENhcHR1cmVkRXhjZXB0aW9uID0gbnVsbDtcbiAgdGhpcy5fbGFzdERhdGEgPSBudWxsO1xuICB0aGlzLl9sYXN0RXZlbnRJZCA9IG51bGw7XG4gIHRoaXMuX2dsb2JhbFNlcnZlciA9IG51bGw7XG4gIHRoaXMuX2dsb2JhbEtleSA9IG51bGw7XG4gIHRoaXMuX2dsb2JhbFByb2plY3QgPSBudWxsO1xuICB0aGlzLl9nbG9iYWxDb250ZXh0ID0ge307XG4gIHRoaXMuX2dsb2JhbE9wdGlvbnMgPSB7XG4gICAgLy8gU0VOVFJZX1JFTEVBU0UgY2FuIGJlIGluamVjdGVkIGJ5IGh0dHBzOi8vZ2l0aHViLmNvbS9nZXRzZW50cnkvc2VudHJ5LXdlYnBhY2stcGx1Z2luXG4gICAgcmVsZWFzZTogX3dpbmRvdy5TRU5UUllfUkVMRUFTRSAmJiBfd2luZG93LlNFTlRSWV9SRUxFQVNFLmlkLFxuICAgIGxvZ2dlcjogJ2phdmFzY3JpcHQnLFxuICAgIGlnbm9yZUVycm9yczogW10sXG4gICAgaWdub3JlVXJsczogW10sXG4gICAgd2hpdGVsaXN0VXJsczogW10sXG4gICAgaW5jbHVkZVBhdGhzOiBbXSxcbiAgICBoZWFkZXJzOiBudWxsLFxuICAgIGNvbGxlY3RXaW5kb3dFcnJvcnM6IHRydWUsXG4gICAgY2FwdHVyZVVuaGFuZGxlZFJlamVjdGlvbnM6IHRydWUsXG4gICAgbWF4TWVzc2FnZUxlbmd0aDogMCxcbiAgICAvLyBCeSBkZWZhdWx0LCB0cnVuY2F0ZXMgVVJMIHZhbHVlcyB0byAyNTAgY2hhcnNcbiAgICBtYXhVcmxMZW5ndGg6IDI1MCxcbiAgICBzdGFja1RyYWNlTGltaXQ6IDUwLFxuICAgIGF1dG9CcmVhZGNydW1iczogdHJ1ZSxcbiAgICBpbnN0cnVtZW50OiB0cnVlLFxuICAgIHNhbXBsZVJhdGU6IDEsXG4gICAgc2FuaXRpemVLZXlzOiBbXVxuICB9O1xuICB0aGlzLl9mZXRjaERlZmF1bHRzID0ge1xuICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgIC8vIERlc3BpdGUgYWxsIHN0YXJzIGluIHRoZSBza3kgc2F5aW5nIHRoYXQgRWRnZSBzdXBwb3J0cyBvbGQgZHJhZnQgc3ludGF4LCBha2EgJ25ldmVyJywgJ2Fsd2F5cycsICdvcmlnaW4nIGFuZCAnZGVmYXVsdFxuICAgIC8vIGh0dHBzOi8vY2FuaXVzZS5jb20vI2ZlYXQ9cmVmZXJyZXItcG9saWN5XG4gICAgLy8gSXQgZG9lc24ndC4gQW5kIGl0IHRocm93IGV4Y2VwdGlvbiBpbnN0ZWFkIG9mIGlnbm9yaW5nIHRoaXMgcGFyYW1ldGVyLi4uXG4gICAgLy8gUkVGOiBodHRwczovL2dpdGh1Yi5jb20vZ2V0c2VudHJ5L3JhdmVuLWpzL2lzc3Vlcy8xMjMzXG4gICAgcmVmZXJyZXJQb2xpY3k6IHN1cHBvcnRzUmVmZXJyZXJQb2xpY3koKSA/ICdvcmlnaW4nIDogJydcbiAgfTtcbiAgdGhpcy5faWdub3JlT25FcnJvciA9IDA7XG4gIHRoaXMuX2lzUmF2ZW5JbnN0YWxsZWQgPSBmYWxzZTtcbiAgdGhpcy5fb3JpZ2luYWxFcnJvclN0YWNrVHJhY2VMaW1pdCA9IEVycm9yLnN0YWNrVHJhY2VMaW1pdDtcbiAgLy8gY2FwdHVyZSByZWZlcmVuY2VzIHRvIHdpbmRvdy5jb25zb2xlICphbmQqIGFsbCBpdHMgbWV0aG9kcyBmaXJzdFxuICAvLyBiZWZvcmUgdGhlIGNvbnNvbGUgcGx1Z2luIGhhcyBhIGNoYW5jZSB0byBtb25rZXkgcGF0Y2hcbiAgdGhpcy5fb3JpZ2luYWxDb25zb2xlID0gX3dpbmRvdy5jb25zb2xlIHx8IHt9O1xuICB0aGlzLl9vcmlnaW5hbENvbnNvbGVNZXRob2RzID0ge307XG4gIHRoaXMuX3BsdWdpbnMgPSBbXTtcbiAgdGhpcy5fc3RhcnRUaW1lID0gbm93KCk7XG4gIHRoaXMuX3dyYXBwZWRCdWlsdElucyA9IFtdO1xuICB0aGlzLl9icmVhZGNydW1icyA9IFtdO1xuICB0aGlzLl9sYXN0Q2FwdHVyZWRFdmVudCA9IG51bGw7XG4gIHRoaXMuX2tleXByZXNzVGltZW91dDtcbiAgdGhpcy5fbG9jYXRpb24gPSBfd2luZG93LmxvY2F0aW9uO1xuICB0aGlzLl9sYXN0SHJlZiA9IHRoaXMuX2xvY2F0aW9uICYmIHRoaXMuX2xvY2F0aW9uLmhyZWY7XG4gIHRoaXMuX3Jlc2V0QmFja29mZigpO1xuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBndWFyZC1mb3ItaW5cbiAgZm9yICh2YXIgbWV0aG9kIGluIHRoaXMuX29yaWdpbmFsQ29uc29sZSkge1xuICAgIHRoaXMuX29yaWdpbmFsQ29uc29sZU1ldGhvZHNbbWV0aG9kXSA9IHRoaXMuX29yaWdpbmFsQ29uc29sZVttZXRob2RdO1xuICB9XG59XG5cbi8qXG4gKiBUaGUgY29yZSBSYXZlbiBzaW5nbGV0b25cbiAqXG4gKiBAdGhpcyB7UmF2ZW59XG4gKi9cblxuUmF2ZW4ucHJvdG90eXBlID0ge1xuICAvLyBIYXJkY29kZSB2ZXJzaW9uIHN0cmluZyBzbyB0aGF0IHJhdmVuIHNvdXJjZSBjYW4gYmUgbG9hZGVkIGRpcmVjdGx5IHZpYVxuICAvLyB3ZWJwYWNrICh1c2luZyBhIGJ1aWxkIHN0ZXAgY2F1c2VzIHdlYnBhY2sgIzE2MTcpLiBHcnVudCB2ZXJpZmllcyB0aGF0XG4gIC8vIHRoaXMgdmFsdWUgbWF0Y2hlcyBwYWNrYWdlLmpzb24gZHVyaW5nIGJ1aWxkLlxuICAvLyAgIFNlZTogaHR0cHM6Ly9naXRodWIuY29tL2dldHNlbnRyeS9yYXZlbi1qcy9pc3N1ZXMvNDY1XG4gIFZFUlNJT046ICczLjI3LjInLFxuXG4gIGRlYnVnOiBmYWxzZSxcblxuICBUcmFjZUtpdDogVHJhY2VLaXQsIC8vIGFsaWFzIHRvIFRyYWNlS2l0XG5cbiAgLypcbiAgICAgKiBDb25maWd1cmUgUmF2ZW4gd2l0aCBhIERTTiBhbmQgZXh0cmEgb3B0aW9uc1xuICAgICAqXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IGRzbiBUaGUgcHVibGljIFNlbnRyeSBEU05cbiAgICAgKiBAcGFyYW0ge29iamVjdH0gb3B0aW9ucyBTZXQgb2YgZ2xvYmFsIG9wdGlvbnMgW29wdGlvbmFsXVxuICAgICAqIEByZXR1cm4ge1JhdmVufVxuICAgICAqL1xuICBjb25maWc6IGZ1bmN0aW9uKGRzbiwgb3B0aW9ucykge1xuICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgIGlmIChzZWxmLl9nbG9iYWxTZXJ2ZXIpIHtcbiAgICAgIHRoaXMuX2xvZ0RlYnVnKCdlcnJvcicsICdFcnJvcjogUmF2ZW4gaGFzIGFscmVhZHkgYmVlbiBjb25maWd1cmVkJyk7XG4gICAgICByZXR1cm4gc2VsZjtcbiAgICB9XG4gICAgaWYgKCFkc24pIHJldHVybiBzZWxmO1xuXG4gICAgdmFyIGdsb2JhbE9wdGlvbnMgPSBzZWxmLl9nbG9iYWxPcHRpb25zO1xuXG4gICAgLy8gbWVyZ2UgaW4gb3B0aW9uc1xuICAgIGlmIChvcHRpb25zKSB7XG4gICAgICBlYWNoKG9wdGlvbnMsIGZ1bmN0aW9uKGtleSwgdmFsdWUpIHtcbiAgICAgICAgLy8gdGFncyBhbmQgZXh0cmEgYXJlIHNwZWNpYWwgYW5kIG5lZWQgdG8gYmUgcHV0IGludG8gY29udGV4dFxuICAgICAgICBpZiAoa2V5ID09PSAndGFncycgfHwga2V5ID09PSAnZXh0cmEnIHx8IGtleSA9PT0gJ3VzZXInKSB7XG4gICAgICAgICAgc2VsZi5fZ2xvYmFsQ29udGV4dFtrZXldID0gdmFsdWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZ2xvYmFsT3B0aW9uc1trZXldID0gdmFsdWU7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHNlbGYuc2V0RFNOKGRzbik7XG5cbiAgICAvLyBcIlNjcmlwdCBlcnJvci5cIiBpcyBoYXJkIGNvZGVkIGludG8gYnJvd3NlcnMgZm9yIGVycm9ycyB0aGF0IGl0IGNhbid0IHJlYWQuXG4gICAgLy8gdGhpcyBpcyB0aGUgcmVzdWx0IG9mIGEgc2NyaXB0IGJlaW5nIHB1bGxlZCBpbiBmcm9tIGFuIGV4dGVybmFsIGRvbWFpbiBhbmQgQ09SUy5cbiAgICBnbG9iYWxPcHRpb25zLmlnbm9yZUVycm9ycy5wdXNoKC9eU2NyaXB0IGVycm9yXFwuPyQvKTtcbiAgICBnbG9iYWxPcHRpb25zLmlnbm9yZUVycm9ycy5wdXNoKC9eSmF2YXNjcmlwdCBlcnJvcjogU2NyaXB0IGVycm9yXFwuPyBvbiBsaW5lIDAkLyk7XG5cbiAgICAvLyBqb2luIHJlZ2V4cCBydWxlcyBpbnRvIG9uZSBiaWcgcnVsZVxuICAgIGdsb2JhbE9wdGlvbnMuaWdub3JlRXJyb3JzID0gam9pblJlZ0V4cChnbG9iYWxPcHRpb25zLmlnbm9yZUVycm9ycyk7XG4gICAgZ2xvYmFsT3B0aW9ucy5pZ25vcmVVcmxzID0gZ2xvYmFsT3B0aW9ucy5pZ25vcmVVcmxzLmxlbmd0aFxuICAgICAgPyBqb2luUmVnRXhwKGdsb2JhbE9wdGlvbnMuaWdub3JlVXJscylcbiAgICAgIDogZmFsc2U7XG4gICAgZ2xvYmFsT3B0aW9ucy53aGl0ZWxpc3RVcmxzID0gZ2xvYmFsT3B0aW9ucy53aGl0ZWxpc3RVcmxzLmxlbmd0aFxuICAgICAgPyBqb2luUmVnRXhwKGdsb2JhbE9wdGlvbnMud2hpdGVsaXN0VXJscylcbiAgICAgIDogZmFsc2U7XG4gICAgZ2xvYmFsT3B0aW9ucy5pbmNsdWRlUGF0aHMgPSBqb2luUmVnRXhwKGdsb2JhbE9wdGlvbnMuaW5jbHVkZVBhdGhzKTtcbiAgICBnbG9iYWxPcHRpb25zLm1heEJyZWFkY3J1bWJzID0gTWF0aC5tYXgoXG4gICAgICAwLFxuICAgICAgTWF0aC5taW4oZ2xvYmFsT3B0aW9ucy5tYXhCcmVhZGNydW1icyB8fCAxMDAsIDEwMClcbiAgICApOyAvLyBkZWZhdWx0IGFuZCBoYXJkIGxpbWl0IGlzIDEwMFxuXG4gICAgdmFyIGF1dG9CcmVhZGNydW1iRGVmYXVsdHMgPSB7XG4gICAgICB4aHI6IHRydWUsXG4gICAgICBjb25zb2xlOiB0cnVlLFxuICAgICAgZG9tOiB0cnVlLFxuICAgICAgbG9jYXRpb246IHRydWUsXG4gICAgICBzZW50cnk6IHRydWVcbiAgICB9O1xuXG4gICAgdmFyIGF1dG9CcmVhZGNydW1icyA9IGdsb2JhbE9wdGlvbnMuYXV0b0JyZWFkY3J1bWJzO1xuICAgIGlmICh7fS50b1N0cmluZy5jYWxsKGF1dG9CcmVhZGNydW1icykgPT09ICdbb2JqZWN0IE9iamVjdF0nKSB7XG4gICAgICBhdXRvQnJlYWRjcnVtYnMgPSBvYmplY3RNZXJnZShhdXRvQnJlYWRjcnVtYkRlZmF1bHRzLCBhdXRvQnJlYWRjcnVtYnMpO1xuICAgIH0gZWxzZSBpZiAoYXV0b0JyZWFkY3J1bWJzICE9PSBmYWxzZSkge1xuICAgICAgYXV0b0JyZWFkY3J1bWJzID0gYXV0b0JyZWFkY3J1bWJEZWZhdWx0cztcbiAgICB9XG4gICAgZ2xvYmFsT3B0aW9ucy5hdXRvQnJlYWRjcnVtYnMgPSBhdXRvQnJlYWRjcnVtYnM7XG5cbiAgICB2YXIgaW5zdHJ1bWVudERlZmF1bHRzID0ge1xuICAgICAgdHJ5Q2F0Y2g6IHRydWVcbiAgICB9O1xuXG4gICAgdmFyIGluc3RydW1lbnQgPSBnbG9iYWxPcHRpb25zLmluc3RydW1lbnQ7XG4gICAgaWYgKHt9LnRvU3RyaW5nLmNhbGwoaW5zdHJ1bWVudCkgPT09ICdbb2JqZWN0IE9iamVjdF0nKSB7XG4gICAgICBpbnN0cnVtZW50ID0gb2JqZWN0TWVyZ2UoaW5zdHJ1bWVudERlZmF1bHRzLCBpbnN0cnVtZW50KTtcbiAgICB9IGVsc2UgaWYgKGluc3RydW1lbnQgIT09IGZhbHNlKSB7XG4gICAgICBpbnN0cnVtZW50ID0gaW5zdHJ1bWVudERlZmF1bHRzO1xuICAgIH1cbiAgICBnbG9iYWxPcHRpb25zLmluc3RydW1lbnQgPSBpbnN0cnVtZW50O1xuXG4gICAgVHJhY2VLaXQuY29sbGVjdFdpbmRvd0Vycm9ycyA9ICEhZ2xvYmFsT3B0aW9ucy5jb2xsZWN0V2luZG93RXJyb3JzO1xuXG4gICAgLy8gcmV0dXJuIGZvciBjaGFpbmluZ1xuICAgIHJldHVybiBzZWxmO1xuICB9LFxuXG4gIC8qXG4gICAgICogSW5zdGFsbHMgYSBnbG9iYWwgd2luZG93Lm9uZXJyb3IgZXJyb3IgaGFuZGxlclxuICAgICAqIHRvIGNhcHR1cmUgYW5kIHJlcG9ydCB1bmNhdWdodCBleGNlcHRpb25zLlxuICAgICAqIEF0IHRoaXMgcG9pbnQsIGluc3RhbGwoKSBpcyByZXF1aXJlZCB0byBiZSBjYWxsZWQgZHVlXG4gICAgICogdG8gdGhlIHdheSBUcmFjZUtpdCBpcyBzZXQgdXAuXG4gICAgICpcbiAgICAgKiBAcmV0dXJuIHtSYXZlbn1cbiAgICAgKi9cbiAgaW5zdGFsbDogZnVuY3Rpb24oKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmIChzZWxmLmlzU2V0dXAoKSAmJiAhc2VsZi5faXNSYXZlbkluc3RhbGxlZCkge1xuICAgICAgVHJhY2VLaXQucmVwb3J0LnN1YnNjcmliZShmdW5jdGlvbigpIHtcbiAgICAgICAgc2VsZi5faGFuZGxlT25FcnJvclN0YWNrSW5mby5hcHBseShzZWxmLCBhcmd1bWVudHMpO1xuICAgICAgfSk7XG5cbiAgICAgIGlmIChzZWxmLl9nbG9iYWxPcHRpb25zLmNhcHR1cmVVbmhhbmRsZWRSZWplY3Rpb25zKSB7XG4gICAgICAgIHNlbGYuX2F0dGFjaFByb21pc2VSZWplY3Rpb25IYW5kbGVyKCk7XG4gICAgICB9XG5cbiAgICAgIHNlbGYuX3BhdGNoRnVuY3Rpb25Ub1N0cmluZygpO1xuXG4gICAgICBpZiAoc2VsZi5fZ2xvYmFsT3B0aW9ucy5pbnN0cnVtZW50ICYmIHNlbGYuX2dsb2JhbE9wdGlvbnMuaW5zdHJ1bWVudC50cnlDYXRjaCkge1xuICAgICAgICBzZWxmLl9pbnN0cnVtZW50VHJ5Q2F0Y2goKTtcbiAgICAgIH1cblxuICAgICAgaWYgKHNlbGYuX2dsb2JhbE9wdGlvbnMuYXV0b0JyZWFkY3J1bWJzKSBzZWxmLl9pbnN0cnVtZW50QnJlYWRjcnVtYnMoKTtcblxuICAgICAgLy8gSW5zdGFsbCBhbGwgb2YgdGhlIHBsdWdpbnNcbiAgICAgIHNlbGYuX2RyYWluUGx1Z2lucygpO1xuXG4gICAgICBzZWxmLl9pc1JhdmVuSW5zdGFsbGVkID0gdHJ1ZTtcbiAgICB9XG5cbiAgICBFcnJvci5zdGFja1RyYWNlTGltaXQgPSBzZWxmLl9nbG9iYWxPcHRpb25zLnN0YWNrVHJhY2VMaW1pdDtcbiAgICByZXR1cm4gdGhpcztcbiAgfSxcblxuICAvKlxuICAgICAqIFNldCB0aGUgRFNOIChjYW4gYmUgY2FsbGVkIG11bHRpcGxlIHRpbWUgdW5saWtlIGNvbmZpZylcbiAgICAgKlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBkc24gVGhlIHB1YmxpYyBTZW50cnkgRFNOXG4gICAgICovXG4gIHNldERTTjogZnVuY3Rpb24oZHNuKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzLFxuICAgICAgdXJpID0gc2VsZi5fcGFyc2VEU04oZHNuKSxcbiAgICAgIGxhc3RTbGFzaCA9IHVyaS5wYXRoLmxhc3RJbmRleE9mKCcvJyksXG4gICAgICBwYXRoID0gdXJpLnBhdGguc3Vic3RyKDEsIGxhc3RTbGFzaCk7XG5cbiAgICBzZWxmLl9kc24gPSBkc247XG4gICAgc2VsZi5fZ2xvYmFsS2V5ID0gdXJpLnVzZXI7XG4gICAgc2VsZi5fZ2xvYmFsU2VjcmV0ID0gdXJpLnBhc3MgJiYgdXJpLnBhc3Muc3Vic3RyKDEpO1xuICAgIHNlbGYuX2dsb2JhbFByb2plY3QgPSB1cmkucGF0aC5zdWJzdHIobGFzdFNsYXNoICsgMSk7XG5cbiAgICBzZWxmLl9nbG9iYWxTZXJ2ZXIgPSBzZWxmLl9nZXRHbG9iYWxTZXJ2ZXIodXJpKTtcblxuICAgIHNlbGYuX2dsb2JhbEVuZHBvaW50ID1cbiAgICAgIHNlbGYuX2dsb2JhbFNlcnZlciArICcvJyArIHBhdGggKyAnYXBpLycgKyBzZWxmLl9nbG9iYWxQcm9qZWN0ICsgJy9zdG9yZS8nO1xuXG4gICAgLy8gUmVzZXQgYmFja29mZiBzdGF0ZSBzaW5jZSB3ZSBtYXkgYmUgcG9pbnRpbmcgYXQgYVxuICAgIC8vIG5ldyBwcm9qZWN0L3NlcnZlclxuICAgIHRoaXMuX3Jlc2V0QmFja29mZigpO1xuICB9LFxuXG4gIC8qXG4gICAgICogV3JhcCBjb2RlIHdpdGhpbiBhIGNvbnRleHQgc28gUmF2ZW4gY2FuIGNhcHR1cmUgZXJyb3JzXG4gICAgICogcmVsaWFibHkgYWNyb3NzIGRvbWFpbnMgdGhhdCBpcyBleGVjdXRlZCBpbW1lZGlhdGVseS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7b2JqZWN0fSBvcHRpb25zIEEgc3BlY2lmaWMgc2V0IG9mIG9wdGlvbnMgZm9yIHRoaXMgY29udGV4dCBbb3B0aW9uYWxdXG4gICAgICogQHBhcmFtIHtmdW5jdGlvbn0gZnVuYyBUaGUgY2FsbGJhY2sgdG8gYmUgaW1tZWRpYXRlbHkgZXhlY3V0ZWQgd2l0aGluIHRoZSBjb250ZXh0XG4gICAgICogQHBhcmFtIHthcnJheX0gYXJncyBBbiBhcnJheSBvZiBhcmd1bWVudHMgdG8gYmUgY2FsbGVkIHdpdGggdGhlIGNhbGxiYWNrIFtvcHRpb25hbF1cbiAgICAgKi9cbiAgY29udGV4dDogZnVuY3Rpb24ob3B0aW9ucywgZnVuYywgYXJncykge1xuICAgIGlmIChpc0Z1bmN0aW9uKG9wdGlvbnMpKSB7XG4gICAgICBhcmdzID0gZnVuYyB8fCBbXTtcbiAgICAgIGZ1bmMgPSBvcHRpb25zO1xuICAgICAgb3B0aW9ucyA9IHt9O1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLndyYXAob3B0aW9ucywgZnVuYykuYXBwbHkodGhpcywgYXJncyk7XG4gIH0sXG5cbiAgLypcbiAgICAgKiBXcmFwIGNvZGUgd2l0aGluIGEgY29udGV4dCBhbmQgcmV0dXJucyBiYWNrIGEgbmV3IGZ1bmN0aW9uIHRvIGJlIGV4ZWN1dGVkXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge29iamVjdH0gb3B0aW9ucyBBIHNwZWNpZmljIHNldCBvZiBvcHRpb25zIGZvciB0aGlzIGNvbnRleHQgW29wdGlvbmFsXVxuICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IGZ1bmMgVGhlIGZ1bmN0aW9uIHRvIGJlIHdyYXBwZWQgaW4gYSBuZXcgY29udGV4dFxuICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IF9iZWZvcmUgQSBmdW5jdGlvbiB0byBjYWxsIGJlZm9yZSB0aGUgdHJ5L2NhdGNoIHdyYXBwZXIgW29wdGlvbmFsLCBwcml2YXRlXVxuICAgICAqIEByZXR1cm4ge2Z1bmN0aW9ufSBUaGUgbmV3bHkgd3JhcHBlZCBmdW5jdGlvbnMgd2l0aCBhIGNvbnRleHRcbiAgICAgKi9cbiAgd3JhcDogZnVuY3Rpb24ob3B0aW9ucywgZnVuYywgX2JlZm9yZSkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAvLyAxIGFyZ3VtZW50IGhhcyBiZWVuIHBhc3NlZCwgYW5kIGl0J3Mgbm90IGEgZnVuY3Rpb25cbiAgICAvLyBzbyBqdXN0IHJldHVybiBpdFxuICAgIGlmIChpc1VuZGVmaW5lZChmdW5jKSAmJiAhaXNGdW5jdGlvbihvcHRpb25zKSkge1xuICAgICAgcmV0dXJuIG9wdGlvbnM7XG4gICAgfVxuXG4gICAgLy8gb3B0aW9ucyBpcyBvcHRpb25hbFxuICAgIGlmIChpc0Z1bmN0aW9uKG9wdGlvbnMpKSB7XG4gICAgICBmdW5jID0gb3B0aW9ucztcbiAgICAgIG9wdGlvbnMgPSB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgLy8gQXQgdGhpcyBwb2ludCwgd2UndmUgcGFzc2VkIGFsb25nIDIgYXJndW1lbnRzLCBhbmQgdGhlIHNlY29uZCBvbmVcbiAgICAvLyBpcyBub3QgYSBmdW5jdGlvbiBlaXRoZXIsIHNvIHdlJ2xsIGp1c3QgcmV0dXJuIHRoZSBzZWNvbmQgYXJndW1lbnQuXG4gICAgaWYgKCFpc0Z1bmN0aW9uKGZ1bmMpKSB7XG4gICAgICByZXR1cm4gZnVuYztcbiAgICB9XG5cbiAgICAvLyBXZSBkb24ndCB3YW5uYSB3cmFwIGl0IHR3aWNlIVxuICAgIHRyeSB7XG4gICAgICBpZiAoZnVuYy5fX3JhdmVuX18pIHtcbiAgICAgICAgcmV0dXJuIGZ1bmM7XG4gICAgICB9XG5cbiAgICAgIC8vIElmIHRoaXMgaGFzIGFscmVhZHkgYmVlbiB3cmFwcGVkIGluIHRoZSBwYXN0LCByZXR1cm4gdGhhdFxuICAgICAgaWYgKGZ1bmMuX19yYXZlbl93cmFwcGVyX18pIHtcbiAgICAgICAgcmV0dXJuIGZ1bmMuX19yYXZlbl93cmFwcGVyX187XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gSnVzdCBhY2Nlc3NpbmcgY3VzdG9tIHByb3BzIGluIHNvbWUgU2VsZW5pdW0gZW52aXJvbm1lbnRzXG4gICAgICAvLyBjYW4gY2F1c2UgYSBcIlBlcm1pc3Npb24gZGVuaWVkXCIgZXhjZXB0aW9uIChzZWUgcmF2ZW4tanMjNDk1KS5cbiAgICAgIC8vIEJhaWwgb24gd3JhcHBpbmcgYW5kIHJldHVybiB0aGUgZnVuY3Rpb24gYXMtaXMgKGRlZmVycyB0byB3aW5kb3cub25lcnJvcikuXG4gICAgICByZXR1cm4gZnVuYztcbiAgICB9XG5cbiAgICBmdW5jdGlvbiB3cmFwcGVkKCkge1xuICAgICAgdmFyIGFyZ3MgPSBbXSxcbiAgICAgICAgaSA9IGFyZ3VtZW50cy5sZW5ndGgsXG4gICAgICAgIGRlZXAgPSAhb3B0aW9ucyB8fCAob3B0aW9ucyAmJiBvcHRpb25zLmRlZXAgIT09IGZhbHNlKTtcblxuICAgICAgaWYgKF9iZWZvcmUgJiYgaXNGdW5jdGlvbihfYmVmb3JlKSkge1xuICAgICAgICBfYmVmb3JlLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFJlY3Vyc2l2ZWx5IHdyYXAgYWxsIG9mIGEgZnVuY3Rpb24ncyBhcmd1bWVudHMgdGhhdCBhcmVcbiAgICAgIC8vIGZ1bmN0aW9ucyB0aGVtc2VsdmVzLlxuICAgICAgd2hpbGUgKGktLSkgYXJnc1tpXSA9IGRlZXAgPyBzZWxmLndyYXAob3B0aW9ucywgYXJndW1lbnRzW2ldKSA6IGFyZ3VtZW50c1tpXTtcblxuICAgICAgdHJ5IHtcbiAgICAgICAgLy8gQXR0ZW1wdCB0byBpbnZva2UgdXNlci1sYW5kIGZ1bmN0aW9uXG4gICAgICAgIC8vIE5PVEU6IElmIHlvdSBhcmUgYSBTZW50cnkgdXNlciwgYW5kIHlvdSBhcmUgc2VlaW5nIHRoaXMgc3RhY2sgZnJhbWUsIGl0XG4gICAgICAgIC8vICAgICAgIG1lYW5zIFJhdmVuIGNhdWdodCBhbiBlcnJvciBpbnZva2luZyB5b3VyIGFwcGxpY2F0aW9uIGNvZGUuIFRoaXMgaXNcbiAgICAgICAgLy8gICAgICAgZXhwZWN0ZWQgYmVoYXZpb3IgYW5kIE5PVCBpbmRpY2F0aXZlIG9mIGEgYnVnIHdpdGggUmF2ZW4uanMuXG4gICAgICAgIHJldHVybiBmdW5jLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBzZWxmLl9pZ25vcmVOZXh0T25FcnJvcigpO1xuICAgICAgICBzZWxmLmNhcHR1cmVFeGNlcHRpb24oZSwgb3B0aW9ucyk7XG4gICAgICAgIHRocm93IGU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gY29weSBvdmVyIHByb3BlcnRpZXMgb2YgdGhlIG9sZCBmdW5jdGlvblxuICAgIGZvciAodmFyIHByb3BlcnR5IGluIGZ1bmMpIHtcbiAgICAgIGlmIChoYXNLZXkoZnVuYywgcHJvcGVydHkpKSB7XG4gICAgICAgIHdyYXBwZWRbcHJvcGVydHldID0gZnVuY1twcm9wZXJ0eV07XG4gICAgICB9XG4gICAgfVxuICAgIHdyYXBwZWQucHJvdG90eXBlID0gZnVuYy5wcm90b3R5cGU7XG5cbiAgICBmdW5jLl9fcmF2ZW5fd3JhcHBlcl9fID0gd3JhcHBlZDtcbiAgICAvLyBTaWduYWwgdGhhdCB0aGlzIGZ1bmN0aW9uIGhhcyBiZWVuIHdyYXBwZWQvZmlsbGVkIGFscmVhZHlcbiAgICAvLyBmb3IgYm90aCBkZWJ1Z2dpbmcgYW5kIHRvIHByZXZlbnQgaXQgdG8gYmVpbmcgd3JhcHBlZC9maWxsZWQgdHdpY2VcbiAgICB3cmFwcGVkLl9fcmF2ZW5fXyA9IHRydWU7XG4gICAgd3JhcHBlZC5fX29yaWdfXyA9IGZ1bmM7XG5cbiAgICByZXR1cm4gd3JhcHBlZDtcbiAgfSxcblxuICAvKipcbiAgICogVW5pbnN0YWxscyB0aGUgZ2xvYmFsIGVycm9yIGhhbmRsZXIuXG4gICAqXG4gICAqIEByZXR1cm4ge1JhdmVufVxuICAgKi9cbiAgdW5pbnN0YWxsOiBmdW5jdGlvbigpIHtcbiAgICBUcmFjZUtpdC5yZXBvcnQudW5pbnN0YWxsKCk7XG5cbiAgICB0aGlzLl9kZXRhY2hQcm9taXNlUmVqZWN0aW9uSGFuZGxlcigpO1xuICAgIHRoaXMuX3VucGF0Y2hGdW5jdGlvblRvU3RyaW5nKCk7XG4gICAgdGhpcy5fcmVzdG9yZUJ1aWx0SW5zKCk7XG4gICAgdGhpcy5fcmVzdG9yZUNvbnNvbGUoKTtcblxuICAgIEVycm9yLnN0YWNrVHJhY2VMaW1pdCA9IHRoaXMuX29yaWdpbmFsRXJyb3JTdGFja1RyYWNlTGltaXQ7XG4gICAgdGhpcy5faXNSYXZlbkluc3RhbGxlZCA9IGZhbHNlO1xuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH0sXG5cbiAgLyoqXG4gICAqIENhbGxiYWNrIHVzZWQgZm9yIGB1bmhhbmRsZWRyZWplY3Rpb25gIGV2ZW50XG4gICAqXG4gICAqIEBwYXJhbSB7UHJvbWlzZVJlamVjdGlvbkV2ZW50fSBldmVudCBBbiBvYmplY3QgY29udGFpbmluZ1xuICAgKiAgIHByb21pc2U6IHRoZSBQcm9taXNlIHRoYXQgd2FzIHJlamVjdGVkXG4gICAqICAgcmVhc29uOiB0aGUgdmFsdWUgd2l0aCB3aGljaCB0aGUgUHJvbWlzZSB3YXMgcmVqZWN0ZWRcbiAgICogQHJldHVybiB2b2lkXG4gICAqL1xuICBfcHJvbWlzZVJlamVjdGlvbkhhbmRsZXI6IGZ1bmN0aW9uKGV2ZW50KSB7XG4gICAgdGhpcy5fbG9nRGVidWcoJ2RlYnVnJywgJ1JhdmVuIGNhdWdodCB1bmhhbmRsZWQgcHJvbWlzZSByZWplY3Rpb246JywgZXZlbnQpO1xuICAgIHRoaXMuY2FwdHVyZUV4Y2VwdGlvbihldmVudC5yZWFzb24sIHtcbiAgICAgIG1lY2hhbmlzbToge1xuICAgICAgICB0eXBlOiAnb251bmhhbmRsZWRyZWplY3Rpb24nLFxuICAgICAgICBoYW5kbGVkOiBmYWxzZVxuICAgICAgfVxuICAgIH0pO1xuICB9LFxuXG4gIC8qKlxuICAgKiBJbnN0YWxscyB0aGUgZ2xvYmFsIHByb21pc2UgcmVqZWN0aW9uIGhhbmRsZXIuXG4gICAqXG4gICAqIEByZXR1cm4ge3JhdmVufVxuICAgKi9cbiAgX2F0dGFjaFByb21pc2VSZWplY3Rpb25IYW5kbGVyOiBmdW5jdGlvbigpIHtcbiAgICB0aGlzLl9wcm9taXNlUmVqZWN0aW9uSGFuZGxlciA9IHRoaXMuX3Byb21pc2VSZWplY3Rpb25IYW5kbGVyLmJpbmQodGhpcyk7XG4gICAgX3dpbmRvdy5hZGRFdmVudExpc3RlbmVyICYmXG4gICAgICBfd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3VuaGFuZGxlZHJlamVjdGlvbicsIHRoaXMuX3Byb21pc2VSZWplY3Rpb25IYW5kbGVyKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfSxcblxuICAvKipcbiAgICogVW5pbnN0YWxscyB0aGUgZ2xvYmFsIHByb21pc2UgcmVqZWN0aW9uIGhhbmRsZXIuXG4gICAqXG4gICAqIEByZXR1cm4ge3JhdmVufVxuICAgKi9cbiAgX2RldGFjaFByb21pc2VSZWplY3Rpb25IYW5kbGVyOiBmdW5jdGlvbigpIHtcbiAgICBfd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIgJiZcbiAgICAgIF93aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigndW5oYW5kbGVkcmVqZWN0aW9uJywgdGhpcy5fcHJvbWlzZVJlamVjdGlvbkhhbmRsZXIpO1xuICAgIHJldHVybiB0aGlzO1xuICB9LFxuXG4gIC8qKlxuICAgKiBNYW51YWxseSBjYXB0dXJlIGFuIGV4Y2VwdGlvbiBhbmQgc2VuZCBpdCBvdmVyIHRvIFNlbnRyeVxuICAgKlxuICAgKiBAcGFyYW0ge2Vycm9yfSBleCBBbiBleGNlcHRpb24gdG8gYmUgbG9nZ2VkXG4gICAqIEBwYXJhbSB7b2JqZWN0fSBvcHRpb25zIEEgc3BlY2lmaWMgc2V0IG9mIG9wdGlvbnMgZm9yIHRoaXMgZXJyb3IgW29wdGlvbmFsXVxuICAgKiBAcmV0dXJuIHtSYXZlbn1cbiAgICovXG4gIGNhcHR1cmVFeGNlcHRpb246IGZ1bmN0aW9uKGV4LCBvcHRpb25zKSB7XG4gICAgb3B0aW9ucyA9IG9iamVjdE1lcmdlKHt0cmltSGVhZEZyYW1lczogMH0sIG9wdGlvbnMgPyBvcHRpb25zIDoge30pO1xuXG4gICAgaWYgKGlzRXJyb3JFdmVudChleCkgJiYgZXguZXJyb3IpIHtcbiAgICAgIC8vIElmIGl0IGlzIGFuIEVycm9yRXZlbnQgd2l0aCBgZXJyb3JgIHByb3BlcnR5LCBleHRyYWN0IGl0IHRvIGdldCBhY3R1YWwgRXJyb3JcbiAgICAgIGV4ID0gZXguZXJyb3I7XG4gICAgfSBlbHNlIGlmIChpc0RPTUVycm9yKGV4KSB8fCBpc0RPTUV4Y2VwdGlvbihleCkpIHtcbiAgICAgIC8vIElmIGl0IGlzIGEgRE9NRXJyb3Igb3IgRE9NRXhjZXB0aW9uICh3aGljaCBhcmUgbGVnYWN5IEFQSXMsIGJ1dCBzdGlsbCBzdXBwb3J0ZWQgaW4gc29tZSBicm93c2VycylcbiAgICAgIC8vIHRoZW4gd2UganVzdCBleHRyYWN0IHRoZSBuYW1lIGFuZCBtZXNzYWdlLCBhcyB0aGV5IGRvbid0IHByb3ZpZGUgYW55dGhpbmcgZWxzZVxuICAgICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0RPTUVycm9yXG4gICAgICAvLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvRE9NRXhjZXB0aW9uXG4gICAgICB2YXIgbmFtZSA9IGV4Lm5hbWUgfHwgKGlzRE9NRXJyb3IoZXgpID8gJ0RPTUVycm9yJyA6ICdET01FeGNlcHRpb24nKTtcbiAgICAgIHZhciBtZXNzYWdlID0gZXgubWVzc2FnZSA/IG5hbWUgKyAnOiAnICsgZXgubWVzc2FnZSA6IG5hbWU7XG5cbiAgICAgIHJldHVybiB0aGlzLmNhcHR1cmVNZXNzYWdlKFxuICAgICAgICBtZXNzYWdlLFxuICAgICAgICBvYmplY3RNZXJnZShvcHRpb25zLCB7XG4gICAgICAgICAgLy8gbmVpdGhlciBET01FcnJvciBvciBET01FeGNlcHRpb24gcHJvdmlkZSBzdGFjayB0cmFjZSBhbmQgd2UgbW9zdCBsaWtlbHkgd29udCBnZXQgaXQgdGhpcyB3YXkgYXMgd2VsbFxuICAgICAgICAgIC8vIGJ1dCBpdCdzIGJhcmVseSBhbnkgb3ZlcmhlYWQgc28gd2UgbWF5IGF0IGxlYXN0IHRyeVxuICAgICAgICAgIHN0YWNrdHJhY2U6IHRydWUsXG4gICAgICAgICAgdHJpbUhlYWRGcmFtZXM6IG9wdGlvbnMudHJpbUhlYWRGcmFtZXMgKyAxXG4gICAgICAgIH0pXG4gICAgICApO1xuICAgIH0gZWxzZSBpZiAoaXNFcnJvcihleCkpIHtcbiAgICAgIC8vIHdlIGhhdmUgYSByZWFsIEVycm9yIG9iamVjdFxuICAgICAgZXggPSBleDtcbiAgICB9IGVsc2UgaWYgKGlzUGxhaW5PYmplY3QoZXgpKSB7XG4gICAgICAvLyBJZiBpdCBpcyBwbGFpbiBPYmplY3QsIHNlcmlhbGl6ZSBpdCBtYW51YWxseSBhbmQgZXh0cmFjdCBvcHRpb25zXG4gICAgICAvLyBUaGlzIHdpbGwgYWxsb3cgdXMgdG8gZ3JvdXAgZXZlbnRzIGJhc2VkIG9uIHRvcC1sZXZlbCBrZXlzXG4gICAgICAvLyB3aGljaCBpcyBtdWNoIGJldHRlciB0aGFuIGNyZWF0aW5nIG5ldyBncm91cCB3aGVuIGFueSBrZXkvdmFsdWUgY2hhbmdlXG4gICAgICBvcHRpb25zID0gdGhpcy5fZ2V0Q2FwdHVyZUV4Y2VwdGlvbk9wdGlvbnNGcm9tUGxhaW5PYmplY3Qob3B0aW9ucywgZXgpO1xuICAgICAgZXggPSBuZXcgRXJyb3Iob3B0aW9ucy5tZXNzYWdlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gSWYgbm9uZSBvZiBwcmV2aW91cyBjaGVja3Mgd2VyZSB2YWxpZCwgdGhlbiBpdCBtZWFucyB0aGF0XG4gICAgICAvLyBpdCdzIG5vdCBhIERPTUVycm9yL0RPTUV4Y2VwdGlvblxuICAgICAgLy8gaXQncyBub3QgYSBwbGFpbiBPYmplY3RcbiAgICAgIC8vIGl0J3Mgbm90IGEgdmFsaWQgRXJyb3JFdmVudCAob25lIHdpdGggYW4gZXJyb3IgcHJvcGVydHkpXG4gICAgICAvLyBpdCdzIG5vdCBhbiBFcnJvclxuICAgICAgLy8gU28gYmFpbCBvdXQgYW5kIGNhcHR1cmUgaXQgYXMgYSBzaW1wbGUgbWVzc2FnZTpcbiAgICAgIHJldHVybiB0aGlzLmNhcHR1cmVNZXNzYWdlKFxuICAgICAgICBleCxcbiAgICAgICAgb2JqZWN0TWVyZ2Uob3B0aW9ucywge1xuICAgICAgICAgIHN0YWNrdHJhY2U6IHRydWUsIC8vIGlmIHdlIGZhbGwgYmFjayB0byBjYXB0dXJlTWVzc2FnZSwgZGVmYXVsdCB0byBhdHRlbXB0aW5nIGEgbmV3IHRyYWNlXG4gICAgICAgICAgdHJpbUhlYWRGcmFtZXM6IG9wdGlvbnMudHJpbUhlYWRGcmFtZXMgKyAxXG4gICAgICAgIH0pXG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIFN0b3JlIHRoZSByYXcgZXhjZXB0aW9uIG9iamVjdCBmb3IgcG90ZW50aWFsIGRlYnVnZ2luZyBhbmQgaW50cm9zcGVjdGlvblxuICAgIHRoaXMuX2xhc3RDYXB0dXJlZEV4Y2VwdGlvbiA9IGV4O1xuXG4gICAgLy8gVHJhY2VLaXQucmVwb3J0IHdpbGwgcmUtcmFpc2UgYW55IGV4Y2VwdGlvbiBwYXNzZWQgdG8gaXQsXG4gICAgLy8gd2hpY2ggbWVhbnMgeW91IGhhdmUgdG8gd3JhcCBpdCBpbiB0cnkvY2F0Y2guIEluc3RlYWQsIHdlXG4gICAgLy8gY2FuIHdyYXAgaXQgaGVyZSBhbmQgb25seSByZS1yYWlzZSBpZiBUcmFjZUtpdC5yZXBvcnRcbiAgICAvLyByYWlzZXMgYW4gZXhjZXB0aW9uIGRpZmZlcmVudCBmcm9tIHRoZSBvbmUgd2UgYXNrZWQgdG9cbiAgICAvLyByZXBvcnQgb24uXG4gICAgdHJ5IHtcbiAgICAgIHZhciBzdGFjayA9IFRyYWNlS2l0LmNvbXB1dGVTdGFja1RyYWNlKGV4KTtcbiAgICAgIHRoaXMuX2hhbmRsZVN0YWNrSW5mbyhzdGFjaywgb3B0aW9ucyk7XG4gICAgfSBjYXRjaCAoZXgxKSB7XG4gICAgICBpZiAoZXggIT09IGV4MSkge1xuICAgICAgICB0aHJvdyBleDE7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH0sXG5cbiAgX2dldENhcHR1cmVFeGNlcHRpb25PcHRpb25zRnJvbVBsYWluT2JqZWN0OiBmdW5jdGlvbihjdXJyZW50T3B0aW9ucywgZXgpIHtcbiAgICB2YXIgZXhLZXlzID0gT2JqZWN0LmtleXMoZXgpLnNvcnQoKTtcbiAgICB2YXIgb3B0aW9ucyA9IG9iamVjdE1lcmdlKGN1cnJlbnRPcHRpb25zLCB7XG4gICAgICBtZXNzYWdlOlxuICAgICAgICAnTm9uLUVycm9yIGV4Y2VwdGlvbiBjYXB0dXJlZCB3aXRoIGtleXM6ICcgKyBzZXJpYWxpemVLZXlzRm9yTWVzc2FnZShleEtleXMpLFxuICAgICAgZmluZ2VycHJpbnQ6IFttZDUoZXhLZXlzKV0sXG4gICAgICBleHRyYTogY3VycmVudE9wdGlvbnMuZXh0cmEgfHwge31cbiAgICB9KTtcbiAgICBvcHRpb25zLmV4dHJhLl9fc2VyaWFsaXplZF9fID0gc2VyaWFsaXplRXhjZXB0aW9uKGV4KTtcblxuICAgIHJldHVybiBvcHRpb25zO1xuICB9LFxuXG4gIC8qXG4gICAgICogTWFudWFsbHkgc2VuZCBhIG1lc3NhZ2UgdG8gU2VudHJ5XG4gICAgICpcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gbXNnIEEgcGxhaW4gbWVzc2FnZSB0byBiZSBjYXB0dXJlZCBpbiBTZW50cnlcbiAgICAgKiBAcGFyYW0ge29iamVjdH0gb3B0aW9ucyBBIHNwZWNpZmljIHNldCBvZiBvcHRpb25zIGZvciB0aGlzIG1lc3NhZ2UgW29wdGlvbmFsXVxuICAgICAqIEByZXR1cm4ge1JhdmVufVxuICAgICAqL1xuICBjYXB0dXJlTWVzc2FnZTogZnVuY3Rpb24obXNnLCBvcHRpb25zKSB7XG4gICAgLy8gY29uZmlnKCkgYXV0b21hZ2ljYWxseSBjb252ZXJ0cyBpZ25vcmVFcnJvcnMgZnJvbSBhIGxpc3QgdG8gYSBSZWdFeHAgc28gd2UgbmVlZCB0byB0ZXN0IGZvciBhblxuICAgIC8vIGVhcmx5IGNhbGw7IHdlJ2xsIGVycm9yIG9uIHRoZSBzaWRlIG9mIGxvZ2dpbmcgYW55dGhpbmcgY2FsbGVkIGJlZm9yZSBjb25maWd1cmF0aW9uIHNpbmNlIGl0J3NcbiAgICAvLyBwcm9iYWJseSBzb21ldGhpbmcgeW91IHNob3VsZCBzZWU6XG4gICAgaWYgKFxuICAgICAgISF0aGlzLl9nbG9iYWxPcHRpb25zLmlnbm9yZUVycm9ycy50ZXN0ICYmXG4gICAgICB0aGlzLl9nbG9iYWxPcHRpb25zLmlnbm9yZUVycm9ycy50ZXN0KG1zZylcbiAgICApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbiAgICBtc2cgPSBtc2cgKyAnJzsgLy8gTWFrZSBzdXJlIGl0J3MgYWN0dWFsbHkgYSBzdHJpbmdcblxuICAgIHZhciBkYXRhID0gb2JqZWN0TWVyZ2UoXG4gICAgICB7XG4gICAgICAgIG1lc3NhZ2U6IG1zZ1xuICAgICAgfSxcbiAgICAgIG9wdGlvbnNcbiAgICApO1xuXG4gICAgdmFyIGV4O1xuICAgIC8vIEdlbmVyYXRlIGEgXCJzeW50aGV0aWNcIiBzdGFjayB0cmFjZSBmcm9tIHRoaXMgcG9pbnQuXG4gICAgLy8gTk9URTogSWYgeW91IGFyZSBhIFNlbnRyeSB1c2VyLCBhbmQgeW91IGFyZSBzZWVpbmcgdGhpcyBzdGFjayBmcmFtZSwgaXQgaXMgTk9UIGluZGljYXRpdmVcbiAgICAvLyAgICAgICBvZiBhIGJ1ZyB3aXRoIFJhdmVuLmpzLiBTZW50cnkgZ2VuZXJhdGVzIHN5bnRoZXRpYyB0cmFjZXMgZWl0aGVyIGJ5IGNvbmZpZ3VyYXRpb24sXG4gICAgLy8gICAgICAgb3IgaWYgaXQgY2F0Y2hlcyBhIHRocm93biBvYmplY3Qgd2l0aG91dCBhIFwic3RhY2tcIiBwcm9wZXJ0eS5cbiAgICB0cnkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKG1zZyk7XG4gICAgfSBjYXRjaCAoZXgxKSB7XG4gICAgICBleCA9IGV4MTtcbiAgICB9XG5cbiAgICAvLyBudWxsIGV4Y2VwdGlvbiBuYW1lIHNvIGBFcnJvcmAgaXNuJ3QgcHJlZml4ZWQgdG8gbXNnXG4gICAgZXgubmFtZSA9IG51bGw7XG4gICAgdmFyIHN0YWNrID0gVHJhY2VLaXQuY29tcHV0ZVN0YWNrVHJhY2UoZXgpO1xuXG4gICAgLy8gc3RhY2tbMF0gaXMgYHRocm93IG5ldyBFcnJvcihtc2cpYCBjYWxsIGl0c2VsZiwgd2UgYXJlIGludGVyZXN0ZWQgaW4gdGhlIGZyYW1lIHRoYXQgd2FzIGp1c3QgYmVmb3JlIHRoYXQsIHN0YWNrWzFdXG4gICAgdmFyIGluaXRpYWxDYWxsID0gaXNBcnJheShzdGFjay5zdGFjaykgJiYgc3RhY2suc3RhY2tbMV07XG5cbiAgICAvLyBpZiBzdGFja1sxXSBpcyBgUmF2ZW4uY2FwdHVyZUV4Y2VwdGlvbmAsIGl0IG1lYW5zIHRoYXQgc29tZW9uZSBwYXNzZWQgYSBzdHJpbmcgdG8gaXQgYW5kIHdlIHJlZGlyZWN0ZWQgdGhhdCBjYWxsXG4gICAgLy8gdG8gYmUgaGFuZGxlZCBieSBgY2FwdHVyZU1lc3NhZ2VgLCB0aHVzIGBpbml0aWFsQ2FsbGAgaXMgdGhlIDNyZCBvbmUsIG5vdCAybmRcbiAgICAvLyBpbml0aWFsQ2FsbCA9PiBjYXB0dXJlRXhjZXB0aW9uKHN0cmluZykgPT4gY2FwdHVyZU1lc3NhZ2Uoc3RyaW5nKVxuICAgIGlmIChpbml0aWFsQ2FsbCAmJiBpbml0aWFsQ2FsbC5mdW5jID09PSAnUmF2ZW4uY2FwdHVyZUV4Y2VwdGlvbicpIHtcbiAgICAgIGluaXRpYWxDYWxsID0gc3RhY2suc3RhY2tbMl07XG4gICAgfVxuXG4gICAgdmFyIGZpbGV1cmwgPSAoaW5pdGlhbENhbGwgJiYgaW5pdGlhbENhbGwudXJsKSB8fCAnJztcblxuICAgIGlmIChcbiAgICAgICEhdGhpcy5fZ2xvYmFsT3B0aW9ucy5pZ25vcmVVcmxzLnRlc3QgJiZcbiAgICAgIHRoaXMuX2dsb2JhbE9wdGlvbnMuaWdub3JlVXJscy50ZXN0KGZpbGV1cmwpXG4gICAgKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKFxuICAgICAgISF0aGlzLl9nbG9iYWxPcHRpb25zLndoaXRlbGlzdFVybHMudGVzdCAmJlxuICAgICAgIXRoaXMuX2dsb2JhbE9wdGlvbnMud2hpdGVsaXN0VXJscy50ZXN0KGZpbGV1cmwpXG4gICAgKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gQWx3YXlzIGF0dGVtcHQgdG8gZ2V0IHN0YWNrdHJhY2UgaWYgbWVzc2FnZSBpcyBlbXB0eS5cbiAgICAvLyBJdCdzIHRoZSBvbmx5IHdheSB0byBwcm92aWRlIGFueSBoZWxwZnVsIGluZm9ybWF0aW9uIHRvIHRoZSB1c2VyLlxuICAgIGlmICh0aGlzLl9nbG9iYWxPcHRpb25zLnN0YWNrdHJhY2UgfHwgb3B0aW9ucy5zdGFja3RyYWNlIHx8IGRhdGEubWVzc2FnZSA9PT0gJycpIHtcbiAgICAgIC8vIGZpbmdlcnByaW50IG9uIG1zZywgbm90IHN0YWNrIHRyYWNlIChsZWdhY3kgYmVoYXZpb3IsIGNvdWxkIGJlIHJldmlzaXRlZClcbiAgICAgIGRhdGEuZmluZ2VycHJpbnQgPSBkYXRhLmZpbmdlcnByaW50ID09IG51bGwgPyBtc2cgOiBkYXRhLmZpbmdlcnByaW50O1xuXG4gICAgICBvcHRpb25zID0gb2JqZWN0TWVyZ2UoXG4gICAgICAgIHtcbiAgICAgICAgICB0cmltSGVhZEZyYW1lczogMFxuICAgICAgICB9LFxuICAgICAgICBvcHRpb25zXG4gICAgICApO1xuICAgICAgLy8gU2luY2Ugd2Uga25vdyB0aGlzIGlzIGEgc3ludGhldGljIHRyYWNlLCB0aGUgdG9wIGZyYW1lICh0aGlzIGZ1bmN0aW9uIGNhbGwpXG4gICAgICAvLyBNVVNUIGJlIGZyb20gUmF2ZW4uanMsIHNvIG1hcmsgaXQgZm9yIHRyaW1taW5nXG4gICAgICAvLyBXZSBhZGQgdG8gdGhlIHRyaW0gY291bnRlciBzbyB0aGF0IGNhbGxlcnMgY2FuIGNob29zZSB0byB0cmltIGV4dHJhIGZyYW1lcywgc3VjaFxuICAgICAgLy8gYXMgdXRpbGl0eSBmdW5jdGlvbnMuXG4gICAgICBvcHRpb25zLnRyaW1IZWFkRnJhbWVzICs9IDE7XG5cbiAgICAgIHZhciBmcmFtZXMgPSB0aGlzLl9wcmVwYXJlRnJhbWVzKHN0YWNrLCBvcHRpb25zKTtcbiAgICAgIGRhdGEuc3RhY2t0cmFjZSA9IHtcbiAgICAgICAgLy8gU2VudHJ5IGV4cGVjdHMgZnJhbWVzIG9sZGVzdCB0byBuZXdlc3RcbiAgICAgICAgZnJhbWVzOiBmcmFtZXMucmV2ZXJzZSgpXG4gICAgICB9O1xuICAgIH1cblxuICAgIC8vIE1ha2Ugc3VyZSB0aGF0IGZpbmdlcnByaW50IGlzIGFsd2F5cyB3cmFwcGVkIGluIGFuIGFycmF5XG4gICAgaWYgKGRhdGEuZmluZ2VycHJpbnQpIHtcbiAgICAgIGRhdGEuZmluZ2VycHJpbnQgPSBpc0FycmF5KGRhdGEuZmluZ2VycHJpbnQpXG4gICAgICAgID8gZGF0YS5maW5nZXJwcmludFxuICAgICAgICA6IFtkYXRhLmZpbmdlcnByaW50XTtcbiAgICB9XG5cbiAgICAvLyBGaXJlIGF3YXkhXG4gICAgdGhpcy5fc2VuZChkYXRhKTtcblxuICAgIHJldHVybiB0aGlzO1xuICB9LFxuXG4gIGNhcHR1cmVCcmVhZGNydW1iOiBmdW5jdGlvbihvYmopIHtcbiAgICB2YXIgY3J1bWIgPSBvYmplY3RNZXJnZShcbiAgICAgIHtcbiAgICAgICAgdGltZXN0YW1wOiBub3coKSAvIDEwMDBcbiAgICAgIH0sXG4gICAgICBvYmpcbiAgICApO1xuXG4gICAgaWYgKGlzRnVuY3Rpb24odGhpcy5fZ2xvYmFsT3B0aW9ucy5icmVhZGNydW1iQ2FsbGJhY2spKSB7XG4gICAgICB2YXIgcmVzdWx0ID0gdGhpcy5fZ2xvYmFsT3B0aW9ucy5icmVhZGNydW1iQ2FsbGJhY2soY3J1bWIpO1xuXG4gICAgICBpZiAoaXNPYmplY3QocmVzdWx0KSAmJiAhaXNFbXB0eU9iamVjdChyZXN1bHQpKSB7XG4gICAgICAgIGNydW1iID0gcmVzdWx0O1xuICAgICAgfSBlbHNlIGlmIChyZXN1bHQgPT09IGZhbHNlKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMuX2JyZWFkY3J1bWJzLnB1c2goY3J1bWIpO1xuICAgIGlmICh0aGlzLl9icmVhZGNydW1icy5sZW5ndGggPiB0aGlzLl9nbG9iYWxPcHRpb25zLm1heEJyZWFkY3J1bWJzKSB7XG4gICAgICB0aGlzLl9icmVhZGNydW1icy5zaGlmdCgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfSxcblxuICBhZGRQbHVnaW46IGZ1bmN0aW9uKHBsdWdpbiAvKmFyZzEsIGFyZzIsIC4uLiBhcmdOKi8pIHtcbiAgICB2YXIgcGx1Z2luQXJncyA9IFtdLnNsaWNlLmNhbGwoYXJndW1lbnRzLCAxKTtcblxuICAgIHRoaXMuX3BsdWdpbnMucHVzaChbcGx1Z2luLCBwbHVnaW5BcmdzXSk7XG4gICAgaWYgKHRoaXMuX2lzUmF2ZW5JbnN0YWxsZWQpIHtcbiAgICAgIHRoaXMuX2RyYWluUGx1Z2lucygpO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzO1xuICB9LFxuXG4gIC8qXG4gICAgICogU2V0L2NsZWFyIGEgdXNlciB0byBiZSBzZW50IGFsb25nIHdpdGggdGhlIHBheWxvYWQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge29iamVjdH0gdXNlciBBbiBvYmplY3QgcmVwcmVzZW50aW5nIHVzZXIgZGF0YSBbb3B0aW9uYWxdXG4gICAgICogQHJldHVybiB7UmF2ZW59XG4gICAgICovXG4gIHNldFVzZXJDb250ZXh0OiBmdW5jdGlvbih1c2VyKSB7XG4gICAgLy8gSW50ZW50aW9uYWxseSBkbyBub3QgbWVyZ2UgaGVyZSBzaW5jZSB0aGF0J3MgYW4gdW5leHBlY3RlZCBiZWhhdmlvci5cbiAgICB0aGlzLl9nbG9iYWxDb250ZXh0LnVzZXIgPSB1c2VyO1xuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH0sXG5cbiAgLypcbiAgICAgKiBNZXJnZSBleHRyYSBhdHRyaWJ1dGVzIHRvIGJlIHNlbnQgYWxvbmcgd2l0aCB0aGUgcGF5bG9hZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7b2JqZWN0fSBleHRyYSBBbiBvYmplY3QgcmVwcmVzZW50aW5nIGV4dHJhIGRhdGEgW29wdGlvbmFsXVxuICAgICAqIEByZXR1cm4ge1JhdmVufVxuICAgICAqL1xuICBzZXRFeHRyYUNvbnRleHQ6IGZ1bmN0aW9uKGV4dHJhKSB7XG4gICAgdGhpcy5fbWVyZ2VDb250ZXh0KCdleHRyYScsIGV4dHJhKTtcblxuICAgIHJldHVybiB0aGlzO1xuICB9LFxuXG4gIC8qXG4gICAgICogTWVyZ2UgdGFncyB0byBiZSBzZW50IGFsb25nIHdpdGggdGhlIHBheWxvYWQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge29iamVjdH0gdGFncyBBbiBvYmplY3QgcmVwcmVzZW50aW5nIHRhZ3MgW29wdGlvbmFsXVxuICAgICAqIEByZXR1cm4ge1JhdmVufVxuICAgICAqL1xuICBzZXRUYWdzQ29udGV4dDogZnVuY3Rpb24odGFncykge1xuICAgIHRoaXMuX21lcmdlQ29udGV4dCgndGFncycsIHRhZ3MpO1xuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH0sXG5cbiAgLypcbiAgICAgKiBDbGVhciBhbGwgb2YgdGhlIGNvbnRleHQuXG4gICAgICpcbiAgICAgKiBAcmV0dXJuIHtSYXZlbn1cbiAgICAgKi9cbiAgY2xlYXJDb250ZXh0OiBmdW5jdGlvbigpIHtcbiAgICB0aGlzLl9nbG9iYWxDb250ZXh0ID0ge307XG5cbiAgICByZXR1cm4gdGhpcztcbiAgfSxcblxuICAvKlxuICAgICAqIEdldCBhIGNvcHkgb2YgdGhlIGN1cnJlbnQgY29udGV4dC4gVGhpcyBjYW5ub3QgYmUgbXV0YXRlZC5cbiAgICAgKlxuICAgICAqIEByZXR1cm4ge29iamVjdH0gY29weSBvZiBjb250ZXh0XG4gICAgICovXG4gIGdldENvbnRleHQ6IGZ1bmN0aW9uKCkge1xuICAgIC8vIGxvbCBqYXZhc2NyaXB0XG4gICAgcmV0dXJuIEpTT04ucGFyc2Uoc3RyaW5naWZ5KHRoaXMuX2dsb2JhbENvbnRleHQpKTtcbiAgfSxcblxuICAvKlxuICAgICAqIFNldCBlbnZpcm9ubWVudCBvZiBhcHBsaWNhdGlvblxuICAgICAqXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IGVudmlyb25tZW50IFR5cGljYWxseSBzb21ldGhpbmcgbGlrZSAncHJvZHVjdGlvbicuXG4gICAgICogQHJldHVybiB7UmF2ZW59XG4gICAgICovXG4gIHNldEVudmlyb25tZW50OiBmdW5jdGlvbihlbnZpcm9ubWVudCkge1xuICAgIHRoaXMuX2dsb2JhbE9wdGlvbnMuZW52aXJvbm1lbnQgPSBlbnZpcm9ubWVudDtcblxuICAgIHJldHVybiB0aGlzO1xuICB9LFxuXG4gIC8qXG4gICAgICogU2V0IHJlbGVhc2UgdmVyc2lvbiBvZiBhcHBsaWNhdGlvblxuICAgICAqXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IHJlbGVhc2UgVHlwaWNhbGx5IHNvbWV0aGluZyBsaWtlIGEgZ2l0IFNIQSB0byBpZGVudGlmeSB2ZXJzaW9uXG4gICAgICogQHJldHVybiB7UmF2ZW59XG4gICAgICovXG4gIHNldFJlbGVhc2U6IGZ1bmN0aW9uKHJlbGVhc2UpIHtcbiAgICB0aGlzLl9nbG9iYWxPcHRpb25zLnJlbGVhc2UgPSByZWxlYXNlO1xuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH0sXG5cbiAgLypcbiAgICAgKiBTZXQgdGhlIGRhdGFDYWxsYmFjayBvcHRpb25cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IGNhbGxiYWNrIFRoZSBjYWxsYmFjayB0byBydW4gd2hpY2ggYWxsb3dzIHRoZVxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEgYmxvYiB0byBiZSBtdXRhdGVkIGJlZm9yZSBzZW5kaW5nXG4gICAgICogQHJldHVybiB7UmF2ZW59XG4gICAgICovXG4gIHNldERhdGFDYWxsYmFjazogZnVuY3Rpb24oY2FsbGJhY2spIHtcbiAgICB2YXIgb3JpZ2luYWwgPSB0aGlzLl9nbG9iYWxPcHRpb25zLmRhdGFDYWxsYmFjaztcbiAgICB0aGlzLl9nbG9iYWxPcHRpb25zLmRhdGFDYWxsYmFjayA9IGtlZXBPcmlnaW5hbENhbGxiYWNrKG9yaWdpbmFsLCBjYWxsYmFjayk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH0sXG5cbiAgLypcbiAgICAgKiBTZXQgdGhlIGJyZWFkY3J1bWJDYWxsYmFjayBvcHRpb25cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IGNhbGxiYWNrIFRoZSBjYWxsYmFjayB0byBydW4gd2hpY2ggYWxsb3dzIGZpbHRlcmluZ1xuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9yIG11dGF0aW5nIGJyZWFkY3J1bWJzXG4gICAgICogQHJldHVybiB7UmF2ZW59XG4gICAgICovXG4gIHNldEJyZWFkY3J1bWJDYWxsYmFjazogZnVuY3Rpb24oY2FsbGJhY2spIHtcbiAgICB2YXIgb3JpZ2luYWwgPSB0aGlzLl9nbG9iYWxPcHRpb25zLmJyZWFkY3J1bWJDYWxsYmFjaztcbiAgICB0aGlzLl9nbG9iYWxPcHRpb25zLmJyZWFkY3J1bWJDYWxsYmFjayA9IGtlZXBPcmlnaW5hbENhbGxiYWNrKG9yaWdpbmFsLCBjYWxsYmFjayk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH0sXG5cbiAgLypcbiAgICAgKiBTZXQgdGhlIHNob3VsZFNlbmRDYWxsYmFjayBvcHRpb25cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IGNhbGxiYWNrIFRoZSBjYWxsYmFjayB0byBydW4gd2hpY2ggYWxsb3dzXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgaW50cm9zcGVjdGluZyB0aGUgYmxvYiBiZWZvcmUgc2VuZGluZ1xuICAgICAqIEByZXR1cm4ge1JhdmVufVxuICAgICAqL1xuICBzZXRTaG91bGRTZW5kQ2FsbGJhY2s6IGZ1bmN0aW9uKGNhbGxiYWNrKSB7XG4gICAgdmFyIG9yaWdpbmFsID0gdGhpcy5fZ2xvYmFsT3B0aW9ucy5zaG91bGRTZW5kQ2FsbGJhY2s7XG4gICAgdGhpcy5fZ2xvYmFsT3B0aW9ucy5zaG91bGRTZW5kQ2FsbGJhY2sgPSBrZWVwT3JpZ2luYWxDYWxsYmFjayhvcmlnaW5hbCwgY2FsbGJhY2spO1xuICAgIHJldHVybiB0aGlzO1xuICB9LFxuXG4gIC8qKlxuICAgKiBPdmVycmlkZSB0aGUgZGVmYXVsdCBIVFRQIHRyYW5zcG9ydCBtZWNoYW5pc20gdGhhdCB0cmFuc21pdHMgZGF0YVxuICAgKiB0byB0aGUgU2VudHJ5IHNlcnZlci5cbiAgICpcbiAgICogQHBhcmFtIHtmdW5jdGlvbn0gdHJhbnNwb3J0IEZ1bmN0aW9uIGludm9rZWQgaW5zdGVhZCBvZiB0aGUgZGVmYXVsdFxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYG1ha2VSZXF1ZXN0YCBoYW5kbGVyLlxuICAgKlxuICAgKiBAcmV0dXJuIHtSYXZlbn1cbiAgICovXG4gIHNldFRyYW5zcG9ydDogZnVuY3Rpb24odHJhbnNwb3J0KSB7XG4gICAgdGhpcy5fZ2xvYmFsT3B0aW9ucy50cmFuc3BvcnQgPSB0cmFuc3BvcnQ7XG5cbiAgICByZXR1cm4gdGhpcztcbiAgfSxcblxuICAvKlxuICAgICAqIEdldCB0aGUgbGF0ZXN0IHJhdyBleGNlcHRpb24gdGhhdCB3YXMgY2FwdHVyZWQgYnkgUmF2ZW4uXG4gICAgICpcbiAgICAgKiBAcmV0dXJuIHtlcnJvcn1cbiAgICAgKi9cbiAgbGFzdEV4Y2VwdGlvbjogZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xhc3RDYXB0dXJlZEV4Y2VwdGlvbjtcbiAgfSxcblxuICAvKlxuICAgICAqIEdldCB0aGUgbGFzdCBldmVudCBpZFxuICAgICAqXG4gICAgICogQHJldHVybiB7c3RyaW5nfVxuICAgICAqL1xuICBsYXN0RXZlbnRJZDogZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xhc3RFdmVudElkO1xuICB9LFxuXG4gIC8qXG4gICAgICogRGV0ZXJtaW5lIGlmIFJhdmVuIGlzIHNldHVwIGFuZCByZWFkeSB0byBnby5cbiAgICAgKlxuICAgICAqIEByZXR1cm4ge2Jvb2xlYW59XG4gICAgICovXG4gIGlzU2V0dXA6IGZ1bmN0aW9uKCkge1xuICAgIGlmICghdGhpcy5faGFzSlNPTikgcmV0dXJuIGZhbHNlOyAvLyBuZWVkcyBKU09OIHN1cHBvcnRcbiAgICBpZiAoIXRoaXMuX2dsb2JhbFNlcnZlcikge1xuICAgICAgaWYgKCF0aGlzLnJhdmVuTm90Q29uZmlndXJlZEVycm9yKSB7XG4gICAgICAgIHRoaXMucmF2ZW5Ob3RDb25maWd1cmVkRXJyb3IgPSB0cnVlO1xuICAgICAgICB0aGlzLl9sb2dEZWJ1ZygnZXJyb3InLCAnRXJyb3I6IFJhdmVuIGhhcyBub3QgYmVlbiBjb25maWd1cmVkLicpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSxcblxuICBhZnRlckxvYWQ6IGZ1bmN0aW9uKCkge1xuICAgIC8vIFRPRE86IHJlbW92ZSB3aW5kb3cgZGVwZW5kZW5jZT9cblxuICAgIC8vIEF0dGVtcHQgdG8gaW5pdGlhbGl6ZSBSYXZlbiBvbiBsb2FkXG4gICAgdmFyIFJhdmVuQ29uZmlnID0gX3dpbmRvdy5SYXZlbkNvbmZpZztcbiAgICBpZiAoUmF2ZW5Db25maWcpIHtcbiAgICAgIHRoaXMuY29uZmlnKFJhdmVuQ29uZmlnLmRzbiwgUmF2ZW5Db25maWcuY29uZmlnKS5pbnN0YWxsKCk7XG4gICAgfVxuICB9LFxuXG4gIHNob3dSZXBvcnREaWFsb2c6IGZ1bmN0aW9uKG9wdGlvbnMpIHtcbiAgICBpZiAoXG4gICAgICAhX2RvY3VtZW50IC8vIGRvZXNuJ3Qgd29yayB3aXRob3V0IGEgZG9jdW1lbnQgKFJlYWN0IG5hdGl2ZSlcbiAgICApXG4gICAgICByZXR1cm47XG5cbiAgICBvcHRpb25zID0gb2JqZWN0TWVyZ2UoXG4gICAgICB7XG4gICAgICAgIGV2ZW50SWQ6IHRoaXMubGFzdEV2ZW50SWQoKSxcbiAgICAgICAgZHNuOiB0aGlzLl9kc24sXG4gICAgICAgIHVzZXI6IHRoaXMuX2dsb2JhbENvbnRleHQudXNlciB8fCB7fVxuICAgICAgfSxcbiAgICAgIG9wdGlvbnNcbiAgICApO1xuXG4gICAgaWYgKCFvcHRpb25zLmV2ZW50SWQpIHtcbiAgICAgIHRocm93IG5ldyBSYXZlbkNvbmZpZ0Vycm9yKCdNaXNzaW5nIGV2ZW50SWQnKTtcbiAgICB9XG5cbiAgICBpZiAoIW9wdGlvbnMuZHNuKSB7XG4gICAgICB0aHJvdyBuZXcgUmF2ZW5Db25maWdFcnJvcignTWlzc2luZyBEU04nKTtcbiAgICB9XG5cbiAgICB2YXIgZW5jb2RlID0gZW5jb2RlVVJJQ29tcG9uZW50O1xuICAgIHZhciBlbmNvZGVkT3B0aW9ucyA9IFtdO1xuXG4gICAgZm9yICh2YXIga2V5IGluIG9wdGlvbnMpIHtcbiAgICAgIGlmIChrZXkgPT09ICd1c2VyJykge1xuICAgICAgICB2YXIgdXNlciA9IG9wdGlvbnMudXNlcjtcbiAgICAgICAgaWYgKHVzZXIubmFtZSkgZW5jb2RlZE9wdGlvbnMucHVzaCgnbmFtZT0nICsgZW5jb2RlKHVzZXIubmFtZSkpO1xuICAgICAgICBpZiAodXNlci5lbWFpbCkgZW5jb2RlZE9wdGlvbnMucHVzaCgnZW1haWw9JyArIGVuY29kZSh1c2VyLmVtYWlsKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBlbmNvZGVkT3B0aW9ucy5wdXNoKGVuY29kZShrZXkpICsgJz0nICsgZW5jb2RlKG9wdGlvbnNba2V5XSkpO1xuICAgICAgfVxuICAgIH1cbiAgICB2YXIgZ2xvYmFsU2VydmVyID0gdGhpcy5fZ2V0R2xvYmFsU2VydmVyKHRoaXMuX3BhcnNlRFNOKG9wdGlvbnMuZHNuKSk7XG5cbiAgICB2YXIgc2NyaXB0ID0gX2RvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpO1xuICAgIHNjcmlwdC5hc3luYyA9IHRydWU7XG4gICAgc2NyaXB0LnNyYyA9IGdsb2JhbFNlcnZlciArICcvYXBpL2VtYmVkL2Vycm9yLXBhZ2UvPycgKyBlbmNvZGVkT3B0aW9ucy5qb2luKCcmJyk7XG4gICAgKF9kb2N1bWVudC5oZWFkIHx8IF9kb2N1bWVudC5ib2R5KS5hcHBlbmRDaGlsZChzY3JpcHQpO1xuICB9LFxuXG4gIC8qKioqIFByaXZhdGUgZnVuY3Rpb25zICoqKiovXG4gIF9pZ25vcmVOZXh0T25FcnJvcjogZnVuY3Rpb24oKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIHRoaXMuX2lnbm9yZU9uRXJyb3IgKz0gMTtcbiAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgLy8gb25lcnJvciBzaG91bGQgdHJpZ2dlciBiZWZvcmUgc2V0VGltZW91dFxuICAgICAgc2VsZi5faWdub3JlT25FcnJvciAtPSAxO1xuICAgIH0pO1xuICB9LFxuXG4gIF90cmlnZ2VyRXZlbnQ6IGZ1bmN0aW9uKGV2ZW50VHlwZSwgb3B0aW9ucykge1xuICAgIC8vIE5PVEU6IGBldmVudGAgaXMgYSBuYXRpdmUgYnJvd3NlciB0aGluZywgc28gbGV0J3MgYXZvaWQgY29uZmxpY3Rpbmcgd2lodCBpdFxuICAgIHZhciBldnQsIGtleTtcblxuICAgIGlmICghdGhpcy5faGFzRG9jdW1lbnQpIHJldHVybjtcblxuICAgIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuXG4gICAgZXZlbnRUeXBlID0gJ3JhdmVuJyArIGV2ZW50VHlwZS5zdWJzdHIoMCwgMSkudG9VcHBlckNhc2UoKSArIGV2ZW50VHlwZS5zdWJzdHIoMSk7XG5cbiAgICBpZiAoX2RvY3VtZW50LmNyZWF0ZUV2ZW50KSB7XG4gICAgICBldnQgPSBfZG9jdW1lbnQuY3JlYXRlRXZlbnQoJ0hUTUxFdmVudHMnKTtcbiAgICAgIGV2dC5pbml0RXZlbnQoZXZlbnRUeXBlLCB0cnVlLCB0cnVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZXZ0ID0gX2RvY3VtZW50LmNyZWF0ZUV2ZW50T2JqZWN0KCk7XG4gICAgICBldnQuZXZlbnRUeXBlID0gZXZlbnRUeXBlO1xuICAgIH1cblxuICAgIGZvciAoa2V5IGluIG9wdGlvbnMpXG4gICAgICBpZiAoaGFzS2V5KG9wdGlvbnMsIGtleSkpIHtcbiAgICAgICAgZXZ0W2tleV0gPSBvcHRpb25zW2tleV07XG4gICAgICB9XG5cbiAgICBpZiAoX2RvY3VtZW50LmNyZWF0ZUV2ZW50KSB7XG4gICAgICAvLyBJRTkgaWYgc3RhbmRhcmRzXG4gICAgICBfZG9jdW1lbnQuZGlzcGF0Y2hFdmVudChldnQpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBJRTggcmVnYXJkbGVzcyBvZiBRdWlya3Mgb3IgU3RhbmRhcmRzXG4gICAgICAvLyBJRTkgaWYgcXVpcmtzXG4gICAgICB0cnkge1xuICAgICAgICBfZG9jdW1lbnQuZmlyZUV2ZW50KCdvbicgKyBldnQuZXZlbnRUeXBlLnRvTG93ZXJDYXNlKCksIGV2dCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIERvIG5vdGhpbmdcbiAgICAgIH1cbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIFdyYXBzIGFkZEV2ZW50TGlzdGVuZXIgdG8gY2FwdHVyZSBVSSBicmVhZGNydW1ic1xuICAgKiBAcGFyYW0gZXZ0TmFtZSB0aGUgZXZlbnQgbmFtZSAoZS5nLiBcImNsaWNrXCIpXG4gICAqIEByZXR1cm5zIHtGdW5jdGlvbn1cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9icmVhZGNydW1iRXZlbnRIYW5kbGVyOiBmdW5jdGlvbihldnROYW1lKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIHJldHVybiBmdW5jdGlvbihldnQpIHtcbiAgICAgIC8vIHJlc2V0IGtleXByZXNzIHRpbWVvdXQ7IGUuZy4gdHJpZ2dlcmluZyBhICdjbGljaycgYWZ0ZXJcbiAgICAgIC8vIGEgJ2tleXByZXNzJyB3aWxsIHJlc2V0IHRoZSBrZXlwcmVzcyBkZWJvdW5jZSBzbyB0aGF0IGEgbmV3XG4gICAgICAvLyBzZXQgb2Yga2V5cHJlc3NlcyBjYW4gYmUgcmVjb3JkZWRcbiAgICAgIHNlbGYuX2tleXByZXNzVGltZW91dCA9IG51bGw7XG5cbiAgICAgIC8vIEl0J3MgcG9zc2libGUgdGhpcyBoYW5kbGVyIG1pZ2h0IHRyaWdnZXIgbXVsdGlwbGUgdGltZXMgZm9yIHRoZSBzYW1lXG4gICAgICAvLyBldmVudCAoZS5nLiBldmVudCBwcm9wYWdhdGlvbiB0aHJvdWdoIG5vZGUgYW5jZXN0b3JzKS4gSWdub3JlIGlmIHdlJ3ZlXG4gICAgICAvLyBhbHJlYWR5IGNhcHR1cmVkIHRoZSBldmVudC5cbiAgICAgIGlmIChzZWxmLl9sYXN0Q2FwdHVyZWRFdmVudCA9PT0gZXZ0KSByZXR1cm47XG5cbiAgICAgIHNlbGYuX2xhc3RDYXB0dXJlZEV2ZW50ID0gZXZ0O1xuXG4gICAgICAvLyB0cnkvY2F0Y2ggYm90aDpcbiAgICAgIC8vIC0gYWNjZXNzaW5nIGV2dC50YXJnZXQgKHNlZSBnZXRzZW50cnkvcmF2ZW4tanMjODM4LCAjNzY4KVxuICAgICAgLy8gLSBgaHRtbFRyZWVBc1N0cmluZ2AgYmVjYXVzZSBpdCdzIGNvbXBsZXgsIGFuZCBqdXN0IGFjY2Vzc2luZyB0aGUgRE9NIGluY29ycmVjdGx5XG4gICAgICAvLyAgIGNhbiB0aHJvdyBhbiBleGNlcHRpb24gaW4gc29tZSBjaXJjdW1zdGFuY2VzLlxuICAgICAgdmFyIHRhcmdldDtcbiAgICAgIHRyeSB7XG4gICAgICAgIHRhcmdldCA9IGh0bWxUcmVlQXNTdHJpbmcoZXZ0LnRhcmdldCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHRhcmdldCA9ICc8dW5rbm93bj4nO1xuICAgICAgfVxuXG4gICAgICBzZWxmLmNhcHR1cmVCcmVhZGNydW1iKHtcbiAgICAgICAgY2F0ZWdvcnk6ICd1aS4nICsgZXZ0TmFtZSwgLy8gZS5nLiB1aS5jbGljaywgdWkuaW5wdXRcbiAgICAgICAgbWVzc2FnZTogdGFyZ2V0XG4gICAgICB9KTtcbiAgICB9O1xuICB9LFxuXG4gIC8qKlxuICAgKiBXcmFwcyBhZGRFdmVudExpc3RlbmVyIHRvIGNhcHR1cmUga2V5cHJlc3MgVUkgZXZlbnRzXG4gICAqIEByZXR1cm5zIHtGdW5jdGlvbn1cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9rZXlwcmVzc0V2ZW50SGFuZGxlcjogZnVuY3Rpb24oKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzLFxuICAgICAgZGVib3VuY2VEdXJhdGlvbiA9IDEwMDA7IC8vIG1pbGxpc2Vjb25kc1xuXG4gICAgLy8gVE9ETzogaWYgc29tZWhvdyB1c2VyIHN3aXRjaGVzIGtleXByZXNzIHRhcmdldCBiZWZvcmVcbiAgICAvLyAgICAgICBkZWJvdW5jZSB0aW1lb3V0IGlzIHRyaWdnZXJlZCwgd2Ugd2lsbCBvbmx5IGNhcHR1cmVcbiAgICAvLyAgICAgICBhIHNpbmdsZSBicmVhZGNydW1iIGZyb20gdGhlIEZJUlNUIHRhcmdldCAoYWNjZXB0YWJsZT8pXG4gICAgcmV0dXJuIGZ1bmN0aW9uKGV2dCkge1xuICAgICAgdmFyIHRhcmdldDtcbiAgICAgIHRyeSB7XG4gICAgICAgIHRhcmdldCA9IGV2dC50YXJnZXQ7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIGp1c3QgYWNjZXNzaW5nIGV2ZW50IHByb3BlcnRpZXMgY2FuIHRocm93IGFuIGV4Y2VwdGlvbiBpbiBzb21lIHJhcmUgY2lyY3Vtc3RhbmNlc1xuICAgICAgICAvLyBzZWU6IGh0dHBzOi8vZ2l0aHViLmNvbS9nZXRzZW50cnkvcmF2ZW4tanMvaXNzdWVzLzgzOFxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB2YXIgdGFnTmFtZSA9IHRhcmdldCAmJiB0YXJnZXQudGFnTmFtZTtcblxuICAgICAgLy8gb25seSBjb25zaWRlciBrZXlwcmVzcyBldmVudHMgb24gYWN0dWFsIGlucHV0IGVsZW1lbnRzXG4gICAgICAvLyB0aGlzIHdpbGwgZGlzcmVnYXJkIGtleXByZXNzZXMgdGFyZ2V0aW5nIGJvZHkgKGUuZy4gdGFiYmluZ1xuICAgICAgLy8gdGhyb3VnaCBlbGVtZW50cywgaG90a2V5cywgZXRjKVxuICAgICAgaWYgKFxuICAgICAgICAhdGFnTmFtZSB8fFxuICAgICAgICAodGFnTmFtZSAhPT0gJ0lOUFVUJyAmJiB0YWdOYW1lICE9PSAnVEVYVEFSRUEnICYmICF0YXJnZXQuaXNDb250ZW50RWRpdGFibGUpXG4gICAgICApXG4gICAgICAgIHJldHVybjtcblxuICAgICAgLy8gcmVjb3JkIGZpcnN0IGtleXByZXNzIGluIGEgc2VyaWVzLCBidXQgaWdub3JlIHN1YnNlcXVlbnRcbiAgICAgIC8vIGtleXByZXNzZXMgdW50aWwgZGVib3VuY2UgY2xlYXJzXG4gICAgICB2YXIgdGltZW91dCA9IHNlbGYuX2tleXByZXNzVGltZW91dDtcbiAgICAgIGlmICghdGltZW91dCkge1xuICAgICAgICBzZWxmLl9icmVhZGNydW1iRXZlbnRIYW5kbGVyKCdpbnB1dCcpKGV2dCk7XG4gICAgICB9XG4gICAgICBjbGVhclRpbWVvdXQodGltZW91dCk7XG4gICAgICBzZWxmLl9rZXlwcmVzc1RpbWVvdXQgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICBzZWxmLl9rZXlwcmVzc1RpbWVvdXQgPSBudWxsO1xuICAgICAgfSwgZGVib3VuY2VEdXJhdGlvbik7XG4gICAgfTtcbiAgfSxcblxuICAvKipcbiAgICogQ2FwdHVyZXMgYSBicmVhZGNydW1iIG9mIHR5cGUgXCJuYXZpZ2F0aW9uXCIsIG5vcm1hbGl6aW5nIGlucHV0IFVSTHNcbiAgICogQHBhcmFtIHRvIHRoZSBvcmlnaW5hdGluZyBVUkxcbiAgICogQHBhcmFtIGZyb20gdGhlIHRhcmdldCBVUkxcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9jYXB0dXJlVXJsQ2hhbmdlOiBmdW5jdGlvbihmcm9tLCB0bykge1xuICAgIHZhciBwYXJzZWRMb2MgPSBwYXJzZVVybCh0aGlzLl9sb2NhdGlvbi5ocmVmKTtcbiAgICB2YXIgcGFyc2VkVG8gPSBwYXJzZVVybCh0byk7XG4gICAgdmFyIHBhcnNlZEZyb20gPSBwYXJzZVVybChmcm9tKTtcblxuICAgIC8vIGJlY2F1c2Ugb25wb3BzdGF0ZSBvbmx5IHRlbGxzIHlvdSB0aGUgXCJuZXdcIiAodG8pIHZhbHVlIG9mIGxvY2F0aW9uLmhyZWYsIGFuZFxuICAgIC8vIG5vdCB0aGUgcHJldmlvdXMgKGZyb20pIHZhbHVlLCB3ZSBuZWVkIHRvIHRyYWNrIHRoZSB2YWx1ZSBvZiB0aGUgY3VycmVudCBVUkxcbiAgICAvLyBzdGF0ZSBvdXJzZWx2ZXNcbiAgICB0aGlzLl9sYXN0SHJlZiA9IHRvO1xuXG4gICAgLy8gVXNlIG9ubHkgdGhlIHBhdGggY29tcG9uZW50IG9mIHRoZSBVUkwgaWYgdGhlIFVSTCBtYXRjaGVzIHRoZSBjdXJyZW50XG4gICAgLy8gZG9jdW1lbnQgKGFsbW9zdCBhbGwgdGhlIHRpbWUgd2hlbiB1c2luZyBwdXNoU3RhdGUpXG4gICAgaWYgKHBhcnNlZExvYy5wcm90b2NvbCA9PT0gcGFyc2VkVG8ucHJvdG9jb2wgJiYgcGFyc2VkTG9jLmhvc3QgPT09IHBhcnNlZFRvLmhvc3QpXG4gICAgICB0byA9IHBhcnNlZFRvLnJlbGF0aXZlO1xuICAgIGlmIChwYXJzZWRMb2MucHJvdG9jb2wgPT09IHBhcnNlZEZyb20ucHJvdG9jb2wgJiYgcGFyc2VkTG9jLmhvc3QgPT09IHBhcnNlZEZyb20uaG9zdClcbiAgICAgIGZyb20gPSBwYXJzZWRGcm9tLnJlbGF0aXZlO1xuXG4gICAgdGhpcy5jYXB0dXJlQnJlYWRjcnVtYih7XG4gICAgICBjYXRlZ29yeTogJ25hdmlnYXRpb24nLFxuICAgICAgZGF0YToge1xuICAgICAgICB0bzogdG8sXG4gICAgICAgIGZyb206IGZyb21cbiAgICAgIH1cbiAgICB9KTtcbiAgfSxcblxuICBfcGF0Y2hGdW5jdGlvblRvU3RyaW5nOiBmdW5jdGlvbigpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgc2VsZi5fb3JpZ2luYWxGdW5jdGlvblRvU3RyaW5nID0gRnVuY3Rpb24ucHJvdG90eXBlLnRvU3RyaW5nO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1leHRlbmQtbmF0aXZlXG4gICAgRnVuY3Rpb24ucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24oKSB7XG4gICAgICBpZiAodHlwZW9mIHRoaXMgPT09ICdmdW5jdGlvbicgJiYgdGhpcy5fX3JhdmVuX18pIHtcbiAgICAgICAgcmV0dXJuIHNlbGYuX29yaWdpbmFsRnVuY3Rpb25Ub1N0cmluZy5hcHBseSh0aGlzLl9fb3JpZ19fLCBhcmd1bWVudHMpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHNlbGYuX29yaWdpbmFsRnVuY3Rpb25Ub1N0cmluZy5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgIH07XG4gIH0sXG5cbiAgX3VucGF0Y2hGdW5jdGlvblRvU3RyaW5nOiBmdW5jdGlvbigpIHtcbiAgICBpZiAodGhpcy5fb3JpZ2luYWxGdW5jdGlvblRvU3RyaW5nKSB7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tZXh0ZW5kLW5hdGl2ZVxuICAgICAgRnVuY3Rpb24ucHJvdG90eXBlLnRvU3RyaW5nID0gdGhpcy5fb3JpZ2luYWxGdW5jdGlvblRvU3RyaW5nO1xuICAgIH1cbiAgfSxcblxuICAvKipcbiAgICogV3JhcCB0aW1lciBmdW5jdGlvbnMgYW5kIGV2ZW50IHRhcmdldHMgdG8gY2F0Y2ggZXJyb3JzIGFuZCBwcm92aWRlXG4gICAqIGJldHRlciBtZXRhZGF0YS5cbiAgICovXG4gIF9pbnN0cnVtZW50VHJ5Q2F0Y2g6IGZ1bmN0aW9uKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgIHZhciB3cmFwcGVkQnVpbHRJbnMgPSBzZWxmLl93cmFwcGVkQnVpbHRJbnM7XG5cbiAgICBmdW5jdGlvbiB3cmFwVGltZUZuKG9yaWcpIHtcbiAgICAgIHJldHVybiBmdW5jdGlvbihmbiwgdCkge1xuICAgICAgICAvLyBwcmVzZXJ2ZSBhcml0eVxuICAgICAgICAvLyBNYWtlIGEgY29weSBvZiB0aGUgYXJndW1lbnRzIHRvIHByZXZlbnQgZGVvcHRpbWl6YXRpb25cbiAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL3BldGthYW50b25vdi9ibHVlYmlyZC93aWtpL09wdGltaXphdGlvbi1raWxsZXJzIzMyLWxlYWtpbmctYXJndW1lbnRzXG4gICAgICAgIHZhciBhcmdzID0gbmV3IEFycmF5KGFyZ3VtZW50cy5sZW5ndGgpO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFyZ3MubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICBhcmdzW2ldID0gYXJndW1lbnRzW2ldO1xuICAgICAgICB9XG4gICAgICAgIHZhciBvcmlnaW5hbENhbGxiYWNrID0gYXJnc1swXTtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb24ob3JpZ2luYWxDYWxsYmFjaykpIHtcbiAgICAgICAgICBhcmdzWzBdID0gc2VsZi53cmFwKFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBtZWNoYW5pc206IHtcbiAgICAgICAgICAgICAgICB0eXBlOiAnaW5zdHJ1bWVudCcsXG4gICAgICAgICAgICAgICAgZGF0YToge2Z1bmN0aW9uOiBvcmlnLm5hbWUgfHwgJzxhbm9ueW1vdXM+J31cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG9yaWdpbmFsQ2FsbGJhY2tcbiAgICAgICAgICApO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gSUUgPCA5IGRvZXNuJ3Qgc3VwcG9ydCAuY2FsbC8uYXBwbHkgb24gc2V0SW50ZXJ2YWwvc2V0VGltZW91dCwgYnV0IGl0XG4gICAgICAgIC8vIGFsc28gc3VwcG9ydHMgb25seSB0d28gYXJndW1lbnRzIGFuZCBkb2Vzbid0IGNhcmUgd2hhdCB0aGlzIGlzLCBzbyB3ZVxuICAgICAgICAvLyBjYW4ganVzdCBjYWxsIHRoZSBvcmlnaW5hbCBmdW5jdGlvbiBkaXJlY3RseS5cbiAgICAgICAgaWYgKG9yaWcuYXBwbHkpIHtcbiAgICAgICAgICByZXR1cm4gb3JpZy5hcHBseSh0aGlzLCBhcmdzKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gb3JpZyhhcmdzWzBdLCBhcmdzWzFdKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9XG5cbiAgICB2YXIgYXV0b0JyZWFkY3J1bWJzID0gdGhpcy5fZ2xvYmFsT3B0aW9ucy5hdXRvQnJlYWRjcnVtYnM7XG5cbiAgICBmdW5jdGlvbiB3cmFwRXZlbnRUYXJnZXQoZ2xvYmFsKSB7XG4gICAgICB2YXIgcHJvdG8gPSBfd2luZG93W2dsb2JhbF0gJiYgX3dpbmRvd1tnbG9iYWxdLnByb3RvdHlwZTtcbiAgICAgIGlmIChwcm90byAmJiBwcm90by5oYXNPd25Qcm9wZXJ0eSAmJiBwcm90by5oYXNPd25Qcm9wZXJ0eSgnYWRkRXZlbnRMaXN0ZW5lcicpKSB7XG4gICAgICAgIGZpbGwoXG4gICAgICAgICAgcHJvdG8sXG4gICAgICAgICAgJ2FkZEV2ZW50TGlzdGVuZXInLFxuICAgICAgICAgIGZ1bmN0aW9uKG9yaWcpIHtcbiAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbihldnROYW1lLCBmbiwgY2FwdHVyZSwgc2VjdXJlKSB7XG4gICAgICAgICAgICAgIC8vIHByZXNlcnZlIGFyaXR5XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgaWYgKGZuICYmIGZuLmhhbmRsZUV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICBmbi5oYW5kbGVFdmVudCA9IHNlbGYud3JhcChcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgIG1lY2hhbmlzbToge1xuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2luc3RydW1lbnQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ6IGdsb2JhbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb246ICdoYW5kbGVFdmVudCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZXI6IChmbiAmJiBmbi5uYW1lKSB8fCAnPGFub255bW91cz4nXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBmbi5oYW5kbGVFdmVudFxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgIC8vIGNhbiBzb21ldGltZXMgZ2V0ICdQZXJtaXNzaW9uIGRlbmllZCB0byBhY2Nlc3MgcHJvcGVydHkgXCJoYW5kbGUgRXZlbnQnXG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAvLyBNb3JlIGJyZWFkY3J1bWIgRE9NIGNhcHR1cmUgLi4uIGRvbmUgaGVyZSBhbmQgbm90IGluIGBfaW5zdHJ1bWVudEJyZWFkY3J1bWJzYFxuICAgICAgICAgICAgICAvLyBzbyB0aGF0IHdlIGRvbid0IGhhdmUgbW9yZSB0aGFuIG9uZSB3cmFwcGVyIGZ1bmN0aW9uXG4gICAgICAgICAgICAgIHZhciBiZWZvcmUsIGNsaWNrSGFuZGxlciwga2V5cHJlc3NIYW5kbGVyO1xuXG4gICAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgICBhdXRvQnJlYWRjcnVtYnMgJiZcbiAgICAgICAgICAgICAgICBhdXRvQnJlYWRjcnVtYnMuZG9tICYmXG4gICAgICAgICAgICAgICAgKGdsb2JhbCA9PT0gJ0V2ZW50VGFyZ2V0JyB8fCBnbG9iYWwgPT09ICdOb2RlJylcbiAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgLy8gTk9URTogZ2VuZXJhdGluZyBtdWx0aXBsZSBoYW5kbGVycyBwZXIgYWRkRXZlbnRMaXN0ZW5lciBpbnZvY2F0aW9uLCBzaG91bGRcbiAgICAgICAgICAgICAgICAvLyAgICAgICByZXZpc2l0IGFuZCB2ZXJpZnkgd2UgY2FuIGp1c3QgdXNlIG9uZSAoYWxtb3N0IGNlcnRhaW5seSlcbiAgICAgICAgICAgICAgICBjbGlja0hhbmRsZXIgPSBzZWxmLl9icmVhZGNydW1iRXZlbnRIYW5kbGVyKCdjbGljaycpO1xuICAgICAgICAgICAgICAgIGtleXByZXNzSGFuZGxlciA9IHNlbGYuX2tleXByZXNzRXZlbnRIYW5kbGVyKCk7XG4gICAgICAgICAgICAgICAgYmVmb3JlID0gZnVuY3Rpb24oZXZ0KSB7XG4gICAgICAgICAgICAgICAgICAvLyBuZWVkIHRvIGludGVyY2VwdCBldmVyeSBET00gZXZlbnQgaW4gYGJlZm9yZWAgYXJndW1lbnQsIGluIGNhc2UgdGhhdFxuICAgICAgICAgICAgICAgICAgLy8gc2FtZSB3cmFwcGVkIG1ldGhvZCBpcyByZS11c2VkIGZvciBkaWZmZXJlbnQgZXZlbnRzIChlLmcuIG1vdXNlbW92ZSBUSEVOIGNsaWNrKVxuICAgICAgICAgICAgICAgICAgLy8gc2VlICM3MjRcbiAgICAgICAgICAgICAgICAgIGlmICghZXZ0KSByZXR1cm47XG5cbiAgICAgICAgICAgICAgICAgIHZhciBldmVudFR5cGU7XG4gICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBldmVudFR5cGUgPSBldnQudHlwZTtcbiAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8ganVzdCBhY2Nlc3NpbmcgZXZlbnQgcHJvcGVydGllcyBjYW4gdGhyb3cgYW4gZXhjZXB0aW9uIGluIHNvbWUgcmFyZSBjaXJjdW1zdGFuY2VzXG4gICAgICAgICAgICAgICAgICAgIC8vIHNlZTogaHR0cHM6Ly9naXRodWIuY29tL2dldHNlbnRyeS9yYXZlbi1qcy9pc3N1ZXMvODM4XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGlmIChldmVudFR5cGUgPT09ICdjbGljaycpIHJldHVybiBjbGlja0hhbmRsZXIoZXZ0KTtcbiAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGV2ZW50VHlwZSA9PT0gJ2tleXByZXNzJykgcmV0dXJuIGtleXByZXNzSGFuZGxlcihldnQpO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIG9yaWcuY2FsbChcbiAgICAgICAgICAgICAgICB0aGlzLFxuICAgICAgICAgICAgICAgIGV2dE5hbWUsXG4gICAgICAgICAgICAgICAgc2VsZi53cmFwKFxuICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBtZWNoYW5pc206IHtcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnaW5zdHJ1bWVudCcsXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0OiBnbG9iYWwsXG4gICAgICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbjogJ2FkZEV2ZW50TGlzdGVuZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlcjogKGZuICYmIGZuLm5hbWUpIHx8ICc8YW5vbnltb3VzPidcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICBmbixcbiAgICAgICAgICAgICAgICAgIGJlZm9yZVxuICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgY2FwdHVyZSxcbiAgICAgICAgICAgICAgICBzZWN1cmVcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSxcbiAgICAgICAgICB3cmFwcGVkQnVpbHRJbnNcbiAgICAgICAgKTtcbiAgICAgICAgZmlsbChcbiAgICAgICAgICBwcm90byxcbiAgICAgICAgICAncmVtb3ZlRXZlbnRMaXN0ZW5lcicsXG4gICAgICAgICAgZnVuY3Rpb24ob3JpZykge1xuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKGV2dCwgZm4sIGNhcHR1cmUsIHNlY3VyZSkge1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGZuID0gZm4gJiYgKGZuLl9fcmF2ZW5fd3JhcHBlcl9fID8gZm4uX19yYXZlbl93cmFwcGVyX18gOiBmbik7XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAvLyBpZ25vcmUsIGFjY2Vzc2luZyBfX3JhdmVuX3dyYXBwZXJfXyB3aWxsIHRocm93IGluIHNvbWUgU2VsZW5pdW0gZW52aXJvbm1lbnRzXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIG9yaWcuY2FsbCh0aGlzLCBldnQsIGZuLCBjYXB0dXJlLCBzZWN1cmUpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIHdyYXBwZWRCdWlsdEluc1xuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cblxuICAgIGZpbGwoX3dpbmRvdywgJ3NldFRpbWVvdXQnLCB3cmFwVGltZUZuLCB3cmFwcGVkQnVpbHRJbnMpO1xuICAgIGZpbGwoX3dpbmRvdywgJ3NldEludGVydmFsJywgd3JhcFRpbWVGbiwgd3JhcHBlZEJ1aWx0SW5zKTtcbiAgICBpZiAoX3dpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUpIHtcbiAgICAgIGZpbGwoXG4gICAgICAgIF93aW5kb3csXG4gICAgICAgICdyZXF1ZXN0QW5pbWF0aW9uRnJhbWUnLFxuICAgICAgICBmdW5jdGlvbihvcmlnKSB7XG4gICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uKGNiKSB7XG4gICAgICAgICAgICByZXR1cm4gb3JpZyhcbiAgICAgICAgICAgICAgc2VsZi53cmFwKFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIG1lY2hhbmlzbToge1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiAnaW5zdHJ1bWVudCcsXG4gICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbjogJ3JlcXVlc3RBbmltYXRpb25GcmFtZScsXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlcjogKG9yaWcgJiYgb3JpZy5uYW1lKSB8fCAnPGFub255bW91cz4nXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGNiXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfTtcbiAgICAgICAgfSxcbiAgICAgICAgd3JhcHBlZEJ1aWx0SW5zXG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIGV2ZW50IHRhcmdldHMgYm9ycm93ZWQgZnJvbSBidWdzbmFnLWpzOlxuICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9idWdzbmFnL2J1Z3NuYWctanMvYmxvYi9tYXN0ZXIvc3JjL2J1Z3NuYWcuanMjTDY2NlxuICAgIHZhciBldmVudFRhcmdldHMgPSBbXG4gICAgICAnRXZlbnRUYXJnZXQnLFxuICAgICAgJ1dpbmRvdycsXG4gICAgICAnTm9kZScsXG4gICAgICAnQXBwbGljYXRpb25DYWNoZScsXG4gICAgICAnQXVkaW9UcmFja0xpc3QnLFxuICAgICAgJ0NoYW5uZWxNZXJnZXJOb2RlJyxcbiAgICAgICdDcnlwdG9PcGVyYXRpb24nLFxuICAgICAgJ0V2ZW50U291cmNlJyxcbiAgICAgICdGaWxlUmVhZGVyJyxcbiAgICAgICdIVE1MVW5rbm93bkVsZW1lbnQnLFxuICAgICAgJ0lEQkRhdGFiYXNlJyxcbiAgICAgICdJREJSZXF1ZXN0JyxcbiAgICAgICdJREJUcmFuc2FjdGlvbicsXG4gICAgICAnS2V5T3BlcmF0aW9uJyxcbiAgICAgICdNZWRpYUNvbnRyb2xsZXInLFxuICAgICAgJ01lc3NhZ2VQb3J0JyxcbiAgICAgICdNb2RhbFdpbmRvdycsXG4gICAgICAnTm90aWZpY2F0aW9uJyxcbiAgICAgICdTVkdFbGVtZW50SW5zdGFuY2UnLFxuICAgICAgJ1NjcmVlbicsXG4gICAgICAnVGV4dFRyYWNrJyxcbiAgICAgICdUZXh0VHJhY2tDdWUnLFxuICAgICAgJ1RleHRUcmFja0xpc3QnLFxuICAgICAgJ1dlYlNvY2tldCcsXG4gICAgICAnV2ViU29ja2V0V29ya2VyJyxcbiAgICAgICdXb3JrZXInLFxuICAgICAgJ1hNTEh0dHBSZXF1ZXN0JyxcbiAgICAgICdYTUxIdHRwUmVxdWVzdEV2ZW50VGFyZ2V0JyxcbiAgICAgICdYTUxIdHRwUmVxdWVzdFVwbG9hZCdcbiAgICBdO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZXZlbnRUYXJnZXRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB3cmFwRXZlbnRUYXJnZXQoZXZlbnRUYXJnZXRzW2ldKTtcbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIEluc3RydW1lbnQgYnJvd3NlciBidWlsdC1pbnMgdy8gYnJlYWRjcnVtYiBjYXB0dXJpbmdcbiAgICogIC0gWE1MSHR0cFJlcXVlc3RzXG4gICAqICAtIERPTSBpbnRlcmFjdGlvbnMgKGNsaWNrL3R5cGluZylcbiAgICogIC0gd2luZG93LmxvY2F0aW9uIGNoYW5nZXNcbiAgICogIC0gY29uc29sZVxuICAgKlxuICAgKiBDYW4gYmUgZGlzYWJsZWQgb3IgaW5kaXZpZHVhbGx5IGNvbmZpZ3VyZWQgdmlhIHRoZSBgYXV0b0JyZWFkY3J1bWJzYCBjb25maWcgb3B0aW9uXG4gICAqL1xuICBfaW5zdHJ1bWVudEJyZWFkY3J1bWJzOiBmdW5jdGlvbigpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdmFyIGF1dG9CcmVhZGNydW1icyA9IHRoaXMuX2dsb2JhbE9wdGlvbnMuYXV0b0JyZWFkY3J1bWJzO1xuXG4gICAgdmFyIHdyYXBwZWRCdWlsdElucyA9IHNlbGYuX3dyYXBwZWRCdWlsdElucztcblxuICAgIGZ1bmN0aW9uIHdyYXBQcm9wKHByb3AsIHhocikge1xuICAgICAgaWYgKHByb3AgaW4geGhyICYmIGlzRnVuY3Rpb24oeGhyW3Byb3BdKSkge1xuICAgICAgICBmaWxsKHhociwgcHJvcCwgZnVuY3Rpb24ob3JpZykge1xuICAgICAgICAgIHJldHVybiBzZWxmLndyYXAoXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG1lY2hhbmlzbToge1xuICAgICAgICAgICAgICAgIHR5cGU6ICdpbnN0cnVtZW50JyxcbiAgICAgICAgICAgICAgICBkYXRhOiB7ZnVuY3Rpb246IHByb3AsIGhhbmRsZXI6IChvcmlnICYmIG9yaWcubmFtZSkgfHwgJzxhbm9ueW1vdXM+J31cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG9yaWdcbiAgICAgICAgICApO1xuICAgICAgICB9KTsgLy8gaW50ZW50aW9uYWxseSBkb24ndCB0cmFjayBmaWxsZWQgbWV0aG9kcyBvbiBYSFIgaW5zdGFuY2VzXG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGF1dG9CcmVhZGNydW1icy54aHIgJiYgJ1hNTEh0dHBSZXF1ZXN0JyBpbiBfd2luZG93KSB7XG4gICAgICB2YXIgeGhycHJvdG8gPSBfd2luZG93LlhNTEh0dHBSZXF1ZXN0ICYmIF93aW5kb3cuWE1MSHR0cFJlcXVlc3QucHJvdG90eXBlO1xuICAgICAgZmlsbChcbiAgICAgICAgeGhycHJvdG8sXG4gICAgICAgICdvcGVuJyxcbiAgICAgICAgZnVuY3Rpb24ob3JpZ09wZW4pIHtcbiAgICAgICAgICByZXR1cm4gZnVuY3Rpb24obWV0aG9kLCB1cmwpIHtcbiAgICAgICAgICAgIC8vIHByZXNlcnZlIGFyaXR5XG5cbiAgICAgICAgICAgIC8vIGlmIFNlbnRyeSBrZXkgYXBwZWFycyBpbiBVUkwsIGRvbid0IGNhcHR1cmVcbiAgICAgICAgICAgIGlmIChpc1N0cmluZyh1cmwpICYmIHVybC5pbmRleE9mKHNlbGYuX2dsb2JhbEtleSkgPT09IC0xKSB7XG4gICAgICAgICAgICAgIHRoaXMuX19yYXZlbl94aHIgPSB7XG4gICAgICAgICAgICAgICAgbWV0aG9kOiBtZXRob2QsXG4gICAgICAgICAgICAgICAgdXJsOiB1cmwsXG4gICAgICAgICAgICAgICAgc3RhdHVzX2NvZGU6IG51bGxcbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIG9yaWdPcGVuLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgICAgfTtcbiAgICAgICAgfSxcbiAgICAgICAgd3JhcHBlZEJ1aWx0SW5zXG4gICAgICApO1xuXG4gICAgICBmaWxsKFxuICAgICAgICB4aHJwcm90byxcbiAgICAgICAgJ3NlbmQnLFxuICAgICAgICBmdW5jdGlvbihvcmlnU2VuZCkge1xuICAgICAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIC8vIHByZXNlcnZlIGFyaXR5XG4gICAgICAgICAgICB2YXIgeGhyID0gdGhpcztcblxuICAgICAgICAgICAgZnVuY3Rpb24gb25yZWFkeXN0YXRlY2hhbmdlSGFuZGxlcigpIHtcbiAgICAgICAgICAgICAgaWYgKHhoci5fX3JhdmVuX3hociAmJiB4aHIucmVhZHlTdGF0ZSA9PT0gNCkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAvLyB0b3VjaGluZyBzdGF0dXNDb2RlIGluIHNvbWUgcGxhdGZvcm1zIHRocm93c1xuICAgICAgICAgICAgICAgICAgLy8gYW4gZXhjZXB0aW9uXG4gICAgICAgICAgICAgICAgICB4aHIuX19yYXZlbl94aHIuc3RhdHVzX2NvZGUgPSB4aHIuc3RhdHVzO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgIC8qIGRvIG5vdGhpbmcgKi9cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBzZWxmLmNhcHR1cmVCcmVhZGNydW1iKHtcbiAgICAgICAgICAgICAgICAgIHR5cGU6ICdodHRwJyxcbiAgICAgICAgICAgICAgICAgIGNhdGVnb3J5OiAneGhyJyxcbiAgICAgICAgICAgICAgICAgIGRhdGE6IHhoci5fX3JhdmVuX3hoclxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHZhciBwcm9wcyA9IFsnb25sb2FkJywgJ29uZXJyb3InLCAnb25wcm9ncmVzcyddO1xuICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBwcm9wcy5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICB3cmFwUHJvcChwcm9wc1tqXSwgeGhyKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKCdvbnJlYWR5c3RhdGVjaGFuZ2UnIGluIHhociAmJiBpc0Z1bmN0aW9uKHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UpKSB7XG4gICAgICAgICAgICAgIGZpbGwoXG4gICAgICAgICAgICAgICAgeGhyLFxuICAgICAgICAgICAgICAgICdvbnJlYWR5c3RhdGVjaGFuZ2UnLFxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uKG9yaWcpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBzZWxmLndyYXAoXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICBtZWNoYW5pc206IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdpbnN0cnVtZW50JyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb246ICdvbnJlYWR5c3RhdGVjaGFuZ2UnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVyOiAob3JpZyAmJiBvcmlnLm5hbWUpIHx8ICc8YW5vbnltb3VzPidcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIG9yaWcsXG4gICAgICAgICAgICAgICAgICAgIG9ucmVhZHlzdGF0ZWNoYW5nZUhhbmRsZXJcbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSAvKiBpbnRlbnRpb25hbGx5IGRvbid0IHRyYWNrIHRoaXMgaW5zdHJ1bWVudGF0aW9uICovXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAvLyBpZiBvbnJlYWR5c3RhdGVjaGFuZ2Ugd2Fzbid0IGFjdHVhbGx5IHNldCBieSB0aGUgcGFnZSBvbiB0aGlzIHhociwgd2VcbiAgICAgICAgICAgICAgLy8gYXJlIGZyZWUgdG8gc2V0IG91ciBvd24gYW5kIGNhcHR1cmUgdGhlIGJyZWFkY3J1bWJcbiAgICAgICAgICAgICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IG9ucmVhZHlzdGF0ZWNoYW5nZUhhbmRsZXI7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiBvcmlnU2VuZC5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICAgIH07XG4gICAgICAgIH0sXG4gICAgICAgIHdyYXBwZWRCdWlsdEluc1xuICAgICAgKTtcbiAgICB9XG5cbiAgICBpZiAoYXV0b0JyZWFkY3J1bWJzLnhociAmJiBzdXBwb3J0c0ZldGNoKCkpIHtcbiAgICAgIGZpbGwoXG4gICAgICAgIF93aW5kb3csXG4gICAgICAgICdmZXRjaCcsXG4gICAgICAgIGZ1bmN0aW9uKG9yaWdGZXRjaCkge1xuICAgICAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIC8vIHByZXNlcnZlIGFyaXR5XG4gICAgICAgICAgICAvLyBNYWtlIGEgY29weSBvZiB0aGUgYXJndW1lbnRzIHRvIHByZXZlbnQgZGVvcHRpbWl6YXRpb25cbiAgICAgICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9wZXRrYWFudG9ub3YvYmx1ZWJpcmQvd2lraS9PcHRpbWl6YXRpb24ta2lsbGVycyMzMi1sZWFraW5nLWFyZ3VtZW50c1xuICAgICAgICAgICAgdmFyIGFyZ3MgPSBuZXcgQXJyYXkoYXJndW1lbnRzLmxlbmd0aCk7XG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFyZ3MubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgICAgYXJnc1tpXSA9IGFyZ3VtZW50c1tpXTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdmFyIGZldGNoSW5wdXQgPSBhcmdzWzBdO1xuICAgICAgICAgICAgdmFyIG1ldGhvZCA9ICdHRVQnO1xuICAgICAgICAgICAgdmFyIHVybDtcblxuICAgICAgICAgICAgaWYgKHR5cGVvZiBmZXRjaElucHV0ID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICB1cmwgPSBmZXRjaElucHV0O1xuICAgICAgICAgICAgfSBlbHNlIGlmICgnUmVxdWVzdCcgaW4gX3dpbmRvdyAmJiBmZXRjaElucHV0IGluc3RhbmNlb2YgX3dpbmRvdy5SZXF1ZXN0KSB7XG4gICAgICAgICAgICAgIHVybCA9IGZldGNoSW5wdXQudXJsO1xuICAgICAgICAgICAgICBpZiAoZmV0Y2hJbnB1dC5tZXRob2QpIHtcbiAgICAgICAgICAgICAgICBtZXRob2QgPSBmZXRjaElucHV0Lm1ldGhvZDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgdXJsID0gJycgKyBmZXRjaElucHV0O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBpZiBTZW50cnkga2V5IGFwcGVhcnMgaW4gVVJMLCBkb24ndCBjYXB0dXJlLCBhcyBpdCdzIG91ciBvd24gcmVxdWVzdFxuICAgICAgICAgICAgaWYgKHVybC5pbmRleE9mKHNlbGYuX2dsb2JhbEtleSkgIT09IC0xKSB7XG4gICAgICAgICAgICAgIHJldHVybiBvcmlnRmV0Y2guYXBwbHkodGhpcywgYXJncyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChhcmdzWzFdICYmIGFyZ3NbMV0ubWV0aG9kKSB7XG4gICAgICAgICAgICAgIG1ldGhvZCA9IGFyZ3NbMV0ubWV0aG9kO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB2YXIgZmV0Y2hEYXRhID0ge1xuICAgICAgICAgICAgICBtZXRob2Q6IG1ldGhvZCxcbiAgICAgICAgICAgICAgdXJsOiB1cmwsXG4gICAgICAgICAgICAgIHN0YXR1c19jb2RlOiBudWxsXG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICByZXR1cm4gb3JpZ0ZldGNoXG4gICAgICAgICAgICAgIC5hcHBseSh0aGlzLCBhcmdzKVxuICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbihyZXNwb25zZSkge1xuICAgICAgICAgICAgICAgIGZldGNoRGF0YS5zdGF0dXNfY29kZSA9IHJlc3BvbnNlLnN0YXR1cztcblxuICAgICAgICAgICAgICAgIHNlbGYuY2FwdHVyZUJyZWFkY3J1bWIoe1xuICAgICAgICAgICAgICAgICAgdHlwZTogJ2h0dHAnLFxuICAgICAgICAgICAgICAgICAgY2F0ZWdvcnk6ICdmZXRjaCcsXG4gICAgICAgICAgICAgICAgICBkYXRhOiBmZXRjaERhdGFcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgWydjYXRjaCddKGZ1bmN0aW9uKGVycikge1xuICAgICAgICAgICAgICAgIC8vIGlmIHRoZXJlIGlzIGFuIGVycm9yIHBlcmZvcm1pbmcgdGhlIHJlcXVlc3RcbiAgICAgICAgICAgICAgICBzZWxmLmNhcHR1cmVCcmVhZGNydW1iKHtcbiAgICAgICAgICAgICAgICAgIHR5cGU6ICdodHRwJyxcbiAgICAgICAgICAgICAgICAgIGNhdGVnb3J5OiAnZmV0Y2gnLFxuICAgICAgICAgICAgICAgICAgZGF0YTogZmV0Y2hEYXRhLFxuICAgICAgICAgICAgICAgICAgbGV2ZWw6ICdlcnJvcidcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfTtcbiAgICAgICAgfSxcbiAgICAgICAgd3JhcHBlZEJ1aWx0SW5zXG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIENhcHR1cmUgYnJlYWRjcnVtYnMgZnJvbSBhbnkgY2xpY2sgdGhhdCBpcyB1bmhhbmRsZWQgLyBidWJibGVkIHVwIGFsbCB0aGUgd2F5XG4gICAgLy8gdG8gdGhlIGRvY3VtZW50LiBEbyB0aGlzIGJlZm9yZSB3ZSBpbnN0cnVtZW50IGFkZEV2ZW50TGlzdGVuZXIuXG4gICAgaWYgKGF1dG9CcmVhZGNydW1icy5kb20gJiYgdGhpcy5faGFzRG9jdW1lbnQpIHtcbiAgICAgIGlmIChfZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcikge1xuICAgICAgICBfZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBzZWxmLl9icmVhZGNydW1iRXZlbnRIYW5kbGVyKCdjbGljaycpLCBmYWxzZSk7XG4gICAgICAgIF9kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdrZXlwcmVzcycsIHNlbGYuX2tleXByZXNzRXZlbnRIYW5kbGVyKCksIGZhbHNlKTtcbiAgICAgIH0gZWxzZSBpZiAoX2RvY3VtZW50LmF0dGFjaEV2ZW50KSB7XG4gICAgICAgIC8vIElFOCBDb21wYXRpYmlsaXR5XG4gICAgICAgIF9kb2N1bWVudC5hdHRhY2hFdmVudCgnb25jbGljaycsIHNlbGYuX2JyZWFkY3J1bWJFdmVudEhhbmRsZXIoJ2NsaWNrJykpO1xuICAgICAgICBfZG9jdW1lbnQuYXR0YWNoRXZlbnQoJ29ua2V5cHJlc3MnLCBzZWxmLl9rZXlwcmVzc0V2ZW50SGFuZGxlcigpKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyByZWNvcmQgbmF2aWdhdGlvbiAoVVJMKSBjaGFuZ2VzXG4gICAgLy8gTk9URTogaW4gQ2hyb21lIEFwcCBlbnZpcm9ubWVudCwgdG91Y2hpbmcgaGlzdG9yeS5wdXNoU3RhdGUsICpldmVuIGluc2lkZVxuICAgIC8vICAgICAgIGEgdHJ5L2NhdGNoIGJsb2NrKiwgd2lsbCBjYXVzZSBDaHJvbWUgdG8gb3V0cHV0IGFuIGVycm9yIHRvIGNvbnNvbGUuZXJyb3JcbiAgICAvLyBib3Jyb3dlZCBmcm9tOiBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyLmpzL3B1bGwvMTM5NDUvZmlsZXNcbiAgICB2YXIgY2hyb21lID0gX3dpbmRvdy5jaHJvbWU7XG4gICAgdmFyIGlzQ2hyb21lUGFja2FnZWRBcHAgPSBjaHJvbWUgJiYgY2hyb21lLmFwcCAmJiBjaHJvbWUuYXBwLnJ1bnRpbWU7XG4gICAgdmFyIGhhc1B1c2hBbmRSZXBsYWNlU3RhdGUgPVxuICAgICAgIWlzQ2hyb21lUGFja2FnZWRBcHAgJiZcbiAgICAgIF93aW5kb3cuaGlzdG9yeSAmJlxuICAgICAgX3dpbmRvdy5oaXN0b3J5LnB1c2hTdGF0ZSAmJlxuICAgICAgX3dpbmRvdy5oaXN0b3J5LnJlcGxhY2VTdGF0ZTtcbiAgICBpZiAoYXV0b0JyZWFkY3J1bWJzLmxvY2F0aW9uICYmIGhhc1B1c2hBbmRSZXBsYWNlU3RhdGUpIHtcbiAgICAgIC8vIFRPRE86IHJlbW92ZSBvbnBvcHN0YXRlIGhhbmRsZXIgb24gdW5pbnN0YWxsKClcbiAgICAgIHZhciBvbGRPblBvcFN0YXRlID0gX3dpbmRvdy5vbnBvcHN0YXRlO1xuICAgICAgX3dpbmRvdy5vbnBvcHN0YXRlID0gZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBjdXJyZW50SHJlZiA9IHNlbGYuX2xvY2F0aW9uLmhyZWY7XG4gICAgICAgIHNlbGYuX2NhcHR1cmVVcmxDaGFuZ2Uoc2VsZi5fbGFzdEhyZWYsIGN1cnJlbnRIcmVmKTtcblxuICAgICAgICBpZiAob2xkT25Qb3BTdGF0ZSkge1xuICAgICAgICAgIHJldHVybiBvbGRPblBvcFN0YXRlLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgIH1cbiAgICAgIH07XG5cbiAgICAgIHZhciBoaXN0b3J5UmVwbGFjZW1lbnRGdW5jdGlvbiA9IGZ1bmN0aW9uKG9yaWdIaXN0RnVuY3Rpb24pIHtcbiAgICAgICAgLy8gbm90ZSBoaXN0b3J5LnB1c2hTdGF0ZS5sZW5ndGggaXMgMDsgaW50ZW50aW9uYWxseSBub3QgZGVjbGFyaW5nXG4gICAgICAgIC8vIHBhcmFtcyB0byBwcmVzZXJ2ZSAwIGFyaXR5XG4gICAgICAgIHJldHVybiBmdW5jdGlvbigvKiBzdGF0ZSwgdGl0bGUsIHVybCAqLykge1xuICAgICAgICAgIHZhciB1cmwgPSBhcmd1bWVudHMubGVuZ3RoID4gMiA/IGFyZ3VtZW50c1syXSA6IHVuZGVmaW5lZDtcblxuICAgICAgICAgIC8vIHVybCBhcmd1bWVudCBpcyBvcHRpb25hbFxuICAgICAgICAgIGlmICh1cmwpIHtcbiAgICAgICAgICAgIC8vIGNvZXJjZSB0byBzdHJpbmcgKHRoaXMgaXMgd2hhdCBwdXNoU3RhdGUgZG9lcylcbiAgICAgICAgICAgIHNlbGYuX2NhcHR1cmVVcmxDaGFuZ2Uoc2VsZi5fbGFzdEhyZWYsIHVybCArICcnKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICByZXR1cm4gb3JpZ0hpc3RGdW5jdGlvbi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICB9O1xuICAgICAgfTtcblxuICAgICAgZmlsbChfd2luZG93Lmhpc3RvcnksICdwdXNoU3RhdGUnLCBoaXN0b3J5UmVwbGFjZW1lbnRGdW5jdGlvbiwgd3JhcHBlZEJ1aWx0SW5zKTtcbiAgICAgIGZpbGwoX3dpbmRvdy5oaXN0b3J5LCAncmVwbGFjZVN0YXRlJywgaGlzdG9yeVJlcGxhY2VtZW50RnVuY3Rpb24sIHdyYXBwZWRCdWlsdElucyk7XG4gICAgfVxuXG4gICAgaWYgKGF1dG9CcmVhZGNydW1icy5jb25zb2xlICYmICdjb25zb2xlJyBpbiBfd2luZG93ICYmIGNvbnNvbGUubG9nKSB7XG4gICAgICAvLyBjb25zb2xlXG4gICAgICB2YXIgY29uc29sZU1ldGhvZENhbGxiYWNrID0gZnVuY3Rpb24obXNnLCBkYXRhKSB7XG4gICAgICAgIHNlbGYuY2FwdHVyZUJyZWFkY3J1bWIoe1xuICAgICAgICAgIG1lc3NhZ2U6IG1zZyxcbiAgICAgICAgICBsZXZlbDogZGF0YS5sZXZlbCxcbiAgICAgICAgICBjYXRlZ29yeTogJ2NvbnNvbGUnXG4gICAgICAgIH0pO1xuICAgICAgfTtcblxuICAgICAgZWFjaChbJ2RlYnVnJywgJ2luZm8nLCAnd2FybicsICdlcnJvcicsICdsb2cnXSwgZnVuY3Rpb24oXywgbGV2ZWwpIHtcbiAgICAgICAgd3JhcENvbnNvbGVNZXRob2QoY29uc29sZSwgbGV2ZWwsIGNvbnNvbGVNZXRob2RDYWxsYmFjayk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0sXG5cbiAgX3Jlc3RvcmVCdWlsdEluczogZnVuY3Rpb24oKSB7XG4gICAgLy8gcmVzdG9yZSBhbnkgd3JhcHBlZCBidWlsdGluc1xuICAgIHZhciBidWlsdGluO1xuICAgIHdoaWxlICh0aGlzLl93cmFwcGVkQnVpbHRJbnMubGVuZ3RoKSB7XG4gICAgICBidWlsdGluID0gdGhpcy5fd3JhcHBlZEJ1aWx0SW5zLnNoaWZ0KCk7XG5cbiAgICAgIHZhciBvYmogPSBidWlsdGluWzBdLFxuICAgICAgICBuYW1lID0gYnVpbHRpblsxXSxcbiAgICAgICAgb3JpZyA9IGJ1aWx0aW5bMl07XG5cbiAgICAgIG9ialtuYW1lXSA9IG9yaWc7XG4gICAgfVxuICB9LFxuXG4gIF9yZXN0b3JlQ29uc29sZTogZnVuY3Rpb24oKSB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGd1YXJkLWZvci1pblxuICAgIGZvciAodmFyIG1ldGhvZCBpbiB0aGlzLl9vcmlnaW5hbENvbnNvbGVNZXRob2RzKSB7XG4gICAgICB0aGlzLl9vcmlnaW5hbENvbnNvbGVbbWV0aG9kXSA9IHRoaXMuX29yaWdpbmFsQ29uc29sZU1ldGhvZHNbbWV0aG9kXTtcbiAgICB9XG4gIH0sXG5cbiAgX2RyYWluUGx1Z2luczogZnVuY3Rpb24oKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgLy8gRklYIE1FIFRPRE9cbiAgICBlYWNoKHRoaXMuX3BsdWdpbnMsIGZ1bmN0aW9uKF8sIHBsdWdpbikge1xuICAgICAgdmFyIGluc3RhbGxlciA9IHBsdWdpblswXTtcbiAgICAgIHZhciBhcmdzID0gcGx1Z2luWzFdO1xuICAgICAgaW5zdGFsbGVyLmFwcGx5KHNlbGYsIFtzZWxmXS5jb25jYXQoYXJncykpO1xuICAgIH0pO1xuICB9LFxuXG4gIF9wYXJzZURTTjogZnVuY3Rpb24oc3RyKSB7XG4gICAgdmFyIG0gPSBkc25QYXR0ZXJuLmV4ZWMoc3RyKSxcbiAgICAgIGRzbiA9IHt9LFxuICAgICAgaSA9IDc7XG5cbiAgICB0cnkge1xuICAgICAgd2hpbGUgKGktLSkgZHNuW2RzbktleXNbaV1dID0gbVtpXSB8fCAnJztcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICB0aHJvdyBuZXcgUmF2ZW5Db25maWdFcnJvcignSW52YWxpZCBEU046ICcgKyBzdHIpO1xuICAgIH1cblxuICAgIGlmIChkc24ucGFzcyAmJiAhdGhpcy5fZ2xvYmFsT3B0aW9ucy5hbGxvd1NlY3JldEtleSkge1xuICAgICAgdGhyb3cgbmV3IFJhdmVuQ29uZmlnRXJyb3IoXG4gICAgICAgICdEbyBub3Qgc3BlY2lmeSB5b3VyIHNlY3JldCBrZXkgaW4gdGhlIERTTi4gU2VlOiBodHRwOi8vYml0Lmx5L3JhdmVuLXNlY3JldC1rZXknXG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiBkc247XG4gIH0sXG5cbiAgX2dldEdsb2JhbFNlcnZlcjogZnVuY3Rpb24odXJpKSB7XG4gICAgLy8gYXNzZW1ibGUgdGhlIGVuZHBvaW50IGZyb20gdGhlIHVyaSBwaWVjZXNcbiAgICB2YXIgZ2xvYmFsU2VydmVyID0gJy8vJyArIHVyaS5ob3N0ICsgKHVyaS5wb3J0ID8gJzonICsgdXJpLnBvcnQgOiAnJyk7XG5cbiAgICBpZiAodXJpLnByb3RvY29sKSB7XG4gICAgICBnbG9iYWxTZXJ2ZXIgPSB1cmkucHJvdG9jb2wgKyAnOicgKyBnbG9iYWxTZXJ2ZXI7XG4gICAgfVxuICAgIHJldHVybiBnbG9iYWxTZXJ2ZXI7XG4gIH0sXG5cbiAgX2hhbmRsZU9uRXJyb3JTdGFja0luZm86IGZ1bmN0aW9uKHN0YWNrSW5mbywgb3B0aW9ucykge1xuICAgIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuICAgIG9wdGlvbnMubWVjaGFuaXNtID0gb3B0aW9ucy5tZWNoYW5pc20gfHwge1xuICAgICAgdHlwZTogJ29uZXJyb3InLFxuICAgICAgaGFuZGxlZDogZmFsc2VcbiAgICB9O1xuXG4gICAgLy8gaWYgd2UgYXJlIGludGVudGlvbmFsbHkgaWdub3JpbmcgZXJyb3JzIHZpYSBvbmVycm9yLCBiYWlsIG91dFxuICAgIGlmICghdGhpcy5faWdub3JlT25FcnJvcikge1xuICAgICAgdGhpcy5faGFuZGxlU3RhY2tJbmZvKHN0YWNrSW5mbywgb3B0aW9ucyk7XG4gICAgfVxuICB9LFxuXG4gIF9oYW5kbGVTdGFja0luZm86IGZ1bmN0aW9uKHN0YWNrSW5mbywgb3B0aW9ucykge1xuICAgIHZhciBmcmFtZXMgPSB0aGlzLl9wcmVwYXJlRnJhbWVzKHN0YWNrSW5mbywgb3B0aW9ucyk7XG5cbiAgICB0aGlzLl90cmlnZ2VyRXZlbnQoJ2hhbmRsZScsIHtcbiAgICAgIHN0YWNrSW5mbzogc3RhY2tJbmZvLFxuICAgICAgb3B0aW9uczogb3B0aW9uc1xuICAgIH0pO1xuXG4gICAgdGhpcy5fcHJvY2Vzc0V4Y2VwdGlvbihcbiAgICAgIHN0YWNrSW5mby5uYW1lLFxuICAgICAgc3RhY2tJbmZvLm1lc3NhZ2UsXG4gICAgICBzdGFja0luZm8udXJsLFxuICAgICAgc3RhY2tJbmZvLmxpbmVubyxcbiAgICAgIGZyYW1lcyxcbiAgICAgIG9wdGlvbnNcbiAgICApO1xuICB9LFxuXG4gIF9wcmVwYXJlRnJhbWVzOiBmdW5jdGlvbihzdGFja0luZm8sIG9wdGlvbnMpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdmFyIGZyYW1lcyA9IFtdO1xuICAgIGlmIChzdGFja0luZm8uc3RhY2sgJiYgc3RhY2tJbmZvLnN0YWNrLmxlbmd0aCkge1xuICAgICAgZWFjaChzdGFja0luZm8uc3RhY2ssIGZ1bmN0aW9uKGksIHN0YWNrKSB7XG4gICAgICAgIHZhciBmcmFtZSA9IHNlbGYuX25vcm1hbGl6ZUZyYW1lKHN0YWNrLCBzdGFja0luZm8udXJsKTtcbiAgICAgICAgaWYgKGZyYW1lKSB7XG4gICAgICAgICAgZnJhbWVzLnB1c2goZnJhbWUpO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgLy8gZS5nLiBmcmFtZXMgY2FwdHVyZWQgdmlhIGNhcHR1cmVNZXNzYWdlIHRocm93XG4gICAgICBpZiAob3B0aW9ucyAmJiBvcHRpb25zLnRyaW1IZWFkRnJhbWVzKSB7XG4gICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgb3B0aW9ucy50cmltSGVhZEZyYW1lcyAmJiBqIDwgZnJhbWVzLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgZnJhbWVzW2pdLmluX2FwcCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGZyYW1lcyA9IGZyYW1lcy5zbGljZSgwLCB0aGlzLl9nbG9iYWxPcHRpb25zLnN0YWNrVHJhY2VMaW1pdCk7XG4gICAgcmV0dXJuIGZyYW1lcztcbiAgfSxcblxuICBfbm9ybWFsaXplRnJhbWU6IGZ1bmN0aW9uKGZyYW1lLCBzdGFja0luZm9VcmwpIHtcbiAgICAvLyBub3JtYWxpemUgdGhlIGZyYW1lcyBkYXRhXG4gICAgdmFyIG5vcm1hbGl6ZWQgPSB7XG4gICAgICBmaWxlbmFtZTogZnJhbWUudXJsLFxuICAgICAgbGluZW5vOiBmcmFtZS5saW5lLFxuICAgICAgY29sbm86IGZyYW1lLmNvbHVtbixcbiAgICAgIGZ1bmN0aW9uOiBmcmFtZS5mdW5jIHx8ICc/J1xuICAgIH07XG5cbiAgICAvLyBDYXNlIHdoZW4gd2UgZG9uJ3QgaGF2ZSBhbnkgaW5mb3JtYXRpb24gYWJvdXQgdGhlIGVycm9yXG4gICAgLy8gRS5nLiB0aHJvd2luZyBhIHN0cmluZyBvciByYXcgb2JqZWN0LCBpbnN0ZWFkIG9mIGFuIGBFcnJvcmAgaW4gRmlyZWZveFxuICAgIC8vIEdlbmVyYXRpbmcgc3ludGhldGljIGVycm9yIGRvZXNuJ3QgYWRkIGFueSB2YWx1ZSBoZXJlXG4gICAgLy9cbiAgICAvLyBXZSBzaG91bGQgcHJvYmFibHkgc29tZWhvdyBsZXQgYSB1c2VyIGtub3cgdGhhdCB0aGV5IHNob3VsZCBmaXggdGhlaXIgY29kZVxuICAgIGlmICghZnJhbWUudXJsKSB7XG4gICAgICBub3JtYWxpemVkLmZpbGVuYW1lID0gc3RhY2tJbmZvVXJsOyAvLyBmYWxsYmFjayB0byB3aG9sZSBzdGFja3MgdXJsIGZyb20gb25lcnJvciBoYW5kbGVyXG4gICAgfVxuXG4gICAgbm9ybWFsaXplZC5pbl9hcHAgPSAhLy8gZGV0ZXJtaW5lIGlmIGFuIGV4Y2VwdGlvbiBjYW1lIGZyb20gb3V0c2lkZSBvZiBvdXIgYXBwXG4gICAgLy8gZmlyc3Qgd2UgY2hlY2sgdGhlIGdsb2JhbCBpbmNsdWRlUGF0aHMgbGlzdC5cbiAgICAoXG4gICAgICAoISF0aGlzLl9nbG9iYWxPcHRpb25zLmluY2x1ZGVQYXRocy50ZXN0ICYmXG4gICAgICAgICF0aGlzLl9nbG9iYWxPcHRpb25zLmluY2x1ZGVQYXRocy50ZXN0KG5vcm1hbGl6ZWQuZmlsZW5hbWUpKSB8fFxuICAgICAgLy8gTm93IHdlIGNoZWNrIGZvciBmdW4sIGlmIHRoZSBmdW5jdGlvbiBuYW1lIGlzIFJhdmVuIG9yIFRyYWNlS2l0XG4gICAgICAvKFJhdmVufFRyYWNlS2l0KVxcLi8udGVzdChub3JtYWxpemVkWydmdW5jdGlvbiddKSB8fFxuICAgICAgLy8gZmluYWxseSwgd2UgZG8gYSBsYXN0IGRpdGNoIGVmZm9ydCBhbmQgY2hlY2sgZm9yIHJhdmVuLm1pbi5qc1xuICAgICAgL3JhdmVuXFwuKG1pblxcLik/anMkLy50ZXN0KG5vcm1hbGl6ZWQuZmlsZW5hbWUpXG4gICAgKTtcblxuICAgIHJldHVybiBub3JtYWxpemVkO1xuICB9LFxuXG4gIF9wcm9jZXNzRXhjZXB0aW9uOiBmdW5jdGlvbih0eXBlLCBtZXNzYWdlLCBmaWxldXJsLCBsaW5lbm8sIGZyYW1lcywgb3B0aW9ucykge1xuICAgIHZhciBwcmVmaXhlZE1lc3NhZ2UgPSAodHlwZSA/IHR5cGUgKyAnOiAnIDogJycpICsgKG1lc3NhZ2UgfHwgJycpO1xuICAgIGlmIChcbiAgICAgICEhdGhpcy5fZ2xvYmFsT3B0aW9ucy5pZ25vcmVFcnJvcnMudGVzdCAmJlxuICAgICAgKHRoaXMuX2dsb2JhbE9wdGlvbnMuaWdub3JlRXJyb3JzLnRlc3QobWVzc2FnZSkgfHxcbiAgICAgICAgdGhpcy5fZ2xvYmFsT3B0aW9ucy5pZ25vcmVFcnJvcnMudGVzdChwcmVmaXhlZE1lc3NhZ2UpKVxuICAgICkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHZhciBzdGFja3RyYWNlO1xuXG4gICAgaWYgKGZyYW1lcyAmJiBmcmFtZXMubGVuZ3RoKSB7XG4gICAgICBmaWxldXJsID0gZnJhbWVzWzBdLmZpbGVuYW1lIHx8IGZpbGV1cmw7XG4gICAgICAvLyBTZW50cnkgZXhwZWN0cyBmcmFtZXMgb2xkZXN0IHRvIG5ld2VzdFxuICAgICAgLy8gYW5kIEpTIHNlbmRzIHRoZW0gYXMgbmV3ZXN0IHRvIG9sZGVzdFxuICAgICAgZnJhbWVzLnJldmVyc2UoKTtcbiAgICAgIHN0YWNrdHJhY2UgPSB7ZnJhbWVzOiBmcmFtZXN9O1xuICAgIH0gZWxzZSBpZiAoZmlsZXVybCkge1xuICAgICAgc3RhY2t0cmFjZSA9IHtcbiAgICAgICAgZnJhbWVzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgZmlsZW5hbWU6IGZpbGV1cmwsXG4gICAgICAgICAgICBsaW5lbm86IGxpbmVubyxcbiAgICAgICAgICAgIGluX2FwcDogdHJ1ZVxuICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgICAgfTtcbiAgICB9XG5cbiAgICBpZiAoXG4gICAgICAhIXRoaXMuX2dsb2JhbE9wdGlvbnMuaWdub3JlVXJscy50ZXN0ICYmXG4gICAgICB0aGlzLl9nbG9iYWxPcHRpb25zLmlnbm9yZVVybHMudGVzdChmaWxldXJsKVxuICAgICkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChcbiAgICAgICEhdGhpcy5fZ2xvYmFsT3B0aW9ucy53aGl0ZWxpc3RVcmxzLnRlc3QgJiZcbiAgICAgICF0aGlzLl9nbG9iYWxPcHRpb25zLndoaXRlbGlzdFVybHMudGVzdChmaWxldXJsKVxuICAgICkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHZhciBkYXRhID0gb2JqZWN0TWVyZ2UoXG4gICAgICB7XG4gICAgICAgIC8vIHNlbnRyeS5pbnRlcmZhY2VzLkV4Y2VwdGlvblxuICAgICAgICBleGNlcHRpb246IHtcbiAgICAgICAgICB2YWx1ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgdHlwZTogdHlwZSxcbiAgICAgICAgICAgICAgdmFsdWU6IG1lc3NhZ2UsXG4gICAgICAgICAgICAgIHN0YWNrdHJhY2U6IHN0YWNrdHJhY2VcbiAgICAgICAgICAgIH1cbiAgICAgICAgICBdXG4gICAgICAgIH0sXG4gICAgICAgIHRyYW5zYWN0aW9uOiBmaWxldXJsXG4gICAgICB9LFxuICAgICAgb3B0aW9uc1xuICAgICk7XG5cbiAgICB2YXIgZXggPSBkYXRhLmV4Y2VwdGlvbi52YWx1ZXNbMF07XG4gICAgaWYgKGV4LnR5cGUgPT0gbnVsbCAmJiBleC52YWx1ZSA9PT0gJycpIHtcbiAgICAgIGV4LnZhbHVlID0gJ1VucmVjb3ZlcmFibGUgZXJyb3IgY2F1Z2h0JztcbiAgICB9XG5cbiAgICAvLyBNb3ZlIG1lY2hhbmlzbSBmcm9tIG9wdGlvbnMgdG8gZXhjZXB0aW9uIGludGVyZmFjZVxuICAgIC8vIFdlIGRvIHRoaXMsIGFzIHJlcXVpcmluZyB1c2VyIHRvIHBhc3MgYHtleGNlcHRpb246e21lY2hhbmlzbTp7IC4uLiB9fX1gIHdvdWxkIGJlXG4gICAgLy8gdG9vIG11Y2hcbiAgICBpZiAoIWRhdGEuZXhjZXB0aW9uLm1lY2hhbmlzbSAmJiBkYXRhLm1lY2hhbmlzbSkge1xuICAgICAgZGF0YS5leGNlcHRpb24ubWVjaGFuaXNtID0gZGF0YS5tZWNoYW5pc207XG4gICAgICBkZWxldGUgZGF0YS5tZWNoYW5pc207XG4gICAgfVxuXG4gICAgZGF0YS5leGNlcHRpb24ubWVjaGFuaXNtID0gb2JqZWN0TWVyZ2UoXG4gICAgICB7XG4gICAgICAgIHR5cGU6ICdnZW5lcmljJyxcbiAgICAgICAgaGFuZGxlZDogdHJ1ZVxuICAgICAgfSxcbiAgICAgIGRhdGEuZXhjZXB0aW9uLm1lY2hhbmlzbSB8fCB7fVxuICAgICk7XG5cbiAgICAvLyBGaXJlIGF3YXkhXG4gICAgdGhpcy5fc2VuZChkYXRhKTtcbiAgfSxcblxuICBfdHJpbVBhY2tldDogZnVuY3Rpb24oZGF0YSkge1xuICAgIC8vIEZvciBub3csIHdlIG9ubHkgd2FudCB0byB0cnVuY2F0ZSB0aGUgdHdvIGRpZmZlcmVudCBtZXNzYWdlc1xuICAgIC8vIGJ1dCB0aGlzIGNvdWxkL3Nob3VsZCBiZSBleHBhbmRlZCB0byBqdXN0IHRyaW0gZXZlcnl0aGluZ1xuICAgIHZhciBtYXggPSB0aGlzLl9nbG9iYWxPcHRpb25zLm1heE1lc3NhZ2VMZW5ndGg7XG4gICAgaWYgKGRhdGEubWVzc2FnZSkge1xuICAgICAgZGF0YS5tZXNzYWdlID0gdHJ1bmNhdGUoZGF0YS5tZXNzYWdlLCBtYXgpO1xuICAgIH1cbiAgICBpZiAoZGF0YS5leGNlcHRpb24pIHtcbiAgICAgIHZhciBleGNlcHRpb24gPSBkYXRhLmV4Y2VwdGlvbi52YWx1ZXNbMF07XG4gICAgICBleGNlcHRpb24udmFsdWUgPSB0cnVuY2F0ZShleGNlcHRpb24udmFsdWUsIG1heCk7XG4gICAgfVxuXG4gICAgdmFyIHJlcXVlc3QgPSBkYXRhLnJlcXVlc3Q7XG4gICAgaWYgKHJlcXVlc3QpIHtcbiAgICAgIGlmIChyZXF1ZXN0LnVybCkge1xuICAgICAgICByZXF1ZXN0LnVybCA9IHRydW5jYXRlKHJlcXVlc3QudXJsLCB0aGlzLl9nbG9iYWxPcHRpb25zLm1heFVybExlbmd0aCk7XG4gICAgICB9XG4gICAgICBpZiAocmVxdWVzdC5SZWZlcmVyKSB7XG4gICAgICAgIHJlcXVlc3QuUmVmZXJlciA9IHRydW5jYXRlKHJlcXVlc3QuUmVmZXJlciwgdGhpcy5fZ2xvYmFsT3B0aW9ucy5tYXhVcmxMZW5ndGgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChkYXRhLmJyZWFkY3J1bWJzICYmIGRhdGEuYnJlYWRjcnVtYnMudmFsdWVzKVxuICAgICAgdGhpcy5fdHJpbUJyZWFkY3J1bWJzKGRhdGEuYnJlYWRjcnVtYnMpO1xuXG4gICAgcmV0dXJuIGRhdGE7XG4gIH0sXG5cbiAgLyoqXG4gICAqIFRydW5jYXRlIGJyZWFkY3J1bWIgdmFsdWVzIChyaWdodCBub3cganVzdCBVUkxzKVxuICAgKi9cbiAgX3RyaW1CcmVhZGNydW1iczogZnVuY3Rpb24oYnJlYWRjcnVtYnMpIHtcbiAgICAvLyBrbm93biBicmVhZGNydW1iIHByb3BlcnRpZXMgd2l0aCB1cmxzXG4gICAgLy8gVE9ETzogYWxzbyBjb25zaWRlciBhcmJpdHJhcnkgcHJvcCB2YWx1ZXMgdGhhdCBzdGFydCB3aXRoIChodHRwcz8pPzovL1xuICAgIHZhciB1cmxQcm9wcyA9IFsndG8nLCAnZnJvbScsICd1cmwnXSxcbiAgICAgIHVybFByb3AsXG4gICAgICBjcnVtYixcbiAgICAgIGRhdGE7XG5cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGJyZWFkY3J1bWJzLnZhbHVlcy5sZW5ndGg7ICsraSkge1xuICAgICAgY3J1bWIgPSBicmVhZGNydW1icy52YWx1ZXNbaV07XG4gICAgICBpZiAoXG4gICAgICAgICFjcnVtYi5oYXNPd25Qcm9wZXJ0eSgnZGF0YScpIHx8XG4gICAgICAgICFpc09iamVjdChjcnVtYi5kYXRhKSB8fFxuICAgICAgICBvYmplY3RGcm96ZW4oY3J1bWIuZGF0YSlcbiAgICAgIClcbiAgICAgICAgY29udGludWU7XG5cbiAgICAgIGRhdGEgPSBvYmplY3RNZXJnZSh7fSwgY3J1bWIuZGF0YSk7XG4gICAgICBmb3IgKHZhciBqID0gMDsgaiA8IHVybFByb3BzLmxlbmd0aDsgKytqKSB7XG4gICAgICAgIHVybFByb3AgPSB1cmxQcm9wc1tqXTtcbiAgICAgICAgaWYgKGRhdGEuaGFzT3duUHJvcGVydHkodXJsUHJvcCkgJiYgZGF0YVt1cmxQcm9wXSkge1xuICAgICAgICAgIGRhdGFbdXJsUHJvcF0gPSB0cnVuY2F0ZShkYXRhW3VybFByb3BdLCB0aGlzLl9nbG9iYWxPcHRpb25zLm1heFVybExlbmd0aCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGJyZWFkY3J1bWJzLnZhbHVlc1tpXS5kYXRhID0gZGF0YTtcbiAgICB9XG4gIH0sXG5cbiAgX2dldEh0dHBEYXRhOiBmdW5jdGlvbigpIHtcbiAgICBpZiAoIXRoaXMuX2hhc05hdmlnYXRvciAmJiAhdGhpcy5faGFzRG9jdW1lbnQpIHJldHVybjtcbiAgICB2YXIgaHR0cERhdGEgPSB7fTtcblxuICAgIGlmICh0aGlzLl9oYXNOYXZpZ2F0b3IgJiYgX25hdmlnYXRvci51c2VyQWdlbnQpIHtcbiAgICAgIGh0dHBEYXRhLmhlYWRlcnMgPSB7XG4gICAgICAgICdVc2VyLUFnZW50JzogX25hdmlnYXRvci51c2VyQWdlbnRcbiAgICAgIH07XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgaW4gYHdpbmRvd2AgaW5zdGVhZCBvZiBgZG9jdW1lbnRgLCBhcyB3ZSBtYXkgYmUgaW4gU2VydmljZVdvcmtlciBlbnZpcm9ubWVudFxuICAgIGlmIChfd2luZG93LmxvY2F0aW9uICYmIF93aW5kb3cubG9jYXRpb24uaHJlZikge1xuICAgICAgaHR0cERhdGEudXJsID0gX3dpbmRvdy5sb2NhdGlvbi5ocmVmO1xuICAgIH1cblxuICAgIGlmICh0aGlzLl9oYXNEb2N1bWVudCAmJiBfZG9jdW1lbnQucmVmZXJyZXIpIHtcbiAgICAgIGlmICghaHR0cERhdGEuaGVhZGVycykgaHR0cERhdGEuaGVhZGVycyA9IHt9O1xuICAgICAgaHR0cERhdGEuaGVhZGVycy5SZWZlcmVyID0gX2RvY3VtZW50LnJlZmVycmVyO1xuICAgIH1cblxuICAgIHJldHVybiBodHRwRGF0YTtcbiAgfSxcblxuICBfcmVzZXRCYWNrb2ZmOiBmdW5jdGlvbigpIHtcbiAgICB0aGlzLl9iYWNrb2ZmRHVyYXRpb24gPSAwO1xuICAgIHRoaXMuX2JhY2tvZmZTdGFydCA9IG51bGw7XG4gIH0sXG5cbiAgX3Nob3VsZEJhY2tvZmY6IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLl9iYWNrb2ZmRHVyYXRpb24gJiYgbm93KCkgLSB0aGlzLl9iYWNrb2ZmU3RhcnQgPCB0aGlzLl9iYWNrb2ZmRHVyYXRpb247XG4gIH0sXG5cbiAgLyoqXG4gICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgaW4tcHJvY2VzcyBkYXRhIHBheWxvYWQgbWF0Y2hlcyB0aGUgc2lnbmF0dXJlXG4gICAqIG9mIHRoZSBwcmV2aW91c2x5LXNlbnQgZGF0YVxuICAgKlxuICAgKiBOT1RFOiBUaGlzIGhhcyB0byBiZSBkb25lIGF0IHRoaXMgbGV2ZWwgYmVjYXVzZSBUcmFjZUtpdCBjYW4gZ2VuZXJhdGVcbiAgICogICAgICAgZGF0YSBmcm9tIHdpbmRvdy5vbmVycm9yIFdJVEhPVVQgYW4gZXhjZXB0aW9uIG9iamVjdCAoSUU4LCBJRTksXG4gICAqICAgICAgIG90aGVyIG9sZCBicm93c2VycykuIFRoaXMgY2FuIHRha2UgdGhlIGZvcm0gb2YgYW4gXCJleGNlcHRpb25cIlxuICAgKiAgICAgICBkYXRhIG9iamVjdCB3aXRoIGEgc2luZ2xlIGZyYW1lIChkZXJpdmVkIGZyb20gdGhlIG9uZXJyb3IgYXJncykuXG4gICAqL1xuICBfaXNSZXBlYXREYXRhOiBmdW5jdGlvbihjdXJyZW50KSB7XG4gICAgdmFyIGxhc3QgPSB0aGlzLl9sYXN0RGF0YTtcblxuICAgIGlmIChcbiAgICAgICFsYXN0IHx8XG4gICAgICBjdXJyZW50Lm1lc3NhZ2UgIT09IGxhc3QubWVzc2FnZSB8fCAvLyBkZWZpbmVkIGZvciBjYXB0dXJlTWVzc2FnZVxuICAgICAgY3VycmVudC50cmFuc2FjdGlvbiAhPT0gbGFzdC50cmFuc2FjdGlvbiAvLyBkZWZpbmVkIGZvciBjYXB0dXJlRXhjZXB0aW9uL29uZXJyb3JcbiAgICApXG4gICAgICByZXR1cm4gZmFsc2U7XG5cbiAgICAvLyBTdGFja3RyYWNlIGludGVyZmFjZSAoaS5lLiBmcm9tIGNhcHR1cmVNZXNzYWdlKVxuICAgIGlmIChjdXJyZW50LnN0YWNrdHJhY2UgfHwgbGFzdC5zdGFja3RyYWNlKSB7XG4gICAgICByZXR1cm4gaXNTYW1lU3RhY2t0cmFjZShjdXJyZW50LnN0YWNrdHJhY2UsIGxhc3Quc3RhY2t0cmFjZSk7XG4gICAgfSBlbHNlIGlmIChjdXJyZW50LmV4Y2VwdGlvbiB8fCBsYXN0LmV4Y2VwdGlvbikge1xuICAgICAgLy8gRXhjZXB0aW9uIGludGVyZmFjZSAoaS5lLiBmcm9tIGNhcHR1cmVFeGNlcHRpb24vb25lcnJvcilcbiAgICAgIHJldHVybiBpc1NhbWVFeGNlcHRpb24oY3VycmVudC5leGNlcHRpb24sIGxhc3QuZXhjZXB0aW9uKTtcbiAgICB9IGVsc2UgaWYgKGN1cnJlbnQuZmluZ2VycHJpbnQgfHwgbGFzdC5maW5nZXJwcmludCkge1xuICAgICAgcmV0dXJuIEJvb2xlYW4oY3VycmVudC5maW5nZXJwcmludCAmJiBsYXN0LmZpbmdlcnByaW50KSAmJlxuICAgICAgICBKU09OLnN0cmluZ2lmeShjdXJyZW50LmZpbmdlcnByaW50KSA9PT0gSlNPTi5zdHJpbmdpZnkobGFzdC5maW5nZXJwcmludClcbiAgICB9XG5cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSxcblxuICBfc2V0QmFja29mZlN0YXRlOiBmdW5jdGlvbihyZXF1ZXN0KSB7XG4gICAgLy8gSWYgd2UgYXJlIGFscmVhZHkgaW4gYSBiYWNrb2ZmIHN0YXRlLCBkb24ndCBjaGFuZ2UgYW55dGhpbmdcbiAgICBpZiAodGhpcy5fc2hvdWxkQmFja29mZigpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdmFyIHN0YXR1cyA9IHJlcXVlc3Quc3RhdHVzO1xuXG4gICAgLy8gNDAwIC0gcHJvamVjdF9pZCBkb2Vzbid0IGV4aXN0IG9yIHNvbWUgb3RoZXIgZmF0YWxcbiAgICAvLyA0MDEgLSBpbnZhbGlkL3Jldm9rZWQgZHNuXG4gICAgLy8gNDI5IC0gdG9vIG1hbnkgcmVxdWVzdHNcbiAgICBpZiAoIShzdGF0dXMgPT09IDQwMCB8fCBzdGF0dXMgPT09IDQwMSB8fCBzdGF0dXMgPT09IDQyOSkpIHJldHVybjtcblxuICAgIHZhciByZXRyeTtcbiAgICB0cnkge1xuICAgICAgLy8gSWYgUmV0cnktQWZ0ZXIgaXMgbm90IGluIEFjY2Vzcy1Db250cm9sLUV4cG9zZS1IZWFkZXJzLCBtb3N0XG4gICAgICAvLyBicm93c2VycyB3aWxsIHRocm93IGFuIGV4Y2VwdGlvbiB0cnlpbmcgdG8gYWNjZXNzIGl0XG4gICAgICBpZiAoc3VwcG9ydHNGZXRjaCgpKSB7XG4gICAgICAgIHJldHJ5ID0gcmVxdWVzdC5oZWFkZXJzLmdldCgnUmV0cnktQWZ0ZXInKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHJ5ID0gcmVxdWVzdC5nZXRSZXNwb25zZUhlYWRlcignUmV0cnktQWZ0ZXInKTtcbiAgICAgIH1cblxuICAgICAgLy8gUmV0cnktQWZ0ZXIgaXMgcmV0dXJuZWQgaW4gc2Vjb25kc1xuICAgICAgcmV0cnkgPSBwYXJzZUludChyZXRyeSwgMTApICogMTAwMDtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvKiBlc2xpbnQgbm8tZW1wdHk6MCAqL1xuICAgIH1cblxuICAgIHRoaXMuX2JhY2tvZmZEdXJhdGlvbiA9IHJldHJ5XG4gICAgICA/IC8vIElmIFNlbnRyeSBzZXJ2ZXIgcmV0dXJuZWQgYSBSZXRyeS1BZnRlciB2YWx1ZSwgdXNlIGl0XG4gICAgICAgIHJldHJ5XG4gICAgICA6IC8vIE90aGVyd2lzZSwgZG91YmxlIHRoZSBsYXN0IGJhY2tvZmYgZHVyYXRpb24gKHN0YXJ0cyBhdCAxIHNlYylcbiAgICAgICAgdGhpcy5fYmFja29mZkR1cmF0aW9uICogMiB8fCAxMDAwO1xuXG4gICAgdGhpcy5fYmFja29mZlN0YXJ0ID0gbm93KCk7XG4gIH0sXG5cbiAgX3NlbmQ6IGZ1bmN0aW9uKGRhdGEpIHtcbiAgICB2YXIgZ2xvYmFsT3B0aW9ucyA9IHRoaXMuX2dsb2JhbE9wdGlvbnM7XG5cbiAgICB2YXIgYmFzZURhdGEgPSB7XG4gICAgICAgIHByb2plY3Q6IHRoaXMuX2dsb2JhbFByb2plY3QsXG4gICAgICAgIGxvZ2dlcjogZ2xvYmFsT3B0aW9ucy5sb2dnZXIsXG4gICAgICAgIHBsYXRmb3JtOiAnamF2YXNjcmlwdCdcbiAgICAgIH0sXG4gICAgICBodHRwRGF0YSA9IHRoaXMuX2dldEh0dHBEYXRhKCk7XG5cbiAgICBpZiAoaHR0cERhdGEpIHtcbiAgICAgIGJhc2VEYXRhLnJlcXVlc3QgPSBodHRwRGF0YTtcbiAgICB9XG5cbiAgICAvLyBIQUNLOiBkZWxldGUgYHRyaW1IZWFkRnJhbWVzYCB0byBwcmV2ZW50IGZyb20gYXBwZWFyaW5nIGluIG91dGJvdW5kIHBheWxvYWRcbiAgICBpZiAoZGF0YS50cmltSGVhZEZyYW1lcykgZGVsZXRlIGRhdGEudHJpbUhlYWRGcmFtZXM7XG5cbiAgICBkYXRhID0gb2JqZWN0TWVyZ2UoYmFzZURhdGEsIGRhdGEpO1xuXG4gICAgLy8gTWVyZ2UgaW4gdGhlIHRhZ3MgYW5kIGV4dHJhIHNlcGFyYXRlbHkgc2luY2Ugb2JqZWN0TWVyZ2UgZG9lc24ndCBoYW5kbGUgYSBkZWVwIG1lcmdlXG4gICAgZGF0YS50YWdzID0gb2JqZWN0TWVyZ2Uob2JqZWN0TWVyZ2Uoe30sIHRoaXMuX2dsb2JhbENvbnRleHQudGFncyksIGRhdGEudGFncyk7XG4gICAgZGF0YS5leHRyYSA9IG9iamVjdE1lcmdlKG9iamVjdE1lcmdlKHt9LCB0aGlzLl9nbG9iYWxDb250ZXh0LmV4dHJhKSwgZGF0YS5leHRyYSk7XG5cbiAgICAvLyBTZW5kIGFsb25nIG91ciBvd24gY29sbGVjdGVkIG1ldGFkYXRhIHdpdGggZXh0cmFcbiAgICBkYXRhLmV4dHJhWydzZXNzaW9uOmR1cmF0aW9uJ10gPSBub3coKSAtIHRoaXMuX3N0YXJ0VGltZTtcblxuICAgIGlmICh0aGlzLl9icmVhZGNydW1icyAmJiB0aGlzLl9icmVhZGNydW1icy5sZW5ndGggPiAwKSB7XG4gICAgICAvLyBpbnRlbnRpb25hbGx5IG1ha2Ugc2hhbGxvdyBjb3B5IHNvIHRoYXQgYWRkaXRpb25zXG4gICAgICAvLyB0byBicmVhZGNydW1icyBhcmVuJ3QgYWNjaWRlbnRhbGx5IHNlbnQgaW4gdGhpcyByZXF1ZXN0XG4gICAgICBkYXRhLmJyZWFkY3J1bWJzID0ge1xuICAgICAgICB2YWx1ZXM6IFtdLnNsaWNlLmNhbGwodGhpcy5fYnJlYWRjcnVtYnMsIDApXG4gICAgICB9O1xuICAgIH1cblxuICAgIGlmICh0aGlzLl9nbG9iYWxDb250ZXh0LnVzZXIpIHtcbiAgICAgIC8vIHNlbnRyeS5pbnRlcmZhY2VzLlVzZXJcbiAgICAgIGRhdGEudXNlciA9IHRoaXMuX2dsb2JhbENvbnRleHQudXNlcjtcbiAgICB9XG5cbiAgICAvLyBJbmNsdWRlIHRoZSBlbnZpcm9ubWVudCBpZiBpdCdzIGRlZmluZWQgaW4gZ2xvYmFsT3B0aW9uc1xuICAgIGlmIChnbG9iYWxPcHRpb25zLmVudmlyb25tZW50KSBkYXRhLmVudmlyb25tZW50ID0gZ2xvYmFsT3B0aW9ucy5lbnZpcm9ubWVudDtcblxuICAgIC8vIEluY2x1ZGUgdGhlIHJlbGVhc2UgaWYgaXQncyBkZWZpbmVkIGluIGdsb2JhbE9wdGlvbnNcbiAgICBpZiAoZ2xvYmFsT3B0aW9ucy5yZWxlYXNlKSBkYXRhLnJlbGVhc2UgPSBnbG9iYWxPcHRpb25zLnJlbGVhc2U7XG5cbiAgICAvLyBJbmNsdWRlIHNlcnZlcl9uYW1lIGlmIGl0J3MgZGVmaW5lZCBpbiBnbG9iYWxPcHRpb25zXG4gICAgaWYgKGdsb2JhbE9wdGlvbnMuc2VydmVyTmFtZSkgZGF0YS5zZXJ2ZXJfbmFtZSA9IGdsb2JhbE9wdGlvbnMuc2VydmVyTmFtZTtcblxuICAgIGRhdGEgPSB0aGlzLl9zYW5pdGl6ZURhdGEoZGF0YSk7XG5cbiAgICAvLyBDbGVhbnVwIGVtcHR5IHByb3BlcnRpZXMgYmVmb3JlIHNlbmRpbmcgdGhlbSB0byB0aGUgc2VydmVyXG4gICAgT2JqZWN0LmtleXMoZGF0YSkuZm9yRWFjaChmdW5jdGlvbihrZXkpIHtcbiAgICAgIGlmIChkYXRhW2tleV0gPT0gbnVsbCB8fCBkYXRhW2tleV0gPT09ICcnIHx8IGlzRW1wdHlPYmplY3QoZGF0YVtrZXldKSkge1xuICAgICAgICBkZWxldGUgZGF0YVtrZXldO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgaWYgKGlzRnVuY3Rpb24oZ2xvYmFsT3B0aW9ucy5kYXRhQ2FsbGJhY2spKSB7XG4gICAgICBkYXRhID0gZ2xvYmFsT3B0aW9ucy5kYXRhQ2FsbGJhY2soZGF0YSkgfHwgZGF0YTtcbiAgICB9XG5cbiAgICAvLyBXaHk/Pz8/Pz8/Pz8/XG4gICAgaWYgKCFkYXRhIHx8IGlzRW1wdHlPYmplY3QoZGF0YSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBDaGVjayBpZiB0aGUgcmVxdWVzdCBzaG91bGQgYmUgZmlsdGVyZWQgb3Igbm90XG4gICAgaWYgKFxuICAgICAgaXNGdW5jdGlvbihnbG9iYWxPcHRpb25zLnNob3VsZFNlbmRDYWxsYmFjaykgJiZcbiAgICAgICFnbG9iYWxPcHRpb25zLnNob3VsZFNlbmRDYWxsYmFjayhkYXRhKVxuICAgICkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIEJhY2tvZmYgc3RhdGU6IFNlbnRyeSBzZXJ2ZXIgcHJldmlvdXNseSByZXNwb25kZWQgdy8gYW4gZXJyb3IgKGUuZy4gNDI5IC0gdG9vIG1hbnkgcmVxdWVzdHMpLFxuICAgIC8vIHNvIGRyb3AgcmVxdWVzdHMgdW50aWwgXCJjb29sLW9mZlwiIHBlcmlvZCBoYXMgZWxhcHNlZC5cbiAgICBpZiAodGhpcy5fc2hvdWxkQmFja29mZigpKSB7XG4gICAgICB0aGlzLl9sb2dEZWJ1Zygnd2FybicsICdSYXZlbiBkcm9wcGVkIGVycm9yIGR1ZSB0byBiYWNrb2ZmOiAnLCBkYXRhKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAodHlwZW9mIGdsb2JhbE9wdGlvbnMuc2FtcGxlUmF0ZSA9PT0gJ251bWJlcicpIHtcbiAgICAgIGlmIChNYXRoLnJhbmRvbSgpIDwgZ2xvYmFsT3B0aW9ucy5zYW1wbGVSYXRlKSB7XG4gICAgICAgIHRoaXMuX3NlbmRQcm9jZXNzZWRQYXlsb2FkKGRhdGEpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9zZW5kUHJvY2Vzc2VkUGF5bG9hZChkYXRhKTtcbiAgICB9XG4gIH0sXG5cbiAgX3Nhbml0aXplRGF0YTogZnVuY3Rpb24oZGF0YSkge1xuICAgIHJldHVybiBzYW5pdGl6ZShkYXRhLCB0aGlzLl9nbG9iYWxPcHRpb25zLnNhbml0aXplS2V5cyk7XG4gIH0sXG5cbiAgX2dldFV1aWQ6IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiB1dWlkNCgpO1xuICB9LFxuXG4gIF9zZW5kUHJvY2Vzc2VkUGF5bG9hZDogZnVuY3Rpb24oZGF0YSwgY2FsbGJhY2spIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdmFyIGdsb2JhbE9wdGlvbnMgPSB0aGlzLl9nbG9iYWxPcHRpb25zO1xuXG4gICAgaWYgKCF0aGlzLmlzU2V0dXAoKSkgcmV0dXJuO1xuXG4gICAgLy8gVHJ5IGFuZCBjbGVhbiB1cCB0aGUgcGFja2V0IGJlZm9yZSBzZW5kaW5nIGJ5IHRydW5jYXRpbmcgbG9uZyB2YWx1ZXNcbiAgICBkYXRhID0gdGhpcy5fdHJpbVBhY2tldChkYXRhKTtcblxuICAgIC8vIGlkZWFsbHkgZHVwbGljYXRlIGVycm9yIHRlc3Rpbmcgc2hvdWxkIG9jY3VyICpiZWZvcmUqIGRhdGFDYWxsYmFjay9zaG91bGRTZW5kQ2FsbGJhY2ssXG4gICAgLy8gYnV0IHRoaXMgd291bGQgcmVxdWlyZSBjb3B5aW5nIGFuIHVuLXRydW5jYXRlZCBjb3B5IG9mIHRoZSBkYXRhIHBhY2tldCwgd2hpY2ggY2FuIGJlXG4gICAgLy8gYXJiaXRyYXJpbHkgZGVlcCAoZXh0cmFfZGF0YSkgLS0gY291bGQgYmUgd29ydGh3aGlsZT8gd2lsbCByZXZpc2l0XG4gICAgaWYgKCF0aGlzLl9nbG9iYWxPcHRpb25zLmFsbG93RHVwbGljYXRlcyAmJiB0aGlzLl9pc1JlcGVhdERhdGEoZGF0YSkpIHtcbiAgICAgIHRoaXMuX2xvZ0RlYnVnKCd3YXJuJywgJ1JhdmVuIGRyb3BwZWQgcmVwZWF0IGV2ZW50OiAnLCBkYXRhKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBTZW5kIGFsb25nIGFuIGV2ZW50X2lkIGlmIG5vdCBleHBsaWNpdGx5IHBhc3NlZC5cbiAgICAvLyBUaGlzIGV2ZW50X2lkIGNhbiBiZSB1c2VkIHRvIHJlZmVyZW5jZSB0aGUgZXJyb3Igd2l0aGluIFNlbnRyeSBpdHNlbGYuXG4gICAgLy8gU2V0IGxhc3RFdmVudElkIGFmdGVyIHdlIGtub3cgdGhlIGVycm9yIHNob3VsZCBhY3R1YWxseSBiZSBzZW50XG4gICAgdGhpcy5fbGFzdEV2ZW50SWQgPSBkYXRhLmV2ZW50X2lkIHx8IChkYXRhLmV2ZW50X2lkID0gdGhpcy5fZ2V0VXVpZCgpKTtcblxuICAgIC8vIFN0b3JlIG91dGJvdW5kIHBheWxvYWQgYWZ0ZXIgdHJpbVxuICAgIHRoaXMuX2xhc3REYXRhID0gZGF0YTtcblxuICAgIHRoaXMuX2xvZ0RlYnVnKCdkZWJ1ZycsICdSYXZlbiBhYm91dCB0byBzZW5kOicsIGRhdGEpO1xuXG4gICAgdmFyIGF1dGggPSB7XG4gICAgICBzZW50cnlfdmVyc2lvbjogJzcnLFxuICAgICAgc2VudHJ5X2NsaWVudDogJ3JhdmVuLWpzLycgKyB0aGlzLlZFUlNJT04sXG4gICAgICBzZW50cnlfa2V5OiB0aGlzLl9nbG9iYWxLZXlcbiAgICB9O1xuXG4gICAgaWYgKHRoaXMuX2dsb2JhbFNlY3JldCkge1xuICAgICAgYXV0aC5zZW50cnlfc2VjcmV0ID0gdGhpcy5fZ2xvYmFsU2VjcmV0O1xuICAgIH1cblxuICAgIHZhciBleGNlcHRpb24gPSBkYXRhLmV4Y2VwdGlvbiAmJiBkYXRhLmV4Y2VwdGlvbi52YWx1ZXNbMF07XG5cbiAgICAvLyBvbmx5IGNhcHR1cmUgJ3NlbnRyeScgYnJlYWRjcnVtYiBpcyBhdXRvQnJlYWRjcnVtYnMgaXMgdHJ1dGh5XG4gICAgaWYgKFxuICAgICAgdGhpcy5fZ2xvYmFsT3B0aW9ucy5hdXRvQnJlYWRjcnVtYnMgJiZcbiAgICAgIHRoaXMuX2dsb2JhbE9wdGlvbnMuYXV0b0JyZWFkY3J1bWJzLnNlbnRyeVxuICAgICkge1xuICAgICAgdGhpcy5jYXB0dXJlQnJlYWRjcnVtYih7XG4gICAgICAgIGNhdGVnb3J5OiAnc2VudHJ5JyxcbiAgICAgICAgbWVzc2FnZTogZXhjZXB0aW9uXG4gICAgICAgICAgPyAoZXhjZXB0aW9uLnR5cGUgPyBleGNlcHRpb24udHlwZSArICc6ICcgOiAnJykgKyBleGNlcHRpb24udmFsdWVcbiAgICAgICAgICA6IGRhdGEubWVzc2FnZSxcbiAgICAgICAgZXZlbnRfaWQ6IGRhdGEuZXZlbnRfaWQsXG4gICAgICAgIGxldmVsOiBkYXRhLmxldmVsIHx8ICdlcnJvcicgLy8gcHJlc3VtZSBlcnJvciB1bmxlc3Mgc3BlY2lmaWVkXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICB2YXIgdXJsID0gdGhpcy5fZ2xvYmFsRW5kcG9pbnQ7XG4gICAgKGdsb2JhbE9wdGlvbnMudHJhbnNwb3J0IHx8IHRoaXMuX21ha2VSZXF1ZXN0KS5jYWxsKHRoaXMsIHtcbiAgICAgIHVybDogdXJsLFxuICAgICAgYXV0aDogYXV0aCxcbiAgICAgIGRhdGE6IGRhdGEsXG4gICAgICBvcHRpb25zOiBnbG9iYWxPcHRpb25zLFxuICAgICAgb25TdWNjZXNzOiBmdW5jdGlvbiBzdWNjZXNzKCkge1xuICAgICAgICBzZWxmLl9yZXNldEJhY2tvZmYoKTtcblxuICAgICAgICBzZWxmLl90cmlnZ2VyRXZlbnQoJ3N1Y2Nlc3MnLCB7XG4gICAgICAgICAgZGF0YTogZGF0YSxcbiAgICAgICAgICBzcmM6IHVybFxuICAgICAgICB9KTtcbiAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soKTtcbiAgICAgIH0sXG4gICAgICBvbkVycm9yOiBmdW5jdGlvbiBmYWlsdXJlKGVycm9yKSB7XG4gICAgICAgIHNlbGYuX2xvZ0RlYnVnKCdlcnJvcicsICdSYXZlbiB0cmFuc3BvcnQgZmFpbGVkIHRvIHNlbmQ6ICcsIGVycm9yKTtcblxuICAgICAgICBpZiAoZXJyb3IucmVxdWVzdCkge1xuICAgICAgICAgIHNlbGYuX3NldEJhY2tvZmZTdGF0ZShlcnJvci5yZXF1ZXN0KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHNlbGYuX3RyaWdnZXJFdmVudCgnZmFpbHVyZScsIHtcbiAgICAgICAgICBkYXRhOiBkYXRhLFxuICAgICAgICAgIHNyYzogdXJsXG4gICAgICAgIH0pO1xuICAgICAgICBlcnJvciA9IGVycm9yIHx8IG5ldyBFcnJvcignUmF2ZW4gc2VuZCBmYWlsZWQgKG5vIGFkZGl0aW9uYWwgZGV0YWlscyBwcm92aWRlZCknKTtcbiAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soZXJyb3IpO1xuICAgICAgfVxuICAgIH0pO1xuICB9LFxuXG4gIF9tYWtlUmVxdWVzdDogZnVuY3Rpb24ob3B0cykge1xuICAgIC8vIEF1dGggaXMgaW50ZW50aW9uYWxseSBzZW50IGFzIHBhcnQgb2YgcXVlcnkgc3RyaW5nIChOT1QgYXMgY3VzdG9tIEhUVFAgaGVhZGVyKSB0byBhdm9pZCBwcmVmbGlnaHQgQ09SUyByZXF1ZXN0c1xuICAgIHZhciB1cmwgPSBvcHRzLnVybCArICc/JyArIHVybGVuY29kZShvcHRzLmF1dGgpO1xuXG4gICAgdmFyIGV2YWx1YXRlZEhlYWRlcnMgPSBudWxsO1xuICAgIHZhciBldmFsdWF0ZWRGZXRjaFBhcmFtZXRlcnMgPSB7fTtcblxuICAgIGlmIChvcHRzLm9wdGlvbnMuaGVhZGVycykge1xuICAgICAgZXZhbHVhdGVkSGVhZGVycyA9IHRoaXMuX2V2YWx1YXRlSGFzaChvcHRzLm9wdGlvbnMuaGVhZGVycyk7XG4gICAgfVxuXG4gICAgaWYgKG9wdHMub3B0aW9ucy5mZXRjaFBhcmFtZXRlcnMpIHtcbiAgICAgIGV2YWx1YXRlZEZldGNoUGFyYW1ldGVycyA9IHRoaXMuX2V2YWx1YXRlSGFzaChvcHRzLm9wdGlvbnMuZmV0Y2hQYXJhbWV0ZXJzKTtcbiAgICB9XG5cbiAgICBpZiAoc3VwcG9ydHNGZXRjaCgpKSB7XG4gICAgICBldmFsdWF0ZWRGZXRjaFBhcmFtZXRlcnMuYm9keSA9IHN0cmluZ2lmeShvcHRzLmRhdGEpO1xuXG4gICAgICB2YXIgZGVmYXVsdEZldGNoT3B0aW9ucyA9IG9iamVjdE1lcmdlKHt9LCB0aGlzLl9mZXRjaERlZmF1bHRzKTtcbiAgICAgIHZhciBmZXRjaE9wdGlvbnMgPSBvYmplY3RNZXJnZShkZWZhdWx0RmV0Y2hPcHRpb25zLCBldmFsdWF0ZWRGZXRjaFBhcmFtZXRlcnMpO1xuXG4gICAgICBpZiAoZXZhbHVhdGVkSGVhZGVycykge1xuICAgICAgICBmZXRjaE9wdGlvbnMuaGVhZGVycyA9IGV2YWx1YXRlZEhlYWRlcnM7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBfd2luZG93XG4gICAgICAgIC5mZXRjaCh1cmwsIGZldGNoT3B0aW9ucylcbiAgICAgICAgLnRoZW4oZnVuY3Rpb24ocmVzcG9uc2UpIHtcbiAgICAgICAgICBpZiAocmVzcG9uc2Uub2spIHtcbiAgICAgICAgICAgIG9wdHMub25TdWNjZXNzICYmIG9wdHMub25TdWNjZXNzKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHZhciBlcnJvciA9IG5ldyBFcnJvcignU2VudHJ5IGVycm9yIGNvZGU6ICcgKyByZXNwb25zZS5zdGF0dXMpO1xuICAgICAgICAgICAgLy8gSXQncyBjYWxsZWQgcmVxdWVzdCBvbmx5IHRvIGtlZXAgY29tcGF0aWJpbGl0eSB3aXRoIFhIUiBpbnRlcmZhY2VcbiAgICAgICAgICAgIC8vIGFuZCBub3QgYWRkIG1vcmUgcmVkdW5kYW50IGNoZWNrcyBpbiBzZXRCYWNrb2ZmU3RhdGUgbWV0aG9kXG4gICAgICAgICAgICBlcnJvci5yZXF1ZXN0ID0gcmVzcG9uc2U7XG4gICAgICAgICAgICBvcHRzLm9uRXJyb3IgJiYgb3B0cy5vbkVycm9yKGVycm9yKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICAgIFsnY2F0Y2gnXShmdW5jdGlvbigpIHtcbiAgICAgICAgICBvcHRzLm9uRXJyb3IgJiZcbiAgICAgICAgICAgIG9wdHMub25FcnJvcihuZXcgRXJyb3IoJ1NlbnRyeSBlcnJvciBjb2RlOiBuZXR3b3JrIHVuYXZhaWxhYmxlJykpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICB2YXIgcmVxdWVzdCA9IF93aW5kb3cuWE1MSHR0cFJlcXVlc3QgJiYgbmV3IF93aW5kb3cuWE1MSHR0cFJlcXVlc3QoKTtcbiAgICBpZiAoIXJlcXVlc3QpIHJldHVybjtcblxuICAgIC8vIGlmIGJyb3dzZXIgZG9lc24ndCBzdXBwb3J0IENPUlMgKGUuZy4gSUU3KSwgd2UgYXJlIG91dCBvZiBsdWNrXG4gICAgdmFyIGhhc0NPUlMgPSAnd2l0aENyZWRlbnRpYWxzJyBpbiByZXF1ZXN0IHx8IHR5cGVvZiBYRG9tYWluUmVxdWVzdCAhPT0gJ3VuZGVmaW5lZCc7XG5cbiAgICBpZiAoIWhhc0NPUlMpIHJldHVybjtcblxuICAgIGlmICgnd2l0aENyZWRlbnRpYWxzJyBpbiByZXF1ZXN0KSB7XG4gICAgICByZXF1ZXN0Lm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICBpZiAocmVxdWVzdC5yZWFkeVN0YXRlICE9PSA0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9IGVsc2UgaWYgKHJlcXVlc3Quc3RhdHVzID09PSAyMDApIHtcbiAgICAgICAgICBvcHRzLm9uU3VjY2VzcyAmJiBvcHRzLm9uU3VjY2VzcygpO1xuICAgICAgICB9IGVsc2UgaWYgKG9wdHMub25FcnJvcikge1xuICAgICAgICAgIHZhciBlcnIgPSBuZXcgRXJyb3IoJ1NlbnRyeSBlcnJvciBjb2RlOiAnICsgcmVxdWVzdC5zdGF0dXMpO1xuICAgICAgICAgIGVyci5yZXF1ZXN0ID0gcmVxdWVzdDtcbiAgICAgICAgICBvcHRzLm9uRXJyb3IoZXJyKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVxdWVzdCA9IG5ldyBYRG9tYWluUmVxdWVzdCgpO1xuICAgICAgLy8geGRvbWFpbnJlcXVlc3QgY2Fubm90IGdvIGh0dHAgLT4gaHR0cHMgKG9yIHZpY2UgdmVyc2EpLFxuICAgICAgLy8gc28gYWx3YXlzIHVzZSBwcm90b2NvbCByZWxhdGl2ZVxuICAgICAgdXJsID0gdXJsLnJlcGxhY2UoL15odHRwcz86LywgJycpO1xuXG4gICAgICAvLyBvbnJlYWR5c3RhdGVjaGFuZ2Ugbm90IHN1cHBvcnRlZCBieSBYRG9tYWluUmVxdWVzdFxuICAgICAgaWYgKG9wdHMub25TdWNjZXNzKSB7XG4gICAgICAgIHJlcXVlc3Qub25sb2FkID0gb3B0cy5vblN1Y2Nlc3M7XG4gICAgICB9XG4gICAgICBpZiAob3B0cy5vbkVycm9yKSB7XG4gICAgICAgIHJlcXVlc3Qub25lcnJvciA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHZhciBlcnIgPSBuZXcgRXJyb3IoJ1NlbnRyeSBlcnJvciBjb2RlOiBYRG9tYWluUmVxdWVzdCcpO1xuICAgICAgICAgIGVyci5yZXF1ZXN0ID0gcmVxdWVzdDtcbiAgICAgICAgICBvcHRzLm9uRXJyb3IoZXJyKTtcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXF1ZXN0Lm9wZW4oJ1BPU1QnLCB1cmwpO1xuXG4gICAgaWYgKGV2YWx1YXRlZEhlYWRlcnMpIHtcbiAgICAgIGVhY2goZXZhbHVhdGVkSGVhZGVycywgZnVuY3Rpb24oa2V5LCB2YWx1ZSkge1xuICAgICAgICByZXF1ZXN0LnNldFJlcXVlc3RIZWFkZXIoa2V5LCB2YWx1ZSk7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICByZXF1ZXN0LnNlbmQoc3RyaW5naWZ5KG9wdHMuZGF0YSkpO1xuICB9LFxuXG4gIF9ldmFsdWF0ZUhhc2g6IGZ1bmN0aW9uKGhhc2gpIHtcbiAgICB2YXIgZXZhbHVhdGVkID0ge307XG5cbiAgICBmb3IgKHZhciBrZXkgaW4gaGFzaCkge1xuICAgICAgaWYgKGhhc2guaGFzT3duUHJvcGVydHkoa2V5KSkge1xuICAgICAgICB2YXIgdmFsdWUgPSBoYXNoW2tleV07XG4gICAgICAgIGV2YWx1YXRlZFtrZXldID0gdHlwZW9mIHZhbHVlID09PSAnZnVuY3Rpb24nID8gdmFsdWUoKSA6IHZhbHVlO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBldmFsdWF0ZWQ7XG4gIH0sXG5cbiAgX2xvZ0RlYnVnOiBmdW5jdGlvbihsZXZlbCkge1xuICAgIC8vIFdlIGFsbG93IGBSYXZlbi5kZWJ1Z2AgYW5kIGBSYXZlbi5jb25maWcoRFNOLCB7IGRlYnVnOiB0cnVlIH0pYCB0byBub3QgbWFrZSBiYWNrd2FyZCBpbmNvbXBhdGlibGUgQVBJIGNoYW5nZVxuICAgIGlmIChcbiAgICAgIHRoaXMuX29yaWdpbmFsQ29uc29sZU1ldGhvZHNbbGV2ZWxdICYmXG4gICAgICAodGhpcy5kZWJ1ZyB8fCB0aGlzLl9nbG9iYWxPcHRpb25zLmRlYnVnKVxuICAgICkge1xuICAgICAgLy8gSW4gSUU8MTAgY29uc29sZSBtZXRob2RzIGRvIG5vdCBoYXZlIHRoZWlyIG93biAnYXBwbHknIG1ldGhvZFxuICAgICAgRnVuY3Rpb24ucHJvdG90eXBlLmFwcGx5LmNhbGwoXG4gICAgICAgIHRoaXMuX29yaWdpbmFsQ29uc29sZU1ldGhvZHNbbGV2ZWxdLFxuICAgICAgICB0aGlzLl9vcmlnaW5hbENvbnNvbGUsXG4gICAgICAgIFtdLnNsaWNlLmNhbGwoYXJndW1lbnRzLCAxKVxuICAgICAgKTtcbiAgICB9XG4gIH0sXG5cbiAgX21lcmdlQ29udGV4dDogZnVuY3Rpb24oa2V5LCBjb250ZXh0KSB7XG4gICAgaWYgKGlzVW5kZWZpbmVkKGNvbnRleHQpKSB7XG4gICAgICBkZWxldGUgdGhpcy5fZ2xvYmFsQ29udGV4dFtrZXldO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9nbG9iYWxDb250ZXh0W2tleV0gPSBvYmplY3RNZXJnZSh0aGlzLl9nbG9iYWxDb250ZXh0W2tleV0gfHwge30sIGNvbnRleHQpO1xuICAgIH1cbiAgfVxufTtcblxuLy8gRGVwcmVjYXRpb25zXG5SYXZlbi5wcm90b3R5cGUuc2V0VXNlciA9IFJhdmVuLnByb3RvdHlwZS5zZXRVc2VyQ29udGV4dDtcblJhdmVuLnByb3RvdHlwZS5zZXRSZWxlYXNlQ29udGV4dCA9IFJhdmVuLnByb3RvdHlwZS5zZXRSZWxlYXNlO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFJhdmVuO1xuIiwiLyoqXG4gKiBFbmZvcmNlcyBhIHNpbmdsZSBpbnN0YW5jZSBvZiB0aGUgUmF2ZW4gY2xpZW50LCBhbmQgdGhlXG4gKiBtYWluIGVudHJ5IHBvaW50IGZvciBSYXZlbi4gSWYgeW91IGFyZSBhIGNvbnN1bWVyIG9mIHRoZVxuICogUmF2ZW4gbGlicmFyeSwgeW91IFNIT1VMRCBsb2FkIHRoaXMgZmlsZSAodnMgcmF2ZW4uanMpLlxuICoqL1xuXG52YXIgUmF2ZW5Db25zdHJ1Y3RvciA9IHJlcXVpcmUoJy4vcmF2ZW4nKTtcblxuLy8gVGhpcyBpcyB0byBiZSBkZWZlbnNpdmUgaW4gZW52aXJvbm1lbnRzIHdoZXJlIHdpbmRvdyBkb2VzIG5vdCBleGlzdCAoc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9nZXRzZW50cnkvcmF2ZW4tanMvcHVsbC83ODUpXG52YXIgX3dpbmRvdyA9XG4gIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnXG4gICAgPyB3aW5kb3dcbiAgICA6IHR5cGVvZiBnbG9iYWwgIT09ICd1bmRlZmluZWQnID8gZ2xvYmFsIDogdHlwZW9mIHNlbGYgIT09ICd1bmRlZmluZWQnID8gc2VsZiA6IHt9O1xudmFyIF9SYXZlbiA9IF93aW5kb3cuUmF2ZW47XG5cbnZhciBSYXZlbiA9IG5ldyBSYXZlbkNvbnN0cnVjdG9yKCk7XG5cbi8qXG4gKiBBbGxvdyBtdWx0aXBsZSB2ZXJzaW9ucyBvZiBSYXZlbiB0byBiZSBpbnN0YWxsZWQuXG4gKiBTdHJpcCBSYXZlbiBmcm9tIHRoZSBnbG9iYWwgY29udGV4dCBhbmQgcmV0dXJucyB0aGUgaW5zdGFuY2UuXG4gKlxuICogQHJldHVybiB7UmF2ZW59XG4gKi9cblJhdmVuLm5vQ29uZmxpY3QgPSBmdW5jdGlvbigpIHtcbiAgX3dpbmRvdy5SYXZlbiA9IF9SYXZlbjtcbiAgcmV0dXJuIFJhdmVuO1xufTtcblxuUmF2ZW4uYWZ0ZXJMb2FkKCk7XG5cbm1vZHVsZS5leHBvcnRzID0gUmF2ZW47XG5cbi8qKlxuICogRElTQ0xBSU1FUjpcbiAqXG4gKiBFeHBvc2UgYENsaWVudGAgY29uc3RydWN0b3IgZm9yIGNhc2VzIHdoZXJlIHVzZXIgd2FudCB0byB0cmFjayBtdWx0aXBsZSBcInN1Yi1hcHBsaWNhdGlvbnNcIiBpbiBvbmUgbGFyZ2VyIGFwcC5cbiAqIEl0J3Mgbm90IG1lYW50IHRvIGJlIHVzZWQgYnkgYSB3aWRlIGF1ZGllbmNlLCBzbyBwbGVhYWFzZSBtYWtlIHN1cmUgdGhhdCB5b3Uga25vdyB3aGF0IHlvdSdyZSBkb2luZyBiZWZvcmUgdXNpbmcgaXQuXG4gKiBBY2NpZGVudGFsbHkgY2FsbGluZyBgaW5zdGFsbGAgbXVsdGlwbGUgdGltZXMsIG1heSByZXN1bHQgaW4gYW4gdW5leHBlY3RlZCBiZWhhdmlvciB0aGF0J3MgdmVyeSBoYXJkIHRvIGRlYnVnLlxuICpcbiAqIEl0J3MgY2FsbGVkIGBDbGllbnQnIHRvIGJlIGluLWxpbmUgd2l0aCBSYXZlbiBOb2RlIGltcGxlbWVudGF0aW9uLlxuICpcbiAqIEhPV1RPOlxuICpcbiAqIGltcG9ydCBSYXZlbiBmcm9tICdyYXZlbi1qcyc7XG4gKlxuICogY29uc3Qgc29tZUFwcFJlcG9ydGVyID0gbmV3IFJhdmVuLkNsaWVudCgpO1xuICogY29uc3Qgc29tZU90aGVyQXBwUmVwb3J0ZXIgPSBuZXcgUmF2ZW4uQ2xpZW50KCk7XG4gKlxuICogc29tZUFwcFJlcG9ydGVyLmNvbmZpZygnX19EU05fXycsIHtcbiAqICAgLi4uY29uZmlnIGdvZXMgaGVyZVxuICogfSk7XG4gKlxuICogc29tZU90aGVyQXBwUmVwb3J0ZXIuY29uZmlnKCdfX09USEVSX0RTTl9fJywge1xuICogICAuLi5jb25maWcgZ29lcyBoZXJlXG4gKiB9KTtcbiAqXG4gKiBzb21lQXBwUmVwb3J0ZXIuY2FwdHVyZU1lc3NhZ2UoLi4uKTtcbiAqIHNvbWVBcHBSZXBvcnRlci5jYXB0dXJlRXhjZXB0aW9uKC4uLik7XG4gKiBzb21lQXBwUmVwb3J0ZXIuY2FwdHVyZUJyZWFkY3J1bWIoLi4uKTtcbiAqXG4gKiBzb21lT3RoZXJBcHBSZXBvcnRlci5jYXB0dXJlTWVzc2FnZSguLi4pO1xuICogc29tZU90aGVyQXBwUmVwb3J0ZXIuY2FwdHVyZUV4Y2VwdGlvbiguLi4pO1xuICogc29tZU90aGVyQXBwUmVwb3J0ZXIuY2FwdHVyZUJyZWFkY3J1bWIoLi4uKTtcbiAqXG4gKiBJdCBzaG91bGQgXCJqdXN0IHdvcmtcIi5cbiAqL1xubW9kdWxlLmV4cG9ydHMuQ2xpZW50ID0gUmF2ZW5Db25zdHJ1Y3RvcjtcbiIsInZhciBzdHJpbmdpZnkgPSByZXF1aXJlKCcuLi92ZW5kb3IvanNvbi1zdHJpbmdpZnktc2FmZS9zdHJpbmdpZnknKTtcblxudmFyIF93aW5kb3cgPVxuICB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJ1xuICAgID8gd2luZG93XG4gICAgOiB0eXBlb2YgZ2xvYmFsICE9PSAndW5kZWZpbmVkJ1xuICAgICAgPyBnbG9iYWxcbiAgICAgIDogdHlwZW9mIHNlbGYgIT09ICd1bmRlZmluZWQnXG4gICAgICAgID8gc2VsZlxuICAgICAgICA6IHt9O1xuXG5mdW5jdGlvbiBpc09iamVjdCh3aGF0KSB7XG4gIHJldHVybiB0eXBlb2Ygd2hhdCA9PT0gJ29iamVjdCcgJiYgd2hhdCAhPT0gbnVsbDtcbn1cblxuLy8gWWFua2VkIGZyb20gaHR0cHM6Ly9naXQuaW8vdlM4RFYgcmUtdXNlZCB1bmRlciBDQzBcbi8vIHdpdGggc29tZSB0aW55IG1vZGlmaWNhdGlvbnNcbmZ1bmN0aW9uIGlzRXJyb3IodmFsdWUpIHtcbiAgc3dpdGNoIChPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpKSB7XG4gICAgY2FzZSAnW29iamVjdCBFcnJvcl0nOlxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgY2FzZSAnW29iamVjdCBFeGNlcHRpb25dJzpcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIGNhc2UgJ1tvYmplY3QgRE9NRXhjZXB0aW9uXSc6XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgRXJyb3I7XG4gIH1cbn1cblxuZnVuY3Rpb24gaXNFcnJvckV2ZW50KHZhbHVlKSB7XG4gIHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpID09PSAnW29iamVjdCBFcnJvckV2ZW50XSc7XG59XG5cbmZ1bmN0aW9uIGlzRE9NRXJyb3IodmFsdWUpIHtcbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWx1ZSkgPT09ICdbb2JqZWN0IERPTUVycm9yXSc7XG59XG5cbmZ1bmN0aW9uIGlzRE9NRXhjZXB0aW9uKHZhbHVlKSB7XG4gIHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpID09PSAnW29iamVjdCBET01FeGNlcHRpb25dJztcbn1cblxuZnVuY3Rpb24gaXNVbmRlZmluZWQod2hhdCkge1xuICByZXR1cm4gd2hhdCA9PT0gdm9pZCAwO1xufVxuXG5mdW5jdGlvbiBpc0Z1bmN0aW9uKHdoYXQpIHtcbiAgcmV0dXJuIHR5cGVvZiB3aGF0ID09PSAnZnVuY3Rpb24nO1xufVxuXG5mdW5jdGlvbiBpc1BsYWluT2JqZWN0KHdoYXQpIHtcbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh3aGF0KSA9PT0gJ1tvYmplY3QgT2JqZWN0XSc7XG59XG5cbmZ1bmN0aW9uIGlzU3RyaW5nKHdoYXQpIHtcbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh3aGF0KSA9PT0gJ1tvYmplY3QgU3RyaW5nXSc7XG59XG5cbmZ1bmN0aW9uIGlzQXJyYXkod2hhdCkge1xuICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHdoYXQpID09PSAnW29iamVjdCBBcnJheV0nO1xufVxuXG5mdW5jdGlvbiBpc0VtcHR5T2JqZWN0KHdoYXQpIHtcbiAgaWYgKCFpc1BsYWluT2JqZWN0KHdoYXQpKSByZXR1cm4gZmFsc2U7XG5cbiAgZm9yICh2YXIgXyBpbiB3aGF0KSB7XG4gICAgaWYgKHdoYXQuaGFzT3duUHJvcGVydHkoXykpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5cbmZ1bmN0aW9uIHN1cHBvcnRzRXJyb3JFdmVudCgpIHtcbiAgdHJ5IHtcbiAgICBuZXcgRXJyb3JFdmVudCgnJyk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tbmV3XG4gICAgcmV0dXJuIHRydWU7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuZnVuY3Rpb24gc3VwcG9ydHNET01FcnJvcigpIHtcbiAgdHJ5IHtcbiAgICBuZXcgRE9NRXJyb3IoJycpOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLW5ld1xuICAgIHJldHVybiB0cnVlO1xuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbmZ1bmN0aW9uIHN1cHBvcnRzRE9NRXhjZXB0aW9uKCkge1xuICB0cnkge1xuICAgIG5ldyBET01FeGNlcHRpb24oJycpOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLW5ld1xuICAgIHJldHVybiB0cnVlO1xuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbmZ1bmN0aW9uIHN1cHBvcnRzRmV0Y2goKSB7XG4gIGlmICghKCdmZXRjaCcgaW4gX3dpbmRvdykpIHJldHVybiBmYWxzZTtcblxuICB0cnkge1xuICAgIG5ldyBIZWFkZXJzKCk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tbmV3XG4gICAgbmV3IFJlcXVlc3QoJycpOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLW5ld1xuICAgIG5ldyBSZXNwb25zZSgpOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLW5ld1xuICAgIHJldHVybiB0cnVlO1xuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbi8vIERlc3BpdGUgYWxsIHN0YXJzIGluIHRoZSBza3kgc2F5aW5nIHRoYXQgRWRnZSBzdXBwb3J0cyBvbGQgZHJhZnQgc3ludGF4LCBha2EgJ25ldmVyJywgJ2Fsd2F5cycsICdvcmlnaW4nIGFuZCAnZGVmYXVsdFxuLy8gaHR0cHM6Ly9jYW5pdXNlLmNvbS8jZmVhdD1yZWZlcnJlci1wb2xpY3lcbi8vIEl0IGRvZXNuJ3QuIEFuZCBpdCB0aHJvdyBleGNlcHRpb24gaW5zdGVhZCBvZiBpZ25vcmluZyB0aGlzIHBhcmFtZXRlci4uLlxuLy8gUkVGOiBodHRwczovL2dpdGh1Yi5jb20vZ2V0c2VudHJ5L3JhdmVuLWpzL2lzc3Vlcy8xMjMzXG5mdW5jdGlvbiBzdXBwb3J0c1JlZmVycmVyUG9saWN5KCkge1xuICBpZiAoIXN1cHBvcnRzRmV0Y2goKSkgcmV0dXJuIGZhbHNlO1xuXG4gIHRyeSB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLW5ld1xuICAgIG5ldyBSZXF1ZXN0KCdwaWNrbGVSaWNrJywge1xuICAgICAgcmVmZXJyZXJQb2xpY3k6ICdvcmlnaW4nXG4gICAgfSk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuZnVuY3Rpb24gc3VwcG9ydHNQcm9taXNlUmVqZWN0aW9uRXZlbnQoKSB7XG4gIHJldHVybiB0eXBlb2YgUHJvbWlzZVJlamVjdGlvbkV2ZW50ID09PSAnZnVuY3Rpb24nO1xufVxuXG5mdW5jdGlvbiB3cmFwcGVkQ2FsbGJhY2soY2FsbGJhY2spIHtcbiAgZnVuY3Rpb24gZGF0YUNhbGxiYWNrKGRhdGEsIG9yaWdpbmFsKSB7XG4gICAgdmFyIG5vcm1hbGl6ZWREYXRhID0gY2FsbGJhY2soZGF0YSkgfHwgZGF0YTtcbiAgICBpZiAob3JpZ2luYWwpIHtcbiAgICAgIHJldHVybiBvcmlnaW5hbChub3JtYWxpemVkRGF0YSkgfHwgbm9ybWFsaXplZERhdGE7XG4gICAgfVxuICAgIHJldHVybiBub3JtYWxpemVkRGF0YTtcbiAgfVxuXG4gIHJldHVybiBkYXRhQ2FsbGJhY2s7XG59XG5cbmZ1bmN0aW9uIGVhY2gob2JqLCBjYWxsYmFjaykge1xuICB2YXIgaSwgajtcblxuICBpZiAoaXNVbmRlZmluZWQob2JqLmxlbmd0aCkpIHtcbiAgICBmb3IgKGkgaW4gb2JqKSB7XG4gICAgICBpZiAoaGFzS2V5KG9iaiwgaSkpIHtcbiAgICAgICAgY2FsbGJhY2suY2FsbChudWxsLCBpLCBvYmpbaV0pO1xuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBqID0gb2JqLmxlbmd0aDtcbiAgICBpZiAoaikge1xuICAgICAgZm9yIChpID0gMDsgaSA8IGo7IGkrKykge1xuICAgICAgICBjYWxsYmFjay5jYWxsKG51bGwsIGksIG9ialtpXSk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIG9iamVjdE1lcmdlKG9iajEsIG9iajIpIHtcbiAgaWYgKCFvYmoyKSB7XG4gICAgcmV0dXJuIG9iajE7XG4gIH1cbiAgZWFjaChvYmoyLCBmdW5jdGlvbihrZXksIHZhbHVlKSB7XG4gICAgb2JqMVtrZXldID0gdmFsdWU7XG4gIH0pO1xuICByZXR1cm4gb2JqMTtcbn1cblxuLyoqXG4gKiBUaGlzIGZ1bmN0aW9uIGlzIG9ubHkgdXNlZCBmb3IgcmVhY3QtbmF0aXZlLlxuICogcmVhY3QtbmF0aXZlIGZyZWV6ZXMgb2JqZWN0IHRoYXQgaGF2ZSBhbHJlYWR5IGJlZW4gc2VudCBvdmVyIHRoZVxuICoganMgYnJpZGdlLiBXZSBuZWVkIHRoaXMgZnVuY3Rpb24gaW4gb3JkZXIgdG8gY2hlY2sgaWYgdGhlIG9iamVjdCBpcyBmcm96ZW4uXG4gKiBTbyBpdCdzIG9rIHRoYXQgb2JqZWN0RnJvemVuIHJldHVybnMgZmFsc2UgaWYgT2JqZWN0LmlzRnJvemVuIGlzIG5vdFxuICogc3VwcG9ydGVkIGJlY2F1c2UgaXQncyBub3QgcmVsZXZhbnQgZm9yIG90aGVyIFwicGxhdGZvcm1zXCIuIFNlZSByZWxhdGVkIGlzc3VlOlxuICogaHR0cHM6Ly9naXRodWIuY29tL2dldHNlbnRyeS9yZWFjdC1uYXRpdmUtc2VudHJ5L2lzc3Vlcy81N1xuICovXG5mdW5jdGlvbiBvYmplY3RGcm96ZW4ob2JqKSB7XG4gIGlmICghT2JqZWN0LmlzRnJvemVuKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiBPYmplY3QuaXNGcm96ZW4ob2JqKTtcbn1cblxuZnVuY3Rpb24gdHJ1bmNhdGUoc3RyLCBtYXgpIHtcbiAgaWYgKHR5cGVvZiBtYXggIT09ICdudW1iZXInKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCcybmQgYXJndW1lbnQgdG8gYHRydW5jYXRlYCBmdW5jdGlvbiBzaG91bGQgYmUgYSBudW1iZXInKTtcbiAgfVxuICBpZiAodHlwZW9mIHN0ciAhPT0gJ3N0cmluZycgfHwgbWF4ID09PSAwKSB7XG4gICAgcmV0dXJuIHN0cjtcbiAgfVxuICByZXR1cm4gc3RyLmxlbmd0aCA8PSBtYXggPyBzdHIgOiBzdHIuc3Vic3RyKDAsIG1heCkgKyAnXFx1MjAyNic7XG59XG5cbi8qKlxuICogaGFzS2V5LCBhIGJldHRlciBmb3JtIG9mIGhhc093blByb3BlcnR5XG4gKiBFeGFtcGxlOiBoYXNLZXkoTWFpbkhvc3RPYmplY3QsIHByb3BlcnR5KSA9PT0gdHJ1ZS9mYWxzZVxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBob3N0IG9iamVjdCB0byBjaGVjayBwcm9wZXJ0eVxuICogQHBhcmFtIHtzdHJpbmd9IGtleSB0byBjaGVja1xuICovXG5mdW5jdGlvbiBoYXNLZXkob2JqZWN0LCBrZXkpIHtcbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIGtleSk7XG59XG5cbmZ1bmN0aW9uIGpvaW5SZWdFeHAocGF0dGVybnMpIHtcbiAgLy8gQ29tYmluZSBhbiBhcnJheSBvZiByZWd1bGFyIGV4cHJlc3Npb25zIGFuZCBzdHJpbmdzIGludG8gb25lIGxhcmdlIHJlZ2V4cFxuICAvLyBCZSBtYWQuXG4gIHZhciBzb3VyY2VzID0gW10sXG4gICAgaSA9IDAsXG4gICAgbGVuID0gcGF0dGVybnMubGVuZ3RoLFxuICAgIHBhdHRlcm47XG5cbiAgZm9yICg7IGkgPCBsZW47IGkrKykge1xuICAgIHBhdHRlcm4gPSBwYXR0ZXJuc1tpXTtcbiAgICBpZiAoaXNTdHJpbmcocGF0dGVybikpIHtcbiAgICAgIC8vIElmIGl0J3MgYSBzdHJpbmcsIHdlIG5lZWQgdG8gZXNjYXBlIGl0XG4gICAgICAvLyBUYWtlbiBmcm9tOiBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9KYXZhU2NyaXB0L0d1aWRlL1JlZ3VsYXJfRXhwcmVzc2lvbnNcbiAgICAgIHNvdXJjZXMucHVzaChwYXR0ZXJuLnJlcGxhY2UoLyhbLiorP149IToke30oKXxcXFtcXF1cXC9cXFxcXSkvZywgJ1xcXFwkMScpKTtcbiAgICB9IGVsc2UgaWYgKHBhdHRlcm4gJiYgcGF0dGVybi5zb3VyY2UpIHtcbiAgICAgIC8vIElmIGl0J3MgYSByZWdleHAgYWxyZWFkeSwgd2Ugd2FudCB0byBleHRyYWN0IHRoZSBzb3VyY2VcbiAgICAgIHNvdXJjZXMucHVzaChwYXR0ZXJuLnNvdXJjZSk7XG4gICAgfVxuICAgIC8vIEludGVudGlvbmFsbHkgc2tpcCBvdGhlciBjYXNlc1xuICB9XG4gIHJldHVybiBuZXcgUmVnRXhwKHNvdXJjZXMuam9pbignfCcpLCAnaScpO1xufVxuXG5mdW5jdGlvbiB1cmxlbmNvZGUobykge1xuICB2YXIgcGFpcnMgPSBbXTtcbiAgZWFjaChvLCBmdW5jdGlvbihrZXksIHZhbHVlKSB7XG4gICAgcGFpcnMucHVzaChlbmNvZGVVUklDb21wb25lbnQoa2V5KSArICc9JyArIGVuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSkpO1xuICB9KTtcbiAgcmV0dXJuIHBhaXJzLmpvaW4oJyYnKTtcbn1cblxuLy8gYm9ycm93ZWQgZnJvbSBodHRwczovL3Rvb2xzLmlldGYub3JnL2h0bWwvcmZjMzk4NiNhcHBlbmRpeC1CXG4vLyBpbnRlbnRpb25hbGx5IHVzaW5nIHJlZ2V4IGFuZCBub3QgPGEvPiBocmVmIHBhcnNpbmcgdHJpY2sgYmVjYXVzZSBSZWFjdCBOYXRpdmUgYW5kIG90aGVyXG4vLyBlbnZpcm9ubWVudHMgd2hlcmUgRE9NIG1pZ2h0IG5vdCBiZSBhdmFpbGFibGVcbmZ1bmN0aW9uIHBhcnNlVXJsKHVybCkge1xuICBpZiAodHlwZW9mIHVybCAhPT0gJ3N0cmluZycpIHJldHVybiB7fTtcbiAgdmFyIG1hdGNoID0gdXJsLm1hdGNoKC9eKChbXjpcXC8/I10rKTopPyhcXC9cXC8oW15cXC8/I10qKSk/KFtePyNdKikoXFw/KFteI10qKSk/KCMoLiopKT8kLyk7XG5cbiAgLy8gY29lcmNlIHRvIHVuZGVmaW5lZCB2YWx1ZXMgdG8gZW1wdHkgc3RyaW5nIHNvIHdlIGRvbid0IGdldCAndW5kZWZpbmVkJ1xuICB2YXIgcXVlcnkgPSBtYXRjaFs2XSB8fCAnJztcbiAgdmFyIGZyYWdtZW50ID0gbWF0Y2hbOF0gfHwgJyc7XG4gIHJldHVybiB7XG4gICAgcHJvdG9jb2w6IG1hdGNoWzJdLFxuICAgIGhvc3Q6IG1hdGNoWzRdLFxuICAgIHBhdGg6IG1hdGNoWzVdLFxuICAgIHJlbGF0aXZlOiBtYXRjaFs1XSArIHF1ZXJ5ICsgZnJhZ21lbnQgLy8gZXZlcnl0aGluZyBtaW51cyBvcmlnaW5cbiAgfTtcbn1cbmZ1bmN0aW9uIHV1aWQ0KCkge1xuICB2YXIgY3J5cHRvID0gX3dpbmRvdy5jcnlwdG8gfHwgX3dpbmRvdy5tc0NyeXB0bztcblxuICBpZiAoIWlzVW5kZWZpbmVkKGNyeXB0bykgJiYgY3J5cHRvLmdldFJhbmRvbVZhbHVlcykge1xuICAgIC8vIFVzZSB3aW5kb3cuY3J5cHRvIEFQSSBpZiBhdmFpbGFibGVcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdW5kZWZcbiAgICB2YXIgYXJyID0gbmV3IFVpbnQxNkFycmF5KDgpO1xuICAgIGNyeXB0by5nZXRSYW5kb21WYWx1ZXMoYXJyKTtcblxuICAgIC8vIHNldCA0IGluIGJ5dGUgN1xuICAgIGFyclszXSA9IChhcnJbM10gJiAweGZmZikgfCAweDQwMDA7XG4gICAgLy8gc2V0IDIgbW9zdCBzaWduaWZpY2FudCBiaXRzIG9mIGJ5dGUgOSB0byAnMTAnXG4gICAgYXJyWzRdID0gKGFycls0XSAmIDB4M2ZmZikgfCAweDgwMDA7XG5cbiAgICB2YXIgcGFkID0gZnVuY3Rpb24obnVtKSB7XG4gICAgICB2YXIgdiA9IG51bS50b1N0cmluZygxNik7XG4gICAgICB3aGlsZSAodi5sZW5ndGggPCA0KSB7XG4gICAgICAgIHYgPSAnMCcgKyB2O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHY7XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICBwYWQoYXJyWzBdKSArXG4gICAgICBwYWQoYXJyWzFdKSArXG4gICAgICBwYWQoYXJyWzJdKSArXG4gICAgICBwYWQoYXJyWzNdKSArXG4gICAgICBwYWQoYXJyWzRdKSArXG4gICAgICBwYWQoYXJyWzVdKSArXG4gICAgICBwYWQoYXJyWzZdKSArXG4gICAgICBwYWQoYXJyWzddKVxuICAgICk7XG4gIH0gZWxzZSB7XG4gICAgLy8gaHR0cDovL3N0YWNrb3ZlcmZsb3cuY29tL3F1ZXN0aW9ucy8xMDUwMzQvaG93LXRvLWNyZWF0ZS1hLWd1aWQtdXVpZC1pbi1qYXZhc2NyaXB0LzIxMTc1MjMjMjExNzUyM1xuICAgIHJldHVybiAneHh4eHh4eHh4eHh4NHh4eHl4eHh4eHh4eHh4eHh4eHgnLnJlcGxhY2UoL1t4eV0vZywgZnVuY3Rpb24oYykge1xuICAgICAgdmFyIHIgPSAoTWF0aC5yYW5kb20oKSAqIDE2KSB8IDAsXG4gICAgICAgIHYgPSBjID09PSAneCcgPyByIDogKHIgJiAweDMpIHwgMHg4O1xuICAgICAgcmV0dXJuIHYudG9TdHJpbmcoMTYpO1xuICAgIH0pO1xuICB9XG59XG5cbi8qKlxuICogR2l2ZW4gYSBjaGlsZCBET00gZWxlbWVudCwgcmV0dXJucyBhIHF1ZXJ5LXNlbGVjdG9yIHN0YXRlbWVudCBkZXNjcmliaW5nIHRoYXRcbiAqIGFuZCBpdHMgYW5jZXN0b3JzXG4gKiBlLmcuIFtIVE1MRWxlbWVudF0gPT4gYm9keSA+IGRpdiA+IGlucHV0I2Zvby5idG5bbmFtZT1iYXpdXG4gKiBAcGFyYW0gZWxlbVxuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZnVuY3Rpb24gaHRtbFRyZWVBc1N0cmluZyhlbGVtKSB7XG4gIC8qIGVzbGludCBuby1leHRyYS1wYXJlbnM6MCovXG4gIHZhciBNQVhfVFJBVkVSU0VfSEVJR0hUID0gNSxcbiAgICBNQVhfT1VUUFVUX0xFTiA9IDgwLFxuICAgIG91dCA9IFtdLFxuICAgIGhlaWdodCA9IDAsXG4gICAgbGVuID0gMCxcbiAgICBzZXBhcmF0b3IgPSAnID4gJyxcbiAgICBzZXBMZW5ndGggPSBzZXBhcmF0b3IubGVuZ3RoLFxuICAgIG5leHRTdHI7XG5cbiAgd2hpbGUgKGVsZW0gJiYgaGVpZ2h0KysgPCBNQVhfVFJBVkVSU0VfSEVJR0hUKSB7XG4gICAgbmV4dFN0ciA9IGh0bWxFbGVtZW50QXNTdHJpbmcoZWxlbSk7XG4gICAgLy8gYmFpbCBvdXQgaWZcbiAgICAvLyAtIG5leHRTdHIgaXMgdGhlICdodG1sJyBlbGVtZW50XG4gICAgLy8gLSB0aGUgbGVuZ3RoIG9mIHRoZSBzdHJpbmcgdGhhdCB3b3VsZCBiZSBjcmVhdGVkIGV4Y2VlZHMgTUFYX09VVFBVVF9MRU5cbiAgICAvLyAgIChpZ25vcmUgdGhpcyBsaW1pdCBpZiB3ZSBhcmUgb24gdGhlIGZpcnN0IGl0ZXJhdGlvbilcbiAgICBpZiAoXG4gICAgICBuZXh0U3RyID09PSAnaHRtbCcgfHxcbiAgICAgIChoZWlnaHQgPiAxICYmIGxlbiArIG91dC5sZW5ndGggKiBzZXBMZW5ndGggKyBuZXh0U3RyLmxlbmd0aCA+PSBNQVhfT1VUUFVUX0xFTilcbiAgICApIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIG91dC5wdXNoKG5leHRTdHIpO1xuXG4gICAgbGVuICs9IG5leHRTdHIubGVuZ3RoO1xuICAgIGVsZW0gPSBlbGVtLnBhcmVudE5vZGU7XG4gIH1cblxuICByZXR1cm4gb3V0LnJldmVyc2UoKS5qb2luKHNlcGFyYXRvcik7XG59XG5cbi8qKlxuICogUmV0dXJucyBhIHNpbXBsZSwgcXVlcnktc2VsZWN0b3IgcmVwcmVzZW50YXRpb24gb2YgYSBET00gZWxlbWVudFxuICogZS5nLiBbSFRNTEVsZW1lbnRdID0+IGlucHV0I2Zvby5idG5bbmFtZT1iYXpdXG4gKiBAcGFyYW0gSFRNTEVsZW1lbnRcbiAqIEByZXR1cm5zIHtzdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIGh0bWxFbGVtZW50QXNTdHJpbmcoZWxlbSkge1xuICB2YXIgb3V0ID0gW10sXG4gICAgY2xhc3NOYW1lLFxuICAgIGNsYXNzZXMsXG4gICAga2V5LFxuICAgIGF0dHIsXG4gICAgaTtcblxuICBpZiAoIWVsZW0gfHwgIWVsZW0udGFnTmFtZSkge1xuICAgIHJldHVybiAnJztcbiAgfVxuXG4gIG91dC5wdXNoKGVsZW0udGFnTmFtZS50b0xvd2VyQ2FzZSgpKTtcbiAgaWYgKGVsZW0uaWQpIHtcbiAgICBvdXQucHVzaCgnIycgKyBlbGVtLmlkKTtcbiAgfVxuXG4gIGNsYXNzTmFtZSA9IGVsZW0uY2xhc3NOYW1lO1xuICBpZiAoY2xhc3NOYW1lICYmIGlzU3RyaW5nKGNsYXNzTmFtZSkpIHtcbiAgICBjbGFzc2VzID0gY2xhc3NOYW1lLnNwbGl0KC9cXHMrLyk7XG4gICAgZm9yIChpID0gMDsgaSA8IGNsYXNzZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIG91dC5wdXNoKCcuJyArIGNsYXNzZXNbaV0pO1xuICAgIH1cbiAgfVxuICB2YXIgYXR0cldoaXRlbGlzdCA9IFsndHlwZScsICduYW1lJywgJ3RpdGxlJywgJ2FsdCddO1xuICBmb3IgKGkgPSAwOyBpIDwgYXR0cldoaXRlbGlzdC5sZW5ndGg7IGkrKykge1xuICAgIGtleSA9IGF0dHJXaGl0ZWxpc3RbaV07XG4gICAgYXR0ciA9IGVsZW0uZ2V0QXR0cmlidXRlKGtleSk7XG4gICAgaWYgKGF0dHIpIHtcbiAgICAgIG91dC5wdXNoKCdbJyArIGtleSArICc9XCInICsgYXR0ciArICdcIl0nKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dC5qb2luKCcnKTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRydWUgaWYgZWl0aGVyIGEgT1IgYiBpcyB0cnV0aHksIGJ1dCBub3QgYm90aFxuICovXG5mdW5jdGlvbiBpc09ubHlPbmVUcnV0aHkoYSwgYikge1xuICByZXR1cm4gISEoISFhIF4gISFiKTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRydWUgaWYgYm90aCBwYXJhbWV0ZXJzIGFyZSB1bmRlZmluZWRcbiAqL1xuZnVuY3Rpb24gaXNCb3RoVW5kZWZpbmVkKGEsIGIpIHtcbiAgcmV0dXJuIGlzVW5kZWZpbmVkKGEpICYmIGlzVW5kZWZpbmVkKGIpO1xufVxuXG4vKipcbiAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgdHdvIGlucHV0IGV4Y2VwdGlvbiBpbnRlcmZhY2VzIGhhdmUgdGhlIHNhbWUgY29udGVudFxuICovXG5mdW5jdGlvbiBpc1NhbWVFeGNlcHRpb24oZXgxLCBleDIpIHtcbiAgaWYgKGlzT25seU9uZVRydXRoeShleDEsIGV4MikpIHJldHVybiBmYWxzZTtcblxuICBleDEgPSBleDEudmFsdWVzWzBdO1xuICBleDIgPSBleDIudmFsdWVzWzBdO1xuXG4gIGlmIChleDEudHlwZSAhPT0gZXgyLnR5cGUgfHwgZXgxLnZhbHVlICE9PSBleDIudmFsdWUpIHJldHVybiBmYWxzZTtcblxuICAvLyBpbiBjYXNlIGJvdGggc3RhY2t0cmFjZXMgYXJlIHVuZGVmaW5lZCwgd2UgY2FuJ3QgZGVjaWRlIHNvIGRlZmF1bHQgdG8gZmFsc2VcbiAgaWYgKGlzQm90aFVuZGVmaW5lZChleDEuc3RhY2t0cmFjZSwgZXgyLnN0YWNrdHJhY2UpKSByZXR1cm4gZmFsc2U7XG5cbiAgcmV0dXJuIGlzU2FtZVN0YWNrdHJhY2UoZXgxLnN0YWNrdHJhY2UsIGV4Mi5zdGFja3RyYWNlKTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRydWUgaWYgdGhlIHR3byBpbnB1dCBzdGFjayB0cmFjZSBpbnRlcmZhY2VzIGhhdmUgdGhlIHNhbWUgY29udGVudFxuICovXG5mdW5jdGlvbiBpc1NhbWVTdGFja3RyYWNlKHN0YWNrMSwgc3RhY2syKSB7XG4gIGlmIChpc09ubHlPbmVUcnV0aHkoc3RhY2sxLCBzdGFjazIpKSByZXR1cm4gZmFsc2U7XG5cbiAgdmFyIGZyYW1lczEgPSBzdGFjazEuZnJhbWVzO1xuICB2YXIgZnJhbWVzMiA9IHN0YWNrMi5mcmFtZXM7XG5cbiAgLy8gRXhpdCBlYXJseSBpZiBzdGFja3RyYWNlIGlzIG1hbGZvcm1lZFxuICBpZiAoZnJhbWVzMSA9PT0gdW5kZWZpbmVkIHx8IGZyYW1lczIgPT09IHVuZGVmaW5lZCkgcmV0dXJuIGZhbHNlO1xuXG4gIC8vIEV4aXQgZWFybHkgaWYgZnJhbWUgY291bnQgZGlmZmVyc1xuICBpZiAoZnJhbWVzMS5sZW5ndGggIT09IGZyYW1lczIubGVuZ3RoKSByZXR1cm4gZmFsc2U7XG5cbiAgLy8gSXRlcmF0ZSB0aHJvdWdoIGV2ZXJ5IGZyYW1lOyBiYWlsIG91dCBpZiBhbnl0aGluZyBkaWZmZXJzXG4gIHZhciBhLCBiO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IGZyYW1lczEubGVuZ3RoOyBpKyspIHtcbiAgICBhID0gZnJhbWVzMVtpXTtcbiAgICBiID0gZnJhbWVzMltpXTtcbiAgICBpZiAoXG4gICAgICBhLmZpbGVuYW1lICE9PSBiLmZpbGVuYW1lIHx8XG4gICAgICBhLmxpbmVubyAhPT0gYi5saW5lbm8gfHxcbiAgICAgIGEuY29sbm8gIT09IGIuY29sbm8gfHxcbiAgICAgIGFbJ2Z1bmN0aW9uJ10gIT09IGJbJ2Z1bmN0aW9uJ11cbiAgICApXG4gICAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5cbi8qKlxuICogUG9seWZpbGwgYSBtZXRob2RcbiAqIEBwYXJhbSBvYmogb2JqZWN0IGUuZy4gYGRvY3VtZW50YFxuICogQHBhcmFtIG5hbWUgbWV0aG9kIG5hbWUgcHJlc2VudCBvbiBvYmplY3QgZS5nLiBgYWRkRXZlbnRMaXN0ZW5lcmBcbiAqIEBwYXJhbSByZXBsYWNlbWVudCByZXBsYWNlbWVudCBmdW5jdGlvblxuICogQHBhcmFtIHRyYWNrIHtvcHRpb25hbH0gcmVjb3JkIGluc3RydW1lbnRhdGlvbiB0byBhbiBhcnJheVxuICovXG5mdW5jdGlvbiBmaWxsKG9iaiwgbmFtZSwgcmVwbGFjZW1lbnQsIHRyYWNrKSB7XG4gIGlmIChvYmogPT0gbnVsbCkgcmV0dXJuO1xuICB2YXIgb3JpZyA9IG9ialtuYW1lXTtcbiAgb2JqW25hbWVdID0gcmVwbGFjZW1lbnQob3JpZyk7XG4gIG9ialtuYW1lXS5fX3JhdmVuX18gPSB0cnVlO1xuICBvYmpbbmFtZV0uX19vcmlnX18gPSBvcmlnO1xuICBpZiAodHJhY2spIHtcbiAgICB0cmFjay5wdXNoKFtvYmosIG5hbWUsIG9yaWddKTtcbiAgfVxufVxuXG4vKipcbiAqIEpvaW4gdmFsdWVzIGluIGFycmF5XG4gKiBAcGFyYW0gaW5wdXQgYXJyYXkgb2YgdmFsdWVzIHRvIGJlIGpvaW5lZCB0b2dldGhlclxuICogQHBhcmFtIGRlbGltaXRlciBzdHJpbmcgdG8gYmUgcGxhY2VkIGluLWJldHdlZW4gdmFsdWVzXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5mdW5jdGlvbiBzYWZlSm9pbihpbnB1dCwgZGVsaW1pdGVyKSB7XG4gIGlmICghaXNBcnJheShpbnB1dCkpIHJldHVybiAnJztcblxuICB2YXIgb3V0cHV0ID0gW107XG5cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBpbnB1dC5sZW5ndGg7IGkrKykge1xuICAgIHRyeSB7XG4gICAgICBvdXRwdXQucHVzaChTdHJpbmcoaW5wdXRbaV0pKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBvdXRwdXQucHVzaCgnW3ZhbHVlIGNhbm5vdCBiZSBzZXJpYWxpemVkXScpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBvdXRwdXQuam9pbihkZWxpbWl0ZXIpO1xufVxuXG4vLyBEZWZhdWx0IE5vZGUuanMgUkVQTCBkZXB0aFxudmFyIE1BWF9TRVJJQUxJWkVfRVhDRVBUSU9OX0RFUFRIID0gMztcbi8vIDUwa0IsIGFzIDEwMGtCIGlzIG1heCBwYXlsb2FkIHNpemUsIHNvIGhhbGYgc291bmRzIHJlYXNvbmFibGVcbnZhciBNQVhfU0VSSUFMSVpFX0VYQ0VQVElPTl9TSVpFID0gNTAgKiAxMDI0O1xudmFyIE1BWF9TRVJJQUxJWkVfS0VZU19MRU5HVEggPSA0MDtcblxuZnVuY3Rpb24gdXRmOExlbmd0aCh2YWx1ZSkge1xuICByZXR1cm4gfi1lbmNvZGVVUkkodmFsdWUpLnNwbGl0KC8lLi58Li8pLmxlbmd0aDtcbn1cblxuZnVuY3Rpb24ganNvblNpemUodmFsdWUpIHtcbiAgcmV0dXJuIHV0ZjhMZW5ndGgoSlNPTi5zdHJpbmdpZnkodmFsdWUpKTtcbn1cblxuZnVuY3Rpb24gc2VyaWFsaXplVmFsdWUodmFsdWUpIHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICB2YXIgbWF4TGVuZ3RoID0gNDA7XG4gICAgcmV0dXJuIHRydW5jYXRlKHZhbHVlLCBtYXhMZW5ndGgpO1xuICB9IGVsc2UgaWYgKFxuICAgIHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicgfHxcbiAgICB0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJyB8fFxuICAgIHR5cGVvZiB2YWx1ZSA9PT0gJ3VuZGVmaW5lZCdcbiAgKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG5cbiAgdmFyIHR5cGUgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpO1xuXG4gIC8vIE5vZGUuanMgUkVQTCBub3RhdGlvblxuICBpZiAodHlwZSA9PT0gJ1tvYmplY3QgT2JqZWN0XScpIHJldHVybiAnW09iamVjdF0nO1xuICBpZiAodHlwZSA9PT0gJ1tvYmplY3QgQXJyYXldJykgcmV0dXJuICdbQXJyYXldJztcbiAgaWYgKHR5cGUgPT09ICdbb2JqZWN0IEZ1bmN0aW9uXScpXG4gICAgcmV0dXJuIHZhbHVlLm5hbWUgPyAnW0Z1bmN0aW9uOiAnICsgdmFsdWUubmFtZSArICddJyA6ICdbRnVuY3Rpb25dJztcblxuICByZXR1cm4gdmFsdWU7XG59XG5cbmZ1bmN0aW9uIHNlcmlhbGl6ZU9iamVjdCh2YWx1ZSwgZGVwdGgpIHtcbiAgaWYgKGRlcHRoID09PSAwKSByZXR1cm4gc2VyaWFsaXplVmFsdWUodmFsdWUpO1xuXG4gIGlmIChpc1BsYWluT2JqZWN0KHZhbHVlKSkge1xuICAgIHJldHVybiBPYmplY3Qua2V5cyh2YWx1ZSkucmVkdWNlKGZ1bmN0aW9uKGFjYywga2V5KSB7XG4gICAgICBhY2Nba2V5XSA9IHNlcmlhbGl6ZU9iamVjdCh2YWx1ZVtrZXldLCBkZXB0aCAtIDEpO1xuICAgICAgcmV0dXJuIGFjYztcbiAgICB9LCB7fSk7XG4gIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICByZXR1cm4gdmFsdWUubWFwKGZ1bmN0aW9uKHZhbCkge1xuICAgICAgcmV0dXJuIHNlcmlhbGl6ZU9iamVjdCh2YWwsIGRlcHRoIC0gMSk7XG4gICAgfSk7XG4gIH1cblxuICByZXR1cm4gc2VyaWFsaXplVmFsdWUodmFsdWUpO1xufVxuXG5mdW5jdGlvbiBzZXJpYWxpemVFeGNlcHRpb24oZXgsIGRlcHRoLCBtYXhTaXplKSB7XG4gIGlmICghaXNQbGFpbk9iamVjdChleCkpIHJldHVybiBleDtcblxuICBkZXB0aCA9IHR5cGVvZiBkZXB0aCAhPT0gJ251bWJlcicgPyBNQVhfU0VSSUFMSVpFX0VYQ0VQVElPTl9ERVBUSCA6IGRlcHRoO1xuICBtYXhTaXplID0gdHlwZW9mIGRlcHRoICE9PSAnbnVtYmVyJyA/IE1BWF9TRVJJQUxJWkVfRVhDRVBUSU9OX1NJWkUgOiBtYXhTaXplO1xuXG4gIHZhciBzZXJpYWxpemVkID0gc2VyaWFsaXplT2JqZWN0KGV4LCBkZXB0aCk7XG5cbiAgaWYgKGpzb25TaXplKHN0cmluZ2lmeShzZXJpYWxpemVkKSkgPiBtYXhTaXplKSB7XG4gICAgcmV0dXJuIHNlcmlhbGl6ZUV4Y2VwdGlvbihleCwgZGVwdGggLSAxKTtcbiAgfVxuXG4gIHJldHVybiBzZXJpYWxpemVkO1xufVxuXG5mdW5jdGlvbiBzZXJpYWxpemVLZXlzRm9yTWVzc2FnZShrZXlzLCBtYXhMZW5ndGgpIHtcbiAgaWYgKHR5cGVvZiBrZXlzID09PSAnbnVtYmVyJyB8fCB0eXBlb2Yga2V5cyA9PT0gJ3N0cmluZycpIHJldHVybiBrZXlzLnRvU3RyaW5nKCk7XG4gIGlmICghQXJyYXkuaXNBcnJheShrZXlzKSkgcmV0dXJuICcnO1xuXG4gIGtleXMgPSBrZXlzLmZpbHRlcihmdW5jdGlvbihrZXkpIHtcbiAgICByZXR1cm4gdHlwZW9mIGtleSA9PT0gJ3N0cmluZyc7XG4gIH0pO1xuICBpZiAoa2V5cy5sZW5ndGggPT09IDApIHJldHVybiAnW29iamVjdCBoYXMgbm8ga2V5c10nO1xuXG4gIG1heExlbmd0aCA9IHR5cGVvZiBtYXhMZW5ndGggIT09ICdudW1iZXInID8gTUFYX1NFUklBTElaRV9LRVlTX0xFTkdUSCA6IG1heExlbmd0aDtcbiAgaWYgKGtleXNbMF0ubGVuZ3RoID49IG1heExlbmd0aCkgcmV0dXJuIGtleXNbMF07XG5cbiAgZm9yICh2YXIgdXNlZEtleXMgPSBrZXlzLmxlbmd0aDsgdXNlZEtleXMgPiAwOyB1c2VkS2V5cy0tKSB7XG4gICAgdmFyIHNlcmlhbGl6ZWQgPSBrZXlzLnNsaWNlKDAsIHVzZWRLZXlzKS5qb2luKCcsICcpO1xuICAgIGlmIChzZXJpYWxpemVkLmxlbmd0aCA+IG1heExlbmd0aCkgY29udGludWU7XG4gICAgaWYgKHVzZWRLZXlzID09PSBrZXlzLmxlbmd0aCkgcmV0dXJuIHNlcmlhbGl6ZWQ7XG4gICAgcmV0dXJuIHNlcmlhbGl6ZWQgKyAnXFx1MjAyNic7XG4gIH1cblxuICByZXR1cm4gJyc7XG59XG5cbmZ1bmN0aW9uIHNhbml0aXplKGlucHV0LCBzYW5pdGl6ZUtleXMpIHtcbiAgaWYgKCFpc0FycmF5KHNhbml0aXplS2V5cykgfHwgKGlzQXJyYXkoc2FuaXRpemVLZXlzKSAmJiBzYW5pdGl6ZUtleXMubGVuZ3RoID09PSAwKSlcbiAgICByZXR1cm4gaW5wdXQ7XG5cbiAgdmFyIHNhbml0aXplUmVnRXhwID0gam9pblJlZ0V4cChzYW5pdGl6ZUtleXMpO1xuICB2YXIgc2FuaXRpemVNYXNrID0gJyoqKioqKioqJztcbiAgdmFyIHNhZmVJbnB1dDtcblxuICB0cnkge1xuICAgIHNhZmVJbnB1dCA9IEpTT04ucGFyc2Uoc3RyaW5naWZ5KGlucHV0KSk7XG4gIH0gY2F0Y2ggKG9fTykge1xuICAgIHJldHVybiBpbnB1dDtcbiAgfVxuXG4gIGZ1bmN0aW9uIHNhbml0aXplV29ya2VyKHdvcmtlcklucHV0KSB7XG4gICAgaWYgKGlzQXJyYXkod29ya2VySW5wdXQpKSB7XG4gICAgICByZXR1cm4gd29ya2VySW5wdXQubWFwKGZ1bmN0aW9uKHZhbCkge1xuICAgICAgICByZXR1cm4gc2FuaXRpemVXb3JrZXIodmFsKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGlmIChpc1BsYWluT2JqZWN0KHdvcmtlcklucHV0KSkge1xuICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKHdvcmtlcklucHV0KS5yZWR1Y2UoZnVuY3Rpb24oYWNjLCBrKSB7XG4gICAgICAgIGlmIChzYW5pdGl6ZVJlZ0V4cC50ZXN0KGspKSB7XG4gICAgICAgICAgYWNjW2tdID0gc2FuaXRpemVNYXNrO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGFjY1trXSA9IHNhbml0aXplV29ya2VyKHdvcmtlcklucHV0W2tdKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYWNjO1xuICAgICAgfSwge30pO1xuICAgIH1cblxuICAgIHJldHVybiB3b3JrZXJJbnB1dDtcbiAgfVxuXG4gIHJldHVybiBzYW5pdGl6ZVdvcmtlcihzYWZlSW5wdXQpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgaXNPYmplY3Q6IGlzT2JqZWN0LFxuICBpc0Vycm9yOiBpc0Vycm9yLFxuICBpc0Vycm9yRXZlbnQ6IGlzRXJyb3JFdmVudCxcbiAgaXNET01FcnJvcjogaXNET01FcnJvcixcbiAgaXNET01FeGNlcHRpb246IGlzRE9NRXhjZXB0aW9uLFxuICBpc1VuZGVmaW5lZDogaXNVbmRlZmluZWQsXG4gIGlzRnVuY3Rpb246IGlzRnVuY3Rpb24sXG4gIGlzUGxhaW5PYmplY3Q6IGlzUGxhaW5PYmplY3QsXG4gIGlzU3RyaW5nOiBpc1N0cmluZyxcbiAgaXNBcnJheTogaXNBcnJheSxcbiAgaXNFbXB0eU9iamVjdDogaXNFbXB0eU9iamVjdCxcbiAgc3VwcG9ydHNFcnJvckV2ZW50OiBzdXBwb3J0c0Vycm9yRXZlbnQsXG4gIHN1cHBvcnRzRE9NRXJyb3I6IHN1cHBvcnRzRE9NRXJyb3IsXG4gIHN1cHBvcnRzRE9NRXhjZXB0aW9uOiBzdXBwb3J0c0RPTUV4Y2VwdGlvbixcbiAgc3VwcG9ydHNGZXRjaDogc3VwcG9ydHNGZXRjaCxcbiAgc3VwcG9ydHNSZWZlcnJlclBvbGljeTogc3VwcG9ydHNSZWZlcnJlclBvbGljeSxcbiAgc3VwcG9ydHNQcm9taXNlUmVqZWN0aW9uRXZlbnQ6IHN1cHBvcnRzUHJvbWlzZVJlamVjdGlvbkV2ZW50LFxuICB3cmFwcGVkQ2FsbGJhY2s6IHdyYXBwZWRDYWxsYmFjayxcbiAgZWFjaDogZWFjaCxcbiAgb2JqZWN0TWVyZ2U6IG9iamVjdE1lcmdlLFxuICB0cnVuY2F0ZTogdHJ1bmNhdGUsXG4gIG9iamVjdEZyb3plbjogb2JqZWN0RnJvemVuLFxuICBoYXNLZXk6IGhhc0tleSxcbiAgam9pblJlZ0V4cDogam9pblJlZ0V4cCxcbiAgdXJsZW5jb2RlOiB1cmxlbmNvZGUsXG4gIHV1aWQ0OiB1dWlkNCxcbiAgaHRtbFRyZWVBc1N0cmluZzogaHRtbFRyZWVBc1N0cmluZyxcbiAgaHRtbEVsZW1lbnRBc1N0cmluZzogaHRtbEVsZW1lbnRBc1N0cmluZyxcbiAgaXNTYW1lRXhjZXB0aW9uOiBpc1NhbWVFeGNlcHRpb24sXG4gIGlzU2FtZVN0YWNrdHJhY2U6IGlzU2FtZVN0YWNrdHJhY2UsXG4gIHBhcnNlVXJsOiBwYXJzZVVybCxcbiAgZmlsbDogZmlsbCxcbiAgc2FmZUpvaW46IHNhZmVKb2luLFxuICBzZXJpYWxpemVFeGNlcHRpb246IHNlcmlhbGl6ZUV4Y2VwdGlvbixcbiAgc2VyaWFsaXplS2V5c0Zvck1lc3NhZ2U6IHNlcmlhbGl6ZUtleXNGb3JNZXNzYWdlLFxuICBzYW5pdGl6ZTogc2FuaXRpemVcbn07XG4iLCJ2YXIgdXRpbHMgPSByZXF1aXJlKCcuLi8uLi9zcmMvdXRpbHMnKTtcblxuLypcbiBUcmFjZUtpdCAtIENyb3NzIGJyb3dlciBzdGFjayB0cmFjZXNcblxuIFRoaXMgd2FzIG9yaWdpbmFsbHkgZm9ya2VkIGZyb20gZ2l0aHViLmNvbS9vY2MvVHJhY2VLaXQsIGJ1dCBoYXMgc2luY2UgYmVlblxuIGxhcmdlbHkgcmUtd3JpdHRlbiBhbmQgaXMgbm93IG1haW50YWluZWQgYXMgcGFydCBvZiByYXZlbi1qcy4gIFRlc3RzIGZvclxuIHRoaXMgYXJlIGluIHRlc3QvdmVuZG9yLlxuXG4gTUlUIGxpY2Vuc2VcbiovXG5cbnZhciBUcmFjZUtpdCA9IHtcbiAgY29sbGVjdFdpbmRvd0Vycm9yczogdHJ1ZSxcbiAgZGVidWc6IGZhbHNlXG59O1xuXG4vLyBUaGlzIGlzIHRvIGJlIGRlZmVuc2l2ZSBpbiBlbnZpcm9ubWVudHMgd2hlcmUgd2luZG93IGRvZXMgbm90IGV4aXN0IChzZWUgaHR0cHM6Ly9naXRodWIuY29tL2dldHNlbnRyeS9yYXZlbi1qcy9wdWxsLzc4NSlcbnZhciBfd2luZG93ID1cbiAgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCdcbiAgICA/IHdpbmRvd1xuICAgIDogdHlwZW9mIGdsb2JhbCAhPT0gJ3VuZGVmaW5lZCdcbiAgICA/IGdsb2JhbFxuICAgIDogdHlwZW9mIHNlbGYgIT09ICd1bmRlZmluZWQnXG4gICAgPyBzZWxmXG4gICAgOiB7fTtcblxuLy8gZ2xvYmFsIHJlZmVyZW5jZSB0byBzbGljZVxudmFyIF9zbGljZSA9IFtdLnNsaWNlO1xudmFyIFVOS05PV05fRlVOQ1RJT04gPSAnPyc7XG5cbi8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0phdmFTY3JpcHQvUmVmZXJlbmNlL0dsb2JhbF9PYmplY3RzL0Vycm9yI0Vycm9yX3R5cGVzXG52YXIgRVJST1JfVFlQRVNfUkUgPSAvXig/OltVdV1uY2F1Z2h0ICg/OmV4Y2VwdGlvbjogKT8pPyg/OigoPzpFdmFsfEludGVybmFsfFJhbmdlfFJlZmVyZW5jZXxTeW50YXh8VHlwZXxVUkl8KUVycm9yKTogKT8oLiopJC87XG5cbmZ1bmN0aW9uIGdldExvY2F0aW9uSHJlZigpIHtcbiAgaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcgfHwgZG9jdW1lbnQubG9jYXRpb24gPT0gbnVsbCkgcmV0dXJuICcnO1xuICByZXR1cm4gZG9jdW1lbnQubG9jYXRpb24uaHJlZjtcbn1cblxuZnVuY3Rpb24gZ2V0TG9jYXRpb25PcmlnaW4oKSB7XG4gIGlmICh0eXBlb2YgZG9jdW1lbnQgPT09ICd1bmRlZmluZWQnIHx8IGRvY3VtZW50LmxvY2F0aW9uID09IG51bGwpIHJldHVybiAnJztcblxuICAvLyBPaCBkZWFyIElFMTAuLi5cbiAgaWYgKCFkb2N1bWVudC5sb2NhdGlvbi5vcmlnaW4pIHtcbiAgICByZXR1cm4gKFxuICAgICAgZG9jdW1lbnQubG9jYXRpb24ucHJvdG9jb2wgK1xuICAgICAgJy8vJyArXG4gICAgICBkb2N1bWVudC5sb2NhdGlvbi5ob3N0bmFtZSArXG4gICAgICAoZG9jdW1lbnQubG9jYXRpb24ucG9ydCA/ICc6JyArIGRvY3VtZW50LmxvY2F0aW9uLnBvcnQgOiAnJylcbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIGRvY3VtZW50LmxvY2F0aW9uLm9yaWdpbjtcbn1cblxuLyoqXG4gKiBUcmFjZUtpdC5yZXBvcnQ6IGNyb3NzLWJyb3dzZXIgcHJvY2Vzc2luZyBvZiB1bmhhbmRsZWQgZXhjZXB0aW9uc1xuICpcbiAqIFN5bnRheDpcbiAqICAgVHJhY2VLaXQucmVwb3J0LnN1YnNjcmliZShmdW5jdGlvbihzdGFja0luZm8pIHsgLi4uIH0pXG4gKiAgIFRyYWNlS2l0LnJlcG9ydC51bnN1YnNjcmliZShmdW5jdGlvbihzdGFja0luZm8pIHsgLi4uIH0pXG4gKiAgIFRyYWNlS2l0LnJlcG9ydChleGNlcHRpb24pXG4gKiAgIHRyeSB7IC4uLmNvZGUuLi4gfSBjYXRjaChleCkgeyBUcmFjZUtpdC5yZXBvcnQoZXgpOyB9XG4gKlxuICogU3VwcG9ydHM6XG4gKiAgIC0gRmlyZWZveDogZnVsbCBzdGFjayB0cmFjZSB3aXRoIGxpbmUgbnVtYmVycywgcGx1cyBjb2x1bW4gbnVtYmVyXG4gKiAgICAgICAgICAgICAgb24gdG9wIGZyYW1lOyBjb2x1bW4gbnVtYmVyIGlzIG5vdCBndWFyYW50ZWVkXG4gKiAgIC0gT3BlcmE6ICAgZnVsbCBzdGFjayB0cmFjZSB3aXRoIGxpbmUgYW5kIGNvbHVtbiBudW1iZXJzXG4gKiAgIC0gQ2hyb21lOiAgZnVsbCBzdGFjayB0cmFjZSB3aXRoIGxpbmUgYW5kIGNvbHVtbiBudW1iZXJzXG4gKiAgIC0gU2FmYXJpOiAgbGluZSBhbmQgY29sdW1uIG51bWJlciBmb3IgdGhlIHRvcCBmcmFtZSBvbmx5OyBzb21lIGZyYW1lc1xuICogICAgICAgICAgICAgIG1heSBiZSBtaXNzaW5nLCBhbmQgY29sdW1uIG51bWJlciBpcyBub3QgZ3VhcmFudGVlZFxuICogICAtIElFOiAgICAgIGxpbmUgYW5kIGNvbHVtbiBudW1iZXIgZm9yIHRoZSB0b3AgZnJhbWUgb25seTsgc29tZSBmcmFtZXNcbiAqICAgICAgICAgICAgICBtYXkgYmUgbWlzc2luZywgYW5kIGNvbHVtbiBudW1iZXIgaXMgbm90IGd1YXJhbnRlZWRcbiAqXG4gKiBJbiB0aGVvcnksIFRyYWNlS2l0IHNob3VsZCB3b3JrIG9uIGFsbCBvZiB0aGUgZm9sbG93aW5nIHZlcnNpb25zOlxuICogICAtIElFNS41KyAob25seSA4LjAgdGVzdGVkKVxuICogICAtIEZpcmVmb3ggMC45KyAob25seSAzLjUrIHRlc3RlZClcbiAqICAgLSBPcGVyYSA3KyAob25seSAxMC41MCB0ZXN0ZWQ7IHZlcnNpb25zIDkgYW5kIGVhcmxpZXIgbWF5IHJlcXVpcmVcbiAqICAgICBFeGNlcHRpb25zIEhhdmUgU3RhY2t0cmFjZSB0byBiZSBlbmFibGVkIGluIG9wZXJhOmNvbmZpZylcbiAqICAgLSBTYWZhcmkgMysgKG9ubHkgNCsgdGVzdGVkKVxuICogICAtIENocm9tZSAxKyAob25seSA1KyB0ZXN0ZWQpXG4gKiAgIC0gS29ucXVlcm9yIDMuNSsgKHVudGVzdGVkKVxuICpcbiAqIFJlcXVpcmVzIFRyYWNlS2l0LmNvbXB1dGVTdGFja1RyYWNlLlxuICpcbiAqIFRyaWVzIHRvIGNhdGNoIGFsbCB1bmhhbmRsZWQgZXhjZXB0aW9ucyBhbmQgcmVwb3J0IHRoZW0gdG8gdGhlXG4gKiBzdWJzY3JpYmVkIGhhbmRsZXJzLiBQbGVhc2Ugbm90ZSB0aGF0IFRyYWNlS2l0LnJlcG9ydCB3aWxsIHJldGhyb3cgdGhlXG4gKiBleGNlcHRpb24uIFRoaXMgaXMgUkVRVUlSRUQgaW4gb3JkZXIgdG8gZ2V0IGEgdXNlZnVsIHN0YWNrIHRyYWNlIGluIElFLlxuICogSWYgdGhlIGV4Y2VwdGlvbiBkb2VzIG5vdCByZWFjaCB0aGUgdG9wIG9mIHRoZSBicm93c2VyLCB5b3Ugd2lsbCBvbmx5XG4gKiBnZXQgYSBzdGFjayB0cmFjZSBmcm9tIHRoZSBwb2ludCB3aGVyZSBUcmFjZUtpdC5yZXBvcnQgd2FzIGNhbGxlZC5cbiAqXG4gKiBIYW5kbGVycyByZWNlaXZlIGEgc3RhY2tJbmZvIG9iamVjdCBhcyBkZXNjcmliZWQgaW4gdGhlXG4gKiBUcmFjZUtpdC5jb21wdXRlU3RhY2tUcmFjZSBkb2NzLlxuICovXG5UcmFjZUtpdC5yZXBvcnQgPSAoZnVuY3Rpb24gcmVwb3J0TW9kdWxlV3JhcHBlcigpIHtcbiAgdmFyIGhhbmRsZXJzID0gW10sXG4gICAgbGFzdEFyZ3MgPSBudWxsLFxuICAgIGxhc3RFeGNlcHRpb24gPSBudWxsLFxuICAgIGxhc3RFeGNlcHRpb25TdGFjayA9IG51bGw7XG5cbiAgLyoqXG4gICAqIEFkZCBhIGNyYXNoIGhhbmRsZXIuXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGhhbmRsZXJcbiAgICovXG4gIGZ1bmN0aW9uIHN1YnNjcmliZShoYW5kbGVyKSB7XG4gICAgaW5zdGFsbEdsb2JhbEhhbmRsZXIoKTtcbiAgICBoYW5kbGVycy5wdXNoKGhhbmRsZXIpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbW92ZSBhIGNyYXNoIGhhbmRsZXIuXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGhhbmRsZXJcbiAgICovXG4gIGZ1bmN0aW9uIHVuc3Vic2NyaWJlKGhhbmRsZXIpIHtcbiAgICBmb3IgKHZhciBpID0gaGFuZGxlcnMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgIGlmIChoYW5kbGVyc1tpXSA9PT0gaGFuZGxlcikge1xuICAgICAgICBoYW5kbGVycy5zcGxpY2UoaSwgMSk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJlbW92ZSBhbGwgY3Jhc2ggaGFuZGxlcnMuXG4gICAqL1xuICBmdW5jdGlvbiB1bnN1YnNjcmliZUFsbCgpIHtcbiAgICB1bmluc3RhbGxHbG9iYWxIYW5kbGVyKCk7XG4gICAgaGFuZGxlcnMgPSBbXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEaXNwYXRjaCBzdGFjayBpbmZvcm1hdGlvbiB0byBhbGwgaGFuZGxlcnMuXG4gICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsICo+fSBzdGFja1xuICAgKi9cbiAgZnVuY3Rpb24gbm90aWZ5SGFuZGxlcnMoc3RhY2ssIGlzV2luZG93RXJyb3IpIHtcbiAgICB2YXIgZXhjZXB0aW9uID0gbnVsbDtcbiAgICBpZiAoaXNXaW5kb3dFcnJvciAmJiAhVHJhY2VLaXQuY29sbGVjdFdpbmRvd0Vycm9ycykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBmb3IgKHZhciBpIGluIGhhbmRsZXJzKSB7XG4gICAgICBpZiAoaGFuZGxlcnMuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBoYW5kbGVyc1tpXS5hcHBseShudWxsLCBbc3RhY2tdLmNvbmNhdChfc2xpY2UuY2FsbChhcmd1bWVudHMsIDIpKSk7XG4gICAgICAgIH0gY2F0Y2ggKGlubmVyKSB7XG4gICAgICAgICAgZXhjZXB0aW9uID0gaW5uZXI7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoZXhjZXB0aW9uKSB7XG4gICAgICB0aHJvdyBleGNlcHRpb247XG4gICAgfVxuICB9XG5cbiAgdmFyIF9vbGRPbmVycm9ySGFuZGxlciwgX29uRXJyb3JIYW5kbGVySW5zdGFsbGVkO1xuXG4gIC8qKlxuICAgKiBFbnN1cmVzIGFsbCBnbG9iYWwgdW5oYW5kbGVkIGV4Y2VwdGlvbnMgYXJlIHJlY29yZGVkLlxuICAgKiBTdXBwb3J0ZWQgYnkgR2Vja28gYW5kIElFLlxuICAgKiBAcGFyYW0ge3N0cmluZ30gbXNnIEVycm9yIG1lc3NhZ2UuXG4gICAqIEBwYXJhbSB7c3RyaW5nfSB1cmwgVVJMIG9mIHNjcmlwdCB0aGF0IGdlbmVyYXRlZCB0aGUgZXhjZXB0aW9uLlxuICAgKiBAcGFyYW0geyhudW1iZXJ8c3RyaW5nKX0gbGluZU5vIFRoZSBsaW5lIG51bWJlciBhdCB3aGljaCB0aGUgZXJyb3JcbiAgICogb2NjdXJyZWQuXG4gICAqIEBwYXJhbSB7PyhudW1iZXJ8c3RyaW5nKX0gY29sTm8gVGhlIGNvbHVtbiBudW1iZXIgYXQgd2hpY2ggdGhlIGVycm9yXG4gICAqIG9jY3VycmVkLlxuICAgKiBAcGFyYW0gez9FcnJvcn0gZXggVGhlIGFjdHVhbCBFcnJvciBvYmplY3QuXG4gICAqL1xuICBmdW5jdGlvbiB0cmFjZUtpdFdpbmRvd09uRXJyb3IobXNnLCB1cmwsIGxpbmVObywgY29sTm8sIGV4KSB7XG4gICAgdmFyIHN0YWNrID0gbnVsbDtcbiAgICAvLyBJZiAnZXgnIGlzIEVycm9yRXZlbnQsIGdldCByZWFsIEVycm9yIGZyb20gaW5zaWRlXG4gICAgdmFyIGV4Y2VwdGlvbiA9IHV0aWxzLmlzRXJyb3JFdmVudChleCkgPyBleC5lcnJvciA6IGV4O1xuICAgIC8vIElmICdtc2cnIGlzIEVycm9yRXZlbnQsIGdldCByZWFsIG1lc3NhZ2UgZnJvbSBpbnNpZGVcbiAgICB2YXIgbWVzc2FnZSA9IHV0aWxzLmlzRXJyb3JFdmVudChtc2cpID8gbXNnLm1lc3NhZ2UgOiBtc2c7XG5cbiAgICBpZiAobGFzdEV4Y2VwdGlvblN0YWNrKSB7XG4gICAgICBUcmFjZUtpdC5jb21wdXRlU3RhY2tUcmFjZS5hdWdtZW50U3RhY2tUcmFjZVdpdGhJbml0aWFsRWxlbWVudChcbiAgICAgICAgbGFzdEV4Y2VwdGlvblN0YWNrLFxuICAgICAgICB1cmwsXG4gICAgICAgIGxpbmVObyxcbiAgICAgICAgbWVzc2FnZVxuICAgICAgKTtcbiAgICAgIHByb2Nlc3NMYXN0RXhjZXB0aW9uKCk7XG4gICAgfSBlbHNlIGlmIChleGNlcHRpb24gJiYgdXRpbHMuaXNFcnJvcihleGNlcHRpb24pKSB7XG4gICAgICAvLyBub24tc3RyaW5nIGBleGNlcHRpb25gIGFyZzsgYXR0ZW1wdCB0byBleHRyYWN0IHN0YWNrIHRyYWNlXG5cbiAgICAgIC8vIE5ldyBjaHJvbWUgYW5kIGJsaW5rIHNlbmQgYWxvbmcgYSByZWFsIGVycm9yIG9iamVjdFxuICAgICAgLy8gTGV0J3MganVzdCByZXBvcnQgdGhhdCBsaWtlIGEgbm9ybWFsIGVycm9yLlxuICAgICAgLy8gU2VlOiBodHRwczovL21pa2V3ZXN0Lm9yZy8yMDEzLzA4L2RlYnVnZ2luZy1ydW50aW1lLWVycm9ycy13aXRoLXdpbmRvdy1vbmVycm9yXG4gICAgICBzdGFjayA9IFRyYWNlS2l0LmNvbXB1dGVTdGFja1RyYWNlKGV4Y2VwdGlvbik7XG4gICAgICBub3RpZnlIYW5kbGVycyhzdGFjaywgdHJ1ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHZhciBsb2NhdGlvbiA9IHtcbiAgICAgICAgdXJsOiB1cmwsXG4gICAgICAgIGxpbmU6IGxpbmVObyxcbiAgICAgICAgY29sdW1uOiBjb2xOb1xuICAgICAgfTtcblxuICAgICAgdmFyIG5hbWUgPSB1bmRlZmluZWQ7XG4gICAgICB2YXIgZ3JvdXBzO1xuXG4gICAgICBpZiAoe30udG9TdHJpbmcuY2FsbChtZXNzYWdlKSA9PT0gJ1tvYmplY3QgU3RyaW5nXScpIHtcbiAgICAgICAgdmFyIGdyb3VwcyA9IG1lc3NhZ2UubWF0Y2goRVJST1JfVFlQRVNfUkUpO1xuICAgICAgICBpZiAoZ3JvdXBzKSB7XG4gICAgICAgICAgbmFtZSA9IGdyb3Vwc1sxXTtcbiAgICAgICAgICBtZXNzYWdlID0gZ3JvdXBzWzJdO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGxvY2F0aW9uLmZ1bmMgPSBVTktOT1dOX0ZVTkNUSU9OO1xuXG4gICAgICBzdGFjayA9IHtcbiAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgbWVzc2FnZTogbWVzc2FnZSxcbiAgICAgICAgdXJsOiBnZXRMb2NhdGlvbkhyZWYoKSxcbiAgICAgICAgc3RhY2s6IFtsb2NhdGlvbl1cbiAgICAgIH07XG4gICAgICBub3RpZnlIYW5kbGVycyhzdGFjaywgdHJ1ZSk7XG4gICAgfVxuXG4gICAgaWYgKF9vbGRPbmVycm9ySGFuZGxlcikge1xuICAgICAgcmV0dXJuIF9vbGRPbmVycm9ySGFuZGxlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGluc3RhbGxHbG9iYWxIYW5kbGVyKCkge1xuICAgIGlmIChfb25FcnJvckhhbmRsZXJJbnN0YWxsZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgX29sZE9uZXJyb3JIYW5kbGVyID0gX3dpbmRvdy5vbmVycm9yO1xuICAgIF93aW5kb3cub25lcnJvciA9IHRyYWNlS2l0V2luZG93T25FcnJvcjtcbiAgICBfb25FcnJvckhhbmRsZXJJbnN0YWxsZWQgPSB0cnVlO1xuICB9XG5cbiAgZnVuY3Rpb24gdW5pbnN0YWxsR2xvYmFsSGFuZGxlcigpIHtcbiAgICBpZiAoIV9vbkVycm9ySGFuZGxlckluc3RhbGxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBfd2luZG93Lm9uZXJyb3IgPSBfb2xkT25lcnJvckhhbmRsZXI7XG4gICAgX29uRXJyb3JIYW5kbGVySW5zdGFsbGVkID0gZmFsc2U7XG4gICAgX29sZE9uZXJyb3JIYW5kbGVyID0gdW5kZWZpbmVkO1xuICB9XG5cbiAgZnVuY3Rpb24gcHJvY2Vzc0xhc3RFeGNlcHRpb24oKSB7XG4gICAgdmFyIF9sYXN0RXhjZXB0aW9uU3RhY2sgPSBsYXN0RXhjZXB0aW9uU3RhY2ssXG4gICAgICBfbGFzdEFyZ3MgPSBsYXN0QXJncztcbiAgICBsYXN0QXJncyA9IG51bGw7XG4gICAgbGFzdEV4Y2VwdGlvblN0YWNrID0gbnVsbDtcbiAgICBsYXN0RXhjZXB0aW9uID0gbnVsbDtcbiAgICBub3RpZnlIYW5kbGVycy5hcHBseShudWxsLCBbX2xhc3RFeGNlcHRpb25TdGFjaywgZmFsc2VdLmNvbmNhdChfbGFzdEFyZ3MpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXBvcnRzIGFuIHVuaGFuZGxlZCBFcnJvciB0byBUcmFjZUtpdC5cbiAgICogQHBhcmFtIHtFcnJvcn0gZXhcbiAgICogQHBhcmFtIHs/Ym9vbGVhbn0gcmV0aHJvdyBJZiBmYWxzZSwgZG8gbm90IHJlLXRocm93IHRoZSBleGNlcHRpb24uXG4gICAqIE9ubHkgdXNlZCBmb3Igd2luZG93Lm9uZXJyb3IgdG8gbm90IGNhdXNlIGFuIGluZmluaXRlIGxvb3Agb2ZcbiAgICogcmV0aHJvd2luZy5cbiAgICovXG4gIGZ1bmN0aW9uIHJlcG9ydChleCwgcmV0aHJvdykge1xuICAgIHZhciBhcmdzID0gX3NsaWNlLmNhbGwoYXJndW1lbnRzLCAxKTtcbiAgICBpZiAobGFzdEV4Y2VwdGlvblN0YWNrKSB7XG4gICAgICBpZiAobGFzdEV4Y2VwdGlvbiA9PT0gZXgpIHtcbiAgICAgICAgcmV0dXJuOyAvLyBhbHJlYWR5IGNhdWdodCBieSBhbiBpbm5lciBjYXRjaCBibG9jaywgaWdub3JlXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwcm9jZXNzTGFzdEV4Y2VwdGlvbigpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHZhciBzdGFjayA9IFRyYWNlS2l0LmNvbXB1dGVTdGFja1RyYWNlKGV4KTtcbiAgICBsYXN0RXhjZXB0aW9uU3RhY2sgPSBzdGFjaztcbiAgICBsYXN0RXhjZXB0aW9uID0gZXg7XG4gICAgbGFzdEFyZ3MgPSBhcmdzO1xuXG4gICAgLy8gSWYgdGhlIHN0YWNrIHRyYWNlIGlzIGluY29tcGxldGUsIHdhaXQgZm9yIDIgc2Vjb25kcyBmb3JcbiAgICAvLyBzbG93IHNsb3cgSUUgdG8gc2VlIGlmIG9uZXJyb3Igb2NjdXJzIG9yIG5vdCBiZWZvcmUgcmVwb3J0aW5nXG4gICAgLy8gdGhpcyBleGNlcHRpb247IG90aGVyd2lzZSwgd2Ugd2lsbCBlbmQgdXAgd2l0aCBhbiBpbmNvbXBsZXRlXG4gICAgLy8gc3RhY2sgdHJhY2VcbiAgICBzZXRUaW1lb3V0KFxuICAgICAgZnVuY3Rpb24oKSB7XG4gICAgICAgIGlmIChsYXN0RXhjZXB0aW9uID09PSBleCkge1xuICAgICAgICAgIHByb2Nlc3NMYXN0RXhjZXB0aW9uKCk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBzdGFjay5pbmNvbXBsZXRlID8gMjAwMCA6IDBcbiAgICApO1xuXG4gICAgaWYgKHJldGhyb3cgIT09IGZhbHNlKSB7XG4gICAgICB0aHJvdyBleDsgLy8gcmUtdGhyb3cgdG8gcHJvcGFnYXRlIHRvIHRoZSB0b3AgbGV2ZWwgKGFuZCBjYXVzZSB3aW5kb3cub25lcnJvcilcbiAgICB9XG4gIH1cblxuICByZXBvcnQuc3Vic2NyaWJlID0gc3Vic2NyaWJlO1xuICByZXBvcnQudW5zdWJzY3JpYmUgPSB1bnN1YnNjcmliZTtcbiAgcmVwb3J0LnVuaW5zdGFsbCA9IHVuc3Vic2NyaWJlQWxsO1xuICByZXR1cm4gcmVwb3J0O1xufSkoKTtcblxuLyoqXG4gKiBUcmFjZUtpdC5jb21wdXRlU3RhY2tUcmFjZTogY3Jvc3MtYnJvd3NlciBzdGFjayB0cmFjZXMgaW4gSmF2YVNjcmlwdFxuICpcbiAqIFN5bnRheDpcbiAqICAgcyA9IFRyYWNlS2l0LmNvbXB1dGVTdGFja1RyYWNlKGV4Y2VwdGlvbikgLy8gY29uc2lkZXIgdXNpbmcgVHJhY2VLaXQucmVwb3J0IGluc3RlYWQgKHNlZSBiZWxvdylcbiAqIFJldHVybnM6XG4gKiAgIHMubmFtZSAgICAgICAgICAgICAgLSBleGNlcHRpb24gbmFtZVxuICogICBzLm1lc3NhZ2UgICAgICAgICAgIC0gZXhjZXB0aW9uIG1lc3NhZ2VcbiAqICAgcy5zdGFja1tpXS51cmwgICAgICAtIEphdmFTY3JpcHQgb3IgSFRNTCBmaWxlIFVSTFxuICogICBzLnN0YWNrW2ldLmZ1bmMgICAgIC0gZnVuY3Rpb24gbmFtZSwgb3IgZW1wdHkgZm9yIGFub255bW91cyBmdW5jdGlvbnMgKGlmIGd1ZXNzaW5nIGRpZCBub3Qgd29yaylcbiAqICAgcy5zdGFja1tpXS5hcmdzICAgICAtIGFyZ3VtZW50cyBwYXNzZWQgdG8gdGhlIGZ1bmN0aW9uLCBpZiBrbm93blxuICogICBzLnN0YWNrW2ldLmxpbmUgICAgIC0gbGluZSBudW1iZXIsIGlmIGtub3duXG4gKiAgIHMuc3RhY2tbaV0uY29sdW1uICAgLSBjb2x1bW4gbnVtYmVyLCBpZiBrbm93blxuICpcbiAqIFN1cHBvcnRzOlxuICogICAtIEZpcmVmb3g6ICBmdWxsIHN0YWNrIHRyYWNlIHdpdGggbGluZSBudW1iZXJzIGFuZCB1bnJlbGlhYmxlIGNvbHVtblxuICogICAgICAgICAgICAgICBudW1iZXIgb24gdG9wIGZyYW1lXG4gKiAgIC0gT3BlcmEgMTA6IGZ1bGwgc3RhY2sgdHJhY2Ugd2l0aCBsaW5lIGFuZCBjb2x1bW4gbnVtYmVyc1xuICogICAtIE9wZXJhIDktOiBmdWxsIHN0YWNrIHRyYWNlIHdpdGggbGluZSBudW1iZXJzXG4gKiAgIC0gQ2hyb21lOiAgIGZ1bGwgc3RhY2sgdHJhY2Ugd2l0aCBsaW5lIGFuZCBjb2x1bW4gbnVtYmVyc1xuICogICAtIFNhZmFyaTogICBsaW5lIGFuZCBjb2x1bW4gbnVtYmVyIGZvciB0aGUgdG9wbW9zdCBzdGFja3RyYWNlIGVsZW1lbnRcbiAqICAgICAgICAgICAgICAgb25seVxuICogICAtIElFOiAgICAgICBubyBsaW5lIG51bWJlcnMgd2hhdHNvZXZlclxuICpcbiAqIFRyaWVzIHRvIGd1ZXNzIG5hbWVzIG9mIGFub255bW91cyBmdW5jdGlvbnMgYnkgbG9va2luZyBmb3IgYXNzaWdubWVudHNcbiAqIGluIHRoZSBzb3VyY2UgY29kZS4gSW4gSUUgYW5kIFNhZmFyaSwgd2UgaGF2ZSB0byBndWVzcyBzb3VyY2UgZmlsZSBuYW1lc1xuICogYnkgc2VhcmNoaW5nIGZvciBmdW5jdGlvbiBib2RpZXMgaW5zaWRlIGFsbCBwYWdlIHNjcmlwdHMuIFRoaXMgd2lsbCBub3RcbiAqIHdvcmsgZm9yIHNjcmlwdHMgdGhhdCBhcmUgbG9hZGVkIGNyb3NzLWRvbWFpbi5cbiAqIEhlcmUgYmUgZHJhZ29uczogc29tZSBmdW5jdGlvbiBuYW1lcyBtYXkgYmUgZ3Vlc3NlZCBpbmNvcnJlY3RseSwgYW5kXG4gKiBkdXBsaWNhdGUgZnVuY3Rpb25zIG1heSBiZSBtaXNtYXRjaGVkLlxuICpcbiAqIFRyYWNlS2l0LmNvbXB1dGVTdGFja1RyYWNlIHNob3VsZCBvbmx5IGJlIHVzZWQgZm9yIHRyYWNpbmcgcHVycG9zZXMuXG4gKiBMb2dnaW5nIG9mIHVuaGFuZGxlZCBleGNlcHRpb25zIHNob3VsZCBiZSBkb25lIHdpdGggVHJhY2VLaXQucmVwb3J0LFxuICogd2hpY2ggYnVpbGRzIG9uIHRvcCBvZiBUcmFjZUtpdC5jb21wdXRlU3RhY2tUcmFjZSBhbmQgcHJvdmlkZXMgYmV0dGVyXG4gKiBJRSBzdXBwb3J0IGJ5IHV0aWxpemluZyB0aGUgd2luZG93Lm9uZXJyb3IgZXZlbnQgdG8gcmV0cmlldmUgaW5mb3JtYXRpb25cbiAqIGFib3V0IHRoZSB0b3Agb2YgdGhlIHN0YWNrLlxuICpcbiAqIE5vdGU6IEluIElFIGFuZCBTYWZhcmksIG5vIHN0YWNrIHRyYWNlIGlzIHJlY29yZGVkIG9uIHRoZSBFcnJvciBvYmplY3QsXG4gKiBzbyBjb21wdXRlU3RhY2tUcmFjZSBpbnN0ZWFkIHdhbGtzIGl0cyAqb3duKiBjaGFpbiBvZiBjYWxsZXJzLlxuICogVGhpcyBtZWFucyB0aGF0OlxuICogICogaW4gU2FmYXJpLCBzb21lIG1ldGhvZHMgbWF5IGJlIG1pc3NpbmcgZnJvbSB0aGUgc3RhY2sgdHJhY2U7XG4gKiAgKiBpbiBJRSwgdGhlIHRvcG1vc3QgZnVuY3Rpb24gaW4gdGhlIHN0YWNrIHRyYWNlIHdpbGwgYWx3YXlzIGJlIHRoZVxuICogICAgY2FsbGVyIG9mIGNvbXB1dGVTdGFja1RyYWNlLlxuICpcbiAqIFRoaXMgaXMgb2theSBmb3IgdHJhY2luZyAoYmVjYXVzZSB5b3UgYXJlIGxpa2VseSB0byBiZSBjYWxsaW5nXG4gKiBjb21wdXRlU3RhY2tUcmFjZSBmcm9tIHRoZSBmdW5jdGlvbiB5b3Ugd2FudCB0byBiZSB0aGUgdG9wbW9zdCBlbGVtZW50XG4gKiBvZiB0aGUgc3RhY2sgdHJhY2UgYW55d2F5KSwgYnV0IG5vdCBva2F5IGZvciBsb2dnaW5nIHVuaGFuZGxlZFxuICogZXhjZXB0aW9ucyAoYmVjYXVzZSB5b3VyIGNhdGNoIGJsb2NrIHdpbGwgbGlrZWx5IGJlIGZhciBhd2F5IGZyb20gdGhlXG4gKiBpbm5lciBmdW5jdGlvbiB0aGF0IGFjdHVhbGx5IGNhdXNlZCB0aGUgZXhjZXB0aW9uKS5cbiAqXG4gKi9cblRyYWNlS2l0LmNvbXB1dGVTdGFja1RyYWNlID0gKGZ1bmN0aW9uIGNvbXB1dGVTdGFja1RyYWNlV3JhcHBlcigpIHtcbiAgLy8gQ29udGVudHMgb2YgRXhjZXB0aW9uIGluIHZhcmlvdXMgYnJvd3NlcnMuXG4gIC8vXG4gIC8vIFNBRkFSSTpcbiAgLy8gZXgubWVzc2FnZSA9IENhbid0IGZpbmQgdmFyaWFibGU6IHFxXG4gIC8vIGV4LmxpbmUgPSA1OVxuICAvLyBleC5zb3VyY2VJZCA9IDU4MDIzODE5MlxuICAvLyBleC5zb3VyY2VVUkwgPSBodHRwOi8vLi4uXG4gIC8vIGV4LmV4cHJlc3Npb25CZWdpbk9mZnNldCA9IDk2XG4gIC8vIGV4LmV4cHJlc3Npb25DYXJldE9mZnNldCA9IDk4XG4gIC8vIGV4LmV4cHJlc3Npb25FbmRPZmZzZXQgPSA5OFxuICAvLyBleC5uYW1lID0gUmVmZXJlbmNlRXJyb3JcbiAgLy9cbiAgLy8gRklSRUZPWDpcbiAgLy8gZXgubWVzc2FnZSA9IHFxIGlzIG5vdCBkZWZpbmVkXG4gIC8vIGV4LmZpbGVOYW1lID0gaHR0cDovLy4uLlxuICAvLyBleC5saW5lTnVtYmVyID0gNTlcbiAgLy8gZXguY29sdW1uTnVtYmVyID0gNjlcbiAgLy8gZXguc3RhY2sgPSAuLi5zdGFjayB0cmFjZS4uLiAoc2VlIHRoZSBleGFtcGxlIGJlbG93KVxuICAvLyBleC5uYW1lID0gUmVmZXJlbmNlRXJyb3JcbiAgLy9cbiAgLy8gQ0hST01FOlxuICAvLyBleC5tZXNzYWdlID0gcXEgaXMgbm90IGRlZmluZWRcbiAgLy8gZXgubmFtZSA9IFJlZmVyZW5jZUVycm9yXG4gIC8vIGV4LnR5cGUgPSBub3RfZGVmaW5lZFxuICAvLyBleC5hcmd1bWVudHMgPSBbJ2FhJ11cbiAgLy8gZXguc3RhY2sgPSAuLi5zdGFjayB0cmFjZS4uLlxuICAvL1xuICAvLyBJTlRFUk5FVCBFWFBMT1JFUjpcbiAgLy8gZXgubWVzc2FnZSA9IC4uLlxuICAvLyBleC5uYW1lID0gUmVmZXJlbmNlRXJyb3JcbiAgLy9cbiAgLy8gT1BFUkE6XG4gIC8vIGV4Lm1lc3NhZ2UgPSAuLi5tZXNzYWdlLi4uIChzZWUgdGhlIGV4YW1wbGUgYmVsb3cpXG4gIC8vIGV4Lm5hbWUgPSBSZWZlcmVuY2VFcnJvclxuICAvLyBleC5vcGVyYSNzb3VyY2Vsb2MgPSAxMSAgKHByZXR0eSBtdWNoIHVzZWxlc3MsIGR1cGxpY2F0ZXMgdGhlIGluZm8gaW4gZXgubWVzc2FnZSlcbiAgLy8gZXguc3RhY2t0cmFjZSA9IG4vYTsgc2VlICdvcGVyYTpjb25maWcjVXNlclByZWZzfEV4Y2VwdGlvbnMgSGF2ZSBTdGFja3RyYWNlJ1xuXG4gIC8qKlxuICAgKiBDb21wdXRlcyBzdGFjayB0cmFjZSBpbmZvcm1hdGlvbiBmcm9tIHRoZSBzdGFjayBwcm9wZXJ0eS5cbiAgICogQ2hyb21lIGFuZCBHZWNrbyB1c2UgdGhpcyBwcm9wZXJ0eS5cbiAgICogQHBhcmFtIHtFcnJvcn0gZXhcbiAgICogQHJldHVybiB7P09iamVjdC48c3RyaW5nLCAqPn0gU3RhY2sgdHJhY2UgaW5mb3JtYXRpb24uXG4gICAqL1xuICBmdW5jdGlvbiBjb21wdXRlU3RhY2tUcmFjZUZyb21TdGFja1Byb3AoZXgpIHtcbiAgICBpZiAodHlwZW9mIGV4LnN0YWNrID09PSAndW5kZWZpbmVkJyB8fCAhZXguc3RhY2spIHJldHVybjtcblxuICAgIHZhciBjaHJvbWUgPSAvXlxccyphdCAoPzooLio/KSA/XFwoKT8oKD86ZmlsZXxodHRwcz98YmxvYnxjaHJvbWUtZXh0ZW5zaW9ufG5hdGl2ZXxldmFsfHdlYnBhY2t8PGFub255bW91cz58W2Etel06fFxcLykuKj8pKD86OihcXGQrKSk/KD86OihcXGQrKSk/XFwpP1xccyokL2k7XG4gICAgdmFyIHdpbmpzID0gL15cXHMqYXQgKD86KCg/OlxcW29iamVjdCBvYmplY3RcXF0pPy4rKSApP1xcKD8oKD86ZmlsZXxtcy1hcHB4KD86LXdlYil8aHR0cHM/fHdlYnBhY2t8YmxvYik6Lio/KTooXFxkKykoPzo6KFxcZCspKT9cXCk/XFxzKiQvaTtcbiAgICAvLyBOT1RFOiBibG9iIHVybHMgYXJlIG5vdyBzdXBwb3NlZCB0byBhbHdheXMgaGF2ZSBhbiBvcmlnaW4sIHRoZXJlZm9yZSBpdCdzIGZvcm1hdFxuICAgIC8vIHdoaWNoIGlzIGBibG9iOmh0dHA6Ly91cmwvcGF0aC93aXRoLXNvbWUtdXVpZGAsIGlzIG1hdGNoZWQgYnkgYGJsb2IuKj86XFwvYCBhcyB3ZWxsXG4gICAgdmFyIGdlY2tvID0gL15cXHMqKC4qPykoPzpcXCgoLio/KVxcKSk/KD86XnxAKSgoPzpmaWxlfGh0dHBzP3xibG9ifGNocm9tZXx3ZWJwYWNrfHJlc291cmNlfG1vei1leHRlbnNpb24pLio/OlxcLy4qP3xcXFtuYXRpdmUgY29kZVxcXXxbXkBdKig/OmJ1bmRsZXxcXGQrXFwuanMpKSg/OjooXFxkKykpPyg/OjooXFxkKykpP1xccyokL2k7XG4gICAgLy8gVXNlZCB0byBhZGRpdGlvbmFsbHkgcGFyc2UgVVJML2xpbmUvY29sdW1uIGZyb20gZXZhbCBmcmFtZXNcbiAgICB2YXIgZ2Vja29FdmFsID0gLyhcXFMrKSBsaW5lIChcXGQrKSg/OiA+IGV2YWwgbGluZSBcXGQrKSogPiBldmFsL2k7XG4gICAgdmFyIGNocm9tZUV2YWwgPSAvXFwoKFxcUyopKD86OihcXGQrKSkoPzo6KFxcZCspKVxcKS87XG4gICAgdmFyIGxpbmVzID0gZXguc3RhY2suc3BsaXQoJ1xcbicpO1xuICAgIHZhciBzdGFjayA9IFtdO1xuICAgIHZhciBzdWJtYXRjaDtcbiAgICB2YXIgcGFydHM7XG4gICAgdmFyIGVsZW1lbnQ7XG4gICAgdmFyIHJlZmVyZW5jZSA9IC9eKC4qKSBpcyB1bmRlZmluZWQkLy5leGVjKGV4Lm1lc3NhZ2UpO1xuXG4gICAgZm9yICh2YXIgaSA9IDAsIGogPSBsaW5lcy5sZW5ndGg7IGkgPCBqOyArK2kpIHtcbiAgICAgIGlmICgocGFydHMgPSBjaHJvbWUuZXhlYyhsaW5lc1tpXSkpKSB7XG4gICAgICAgIHZhciBpc05hdGl2ZSA9IHBhcnRzWzJdICYmIHBhcnRzWzJdLmluZGV4T2YoJ25hdGl2ZScpID09PSAwOyAvLyBzdGFydCBvZiBsaW5lXG4gICAgICAgIHZhciBpc0V2YWwgPSBwYXJ0c1syXSAmJiBwYXJ0c1syXS5pbmRleE9mKCdldmFsJykgPT09IDA7IC8vIHN0YXJ0IG9mIGxpbmVcbiAgICAgICAgaWYgKGlzRXZhbCAmJiAoc3VibWF0Y2ggPSBjaHJvbWVFdmFsLmV4ZWMocGFydHNbMl0pKSkge1xuICAgICAgICAgIC8vIHRocm93IG91dCBldmFsIGxpbmUvY29sdW1uIGFuZCB1c2UgdG9wLW1vc3QgbGluZS9jb2x1bW4gbnVtYmVyXG4gICAgICAgICAgcGFydHNbMl0gPSBzdWJtYXRjaFsxXTsgLy8gdXJsXG4gICAgICAgICAgcGFydHNbM10gPSBzdWJtYXRjaFsyXTsgLy8gbGluZVxuICAgICAgICAgIHBhcnRzWzRdID0gc3VibWF0Y2hbM107IC8vIGNvbHVtblxuICAgICAgICB9XG4gICAgICAgIGVsZW1lbnQgPSB7XG4gICAgICAgICAgdXJsOiAhaXNOYXRpdmUgPyBwYXJ0c1syXSA6IG51bGwsXG4gICAgICAgICAgZnVuYzogcGFydHNbMV0gfHwgVU5LTk9XTl9GVU5DVElPTixcbiAgICAgICAgICBhcmdzOiBpc05hdGl2ZSA/IFtwYXJ0c1syXV0gOiBbXSxcbiAgICAgICAgICBsaW5lOiBwYXJ0c1szXSA/ICtwYXJ0c1szXSA6IG51bGwsXG4gICAgICAgICAgY29sdW1uOiBwYXJ0c1s0XSA/ICtwYXJ0c1s0XSA6IG51bGxcbiAgICAgICAgfTtcbiAgICAgIH0gZWxzZSBpZiAoKHBhcnRzID0gd2luanMuZXhlYyhsaW5lc1tpXSkpKSB7XG4gICAgICAgIGVsZW1lbnQgPSB7XG4gICAgICAgICAgdXJsOiBwYXJ0c1syXSxcbiAgICAgICAgICBmdW5jOiBwYXJ0c1sxXSB8fCBVTktOT1dOX0ZVTkNUSU9OLFxuICAgICAgICAgIGFyZ3M6IFtdLFxuICAgICAgICAgIGxpbmU6ICtwYXJ0c1szXSxcbiAgICAgICAgICBjb2x1bW46IHBhcnRzWzRdID8gK3BhcnRzWzRdIDogbnVsbFxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIGlmICgocGFydHMgPSBnZWNrby5leGVjKGxpbmVzW2ldKSkpIHtcbiAgICAgICAgdmFyIGlzRXZhbCA9IHBhcnRzWzNdICYmIHBhcnRzWzNdLmluZGV4T2YoJyA+IGV2YWwnKSA+IC0xO1xuICAgICAgICBpZiAoaXNFdmFsICYmIChzdWJtYXRjaCA9IGdlY2tvRXZhbC5leGVjKHBhcnRzWzNdKSkpIHtcbiAgICAgICAgICAvLyB0aHJvdyBvdXQgZXZhbCBsaW5lL2NvbHVtbiBhbmQgdXNlIHRvcC1tb3N0IGxpbmUgbnVtYmVyXG4gICAgICAgICAgcGFydHNbM10gPSBzdWJtYXRjaFsxXTtcbiAgICAgICAgICBwYXJ0c1s0XSA9IHN1Ym1hdGNoWzJdO1xuICAgICAgICAgIHBhcnRzWzVdID0gbnVsbDsgLy8gbm8gY29sdW1uIHdoZW4gZXZhbFxuICAgICAgICB9IGVsc2UgaWYgKGkgPT09IDAgJiYgIXBhcnRzWzVdICYmIHR5cGVvZiBleC5jb2x1bW5OdW1iZXIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgLy8gRmlyZUZveCB1c2VzIHRoaXMgYXdlc29tZSBjb2x1bW5OdW1iZXIgcHJvcGVydHkgZm9yIGl0cyB0b3AgZnJhbWVcbiAgICAgICAgICAvLyBBbHNvIG5vdGUsIEZpcmVmb3gncyBjb2x1bW4gbnVtYmVyIGlzIDAtYmFzZWQgYW5kIGV2ZXJ5dGhpbmcgZWxzZSBleHBlY3RzIDEtYmFzZWQsXG4gICAgICAgICAgLy8gc28gYWRkaW5nIDFcbiAgICAgICAgICAvLyBOT1RFOiB0aGlzIGhhY2sgZG9lc24ndCB3b3JrIGlmIHRvcC1tb3N0IGZyYW1lIGlzIGV2YWxcbiAgICAgICAgICBzdGFja1swXS5jb2x1bW4gPSBleC5jb2x1bW5OdW1iZXIgKyAxO1xuICAgICAgICB9XG4gICAgICAgIGVsZW1lbnQgPSB7XG4gICAgICAgICAgdXJsOiBwYXJ0c1szXSxcbiAgICAgICAgICBmdW5jOiBwYXJ0c1sxXSB8fCBVTktOT1dOX0ZVTkNUSU9OLFxuICAgICAgICAgIGFyZ3M6IHBhcnRzWzJdID8gcGFydHNbMl0uc3BsaXQoJywnKSA6IFtdLFxuICAgICAgICAgIGxpbmU6IHBhcnRzWzRdID8gK3BhcnRzWzRdIDogbnVsbCxcbiAgICAgICAgICBjb2x1bW46IHBhcnRzWzVdID8gK3BhcnRzWzVdIDogbnVsbFxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG5cbiAgICAgIGlmICghZWxlbWVudC5mdW5jICYmIGVsZW1lbnQubGluZSkge1xuICAgICAgICBlbGVtZW50LmZ1bmMgPSBVTktOT1dOX0ZVTkNUSU9OO1xuICAgICAgfVxuXG4gICAgICBpZiAoZWxlbWVudC51cmwgJiYgZWxlbWVudC51cmwuc3Vic3RyKDAsIDUpID09PSAnYmxvYjonKSB7XG4gICAgICAgIC8vIFNwZWNpYWwgY2FzZSBmb3IgaGFuZGxpbmcgSmF2YVNjcmlwdCBsb2FkZWQgaW50byBhIGJsb2IuXG4gICAgICAgIC8vIFdlIHVzZSBhIHN5bmNocm9ub3VzIEFKQVggcmVxdWVzdCBoZXJlIGFzIGEgYmxvYiBpcyBhbHJlYWR5IGluXG4gICAgICAgIC8vIG1lbW9yeSAtIGl0J3Mgbm90IG1ha2luZyBhIG5ldHdvcmsgcmVxdWVzdC4gIFRoaXMgd2lsbCBnZW5lcmF0ZSBhIHdhcm5pbmdcbiAgICAgICAgLy8gaW4gdGhlIGJyb3dzZXIgY29uc29sZSwgYnV0IHRoZXJlIGhhcyBhbHJlYWR5IGJlZW4gYW4gZXJyb3Igc28gdGhhdCdzIG5vdFxuICAgICAgICAvLyB0aGF0IG11Y2ggb2YgYW4gaXNzdWUuXG4gICAgICAgIHZhciB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgICAgeGhyLm9wZW4oJ0dFVCcsIGVsZW1lbnQudXJsLCBmYWxzZSk7XG4gICAgICAgIHhoci5zZW5kKG51bGwpO1xuXG4gICAgICAgIC8vIElmIHdlIGZhaWxlZCB0byBkb3dubG9hZCB0aGUgc291cmNlLCBza2lwIHRoaXMgcGF0Y2hcbiAgICAgICAgaWYgKHhoci5zdGF0dXMgPT09IDIwMCkge1xuICAgICAgICAgIHZhciBzb3VyY2UgPSB4aHIucmVzcG9uc2VUZXh0IHx8ICcnO1xuXG4gICAgICAgICAgLy8gV2UgdHJpbSB0aGUgc291cmNlIGRvd24gdG8gdGhlIGxhc3QgMzAwIGNoYXJhY3RlcnMgYXMgc291cmNlTWFwcGluZ1VSTCBpcyBhbHdheXMgYXQgdGhlIGVuZCBvZiB0aGUgZmlsZS5cbiAgICAgICAgICAvLyBXaHkgMzAwPyBUbyBiZSBpbiBsaW5lIHdpdGg6IGh0dHBzOi8vZ2l0aHViLmNvbS9nZXRzZW50cnkvc2VudHJ5L2Jsb2IvNGFmMjllOGYyMzUwZTIwYzI4YTY5MzMzNTRlNGY0MjQzN2I0YmE0Mi9zcmMvc2VudHJ5L2xhbmcvamF2YXNjcmlwdC9wcm9jZXNzb3IucHkjTDE2NC1MMTc1XG4gICAgICAgICAgc291cmNlID0gc291cmNlLnNsaWNlKC0zMDApO1xuXG4gICAgICAgICAgLy8gTm93IHdlIGRpZyBvdXQgdGhlIHNvdXJjZSBtYXAgVVJMXG4gICAgICAgICAgdmFyIHNvdXJjZU1hcHMgPSBzb3VyY2UubWF0Y2goL1xcL1xcLyMgc291cmNlTWFwcGluZ1VSTD0oLiopJC8pO1xuXG4gICAgICAgICAgLy8gSWYgd2UgZG9uJ3QgZmluZCBhIHNvdXJjZSBtYXAgY29tbWVudCBvciB3ZSBmaW5kIG1vcmUgdGhhbiBvbmUsIGNvbnRpbnVlIG9uIHRvIHRoZSBuZXh0IGVsZW1lbnQuXG4gICAgICAgICAgaWYgKHNvdXJjZU1hcHMpIHtcbiAgICAgICAgICAgIHZhciBzb3VyY2VNYXBBZGRyZXNzID0gc291cmNlTWFwc1sxXTtcblxuICAgICAgICAgICAgLy8gTm93IHdlIGNoZWNrIHRvIHNlZSBpZiBpdCdzIGEgcmVsYXRpdmUgVVJMLlxuICAgICAgICAgICAgLy8gSWYgaXQgaXMsIGNvbnZlcnQgaXQgdG8gYW4gYWJzb2x1dGUgb25lLlxuICAgICAgICAgICAgaWYgKHNvdXJjZU1hcEFkZHJlc3MuY2hhckF0KDApID09PSAnficpIHtcbiAgICAgICAgICAgICAgc291cmNlTWFwQWRkcmVzcyA9IGdldExvY2F0aW9uT3JpZ2luKCkgKyBzb3VyY2VNYXBBZGRyZXNzLnNsaWNlKDEpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBOb3cgd2Ugc3RyaXAgdGhlICcubWFwJyBvZmYgb2YgdGhlIGVuZCBvZiB0aGUgVVJMIGFuZCB1cGRhdGUgdGhlXG4gICAgICAgICAgICAvLyBlbGVtZW50IHNvIHRoYXQgU2VudHJ5IGNhbiBtYXRjaCB0aGUgbWFwIHRvIHRoZSBibG9iLlxuICAgICAgICAgICAgZWxlbWVudC51cmwgPSBzb3VyY2VNYXBBZGRyZXNzLnNsaWNlKDAsIC00KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgc3RhY2sucHVzaChlbGVtZW50KTtcbiAgICB9XG5cbiAgICBpZiAoIXN0YWNrLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIG5hbWU6IGV4Lm5hbWUsXG4gICAgICBtZXNzYWdlOiBleC5tZXNzYWdlLFxuICAgICAgdXJsOiBnZXRMb2NhdGlvbkhyZWYoKSxcbiAgICAgIHN0YWNrOiBzdGFja1xuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBpbmZvcm1hdGlvbiBhYm91dCB0aGUgZmlyc3QgZnJhbWUgdG8gaW5jb21wbGV0ZSBzdGFjayB0cmFjZXMuXG4gICAqIFNhZmFyaSBhbmQgSUUgcmVxdWlyZSB0aGlzIHRvIGdldCBjb21wbGV0ZSBkYXRhIG9uIHRoZSBmaXJzdCBmcmFtZS5cbiAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywgKj59IHN0YWNrSW5mbyBTdGFjayB0cmFjZSBpbmZvcm1hdGlvbiBmcm9tXG4gICAqIG9uZSBvZiB0aGUgY29tcHV0ZSogbWV0aG9kcy5cbiAgICogQHBhcmFtIHtzdHJpbmd9IHVybCBUaGUgVVJMIG9mIHRoZSBzY3JpcHQgdGhhdCBjYXVzZWQgYW4gZXJyb3IuXG4gICAqIEBwYXJhbSB7KG51bWJlcnxzdHJpbmcpfSBsaW5lTm8gVGhlIGxpbmUgbnVtYmVyIG9mIHRoZSBzY3JpcHQgdGhhdFxuICAgKiBjYXVzZWQgYW4gZXJyb3IuXG4gICAqIEBwYXJhbSB7c3RyaW5nPX0gbWVzc2FnZSBUaGUgZXJyb3IgZ2VuZXJhdGVkIGJ5IHRoZSBicm93c2VyLCB3aGljaFxuICAgKiBob3BlZnVsbHkgY29udGFpbnMgdGhlIG5hbWUgb2YgdGhlIG9iamVjdCB0aGF0IGNhdXNlZCB0aGUgZXJyb3IuXG4gICAqIEByZXR1cm4ge2Jvb2xlYW59IFdoZXRoZXIgb3Igbm90IHRoZSBzdGFjayBpbmZvcm1hdGlvbiB3YXNcbiAgICogYXVnbWVudGVkLlxuICAgKi9cbiAgZnVuY3Rpb24gYXVnbWVudFN0YWNrVHJhY2VXaXRoSW5pdGlhbEVsZW1lbnQoc3RhY2tJbmZvLCB1cmwsIGxpbmVObywgbWVzc2FnZSkge1xuICAgIHZhciBpbml0aWFsID0ge1xuICAgICAgdXJsOiB1cmwsXG4gICAgICBsaW5lOiBsaW5lTm9cbiAgICB9O1xuXG4gICAgaWYgKGluaXRpYWwudXJsICYmIGluaXRpYWwubGluZSkge1xuICAgICAgc3RhY2tJbmZvLmluY29tcGxldGUgPSBmYWxzZTtcblxuICAgICAgaWYgKCFpbml0aWFsLmZ1bmMpIHtcbiAgICAgICAgaW5pdGlhbC5mdW5jID0gVU5LTk9XTl9GVU5DVElPTjtcbiAgICAgIH1cblxuICAgICAgaWYgKHN0YWNrSW5mby5zdGFjay5sZW5ndGggPiAwKSB7XG4gICAgICAgIGlmIChzdGFja0luZm8uc3RhY2tbMF0udXJsID09PSBpbml0aWFsLnVybCkge1xuICAgICAgICAgIGlmIChzdGFja0luZm8uc3RhY2tbMF0ubGluZSA9PT0gaW5pdGlhbC5saW5lKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7IC8vIGFscmVhZHkgaW4gc3RhY2sgdHJhY2VcbiAgICAgICAgICB9IGVsc2UgaWYgKFxuICAgICAgICAgICAgIXN0YWNrSW5mby5zdGFja1swXS5saW5lICYmXG4gICAgICAgICAgICBzdGFja0luZm8uc3RhY2tbMF0uZnVuYyA9PT0gaW5pdGlhbC5mdW5jXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICBzdGFja0luZm8uc3RhY2tbMF0ubGluZSA9IGluaXRpYWwubGluZTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgc3RhY2tJbmZvLnN0YWNrLnVuc2hpZnQoaW5pdGlhbCk7XG4gICAgICBzdGFja0luZm8ucGFydGlhbCA9IHRydWU7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgc3RhY2tJbmZvLmluY29tcGxldGUgPSB0cnVlO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb21wdXRlcyBzdGFjayB0cmFjZSBpbmZvcm1hdGlvbiBieSB3YWxraW5nIHRoZSBhcmd1bWVudHMuY2FsbGVyXG4gICAqIGNoYWluIGF0IHRoZSB0aW1lIHRoZSBleGNlcHRpb24gb2NjdXJyZWQuIFRoaXMgd2lsbCBjYXVzZSBlYXJsaWVyXG4gICAqIGZyYW1lcyB0byBiZSBtaXNzZWQgYnV0IGlzIHRoZSBvbmx5IHdheSB0byBnZXQgYW55IHN0YWNrIHRyYWNlIGluXG4gICAqIFNhZmFyaSBhbmQgSUUuIFRoZSB0b3AgZnJhbWUgaXMgcmVzdG9yZWQgYnlcbiAgICoge0BsaW5rIGF1Z21lbnRTdGFja1RyYWNlV2l0aEluaXRpYWxFbGVtZW50fS5cbiAgICogQHBhcmFtIHtFcnJvcn0gZXhcbiAgICogQHJldHVybiB7P09iamVjdC48c3RyaW5nLCAqPn0gU3RhY2sgdHJhY2UgaW5mb3JtYXRpb24uXG4gICAqL1xuICBmdW5jdGlvbiBjb21wdXRlU3RhY2tUcmFjZUJ5V2Fsa2luZ0NhbGxlckNoYWluKGV4LCBkZXB0aCkge1xuICAgIHZhciBmdW5jdGlvbk5hbWUgPSAvZnVuY3Rpb25cXHMrKFtfJGEtekEtWlxceEEwLVxcdUZGRkZdW18kYS16QS1aMC05XFx4QTAtXFx1RkZGRl0qKT9cXHMqXFwoL2ksXG4gICAgICBzdGFjayA9IFtdLFxuICAgICAgZnVuY3MgPSB7fSxcbiAgICAgIHJlY3Vyc2lvbiA9IGZhbHNlLFxuICAgICAgcGFydHMsXG4gICAgICBpdGVtLFxuICAgICAgc291cmNlO1xuXG4gICAgZm9yIChcbiAgICAgIHZhciBjdXJyID0gY29tcHV0ZVN0YWNrVHJhY2VCeVdhbGtpbmdDYWxsZXJDaGFpbi5jYWxsZXI7XG4gICAgICBjdXJyICYmICFyZWN1cnNpb247XG4gICAgICBjdXJyID0gY3Vyci5jYWxsZXJcbiAgICApIHtcbiAgICAgIGlmIChjdXJyID09PSBjb21wdXRlU3RhY2tUcmFjZSB8fCBjdXJyID09PSBUcmFjZUtpdC5yZXBvcnQpIHtcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ3NraXBwaW5nIGludGVybmFsIGZ1bmN0aW9uJyk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBpdGVtID0ge1xuICAgICAgICB1cmw6IG51bGwsXG4gICAgICAgIGZ1bmM6IFVOS05PV05fRlVOQ1RJT04sXG4gICAgICAgIGxpbmU6IG51bGwsXG4gICAgICAgIGNvbHVtbjogbnVsbFxuICAgICAgfTtcblxuICAgICAgaWYgKGN1cnIubmFtZSkge1xuICAgICAgICBpdGVtLmZ1bmMgPSBjdXJyLm5hbWU7XG4gICAgICB9IGVsc2UgaWYgKChwYXJ0cyA9IGZ1bmN0aW9uTmFtZS5leGVjKGN1cnIudG9TdHJpbmcoKSkpKSB7XG4gICAgICAgIGl0ZW0uZnVuYyA9IHBhcnRzWzFdO1xuICAgICAgfVxuXG4gICAgICBpZiAodHlwZW9mIGl0ZW0uZnVuYyA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBpdGVtLmZ1bmMgPSBwYXJ0cy5pbnB1dC5zdWJzdHJpbmcoMCwgcGFydHMuaW5wdXQuaW5kZXhPZigneycpKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge31cbiAgICAgIH1cblxuICAgICAgaWYgKGZ1bmNzWycnICsgY3Vycl0pIHtcbiAgICAgICAgcmVjdXJzaW9uID0gdHJ1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGZ1bmNzWycnICsgY3Vycl0gPSB0cnVlO1xuICAgICAgfVxuXG4gICAgICBzdGFjay5wdXNoKGl0ZW0pO1xuICAgIH1cblxuICAgIGlmIChkZXB0aCkge1xuICAgICAgLy8gY29uc29sZS5sb2coJ2RlcHRoIGlzICcgKyBkZXB0aCk7XG4gICAgICAvLyBjb25zb2xlLmxvZygnc3RhY2sgaXMgJyArIHN0YWNrLmxlbmd0aCk7XG4gICAgICBzdGFjay5zcGxpY2UoMCwgZGVwdGgpO1xuICAgIH1cblxuICAgIHZhciByZXN1bHQgPSB7XG4gICAgICBuYW1lOiBleC5uYW1lLFxuICAgICAgbWVzc2FnZTogZXgubWVzc2FnZSxcbiAgICAgIHVybDogZ2V0TG9jYXRpb25IcmVmKCksXG4gICAgICBzdGFjazogc3RhY2tcbiAgICB9O1xuICAgIGF1Z21lbnRTdGFja1RyYWNlV2l0aEluaXRpYWxFbGVtZW50KFxuICAgICAgcmVzdWx0LFxuICAgICAgZXguc291cmNlVVJMIHx8IGV4LmZpbGVOYW1lLFxuICAgICAgZXgubGluZSB8fCBleC5saW5lTnVtYmVyLFxuICAgICAgZXgubWVzc2FnZSB8fCBleC5kZXNjcmlwdGlvblxuICAgICk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb21wdXRlcyBhIHN0YWNrIHRyYWNlIGZvciBhbiBleGNlcHRpb24uXG4gICAqIEBwYXJhbSB7RXJyb3J9IGV4XG4gICAqIEBwYXJhbSB7KHN0cmluZ3xudW1iZXIpPX0gZGVwdGhcbiAgICovXG4gIGZ1bmN0aW9uIGNvbXB1dGVTdGFja1RyYWNlKGV4LCBkZXB0aCkge1xuICAgIHZhciBzdGFjayA9IG51bGw7XG4gICAgZGVwdGggPSBkZXB0aCA9PSBudWxsID8gMCA6ICtkZXB0aDtcblxuICAgIHRyeSB7XG4gICAgICBzdGFjayA9IGNvbXB1dGVTdGFja1RyYWNlRnJvbVN0YWNrUHJvcChleCk7XG4gICAgICBpZiAoc3RhY2spIHtcbiAgICAgICAgcmV0dXJuIHN0YWNrO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGlmIChUcmFjZUtpdC5kZWJ1Zykge1xuICAgICAgICB0aHJvdyBlO1xuICAgICAgfVxuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBzdGFjayA9IGNvbXB1dGVTdGFja1RyYWNlQnlXYWxraW5nQ2FsbGVyQ2hhaW4oZXgsIGRlcHRoICsgMSk7XG4gICAgICBpZiAoc3RhY2spIHtcbiAgICAgICAgcmV0dXJuIHN0YWNrO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGlmIChUcmFjZUtpdC5kZWJ1Zykge1xuICAgICAgICB0aHJvdyBlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgbmFtZTogZXgubmFtZSxcbiAgICAgIG1lc3NhZ2U6IGV4Lm1lc3NhZ2UsXG4gICAgICB1cmw6IGdldExvY2F0aW9uSHJlZigpXG4gICAgfTtcbiAgfVxuXG4gIGNvbXB1dGVTdGFja1RyYWNlLmF1Z21lbnRTdGFja1RyYWNlV2l0aEluaXRpYWxFbGVtZW50ID0gYXVnbWVudFN0YWNrVHJhY2VXaXRoSW5pdGlhbEVsZW1lbnQ7XG4gIGNvbXB1dGVTdGFja1RyYWNlLmNvbXB1dGVTdGFja1RyYWNlRnJvbVN0YWNrUHJvcCA9IGNvbXB1dGVTdGFja1RyYWNlRnJvbVN0YWNrUHJvcDtcblxuICByZXR1cm4gY29tcHV0ZVN0YWNrVHJhY2U7XG59KSgpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFRyYWNlS2l0O1xuIiwiLypcbiBqc29uLXN0cmluZ2lmeS1zYWZlXG4gTGlrZSBKU09OLnN0cmluZ2lmeSwgYnV0IGRvZXNuJ3QgdGhyb3cgb24gY2lyY3VsYXIgcmVmZXJlbmNlcy5cblxuIE9yaWdpbmFsbHkgZm9ya2VkIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL2lzYWFjcy9qc29uLXN0cmluZ2lmeS1zYWZlXG4gdmVyc2lvbiA1LjAuMSBvbiAzLzgvMjAxNyBhbmQgbW9kaWZpZWQgdG8gaGFuZGxlIEVycm9ycyBzZXJpYWxpemF0aW9uXG4gYW5kIElFOCBjb21wYXRpYmlsaXR5LiBUZXN0cyBmb3IgdGhpcyBhcmUgaW4gdGVzdC92ZW5kb3IuXG5cbiBJU0MgbGljZW5zZTogaHR0cHM6Ly9naXRodWIuY29tL2lzYWFjcy9qc29uLXN0cmluZ2lmeS1zYWZlL2Jsb2IvbWFzdGVyL0xJQ0VOU0VcbiovXG5cbmV4cG9ydHMgPSBtb2R1bGUuZXhwb3J0cyA9IHN0cmluZ2lmeTtcbmV4cG9ydHMuZ2V0U2VyaWFsaXplID0gc2VyaWFsaXplcjtcblxuZnVuY3Rpb24gaW5kZXhPZihoYXlzdGFjaywgbmVlZGxlKSB7XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgaGF5c3RhY2subGVuZ3RoOyArK2kpIHtcbiAgICBpZiAoaGF5c3RhY2tbaV0gPT09IG5lZWRsZSkgcmV0dXJuIGk7XG4gIH1cbiAgcmV0dXJuIC0xO1xufVxuXG5mdW5jdGlvbiBzdHJpbmdpZnkob2JqLCByZXBsYWNlciwgc3BhY2VzLCBjeWNsZVJlcGxhY2VyKSB7XG4gIHJldHVybiBKU09OLnN0cmluZ2lmeShvYmosIHNlcmlhbGl6ZXIocmVwbGFjZXIsIGN5Y2xlUmVwbGFjZXIpLCBzcGFjZXMpO1xufVxuXG4vLyBodHRwczovL2dpdGh1Yi5jb20vZnRsYWJzL2pzLWFiYnJldmlhdGUvYmxvYi9mYTcwOWU1ZjEzOWU3NzcwYTcxODI3YjE4OTNmMjI0MTgwOTdmYmRhL2luZGV4LmpzI0w5NS1MMTA2XG5mdW5jdGlvbiBzdHJpbmdpZnlFcnJvcih2YWx1ZSkge1xuICB2YXIgZXJyID0ge1xuICAgIC8vIFRoZXNlIHByb3BlcnRpZXMgYXJlIGltcGxlbWVudGVkIGFzIG1hZ2ljYWwgZ2V0dGVycyBhbmQgZG9uJ3Qgc2hvdyB1cCBpbiBmb3IgaW5cbiAgICBzdGFjazogdmFsdWUuc3RhY2ssXG4gICAgbWVzc2FnZTogdmFsdWUubWVzc2FnZSxcbiAgICBuYW1lOiB2YWx1ZS5uYW1lXG4gIH07XG5cbiAgZm9yICh2YXIgaSBpbiB2YWx1ZSkge1xuICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwodmFsdWUsIGkpKSB7XG4gICAgICBlcnJbaV0gPSB2YWx1ZVtpXTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gZXJyO1xufVxuXG5mdW5jdGlvbiBzZXJpYWxpemVyKHJlcGxhY2VyLCBjeWNsZVJlcGxhY2VyKSB7XG4gIHZhciBzdGFjayA9IFtdO1xuICB2YXIga2V5cyA9IFtdO1xuXG4gIGlmIChjeWNsZVJlcGxhY2VyID09IG51bGwpIHtcbiAgICBjeWNsZVJlcGxhY2VyID0gZnVuY3Rpb24oa2V5LCB2YWx1ZSkge1xuICAgICAgaWYgKHN0YWNrWzBdID09PSB2YWx1ZSkge1xuICAgICAgICByZXR1cm4gJ1tDaXJjdWxhciB+XSc7XG4gICAgICB9XG4gICAgICByZXR1cm4gJ1tDaXJjdWxhciB+LicgKyBrZXlzLnNsaWNlKDAsIGluZGV4T2Yoc3RhY2ssIHZhbHVlKSkuam9pbignLicpICsgJ10nO1xuICAgIH07XG4gIH1cblxuICByZXR1cm4gZnVuY3Rpb24oa2V5LCB2YWx1ZSkge1xuICAgIGlmIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgICB2YXIgdGhpc1BvcyA9IGluZGV4T2Yoc3RhY2ssIHRoaXMpO1xuICAgICAgfnRoaXNQb3MgPyBzdGFjay5zcGxpY2UodGhpc1BvcyArIDEpIDogc3RhY2sucHVzaCh0aGlzKTtcbiAgICAgIH50aGlzUG9zID8ga2V5cy5zcGxpY2UodGhpc1BvcywgSW5maW5pdHksIGtleSkgOiBrZXlzLnB1c2goa2V5KTtcblxuICAgICAgaWYgKH5pbmRleE9mKHN0YWNrLCB2YWx1ZSkpIHtcbiAgICAgICAgdmFsdWUgPSBjeWNsZVJlcGxhY2VyLmNhbGwodGhpcywga2V5LCB2YWx1ZSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHN0YWNrLnB1c2godmFsdWUpO1xuICAgIH1cblxuICAgIHJldHVybiByZXBsYWNlciA9PSBudWxsXG4gICAgICA/IHZhbHVlIGluc3RhbmNlb2YgRXJyb3IgPyBzdHJpbmdpZnlFcnJvcih2YWx1ZSkgOiB2YWx1ZVxuICAgICAgOiByZXBsYWNlci5jYWxsKHRoaXMsIGtleSwgdmFsdWUpO1xuICB9O1xufVxuIiwiLypcbiAqIEphdmFTY3JpcHQgTUQ1XG4gKiBodHRwczovL2dpdGh1Yi5jb20vYmx1ZWltcC9KYXZhU2NyaXB0LU1ENVxuICpcbiAqIENvcHlyaWdodCAyMDExLCBTZWJhc3RpYW4gVHNjaGFuXG4gKiBodHRwczovL2JsdWVpbXAubmV0XG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlOlxuICogaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVRcbiAqXG4gKiBCYXNlZCBvblxuICogQSBKYXZhU2NyaXB0IGltcGxlbWVudGF0aW9uIG9mIHRoZSBSU0EgRGF0YSBTZWN1cml0eSwgSW5jLiBNRDUgTWVzc2FnZVxuICogRGlnZXN0IEFsZ29yaXRobSwgYXMgZGVmaW5lZCBpbiBSRkMgMTMyMS5cbiAqIFZlcnNpb24gMi4yIENvcHlyaWdodCAoQykgUGF1bCBKb2huc3RvbiAxOTk5IC0gMjAwOVxuICogT3RoZXIgY29udHJpYnV0b3JzOiBHcmVnIEhvbHQsIEFuZHJldyBLZXBlcnQsIFlkbmFyLCBMb3N0aW5ldFxuICogRGlzdHJpYnV0ZWQgdW5kZXIgdGhlIEJTRCBMaWNlbnNlXG4gKiBTZWUgaHR0cDovL3BhamhvbWUub3JnLnVrL2NyeXB0L21kNSBmb3IgbW9yZSBpbmZvLlxuICovXG5cbi8qXG4qIEFkZCBpbnRlZ2Vycywgd3JhcHBpbmcgYXQgMl4zMi4gVGhpcyB1c2VzIDE2LWJpdCBvcGVyYXRpb25zIGludGVybmFsbHlcbiogdG8gd29yayBhcm91bmQgYnVncyBpbiBzb21lIEpTIGludGVycHJldGVycy5cbiovXG5mdW5jdGlvbiBzYWZlQWRkKHgsIHkpIHtcbiAgdmFyIGxzdyA9ICh4ICYgMHhmZmZmKSArICh5ICYgMHhmZmZmKTtcbiAgdmFyIG1zdyA9ICh4ID4+IDE2KSArICh5ID4+IDE2KSArIChsc3cgPj4gMTYpO1xuICByZXR1cm4gKG1zdyA8PCAxNikgfCAobHN3ICYgMHhmZmZmKTtcbn1cblxuLypcbiogQml0d2lzZSByb3RhdGUgYSAzMi1iaXQgbnVtYmVyIHRvIHRoZSBsZWZ0LlxuKi9cbmZ1bmN0aW9uIGJpdFJvdGF0ZUxlZnQobnVtLCBjbnQpIHtcbiAgcmV0dXJuIChudW0gPDwgY250KSB8IChudW0gPj4+ICgzMiAtIGNudCkpO1xufVxuXG4vKlxuKiBUaGVzZSBmdW5jdGlvbnMgaW1wbGVtZW50IHRoZSBmb3VyIGJhc2ljIG9wZXJhdGlvbnMgdGhlIGFsZ29yaXRobSB1c2VzLlxuKi9cbmZ1bmN0aW9uIG1kNWNtbihxLCBhLCBiLCB4LCBzLCB0KSB7XG4gIHJldHVybiBzYWZlQWRkKGJpdFJvdGF0ZUxlZnQoc2FmZUFkZChzYWZlQWRkKGEsIHEpLCBzYWZlQWRkKHgsIHQpKSwgcyksIGIpO1xufVxuZnVuY3Rpb24gbWQ1ZmYoYSwgYiwgYywgZCwgeCwgcywgdCkge1xuICByZXR1cm4gbWQ1Y21uKChiICYgYykgfCAofmIgJiBkKSwgYSwgYiwgeCwgcywgdCk7XG59XG5mdW5jdGlvbiBtZDVnZyhhLCBiLCBjLCBkLCB4LCBzLCB0KSB7XG4gIHJldHVybiBtZDVjbW4oKGIgJiBkKSB8IChjICYgfmQpLCBhLCBiLCB4LCBzLCB0KTtcbn1cbmZ1bmN0aW9uIG1kNWhoKGEsIGIsIGMsIGQsIHgsIHMsIHQpIHtcbiAgcmV0dXJuIG1kNWNtbihiIF4gYyBeIGQsIGEsIGIsIHgsIHMsIHQpO1xufVxuZnVuY3Rpb24gbWQ1aWkoYSwgYiwgYywgZCwgeCwgcywgdCkge1xuICByZXR1cm4gbWQ1Y21uKGMgXiAoYiB8IH5kKSwgYSwgYiwgeCwgcywgdCk7XG59XG5cbi8qXG4qIENhbGN1bGF0ZSB0aGUgTUQ1IG9mIGFuIGFycmF5IG9mIGxpdHRsZS1lbmRpYW4gd29yZHMsIGFuZCBhIGJpdCBsZW5ndGguXG4qL1xuZnVuY3Rpb24gYmlubE1ENSh4LCBsZW4pIHtcbiAgLyogYXBwZW5kIHBhZGRpbmcgKi9cbiAgeFtsZW4gPj4gNV0gfD0gMHg4MCA8PCAobGVuICUgMzIpO1xuICB4WygoKGxlbiArIDY0KSA+Pj4gOSkgPDwgNCkgKyAxNF0gPSBsZW47XG5cbiAgdmFyIGk7XG4gIHZhciBvbGRhO1xuICB2YXIgb2xkYjtcbiAgdmFyIG9sZGM7XG4gIHZhciBvbGRkO1xuICB2YXIgYSA9IDE3MzI1ODQxOTM7XG4gIHZhciBiID0gLTI3MTczMzg3OTtcbiAgdmFyIGMgPSAtMTczMjU4NDE5NDtcbiAgdmFyIGQgPSAyNzE3MzM4Nzg7XG5cbiAgZm9yIChpID0gMDsgaSA8IHgubGVuZ3RoOyBpICs9IDE2KSB7XG4gICAgb2xkYSA9IGE7XG4gICAgb2xkYiA9IGI7XG4gICAgb2xkYyA9IGM7XG4gICAgb2xkZCA9IGQ7XG5cbiAgICBhID0gbWQ1ZmYoYSwgYiwgYywgZCwgeFtpXSwgNywgLTY4MDg3NjkzNik7XG4gICAgZCA9IG1kNWZmKGQsIGEsIGIsIGMsIHhbaSArIDFdLCAxMiwgLTM4OTU2NDU4Nik7XG4gICAgYyA9IG1kNWZmKGMsIGQsIGEsIGIsIHhbaSArIDJdLCAxNywgNjA2MTA1ODE5KTtcbiAgICBiID0gbWQ1ZmYoYiwgYywgZCwgYSwgeFtpICsgM10sIDIyLCAtMTA0NDUyNTMzMCk7XG4gICAgYSA9IG1kNWZmKGEsIGIsIGMsIGQsIHhbaSArIDRdLCA3LCAtMTc2NDE4ODk3KTtcbiAgICBkID0gbWQ1ZmYoZCwgYSwgYiwgYywgeFtpICsgNV0sIDEyLCAxMjAwMDgwNDI2KTtcbiAgICBjID0gbWQ1ZmYoYywgZCwgYSwgYiwgeFtpICsgNl0sIDE3LCAtMTQ3MzIzMTM0MSk7XG4gICAgYiA9IG1kNWZmKGIsIGMsIGQsIGEsIHhbaSArIDddLCAyMiwgLTQ1NzA1OTgzKTtcbiAgICBhID0gbWQ1ZmYoYSwgYiwgYywgZCwgeFtpICsgOF0sIDcsIDE3NzAwMzU0MTYpO1xuICAgIGQgPSBtZDVmZihkLCBhLCBiLCBjLCB4W2kgKyA5XSwgMTIsIC0xOTU4NDE0NDE3KTtcbiAgICBjID0gbWQ1ZmYoYywgZCwgYSwgYiwgeFtpICsgMTBdLCAxNywgLTQyMDYzKTtcbiAgICBiID0gbWQ1ZmYoYiwgYywgZCwgYSwgeFtpICsgMTFdLCAyMiwgLTE5OTA0MDQxNjIpO1xuICAgIGEgPSBtZDVmZihhLCBiLCBjLCBkLCB4W2kgKyAxMl0sIDcsIDE4MDQ2MDM2ODIpO1xuICAgIGQgPSBtZDVmZihkLCBhLCBiLCBjLCB4W2kgKyAxM10sIDEyLCAtNDAzNDExMDEpO1xuICAgIGMgPSBtZDVmZihjLCBkLCBhLCBiLCB4W2kgKyAxNF0sIDE3LCAtMTUwMjAwMjI5MCk7XG4gICAgYiA9IG1kNWZmKGIsIGMsIGQsIGEsIHhbaSArIDE1XSwgMjIsIDEyMzY1MzUzMjkpO1xuXG4gICAgYSA9IG1kNWdnKGEsIGIsIGMsIGQsIHhbaSArIDFdLCA1LCAtMTY1Nzk2NTEwKTtcbiAgICBkID0gbWQ1Z2coZCwgYSwgYiwgYywgeFtpICsgNl0sIDksIC0xMDY5NTAxNjMyKTtcbiAgICBjID0gbWQ1Z2coYywgZCwgYSwgYiwgeFtpICsgMTFdLCAxNCwgNjQzNzE3NzEzKTtcbiAgICBiID0gbWQ1Z2coYiwgYywgZCwgYSwgeFtpXSwgMjAsIC0zNzM4OTczMDIpO1xuICAgIGEgPSBtZDVnZyhhLCBiLCBjLCBkLCB4W2kgKyA1XSwgNSwgLTcwMTU1ODY5MSk7XG4gICAgZCA9IG1kNWdnKGQsIGEsIGIsIGMsIHhbaSArIDEwXSwgOSwgMzgwMTYwODMpO1xuICAgIGMgPSBtZDVnZyhjLCBkLCBhLCBiLCB4W2kgKyAxNV0sIDE0LCAtNjYwNDc4MzM1KTtcbiAgICBiID0gbWQ1Z2coYiwgYywgZCwgYSwgeFtpICsgNF0sIDIwLCAtNDA1NTM3ODQ4KTtcbiAgICBhID0gbWQ1Z2coYSwgYiwgYywgZCwgeFtpICsgOV0sIDUsIDU2ODQ0NjQzOCk7XG4gICAgZCA9IG1kNWdnKGQsIGEsIGIsIGMsIHhbaSArIDE0XSwgOSwgLTEwMTk4MDM2OTApO1xuICAgIGMgPSBtZDVnZyhjLCBkLCBhLCBiLCB4W2kgKyAzXSwgMTQsIC0xODczNjM5NjEpO1xuICAgIGIgPSBtZDVnZyhiLCBjLCBkLCBhLCB4W2kgKyA4XSwgMjAsIDExNjM1MzE1MDEpO1xuICAgIGEgPSBtZDVnZyhhLCBiLCBjLCBkLCB4W2kgKyAxM10sIDUsIC0xNDQ0NjgxNDY3KTtcbiAgICBkID0gbWQ1Z2coZCwgYSwgYiwgYywgeFtpICsgMl0sIDksIC01MTQwMzc4NCk7XG4gICAgYyA9IG1kNWdnKGMsIGQsIGEsIGIsIHhbaSArIDddLCAxNCwgMTczNTMyODQ3Myk7XG4gICAgYiA9IG1kNWdnKGIsIGMsIGQsIGEsIHhbaSArIDEyXSwgMjAsIC0xOTI2NjA3NzM0KTtcblxuICAgIGEgPSBtZDVoaChhLCBiLCBjLCBkLCB4W2kgKyA1XSwgNCwgLTM3ODU1OCk7XG4gICAgZCA9IG1kNWhoKGQsIGEsIGIsIGMsIHhbaSArIDhdLCAxMSwgLTIwMjI1NzQ0NjMpO1xuICAgIGMgPSBtZDVoaChjLCBkLCBhLCBiLCB4W2kgKyAxMV0sIDE2LCAxODM5MDMwNTYyKTtcbiAgICBiID0gbWQ1aGgoYiwgYywgZCwgYSwgeFtpICsgMTRdLCAyMywgLTM1MzA5NTU2KTtcbiAgICBhID0gbWQ1aGgoYSwgYiwgYywgZCwgeFtpICsgMV0sIDQsIC0xNTMwOTkyMDYwKTtcbiAgICBkID0gbWQ1aGgoZCwgYSwgYiwgYywgeFtpICsgNF0sIDExLCAxMjcyODkzMzUzKTtcbiAgICBjID0gbWQ1aGgoYywgZCwgYSwgYiwgeFtpICsgN10sIDE2LCAtMTU1NDk3NjMyKTtcbiAgICBiID0gbWQ1aGgoYiwgYywgZCwgYSwgeFtpICsgMTBdLCAyMywgLTEwOTQ3MzA2NDApO1xuICAgIGEgPSBtZDVoaChhLCBiLCBjLCBkLCB4W2kgKyAxM10sIDQsIDY4MTI3OTE3NCk7XG4gICAgZCA9IG1kNWhoKGQsIGEsIGIsIGMsIHhbaV0sIDExLCAtMzU4NTM3MjIyKTtcbiAgICBjID0gbWQ1aGgoYywgZCwgYSwgYiwgeFtpICsgM10sIDE2LCAtNzIyNTIxOTc5KTtcbiAgICBiID0gbWQ1aGgoYiwgYywgZCwgYSwgeFtpICsgNl0sIDIzLCA3NjAyOTE4OSk7XG4gICAgYSA9IG1kNWhoKGEsIGIsIGMsIGQsIHhbaSArIDldLCA0LCAtNjQwMzY0NDg3KTtcbiAgICBkID0gbWQ1aGgoZCwgYSwgYiwgYywgeFtpICsgMTJdLCAxMSwgLTQyMTgxNTgzNSk7XG4gICAgYyA9IG1kNWhoKGMsIGQsIGEsIGIsIHhbaSArIDE1XSwgMTYsIDUzMDc0MjUyMCk7XG4gICAgYiA9IG1kNWhoKGIsIGMsIGQsIGEsIHhbaSArIDJdLCAyMywgLTk5NTMzODY1MSk7XG5cbiAgICBhID0gbWQ1aWkoYSwgYiwgYywgZCwgeFtpXSwgNiwgLTE5ODYzMDg0NCk7XG4gICAgZCA9IG1kNWlpKGQsIGEsIGIsIGMsIHhbaSArIDddLCAxMCwgMTEyNjg5MTQxNSk7XG4gICAgYyA9IG1kNWlpKGMsIGQsIGEsIGIsIHhbaSArIDE0XSwgMTUsIC0xNDE2MzU0OTA1KTtcbiAgICBiID0gbWQ1aWkoYiwgYywgZCwgYSwgeFtpICsgNV0sIDIxLCAtNTc0MzQwNTUpO1xuICAgIGEgPSBtZDVpaShhLCBiLCBjLCBkLCB4W2kgKyAxMl0sIDYsIDE3MDA0ODU1NzEpO1xuICAgIGQgPSBtZDVpaShkLCBhLCBiLCBjLCB4W2kgKyAzXSwgMTAsIC0xODk0OTg2NjA2KTtcbiAgICBjID0gbWQ1aWkoYywgZCwgYSwgYiwgeFtpICsgMTBdLCAxNSwgLTEwNTE1MjMpO1xuICAgIGIgPSBtZDVpaShiLCBjLCBkLCBhLCB4W2kgKyAxXSwgMjEsIC0yMDU0OTIyNzk5KTtcbiAgICBhID0gbWQ1aWkoYSwgYiwgYywgZCwgeFtpICsgOF0sIDYsIDE4NzMzMTMzNTkpO1xuICAgIGQgPSBtZDVpaShkLCBhLCBiLCBjLCB4W2kgKyAxNV0sIDEwLCAtMzA2MTE3NDQpO1xuICAgIGMgPSBtZDVpaShjLCBkLCBhLCBiLCB4W2kgKyA2XSwgMTUsIC0xNTYwMTk4MzgwKTtcbiAgICBiID0gbWQ1aWkoYiwgYywgZCwgYSwgeFtpICsgMTNdLCAyMSwgMTMwOTE1MTY0OSk7XG4gICAgYSA9IG1kNWlpKGEsIGIsIGMsIGQsIHhbaSArIDRdLCA2LCAtMTQ1NTIzMDcwKTtcbiAgICBkID0gbWQ1aWkoZCwgYSwgYiwgYywgeFtpICsgMTFdLCAxMCwgLTExMjAyMTAzNzkpO1xuICAgIGMgPSBtZDVpaShjLCBkLCBhLCBiLCB4W2kgKyAyXSwgMTUsIDcxODc4NzI1OSk7XG4gICAgYiA9IG1kNWlpKGIsIGMsIGQsIGEsIHhbaSArIDldLCAyMSwgLTM0MzQ4NTU1MSk7XG5cbiAgICBhID0gc2FmZUFkZChhLCBvbGRhKTtcbiAgICBiID0gc2FmZUFkZChiLCBvbGRiKTtcbiAgICBjID0gc2FmZUFkZChjLCBvbGRjKTtcbiAgICBkID0gc2FmZUFkZChkLCBvbGRkKTtcbiAgfVxuICByZXR1cm4gW2EsIGIsIGMsIGRdO1xufVxuXG4vKlxuKiBDb252ZXJ0IGFuIGFycmF5IG9mIGxpdHRsZS1lbmRpYW4gd29yZHMgdG8gYSBzdHJpbmdcbiovXG5mdW5jdGlvbiBiaW5sMnJzdHIoaW5wdXQpIHtcbiAgdmFyIGk7XG4gIHZhciBvdXRwdXQgPSAnJztcbiAgdmFyIGxlbmd0aDMyID0gaW5wdXQubGVuZ3RoICogMzI7XG4gIGZvciAoaSA9IDA7IGkgPCBsZW5ndGgzMjsgaSArPSA4KSB7XG4gICAgb3V0cHV0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoKGlucHV0W2kgPj4gNV0gPj4+IChpICUgMzIpKSAmIDB4ZmYpO1xuICB9XG4gIHJldHVybiBvdXRwdXQ7XG59XG5cbi8qXG4qIENvbnZlcnQgYSByYXcgc3RyaW5nIHRvIGFuIGFycmF5IG9mIGxpdHRsZS1lbmRpYW4gd29yZHNcbiogQ2hhcmFjdGVycyA+MjU1IGhhdmUgdGhlaXIgaGlnaC1ieXRlIHNpbGVudGx5IGlnbm9yZWQuXG4qL1xuZnVuY3Rpb24gcnN0cjJiaW5sKGlucHV0KSB7XG4gIHZhciBpO1xuICB2YXIgb3V0cHV0ID0gW107XG4gIG91dHB1dFsoaW5wdXQubGVuZ3RoID4+IDIpIC0gMV0gPSB1bmRlZmluZWQ7XG4gIGZvciAoaSA9IDA7IGkgPCBvdXRwdXQubGVuZ3RoOyBpICs9IDEpIHtcbiAgICBvdXRwdXRbaV0gPSAwO1xuICB9XG4gIHZhciBsZW5ndGg4ID0gaW5wdXQubGVuZ3RoICogODtcbiAgZm9yIChpID0gMDsgaSA8IGxlbmd0aDg7IGkgKz0gOCkge1xuICAgIG91dHB1dFtpID4+IDVdIHw9IChpbnB1dC5jaGFyQ29kZUF0KGkgLyA4KSAmIDB4ZmYpIDw8IChpICUgMzIpO1xuICB9XG4gIHJldHVybiBvdXRwdXQ7XG59XG5cbi8qXG4qIENhbGN1bGF0ZSB0aGUgTUQ1IG9mIGEgcmF3IHN0cmluZ1xuKi9cbmZ1bmN0aW9uIHJzdHJNRDUocykge1xuICByZXR1cm4gYmlubDJyc3RyKGJpbmxNRDUocnN0cjJiaW5sKHMpLCBzLmxlbmd0aCAqIDgpKTtcbn1cblxuLypcbiogQ2FsY3VsYXRlIHRoZSBITUFDLU1ENSwgb2YgYSBrZXkgYW5kIHNvbWUgZGF0YSAocmF3IHN0cmluZ3MpXG4qL1xuZnVuY3Rpb24gcnN0ckhNQUNNRDUoa2V5LCBkYXRhKSB7XG4gIHZhciBpO1xuICB2YXIgYmtleSA9IHJzdHIyYmlubChrZXkpO1xuICB2YXIgaXBhZCA9IFtdO1xuICB2YXIgb3BhZCA9IFtdO1xuICB2YXIgaGFzaDtcbiAgaXBhZFsxNV0gPSBvcGFkWzE1XSA9IHVuZGVmaW5lZDtcbiAgaWYgKGJrZXkubGVuZ3RoID4gMTYpIHtcbiAgICBia2V5ID0gYmlubE1ENShia2V5LCBrZXkubGVuZ3RoICogOCk7XG4gIH1cbiAgZm9yIChpID0gMDsgaSA8IDE2OyBpICs9IDEpIHtcbiAgICBpcGFkW2ldID0gYmtleVtpXSBeIDB4MzYzNjM2MzY7XG4gICAgb3BhZFtpXSA9IGJrZXlbaV0gXiAweDVjNWM1YzVjO1xuICB9XG4gIGhhc2ggPSBiaW5sTUQ1KGlwYWQuY29uY2F0KHJzdHIyYmlubChkYXRhKSksIDUxMiArIGRhdGEubGVuZ3RoICogOCk7XG4gIHJldHVybiBiaW5sMnJzdHIoYmlubE1ENShvcGFkLmNvbmNhdChoYXNoKSwgNTEyICsgMTI4KSk7XG59XG5cbi8qXG4qIENvbnZlcnQgYSByYXcgc3RyaW5nIHRvIGEgaGV4IHN0cmluZ1xuKi9cbmZ1bmN0aW9uIHJzdHIyaGV4KGlucHV0KSB7XG4gIHZhciBoZXhUYWIgPSAnMDEyMzQ1Njc4OWFiY2RlZic7XG4gIHZhciBvdXRwdXQgPSAnJztcbiAgdmFyIHg7XG4gIHZhciBpO1xuICBmb3IgKGkgPSAwOyBpIDwgaW5wdXQubGVuZ3RoOyBpICs9IDEpIHtcbiAgICB4ID0gaW5wdXQuY2hhckNvZGVBdChpKTtcbiAgICBvdXRwdXQgKz0gaGV4VGFiLmNoYXJBdCgoeCA+Pj4gNCkgJiAweDBmKSArIGhleFRhYi5jaGFyQXQoeCAmIDB4MGYpO1xuICB9XG4gIHJldHVybiBvdXRwdXQ7XG59XG5cbi8qXG4qIEVuY29kZSBhIHN0cmluZyBhcyB1dGYtOFxuKi9cbmZ1bmN0aW9uIHN0cjJyc3RyVVRGOChpbnB1dCkge1xuICByZXR1cm4gdW5lc2NhcGUoZW5jb2RlVVJJQ29tcG9uZW50KGlucHV0KSk7XG59XG5cbi8qXG4qIFRha2Ugc3RyaW5nIGFyZ3VtZW50cyBhbmQgcmV0dXJuIGVpdGhlciByYXcgb3IgaGV4IGVuY29kZWQgc3RyaW5nc1xuKi9cbmZ1bmN0aW9uIHJhd01ENShzKSB7XG4gIHJldHVybiByc3RyTUQ1KHN0cjJyc3RyVVRGOChzKSk7XG59XG5mdW5jdGlvbiBoZXhNRDUocykge1xuICByZXR1cm4gcnN0cjJoZXgocmF3TUQ1KHMpKTtcbn1cbmZ1bmN0aW9uIHJhd0hNQUNNRDUoaywgZCkge1xuICByZXR1cm4gcnN0ckhNQUNNRDUoc3RyMnJzdHJVVEY4KGspLCBzdHIycnN0clVURjgoZCkpO1xufVxuZnVuY3Rpb24gaGV4SE1BQ01ENShrLCBkKSB7XG4gIHJldHVybiByc3RyMmhleChyYXdITUFDTUQ1KGssIGQpKTtcbn1cblxuZnVuY3Rpb24gbWQ1KHN0cmluZywga2V5LCByYXcpIHtcbiAgaWYgKCFrZXkpIHtcbiAgICBpZiAoIXJhdykge1xuICAgICAgcmV0dXJuIGhleE1ENShzdHJpbmcpO1xuICAgIH1cbiAgICByZXR1cm4gcmF3TUQ1KHN0cmluZyk7XG4gIH1cbiAgaWYgKCFyYXcpIHtcbiAgICByZXR1cm4gaGV4SE1BQ01ENShrZXksIHN0cmluZyk7XG4gIH1cbiAgcmV0dXJuIHJhd0hNQUNNRDUoa2V5LCBzdHJpbmcpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IG1kNTtcbiIsIi8vIENvcHlyaWdodCBKb3llbnQsIEluYy4gYW5kIG90aGVyIE5vZGUgY29udHJpYnV0b3JzLlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhXG4vLyBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlXG4vLyBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmdcbi8vIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCxcbi8vIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXRcbi8vIHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZVxuLy8gZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWRcbi8vIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1Ncbi8vIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0Zcbi8vIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU5cbi8vIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLFxuLy8gREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SXG4vLyBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFXG4vLyBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuXG4ndXNlIHN0cmljdCc7XG5cbnZhciBwdW55Y29kZSA9IHJlcXVpcmUoJ3B1bnljb2RlJyk7XG52YXIgdXRpbCA9IHJlcXVpcmUoJy4vdXRpbCcpO1xuXG5leHBvcnRzLnBhcnNlID0gdXJsUGFyc2U7XG5leHBvcnRzLnJlc29sdmUgPSB1cmxSZXNvbHZlO1xuZXhwb3J0cy5yZXNvbHZlT2JqZWN0ID0gdXJsUmVzb2x2ZU9iamVjdDtcbmV4cG9ydHMuZm9ybWF0ID0gdXJsRm9ybWF0O1xuXG5leHBvcnRzLlVybCA9IFVybDtcblxuZnVuY3Rpb24gVXJsKCkge1xuICB0aGlzLnByb3RvY29sID0gbnVsbDtcbiAgdGhpcy5zbGFzaGVzID0gbnVsbDtcbiAgdGhpcy5hdXRoID0gbnVsbDtcbiAgdGhpcy5ob3N0ID0gbnVsbDtcbiAgdGhpcy5wb3J0ID0gbnVsbDtcbiAgdGhpcy5ob3N0bmFtZSA9IG51bGw7XG4gIHRoaXMuaGFzaCA9IG51bGw7XG4gIHRoaXMuc2VhcmNoID0gbnVsbDtcbiAgdGhpcy5xdWVyeSA9IG51bGw7XG4gIHRoaXMucGF0aG5hbWUgPSBudWxsO1xuICB0aGlzLnBhdGggPSBudWxsO1xuICB0aGlzLmhyZWYgPSBudWxsO1xufVxuXG4vLyBSZWZlcmVuY2U6IFJGQyAzOTg2LCBSRkMgMTgwOCwgUkZDIDIzOTZcblxuLy8gZGVmaW5lIHRoZXNlIGhlcmUgc28gYXQgbGVhc3QgdGhleSBvbmx5IGhhdmUgdG8gYmVcbi8vIGNvbXBpbGVkIG9uY2Ugb24gdGhlIGZpcnN0IG1vZHVsZSBsb2FkLlxudmFyIHByb3RvY29sUGF0dGVybiA9IC9eKFthLXowLTkuKy1dKzopL2ksXG4gICAgcG9ydFBhdHRlcm4gPSAvOlswLTldKiQvLFxuXG4gICAgLy8gU3BlY2lhbCBjYXNlIGZvciBhIHNpbXBsZSBwYXRoIFVSTFxuICAgIHNpbXBsZVBhdGhQYXR0ZXJuID0gL14oXFwvXFwvPyg/IVxcLylbXlxcP1xcc10qKShcXD9bXlxcc10qKT8kLyxcblxuICAgIC8vIFJGQyAyMzk2OiBjaGFyYWN0ZXJzIHJlc2VydmVkIGZvciBkZWxpbWl0aW5nIFVSTHMuXG4gICAgLy8gV2UgYWN0dWFsbHkganVzdCBhdXRvLWVzY2FwZSB0aGVzZS5cbiAgICBkZWxpbXMgPSBbJzwnLCAnPicsICdcIicsICdgJywgJyAnLCAnXFxyJywgJ1xcbicsICdcXHQnXSxcblxuICAgIC8vIFJGQyAyMzk2OiBjaGFyYWN0ZXJzIG5vdCBhbGxvd2VkIGZvciB2YXJpb3VzIHJlYXNvbnMuXG4gICAgdW53aXNlID0gWyd7JywgJ30nLCAnfCcsICdcXFxcJywgJ14nLCAnYCddLmNvbmNhdChkZWxpbXMpLFxuXG4gICAgLy8gQWxsb3dlZCBieSBSRkNzLCBidXQgY2F1c2Ugb2YgWFNTIGF0dGFja3MuICBBbHdheXMgZXNjYXBlIHRoZXNlLlxuICAgIGF1dG9Fc2NhcGUgPSBbJ1xcJyddLmNvbmNhdCh1bndpc2UpLFxuICAgIC8vIENoYXJhY3RlcnMgdGhhdCBhcmUgbmV2ZXIgZXZlciBhbGxvd2VkIGluIGEgaG9zdG5hbWUuXG4gICAgLy8gTm90ZSB0aGF0IGFueSBpbnZhbGlkIGNoYXJzIGFyZSBhbHNvIGhhbmRsZWQsIGJ1dCB0aGVzZVxuICAgIC8vIGFyZSB0aGUgb25lcyB0aGF0IGFyZSAqZXhwZWN0ZWQqIHRvIGJlIHNlZW4sIHNvIHdlIGZhc3QtcGF0aFxuICAgIC8vIHRoZW0uXG4gICAgbm9uSG9zdENoYXJzID0gWyclJywgJy8nLCAnPycsICc7JywgJyMnXS5jb25jYXQoYXV0b0VzY2FwZSksXG4gICAgaG9zdEVuZGluZ0NoYXJzID0gWycvJywgJz8nLCAnIyddLFxuICAgIGhvc3RuYW1lTWF4TGVuID0gMjU1LFxuICAgIGhvc3RuYW1lUGFydFBhdHRlcm4gPSAvXlsrYS16MC05QS1aXy1dezAsNjN9JC8sXG4gICAgaG9zdG5hbWVQYXJ0U3RhcnQgPSAvXihbK2EtejAtOUEtWl8tXXswLDYzfSkoLiopJC8sXG4gICAgLy8gcHJvdG9jb2xzIHRoYXQgY2FuIGFsbG93IFwidW5zYWZlXCIgYW5kIFwidW53aXNlXCIgY2hhcnMuXG4gICAgdW5zYWZlUHJvdG9jb2wgPSB7XG4gICAgICAnamF2YXNjcmlwdCc6IHRydWUsXG4gICAgICAnamF2YXNjcmlwdDonOiB0cnVlXG4gICAgfSxcbiAgICAvLyBwcm90b2NvbHMgdGhhdCBuZXZlciBoYXZlIGEgaG9zdG5hbWUuXG4gICAgaG9zdGxlc3NQcm90b2NvbCA9IHtcbiAgICAgICdqYXZhc2NyaXB0JzogdHJ1ZSxcbiAgICAgICdqYXZhc2NyaXB0Oic6IHRydWVcbiAgICB9LFxuICAgIC8vIHByb3RvY29scyB0aGF0IGFsd2F5cyBjb250YWluIGEgLy8gYml0LlxuICAgIHNsYXNoZWRQcm90b2NvbCA9IHtcbiAgICAgICdodHRwJzogdHJ1ZSxcbiAgICAgICdodHRwcyc6IHRydWUsXG4gICAgICAnZnRwJzogdHJ1ZSxcbiAgICAgICdnb3BoZXInOiB0cnVlLFxuICAgICAgJ2ZpbGUnOiB0cnVlLFxuICAgICAgJ2h0dHA6JzogdHJ1ZSxcbiAgICAgICdodHRwczonOiB0cnVlLFxuICAgICAgJ2Z0cDonOiB0cnVlLFxuICAgICAgJ2dvcGhlcjonOiB0cnVlLFxuICAgICAgJ2ZpbGU6JzogdHJ1ZVxuICAgIH0sXG4gICAgcXVlcnlzdHJpbmcgPSByZXF1aXJlKCdxdWVyeXN0cmluZycpO1xuXG5mdW5jdGlvbiB1cmxQYXJzZSh1cmwsIHBhcnNlUXVlcnlTdHJpbmcsIHNsYXNoZXNEZW5vdGVIb3N0KSB7XG4gIGlmICh1cmwgJiYgdXRpbC5pc09iamVjdCh1cmwpICYmIHVybCBpbnN0YW5jZW9mIFVybCkgcmV0dXJuIHVybDtcblxuICB2YXIgdSA9IG5ldyBVcmw7XG4gIHUucGFyc2UodXJsLCBwYXJzZVF1ZXJ5U3RyaW5nLCBzbGFzaGVzRGVub3RlSG9zdCk7XG4gIHJldHVybiB1O1xufVxuXG5VcmwucHJvdG90eXBlLnBhcnNlID0gZnVuY3Rpb24odXJsLCBwYXJzZVF1ZXJ5U3RyaW5nLCBzbGFzaGVzRGVub3RlSG9zdCkge1xuICBpZiAoIXV0aWwuaXNTdHJpbmcodXJsKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJQYXJhbWV0ZXIgJ3VybCcgbXVzdCBiZSBhIHN0cmluZywgbm90IFwiICsgdHlwZW9mIHVybCk7XG4gIH1cblxuICAvLyBDb3B5IGNocm9tZSwgSUUsIG9wZXJhIGJhY2tzbGFzaC1oYW5kbGluZyBiZWhhdmlvci5cbiAgLy8gQmFjayBzbGFzaGVzIGJlZm9yZSB0aGUgcXVlcnkgc3RyaW5nIGdldCBjb252ZXJ0ZWQgdG8gZm9yd2FyZCBzbGFzaGVzXG4gIC8vIFNlZTogaHR0cHM6Ly9jb2RlLmdvb2dsZS5jb20vcC9jaHJvbWl1bS9pc3N1ZXMvZGV0YWlsP2lkPTI1OTE2XG4gIHZhciBxdWVyeUluZGV4ID0gdXJsLmluZGV4T2YoJz8nKSxcbiAgICAgIHNwbGl0dGVyID1cbiAgICAgICAgICAocXVlcnlJbmRleCAhPT0gLTEgJiYgcXVlcnlJbmRleCA8IHVybC5pbmRleE9mKCcjJykpID8gJz8nIDogJyMnLFxuICAgICAgdVNwbGl0ID0gdXJsLnNwbGl0KHNwbGl0dGVyKSxcbiAgICAgIHNsYXNoUmVnZXggPSAvXFxcXC9nO1xuICB1U3BsaXRbMF0gPSB1U3BsaXRbMF0ucmVwbGFjZShzbGFzaFJlZ2V4LCAnLycpO1xuICB1cmwgPSB1U3BsaXQuam9pbihzcGxpdHRlcik7XG5cbiAgdmFyIHJlc3QgPSB1cmw7XG5cbiAgLy8gdHJpbSBiZWZvcmUgcHJvY2VlZGluZy5cbiAgLy8gVGhpcyBpcyB0byBzdXBwb3J0IHBhcnNlIHN0dWZmIGxpa2UgXCIgIGh0dHA6Ly9mb28uY29tICBcXG5cIlxuICByZXN0ID0gcmVzdC50cmltKCk7XG5cbiAgaWYgKCFzbGFzaGVzRGVub3RlSG9zdCAmJiB1cmwuc3BsaXQoJyMnKS5sZW5ndGggPT09IDEpIHtcbiAgICAvLyBUcnkgZmFzdCBwYXRoIHJlZ2V4cFxuICAgIHZhciBzaW1wbGVQYXRoID0gc2ltcGxlUGF0aFBhdHRlcm4uZXhlYyhyZXN0KTtcbiAgICBpZiAoc2ltcGxlUGF0aCkge1xuICAgICAgdGhpcy5wYXRoID0gcmVzdDtcbiAgICAgIHRoaXMuaHJlZiA9IHJlc3Q7XG4gICAgICB0aGlzLnBhdGhuYW1lID0gc2ltcGxlUGF0aFsxXTtcbiAgICAgIGlmIChzaW1wbGVQYXRoWzJdKSB7XG4gICAgICAgIHRoaXMuc2VhcmNoID0gc2ltcGxlUGF0aFsyXTtcbiAgICAgICAgaWYgKHBhcnNlUXVlcnlTdHJpbmcpIHtcbiAgICAgICAgICB0aGlzLnF1ZXJ5ID0gcXVlcnlzdHJpbmcucGFyc2UodGhpcy5zZWFyY2guc3Vic3RyKDEpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLnF1ZXJ5ID0gdGhpcy5zZWFyY2guc3Vic3RyKDEpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKHBhcnNlUXVlcnlTdHJpbmcpIHtcbiAgICAgICAgdGhpcy5zZWFyY2ggPSAnJztcbiAgICAgICAgdGhpcy5xdWVyeSA9IHt9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICB9XG5cbiAgdmFyIHByb3RvID0gcHJvdG9jb2xQYXR0ZXJuLmV4ZWMocmVzdCk7XG4gIGlmIChwcm90bykge1xuICAgIHByb3RvID0gcHJvdG9bMF07XG4gICAgdmFyIGxvd2VyUHJvdG8gPSBwcm90by50b0xvd2VyQ2FzZSgpO1xuICAgIHRoaXMucHJvdG9jb2wgPSBsb3dlclByb3RvO1xuICAgIHJlc3QgPSByZXN0LnN1YnN0cihwcm90by5sZW5ndGgpO1xuICB9XG5cbiAgLy8gZmlndXJlIG91dCBpZiBpdCdzIGdvdCBhIGhvc3RcbiAgLy8gdXNlckBzZXJ2ZXIgaXMgKmFsd2F5cyogaW50ZXJwcmV0ZWQgYXMgYSBob3N0bmFtZSwgYW5kIHVybFxuICAvLyByZXNvbHV0aW9uIHdpbGwgdHJlYXQgLy9mb28vYmFyIGFzIGhvc3Q9Zm9vLHBhdGg9YmFyIGJlY2F1c2UgdGhhdCdzXG4gIC8vIGhvdyB0aGUgYnJvd3NlciByZXNvbHZlcyByZWxhdGl2ZSBVUkxzLlxuICBpZiAoc2xhc2hlc0Rlbm90ZUhvc3QgfHwgcHJvdG8gfHwgcmVzdC5tYXRjaCgvXlxcL1xcL1teQFxcL10rQFteQFxcL10rLykpIHtcbiAgICB2YXIgc2xhc2hlcyA9IHJlc3Quc3Vic3RyKDAsIDIpID09PSAnLy8nO1xuICAgIGlmIChzbGFzaGVzICYmICEocHJvdG8gJiYgaG9zdGxlc3NQcm90b2NvbFtwcm90b10pKSB7XG4gICAgICByZXN0ID0gcmVzdC5zdWJzdHIoMik7XG4gICAgICB0aGlzLnNsYXNoZXMgPSB0cnVlO1xuICAgIH1cbiAgfVxuXG4gIGlmICghaG9zdGxlc3NQcm90b2NvbFtwcm90b10gJiZcbiAgICAgIChzbGFzaGVzIHx8IChwcm90byAmJiAhc2xhc2hlZFByb3RvY29sW3Byb3RvXSkpKSB7XG5cbiAgICAvLyB0aGVyZSdzIGEgaG9zdG5hbWUuXG4gICAgLy8gdGhlIGZpcnN0IGluc3RhbmNlIG9mIC8sID8sIDssIG9yICMgZW5kcyB0aGUgaG9zdC5cbiAgICAvL1xuICAgIC8vIElmIHRoZXJlIGlzIGFuIEAgaW4gdGhlIGhvc3RuYW1lLCB0aGVuIG5vbi1ob3N0IGNoYXJzICphcmUqIGFsbG93ZWRcbiAgICAvLyB0byB0aGUgbGVmdCBvZiB0aGUgbGFzdCBAIHNpZ24sIHVubGVzcyBzb21lIGhvc3QtZW5kaW5nIGNoYXJhY3RlclxuICAgIC8vIGNvbWVzICpiZWZvcmUqIHRoZSBALXNpZ24uXG4gICAgLy8gVVJMcyBhcmUgb2Jub3hpb3VzLlxuICAgIC8vXG4gICAgLy8gZXg6XG4gICAgLy8gaHR0cDovL2FAYkBjLyA9PiB1c2VyOmFAYiBob3N0OmNcbiAgICAvLyBodHRwOi8vYUBiP0BjID0+IHVzZXI6YSBob3N0OmMgcGF0aDovP0BjXG5cbiAgICAvLyB2MC4xMiBUT0RPKGlzYWFjcyk6IFRoaXMgaXMgbm90IHF1aXRlIGhvdyBDaHJvbWUgZG9lcyB0aGluZ3MuXG4gICAgLy8gUmV2aWV3IG91ciB0ZXN0IGNhc2UgYWdhaW5zdCBicm93c2VycyBtb3JlIGNvbXByZWhlbnNpdmVseS5cblxuICAgIC8vIGZpbmQgdGhlIGZpcnN0IGluc3RhbmNlIG9mIGFueSBob3N0RW5kaW5nQ2hhcnNcbiAgICB2YXIgaG9zdEVuZCA9IC0xO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgaG9zdEVuZGluZ0NoYXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YXIgaGVjID0gcmVzdC5pbmRleE9mKGhvc3RFbmRpbmdDaGFyc1tpXSk7XG4gICAgICBpZiAoaGVjICE9PSAtMSAmJiAoaG9zdEVuZCA9PT0gLTEgfHwgaGVjIDwgaG9zdEVuZCkpXG4gICAgICAgIGhvc3RFbmQgPSBoZWM7XG4gICAgfVxuXG4gICAgLy8gYXQgdGhpcyBwb2ludCwgZWl0aGVyIHdlIGhhdmUgYW4gZXhwbGljaXQgcG9pbnQgd2hlcmUgdGhlXG4gICAgLy8gYXV0aCBwb3J0aW9uIGNhbm5vdCBnbyBwYXN0LCBvciB0aGUgbGFzdCBAIGNoYXIgaXMgdGhlIGRlY2lkZXIuXG4gICAgdmFyIGF1dGgsIGF0U2lnbjtcbiAgICBpZiAoaG9zdEVuZCA9PT0gLTEpIHtcbiAgICAgIC8vIGF0U2lnbiBjYW4gYmUgYW55d2hlcmUuXG4gICAgICBhdFNpZ24gPSByZXN0Lmxhc3RJbmRleE9mKCdAJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIGF0U2lnbiBtdXN0IGJlIGluIGF1dGggcG9ydGlvbi5cbiAgICAgIC8vIGh0dHA6Ly9hQGIvY0BkID0+IGhvc3Q6YiBhdXRoOmEgcGF0aDovY0BkXG4gICAgICBhdFNpZ24gPSByZXN0Lmxhc3RJbmRleE9mKCdAJywgaG9zdEVuZCk7XG4gICAgfVxuXG4gICAgLy8gTm93IHdlIGhhdmUgYSBwb3J0aW9uIHdoaWNoIGlzIGRlZmluaXRlbHkgdGhlIGF1dGguXG4gICAgLy8gUHVsbCB0aGF0IG9mZi5cbiAgICBpZiAoYXRTaWduICE9PSAtMSkge1xuICAgICAgYXV0aCA9IHJlc3Quc2xpY2UoMCwgYXRTaWduKTtcbiAgICAgIHJlc3QgPSByZXN0LnNsaWNlKGF0U2lnbiArIDEpO1xuICAgICAgdGhpcy5hdXRoID0gZGVjb2RlVVJJQ29tcG9uZW50KGF1dGgpO1xuICAgIH1cblxuICAgIC8vIHRoZSBob3N0IGlzIHRoZSByZW1haW5pbmcgdG8gdGhlIGxlZnQgb2YgdGhlIGZpcnN0IG5vbi1ob3N0IGNoYXJcbiAgICBob3N0RW5kID0gLTE7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBub25Ib3N0Q2hhcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgIHZhciBoZWMgPSByZXN0LmluZGV4T2Yobm9uSG9zdENoYXJzW2ldKTtcbiAgICAgIGlmIChoZWMgIT09IC0xICYmIChob3N0RW5kID09PSAtMSB8fCBoZWMgPCBob3N0RW5kKSlcbiAgICAgICAgaG9zdEVuZCA9IGhlYztcbiAgICB9XG4gICAgLy8gaWYgd2Ugc3RpbGwgaGF2ZSBub3QgaGl0IGl0LCB0aGVuIHRoZSBlbnRpcmUgdGhpbmcgaXMgYSBob3N0LlxuICAgIGlmIChob3N0RW5kID09PSAtMSlcbiAgICAgIGhvc3RFbmQgPSByZXN0Lmxlbmd0aDtcblxuICAgIHRoaXMuaG9zdCA9IHJlc3Quc2xpY2UoMCwgaG9zdEVuZCk7XG4gICAgcmVzdCA9IHJlc3Quc2xpY2UoaG9zdEVuZCk7XG5cbiAgICAvLyBwdWxsIG91dCBwb3J0LlxuICAgIHRoaXMucGFyc2VIb3N0KCk7XG5cbiAgICAvLyB3ZSd2ZSBpbmRpY2F0ZWQgdGhhdCB0aGVyZSBpcyBhIGhvc3RuYW1lLFxuICAgIC8vIHNvIGV2ZW4gaWYgaXQncyBlbXB0eSwgaXQgaGFzIHRvIGJlIHByZXNlbnQuXG4gICAgdGhpcy5ob3N0bmFtZSA9IHRoaXMuaG9zdG5hbWUgfHwgJyc7XG5cbiAgICAvLyBpZiBob3N0bmFtZSBiZWdpbnMgd2l0aCBbIGFuZCBlbmRzIHdpdGggXVxuICAgIC8vIGFzc3VtZSB0aGF0IGl0J3MgYW4gSVB2NiBhZGRyZXNzLlxuICAgIHZhciBpcHY2SG9zdG5hbWUgPSB0aGlzLmhvc3RuYW1lWzBdID09PSAnWycgJiZcbiAgICAgICAgdGhpcy5ob3N0bmFtZVt0aGlzLmhvc3RuYW1lLmxlbmd0aCAtIDFdID09PSAnXSc7XG5cbiAgICAvLyB2YWxpZGF0ZSBhIGxpdHRsZS5cbiAgICBpZiAoIWlwdjZIb3N0bmFtZSkge1xuICAgICAgdmFyIGhvc3RwYXJ0cyA9IHRoaXMuaG9zdG5hbWUuc3BsaXQoL1xcLi8pO1xuICAgICAgZm9yICh2YXIgaSA9IDAsIGwgPSBob3N0cGFydHMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgIHZhciBwYXJ0ID0gaG9zdHBhcnRzW2ldO1xuICAgICAgICBpZiAoIXBhcnQpIGNvbnRpbnVlO1xuICAgICAgICBpZiAoIXBhcnQubWF0Y2goaG9zdG5hbWVQYXJ0UGF0dGVybikpIHtcbiAgICAgICAgICB2YXIgbmV3cGFydCA9ICcnO1xuICAgICAgICAgIGZvciAodmFyIGogPSAwLCBrID0gcGFydC5sZW5ndGg7IGogPCBrOyBqKyspIHtcbiAgICAgICAgICAgIGlmIChwYXJ0LmNoYXJDb2RlQXQoaikgPiAxMjcpIHtcbiAgICAgICAgICAgICAgLy8gd2UgcmVwbGFjZSBub24tQVNDSUkgY2hhciB3aXRoIGEgdGVtcG9yYXJ5IHBsYWNlaG9sZGVyXG4gICAgICAgICAgICAgIC8vIHdlIG5lZWQgdGhpcyB0byBtYWtlIHN1cmUgc2l6ZSBvZiBob3N0bmFtZSBpcyBub3RcbiAgICAgICAgICAgICAgLy8gYnJva2VuIGJ5IHJlcGxhY2luZyBub24tQVNDSUkgYnkgbm90aGluZ1xuICAgICAgICAgICAgICBuZXdwYXJ0ICs9ICd4JztcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIG5ld3BhcnQgKz0gcGFydFtqXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgLy8gd2UgdGVzdCBhZ2FpbiB3aXRoIEFTQ0lJIGNoYXIgb25seVxuICAgICAgICAgIGlmICghbmV3cGFydC5tYXRjaChob3N0bmFtZVBhcnRQYXR0ZXJuKSkge1xuICAgICAgICAgICAgdmFyIHZhbGlkUGFydHMgPSBob3N0cGFydHMuc2xpY2UoMCwgaSk7XG4gICAgICAgICAgICB2YXIgbm90SG9zdCA9IGhvc3RwYXJ0cy5zbGljZShpICsgMSk7XG4gICAgICAgICAgICB2YXIgYml0ID0gcGFydC5tYXRjaChob3N0bmFtZVBhcnRTdGFydCk7XG4gICAgICAgICAgICBpZiAoYml0KSB7XG4gICAgICAgICAgICAgIHZhbGlkUGFydHMucHVzaChiaXRbMV0pO1xuICAgICAgICAgICAgICBub3RIb3N0LnVuc2hpZnQoYml0WzJdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChub3RIb3N0Lmxlbmd0aCkge1xuICAgICAgICAgICAgICByZXN0ID0gJy8nICsgbm90SG9zdC5qb2luKCcuJykgKyByZXN0O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5ob3N0bmFtZSA9IHZhbGlkUGFydHMuam9pbignLicpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuaG9zdG5hbWUubGVuZ3RoID4gaG9zdG5hbWVNYXhMZW4pIHtcbiAgICAgIHRoaXMuaG9zdG5hbWUgPSAnJztcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gaG9zdG5hbWVzIGFyZSBhbHdheXMgbG93ZXIgY2FzZS5cbiAgICAgIHRoaXMuaG9zdG5hbWUgPSB0aGlzLmhvc3RuYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgfVxuXG4gICAgaWYgKCFpcHY2SG9zdG5hbWUpIHtcbiAgICAgIC8vIElETkEgU3VwcG9ydDogUmV0dXJucyBhIHB1bnljb2RlZCByZXByZXNlbnRhdGlvbiBvZiBcImRvbWFpblwiLlxuICAgICAgLy8gSXQgb25seSBjb252ZXJ0cyBwYXJ0cyBvZiB0aGUgZG9tYWluIG5hbWUgdGhhdFxuICAgICAgLy8gaGF2ZSBub24tQVNDSUkgY2hhcmFjdGVycywgaS5lLiBpdCBkb2Vzbid0IG1hdHRlciBpZlxuICAgICAgLy8geW91IGNhbGwgaXQgd2l0aCBhIGRvbWFpbiB0aGF0IGFscmVhZHkgaXMgQVNDSUktb25seS5cbiAgICAgIHRoaXMuaG9zdG5hbWUgPSBwdW55Y29kZS50b0FTQ0lJKHRoaXMuaG9zdG5hbWUpO1xuICAgIH1cblxuICAgIHZhciBwID0gdGhpcy5wb3J0ID8gJzonICsgdGhpcy5wb3J0IDogJyc7XG4gICAgdmFyIGggPSB0aGlzLmhvc3RuYW1lIHx8ICcnO1xuICAgIHRoaXMuaG9zdCA9IGggKyBwO1xuICAgIHRoaXMuaHJlZiArPSB0aGlzLmhvc3Q7XG5cbiAgICAvLyBzdHJpcCBbIGFuZCBdIGZyb20gdGhlIGhvc3RuYW1lXG4gICAgLy8gdGhlIGhvc3QgZmllbGQgc3RpbGwgcmV0YWlucyB0aGVtLCB0aG91Z2hcbiAgICBpZiAoaXB2Nkhvc3RuYW1lKSB7XG4gICAgICB0aGlzLmhvc3RuYW1lID0gdGhpcy5ob3N0bmFtZS5zdWJzdHIoMSwgdGhpcy5ob3N0bmFtZS5sZW5ndGggLSAyKTtcbiAgICAgIGlmIChyZXN0WzBdICE9PSAnLycpIHtcbiAgICAgICAgcmVzdCA9ICcvJyArIHJlc3Q7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLy8gbm93IHJlc3QgaXMgc2V0IHRvIHRoZSBwb3N0LWhvc3Qgc3R1ZmYuXG4gIC8vIGNob3Agb2ZmIGFueSBkZWxpbSBjaGFycy5cbiAgaWYgKCF1bnNhZmVQcm90b2NvbFtsb3dlclByb3RvXSkge1xuXG4gICAgLy8gRmlyc3QsIG1ha2UgMTAwJSBzdXJlIHRoYXQgYW55IFwiYXV0b0VzY2FwZVwiIGNoYXJzIGdldFxuICAgIC8vIGVzY2FwZWQsIGV2ZW4gaWYgZW5jb2RlVVJJQ29tcG9uZW50IGRvZXNuJ3QgdGhpbmsgdGhleVxuICAgIC8vIG5lZWQgdG8gYmUuXG4gICAgZm9yICh2YXIgaSA9IDAsIGwgPSBhdXRvRXNjYXBlLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgdmFyIGFlID0gYXV0b0VzY2FwZVtpXTtcbiAgICAgIGlmIChyZXN0LmluZGV4T2YoYWUpID09PSAtMSlcbiAgICAgICAgY29udGludWU7XG4gICAgICB2YXIgZXNjID0gZW5jb2RlVVJJQ29tcG9uZW50KGFlKTtcbiAgICAgIGlmIChlc2MgPT09IGFlKSB7XG4gICAgICAgIGVzYyA9IGVzY2FwZShhZSk7XG4gICAgICB9XG4gICAgICByZXN0ID0gcmVzdC5zcGxpdChhZSkuam9pbihlc2MpO1xuICAgIH1cbiAgfVxuXG5cbiAgLy8gY2hvcCBvZmYgZnJvbSB0aGUgdGFpbCBmaXJzdC5cbiAgdmFyIGhhc2ggPSByZXN0LmluZGV4T2YoJyMnKTtcbiAgaWYgKGhhc2ggIT09IC0xKSB7XG4gICAgLy8gZ290IGEgZnJhZ21lbnQgc3RyaW5nLlxuICAgIHRoaXMuaGFzaCA9IHJlc3Quc3Vic3RyKGhhc2gpO1xuICAgIHJlc3QgPSByZXN0LnNsaWNlKDAsIGhhc2gpO1xuICB9XG4gIHZhciBxbSA9IHJlc3QuaW5kZXhPZignPycpO1xuICBpZiAocW0gIT09IC0xKSB7XG4gICAgdGhpcy5zZWFyY2ggPSByZXN0LnN1YnN0cihxbSk7XG4gICAgdGhpcy5xdWVyeSA9IHJlc3Quc3Vic3RyKHFtICsgMSk7XG4gICAgaWYgKHBhcnNlUXVlcnlTdHJpbmcpIHtcbiAgICAgIHRoaXMucXVlcnkgPSBxdWVyeXN0cmluZy5wYXJzZSh0aGlzLnF1ZXJ5KTtcbiAgICB9XG4gICAgcmVzdCA9IHJlc3Quc2xpY2UoMCwgcW0pO1xuICB9IGVsc2UgaWYgKHBhcnNlUXVlcnlTdHJpbmcpIHtcbiAgICAvLyBubyBxdWVyeSBzdHJpbmcsIGJ1dCBwYXJzZVF1ZXJ5U3RyaW5nIHN0aWxsIHJlcXVlc3RlZFxuICAgIHRoaXMuc2VhcmNoID0gJyc7XG4gICAgdGhpcy5xdWVyeSA9IHt9O1xuICB9XG4gIGlmIChyZXN0KSB0aGlzLnBhdGhuYW1lID0gcmVzdDtcbiAgaWYgKHNsYXNoZWRQcm90b2NvbFtsb3dlclByb3RvXSAmJlxuICAgICAgdGhpcy5ob3N0bmFtZSAmJiAhdGhpcy5wYXRobmFtZSkge1xuICAgIHRoaXMucGF0aG5hbWUgPSAnLyc7XG4gIH1cblxuICAvL3RvIHN1cHBvcnQgaHR0cC5yZXF1ZXN0XG4gIGlmICh0aGlzLnBhdGhuYW1lIHx8IHRoaXMuc2VhcmNoKSB7XG4gICAgdmFyIHAgPSB0aGlzLnBhdGhuYW1lIHx8ICcnO1xuICAgIHZhciBzID0gdGhpcy5zZWFyY2ggfHwgJyc7XG4gICAgdGhpcy5wYXRoID0gcCArIHM7XG4gIH1cblxuICAvLyBmaW5hbGx5LCByZWNvbnN0cnVjdCB0aGUgaHJlZiBiYXNlZCBvbiB3aGF0IGhhcyBiZWVuIHZhbGlkYXRlZC5cbiAgdGhpcy5ocmVmID0gdGhpcy5mb3JtYXQoKTtcbiAgcmV0dXJuIHRoaXM7XG59O1xuXG4vLyBmb3JtYXQgYSBwYXJzZWQgb2JqZWN0IGludG8gYSB1cmwgc3RyaW5nXG5mdW5jdGlvbiB1cmxGb3JtYXQob2JqKSB7XG4gIC8vIGVuc3VyZSBpdCdzIGFuIG9iamVjdCwgYW5kIG5vdCBhIHN0cmluZyB1cmwuXG4gIC8vIElmIGl0J3MgYW4gb2JqLCB0aGlzIGlzIGEgbm8tb3AuXG4gIC8vIHRoaXMgd2F5LCB5b3UgY2FuIGNhbGwgdXJsX2Zvcm1hdCgpIG9uIHN0cmluZ3NcbiAgLy8gdG8gY2xlYW4gdXAgcG90ZW50aWFsbHkgd29ua3kgdXJscy5cbiAgaWYgKHV0aWwuaXNTdHJpbmcob2JqKSkgb2JqID0gdXJsUGFyc2Uob2JqKTtcbiAgaWYgKCEob2JqIGluc3RhbmNlb2YgVXJsKSkgcmV0dXJuIFVybC5wcm90b3R5cGUuZm9ybWF0LmNhbGwob2JqKTtcbiAgcmV0dXJuIG9iai5mb3JtYXQoKTtcbn1cblxuVXJsLnByb3RvdHlwZS5mb3JtYXQgPSBmdW5jdGlvbigpIHtcbiAgdmFyIGF1dGggPSB0aGlzLmF1dGggfHwgJyc7XG4gIGlmIChhdXRoKSB7XG4gICAgYXV0aCA9IGVuY29kZVVSSUNvbXBvbmVudChhdXRoKTtcbiAgICBhdXRoID0gYXV0aC5yZXBsYWNlKC8lM0EvaSwgJzonKTtcbiAgICBhdXRoICs9ICdAJztcbiAgfVxuXG4gIHZhciBwcm90b2NvbCA9IHRoaXMucHJvdG9jb2wgfHwgJycsXG4gICAgICBwYXRobmFtZSA9IHRoaXMucGF0aG5hbWUgfHwgJycsXG4gICAgICBoYXNoID0gdGhpcy5oYXNoIHx8ICcnLFxuICAgICAgaG9zdCA9IGZhbHNlLFxuICAgICAgcXVlcnkgPSAnJztcblxuICBpZiAodGhpcy5ob3N0KSB7XG4gICAgaG9zdCA9IGF1dGggKyB0aGlzLmhvc3Q7XG4gIH0gZWxzZSBpZiAodGhpcy5ob3N0bmFtZSkge1xuICAgIGhvc3QgPSBhdXRoICsgKHRoaXMuaG9zdG5hbWUuaW5kZXhPZignOicpID09PSAtMSA/XG4gICAgICAgIHRoaXMuaG9zdG5hbWUgOlxuICAgICAgICAnWycgKyB0aGlzLmhvc3RuYW1lICsgJ10nKTtcbiAgICBpZiAodGhpcy5wb3J0KSB7XG4gICAgICBob3N0ICs9ICc6JyArIHRoaXMucG9ydDtcbiAgICB9XG4gIH1cblxuICBpZiAodGhpcy5xdWVyeSAmJlxuICAgICAgdXRpbC5pc09iamVjdCh0aGlzLnF1ZXJ5KSAmJlxuICAgICAgT2JqZWN0LmtleXModGhpcy5xdWVyeSkubGVuZ3RoKSB7XG4gICAgcXVlcnkgPSBxdWVyeXN0cmluZy5zdHJpbmdpZnkodGhpcy5xdWVyeSk7XG4gIH1cblxuICB2YXIgc2VhcmNoID0gdGhpcy5zZWFyY2ggfHwgKHF1ZXJ5ICYmICgnPycgKyBxdWVyeSkpIHx8ICcnO1xuXG4gIGlmIChwcm90b2NvbCAmJiBwcm90b2NvbC5zdWJzdHIoLTEpICE9PSAnOicpIHByb3RvY29sICs9ICc6JztcblxuICAvLyBvbmx5IHRoZSBzbGFzaGVkUHJvdG9jb2xzIGdldCB0aGUgLy8uICBOb3QgbWFpbHRvOiwgeG1wcDosIGV0Yy5cbiAgLy8gdW5sZXNzIHRoZXkgaGFkIHRoZW0gdG8gYmVnaW4gd2l0aC5cbiAgaWYgKHRoaXMuc2xhc2hlcyB8fFxuICAgICAgKCFwcm90b2NvbCB8fCBzbGFzaGVkUHJvdG9jb2xbcHJvdG9jb2xdKSAmJiBob3N0ICE9PSBmYWxzZSkge1xuICAgIGhvc3QgPSAnLy8nICsgKGhvc3QgfHwgJycpO1xuICAgIGlmIChwYXRobmFtZSAmJiBwYXRobmFtZS5jaGFyQXQoMCkgIT09ICcvJykgcGF0aG5hbWUgPSAnLycgKyBwYXRobmFtZTtcbiAgfSBlbHNlIGlmICghaG9zdCkge1xuICAgIGhvc3QgPSAnJztcbiAgfVxuXG4gIGlmIChoYXNoICYmIGhhc2guY2hhckF0KDApICE9PSAnIycpIGhhc2ggPSAnIycgKyBoYXNoO1xuICBpZiAoc2VhcmNoICYmIHNlYXJjaC5jaGFyQXQoMCkgIT09ICc/Jykgc2VhcmNoID0gJz8nICsgc2VhcmNoO1xuXG4gIHBhdGhuYW1lID0gcGF0aG5hbWUucmVwbGFjZSgvWz8jXS9nLCBmdW5jdGlvbihtYXRjaCkge1xuICAgIHJldHVybiBlbmNvZGVVUklDb21wb25lbnQobWF0Y2gpO1xuICB9KTtcbiAgc2VhcmNoID0gc2VhcmNoLnJlcGxhY2UoJyMnLCAnJTIzJyk7XG5cbiAgcmV0dXJuIHByb3RvY29sICsgaG9zdCArIHBhdGhuYW1lICsgc2VhcmNoICsgaGFzaDtcbn07XG5cbmZ1bmN0aW9uIHVybFJlc29sdmUoc291cmNlLCByZWxhdGl2ZSkge1xuICByZXR1cm4gdXJsUGFyc2Uoc291cmNlLCBmYWxzZSwgdHJ1ZSkucmVzb2x2ZShyZWxhdGl2ZSk7XG59XG5cblVybC5wcm90b3R5cGUucmVzb2x2ZSA9IGZ1bmN0aW9uKHJlbGF0aXZlKSB7XG4gIHJldHVybiB0aGlzLnJlc29sdmVPYmplY3QodXJsUGFyc2UocmVsYXRpdmUsIGZhbHNlLCB0cnVlKSkuZm9ybWF0KCk7XG59O1xuXG5mdW5jdGlvbiB1cmxSZXNvbHZlT2JqZWN0KHNvdXJjZSwgcmVsYXRpdmUpIHtcbiAgaWYgKCFzb3VyY2UpIHJldHVybiByZWxhdGl2ZTtcbiAgcmV0dXJuIHVybFBhcnNlKHNvdXJjZSwgZmFsc2UsIHRydWUpLnJlc29sdmVPYmplY3QocmVsYXRpdmUpO1xufVxuXG5VcmwucHJvdG90eXBlLnJlc29sdmVPYmplY3QgPSBmdW5jdGlvbihyZWxhdGl2ZSkge1xuICBpZiAodXRpbC5pc1N0cmluZyhyZWxhdGl2ZSkpIHtcbiAgICB2YXIgcmVsID0gbmV3IFVybCgpO1xuICAgIHJlbC5wYXJzZShyZWxhdGl2ZSwgZmFsc2UsIHRydWUpO1xuICAgIHJlbGF0aXZlID0gcmVsO1xuICB9XG5cbiAgdmFyIHJlc3VsdCA9IG5ldyBVcmwoKTtcbiAgdmFyIHRrZXlzID0gT2JqZWN0LmtleXModGhpcyk7XG4gIGZvciAodmFyIHRrID0gMDsgdGsgPCB0a2V5cy5sZW5ndGg7IHRrKyspIHtcbiAgICB2YXIgdGtleSA9IHRrZXlzW3RrXTtcbiAgICByZXN1bHRbdGtleV0gPSB0aGlzW3RrZXldO1xuICB9XG5cbiAgLy8gaGFzaCBpcyBhbHdheXMgb3ZlcnJpZGRlbiwgbm8gbWF0dGVyIHdoYXQuXG4gIC8vIGV2ZW4gaHJlZj1cIlwiIHdpbGwgcmVtb3ZlIGl0LlxuICByZXN1bHQuaGFzaCA9IHJlbGF0aXZlLmhhc2g7XG5cbiAgLy8gaWYgdGhlIHJlbGF0aXZlIHVybCBpcyBlbXB0eSwgdGhlbiB0aGVyZSdzIG5vdGhpbmcgbGVmdCB0byBkbyBoZXJlLlxuICBpZiAocmVsYXRpdmUuaHJlZiA9PT0gJycpIHtcbiAgICByZXN1bHQuaHJlZiA9IHJlc3VsdC5mb3JtYXQoKTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG5cbiAgLy8gaHJlZnMgbGlrZSAvL2Zvby9iYXIgYWx3YXlzIGN1dCB0byB0aGUgcHJvdG9jb2wuXG4gIGlmIChyZWxhdGl2ZS5zbGFzaGVzICYmICFyZWxhdGl2ZS5wcm90b2NvbCkge1xuICAgIC8vIHRha2UgZXZlcnl0aGluZyBleGNlcHQgdGhlIHByb3RvY29sIGZyb20gcmVsYXRpdmVcbiAgICB2YXIgcmtleXMgPSBPYmplY3Qua2V5cyhyZWxhdGl2ZSk7XG4gICAgZm9yICh2YXIgcmsgPSAwOyByayA8IHJrZXlzLmxlbmd0aDsgcmsrKykge1xuICAgICAgdmFyIHJrZXkgPSBya2V5c1tya107XG4gICAgICBpZiAocmtleSAhPT0gJ3Byb3RvY29sJylcbiAgICAgICAgcmVzdWx0W3JrZXldID0gcmVsYXRpdmVbcmtleV07XG4gICAgfVxuXG4gICAgLy91cmxQYXJzZSBhcHBlbmRzIHRyYWlsaW5nIC8gdG8gdXJscyBsaWtlIGh0dHA6Ly93d3cuZXhhbXBsZS5jb21cbiAgICBpZiAoc2xhc2hlZFByb3RvY29sW3Jlc3VsdC5wcm90b2NvbF0gJiZcbiAgICAgICAgcmVzdWx0Lmhvc3RuYW1lICYmICFyZXN1bHQucGF0aG5hbWUpIHtcbiAgICAgIHJlc3VsdC5wYXRoID0gcmVzdWx0LnBhdGhuYW1lID0gJy8nO1xuICAgIH1cblxuICAgIHJlc3VsdC5ocmVmID0gcmVzdWx0LmZvcm1hdCgpO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICBpZiAocmVsYXRpdmUucHJvdG9jb2wgJiYgcmVsYXRpdmUucHJvdG9jb2wgIT09IHJlc3VsdC5wcm90b2NvbCkge1xuICAgIC8vIGlmIGl0J3MgYSBrbm93biB1cmwgcHJvdG9jb2wsIHRoZW4gY2hhbmdpbmdcbiAgICAvLyB0aGUgcHJvdG9jb2wgZG9lcyB3ZWlyZCB0aGluZ3NcbiAgICAvLyBmaXJzdCwgaWYgaXQncyBub3QgZmlsZTosIHRoZW4gd2UgTVVTVCBoYXZlIGEgaG9zdCxcbiAgICAvLyBhbmQgaWYgdGhlcmUgd2FzIGEgcGF0aFxuICAgIC8vIHRvIGJlZ2luIHdpdGgsIHRoZW4gd2UgTVVTVCBoYXZlIGEgcGF0aC5cbiAgICAvLyBpZiBpdCBpcyBmaWxlOiwgdGhlbiB0aGUgaG9zdCBpcyBkcm9wcGVkLFxuICAgIC8vIGJlY2F1c2UgdGhhdCdzIGtub3duIHRvIGJlIGhvc3RsZXNzLlxuICAgIC8vIGFueXRoaW5nIGVsc2UgaXMgYXNzdW1lZCB0byBiZSBhYnNvbHV0ZS5cbiAgICBpZiAoIXNsYXNoZWRQcm90b2NvbFtyZWxhdGl2ZS5wcm90b2NvbF0pIHtcbiAgICAgIHZhciBrZXlzID0gT2JqZWN0LmtleXMocmVsYXRpdmUpO1xuICAgICAgZm9yICh2YXIgdiA9IDA7IHYgPCBrZXlzLmxlbmd0aDsgdisrKSB7XG4gICAgICAgIHZhciBrID0ga2V5c1t2XTtcbiAgICAgICAgcmVzdWx0W2tdID0gcmVsYXRpdmVba107XG4gICAgICB9XG4gICAgICByZXN1bHQuaHJlZiA9IHJlc3VsdC5mb3JtYXQoKTtcbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuXG4gICAgcmVzdWx0LnByb3RvY29sID0gcmVsYXRpdmUucHJvdG9jb2w7XG4gICAgaWYgKCFyZWxhdGl2ZS5ob3N0ICYmICFob3N0bGVzc1Byb3RvY29sW3JlbGF0aXZlLnByb3RvY29sXSkge1xuICAgICAgdmFyIHJlbFBhdGggPSAocmVsYXRpdmUucGF0aG5hbWUgfHwgJycpLnNwbGl0KCcvJyk7XG4gICAgICB3aGlsZSAocmVsUGF0aC5sZW5ndGggJiYgIShyZWxhdGl2ZS5ob3N0ID0gcmVsUGF0aC5zaGlmdCgpKSk7XG4gICAgICBpZiAoIXJlbGF0aXZlLmhvc3QpIHJlbGF0aXZlLmhvc3QgPSAnJztcbiAgICAgIGlmICghcmVsYXRpdmUuaG9zdG5hbWUpIHJlbGF0aXZlLmhvc3RuYW1lID0gJyc7XG4gICAgICBpZiAocmVsUGF0aFswXSAhPT0gJycpIHJlbFBhdGgudW5zaGlmdCgnJyk7XG4gICAgICBpZiAocmVsUGF0aC5sZW5ndGggPCAyKSByZWxQYXRoLnVuc2hpZnQoJycpO1xuICAgICAgcmVzdWx0LnBhdGhuYW1lID0gcmVsUGF0aC5qb2luKCcvJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlc3VsdC5wYXRobmFtZSA9IHJlbGF0aXZlLnBhdGhuYW1lO1xuICAgIH1cbiAgICByZXN1bHQuc2VhcmNoID0gcmVsYXRpdmUuc2VhcmNoO1xuICAgIHJlc3VsdC5xdWVyeSA9IHJlbGF0aXZlLnF1ZXJ5O1xuICAgIHJlc3VsdC5ob3N0ID0gcmVsYXRpdmUuaG9zdCB8fCAnJztcbiAgICByZXN1bHQuYXV0aCA9IHJlbGF0aXZlLmF1dGg7XG4gICAgcmVzdWx0Lmhvc3RuYW1lID0gcmVsYXRpdmUuaG9zdG5hbWUgfHwgcmVsYXRpdmUuaG9zdDtcbiAgICByZXN1bHQucG9ydCA9IHJlbGF0aXZlLnBvcnQ7XG4gICAgLy8gdG8gc3VwcG9ydCBodHRwLnJlcXVlc3RcbiAgICBpZiAocmVzdWx0LnBhdGhuYW1lIHx8IHJlc3VsdC5zZWFyY2gpIHtcbiAgICAgIHZhciBwID0gcmVzdWx0LnBhdGhuYW1lIHx8ICcnO1xuICAgICAgdmFyIHMgPSByZXN1bHQuc2VhcmNoIHx8ICcnO1xuICAgICAgcmVzdWx0LnBhdGggPSBwICsgcztcbiAgICB9XG4gICAgcmVzdWx0LnNsYXNoZXMgPSByZXN1bHQuc2xhc2hlcyB8fCByZWxhdGl2ZS5zbGFzaGVzO1xuICAgIHJlc3VsdC5ocmVmID0gcmVzdWx0LmZvcm1hdCgpO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICB2YXIgaXNTb3VyY2VBYnMgPSAocmVzdWx0LnBhdGhuYW1lICYmIHJlc3VsdC5wYXRobmFtZS5jaGFyQXQoMCkgPT09ICcvJyksXG4gICAgICBpc1JlbEFicyA9IChcbiAgICAgICAgICByZWxhdGl2ZS5ob3N0IHx8XG4gICAgICAgICAgcmVsYXRpdmUucGF0aG5hbWUgJiYgcmVsYXRpdmUucGF0aG5hbWUuY2hhckF0KDApID09PSAnLydcbiAgICAgICksXG4gICAgICBtdXN0RW5kQWJzID0gKGlzUmVsQWJzIHx8IGlzU291cmNlQWJzIHx8XG4gICAgICAgICAgICAgICAgICAgIChyZXN1bHQuaG9zdCAmJiByZWxhdGl2ZS5wYXRobmFtZSkpLFxuICAgICAgcmVtb3ZlQWxsRG90cyA9IG11c3RFbmRBYnMsXG4gICAgICBzcmNQYXRoID0gcmVzdWx0LnBhdGhuYW1lICYmIHJlc3VsdC5wYXRobmFtZS5zcGxpdCgnLycpIHx8IFtdLFxuICAgICAgcmVsUGF0aCA9IHJlbGF0aXZlLnBhdGhuYW1lICYmIHJlbGF0aXZlLnBhdGhuYW1lLnNwbGl0KCcvJykgfHwgW10sXG4gICAgICBwc3ljaG90aWMgPSByZXN1bHQucHJvdG9jb2wgJiYgIXNsYXNoZWRQcm90b2NvbFtyZXN1bHQucHJvdG9jb2xdO1xuXG4gIC8vIGlmIHRoZSB1cmwgaXMgYSBub24tc2xhc2hlZCB1cmwsIHRoZW4gcmVsYXRpdmVcbiAgLy8gbGlua3MgbGlrZSAuLi8uLiBzaG91bGQgYmUgYWJsZVxuICAvLyB0byBjcmF3bCB1cCB0byB0aGUgaG9zdG5hbWUsIGFzIHdlbGwuICBUaGlzIGlzIHN0cmFuZ2UuXG4gIC8vIHJlc3VsdC5wcm90b2NvbCBoYXMgYWxyZWFkeSBiZWVuIHNldCBieSBub3cuXG4gIC8vIExhdGVyIG9uLCBwdXQgdGhlIGZpcnN0IHBhdGggcGFydCBpbnRvIHRoZSBob3N0IGZpZWxkLlxuICBpZiAocHN5Y2hvdGljKSB7XG4gICAgcmVzdWx0Lmhvc3RuYW1lID0gJyc7XG4gICAgcmVzdWx0LnBvcnQgPSBudWxsO1xuICAgIGlmIChyZXN1bHQuaG9zdCkge1xuICAgICAgaWYgKHNyY1BhdGhbMF0gPT09ICcnKSBzcmNQYXRoWzBdID0gcmVzdWx0Lmhvc3Q7XG4gICAgICBlbHNlIHNyY1BhdGgudW5zaGlmdChyZXN1bHQuaG9zdCk7XG4gICAgfVxuICAgIHJlc3VsdC5ob3N0ID0gJyc7XG4gICAgaWYgKHJlbGF0aXZlLnByb3RvY29sKSB7XG4gICAgICByZWxhdGl2ZS5ob3N0bmFtZSA9IG51bGw7XG4gICAgICByZWxhdGl2ZS5wb3J0ID0gbnVsbDtcbiAgICAgIGlmIChyZWxhdGl2ZS5ob3N0KSB7XG4gICAgICAgIGlmIChyZWxQYXRoWzBdID09PSAnJykgcmVsUGF0aFswXSA9IHJlbGF0aXZlLmhvc3Q7XG4gICAgICAgIGVsc2UgcmVsUGF0aC51bnNoaWZ0KHJlbGF0aXZlLmhvc3QpO1xuICAgICAgfVxuICAgICAgcmVsYXRpdmUuaG9zdCA9IG51bGw7XG4gICAgfVxuICAgIG11c3RFbmRBYnMgPSBtdXN0RW5kQWJzICYmIChyZWxQYXRoWzBdID09PSAnJyB8fCBzcmNQYXRoWzBdID09PSAnJyk7XG4gIH1cblxuICBpZiAoaXNSZWxBYnMpIHtcbiAgICAvLyBpdCdzIGFic29sdXRlLlxuICAgIHJlc3VsdC5ob3N0ID0gKHJlbGF0aXZlLmhvc3QgfHwgcmVsYXRpdmUuaG9zdCA9PT0gJycpID9cbiAgICAgICAgICAgICAgICAgIHJlbGF0aXZlLmhvc3QgOiByZXN1bHQuaG9zdDtcbiAgICByZXN1bHQuaG9zdG5hbWUgPSAocmVsYXRpdmUuaG9zdG5hbWUgfHwgcmVsYXRpdmUuaG9zdG5hbWUgPT09ICcnKSA/XG4gICAgICAgICAgICAgICAgICAgICAgcmVsYXRpdmUuaG9zdG5hbWUgOiByZXN1bHQuaG9zdG5hbWU7XG4gICAgcmVzdWx0LnNlYXJjaCA9IHJlbGF0aXZlLnNlYXJjaDtcbiAgICByZXN1bHQucXVlcnkgPSByZWxhdGl2ZS5xdWVyeTtcbiAgICBzcmNQYXRoID0gcmVsUGF0aDtcbiAgICAvLyBmYWxsIHRocm91Z2ggdG8gdGhlIGRvdC1oYW5kbGluZyBiZWxvdy5cbiAgfSBlbHNlIGlmIChyZWxQYXRoLmxlbmd0aCkge1xuICAgIC8vIGl0J3MgcmVsYXRpdmVcbiAgICAvLyB0aHJvdyBhd2F5IHRoZSBleGlzdGluZyBmaWxlLCBhbmQgdGFrZSB0aGUgbmV3IHBhdGggaW5zdGVhZC5cbiAgICBpZiAoIXNyY1BhdGgpIHNyY1BhdGggPSBbXTtcbiAgICBzcmNQYXRoLnBvcCgpO1xuICAgIHNyY1BhdGggPSBzcmNQYXRoLmNvbmNhdChyZWxQYXRoKTtcbiAgICByZXN1bHQuc2VhcmNoID0gcmVsYXRpdmUuc2VhcmNoO1xuICAgIHJlc3VsdC5xdWVyeSA9IHJlbGF0aXZlLnF1ZXJ5O1xuICB9IGVsc2UgaWYgKCF1dGlsLmlzTnVsbE9yVW5kZWZpbmVkKHJlbGF0aXZlLnNlYXJjaCkpIHtcbiAgICAvLyBqdXN0IHB1bGwgb3V0IHRoZSBzZWFyY2guXG4gICAgLy8gbGlrZSBocmVmPSc/Zm9vJy5cbiAgICAvLyBQdXQgdGhpcyBhZnRlciB0aGUgb3RoZXIgdHdvIGNhc2VzIGJlY2F1c2UgaXQgc2ltcGxpZmllcyB0aGUgYm9vbGVhbnNcbiAgICBpZiAocHN5Y2hvdGljKSB7XG4gICAgICByZXN1bHQuaG9zdG5hbWUgPSByZXN1bHQuaG9zdCA9IHNyY1BhdGguc2hpZnQoKTtcbiAgICAgIC8vb2NjYXRpb25hbHkgdGhlIGF1dGggY2FuIGdldCBzdHVjayBvbmx5IGluIGhvc3RcbiAgICAgIC8vdGhpcyBlc3BlY2lhbGx5IGhhcHBlbnMgaW4gY2FzZXMgbGlrZVxuICAgICAgLy91cmwucmVzb2x2ZU9iamVjdCgnbWFpbHRvOmxvY2FsMUBkb21haW4xJywgJ2xvY2FsMkBkb21haW4yJylcbiAgICAgIHZhciBhdXRoSW5Ib3N0ID0gcmVzdWx0Lmhvc3QgJiYgcmVzdWx0Lmhvc3QuaW5kZXhPZignQCcpID4gMCA/XG4gICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5ob3N0LnNwbGl0KCdAJykgOiBmYWxzZTtcbiAgICAgIGlmIChhdXRoSW5Ib3N0KSB7XG4gICAgICAgIHJlc3VsdC5hdXRoID0gYXV0aEluSG9zdC5zaGlmdCgpO1xuICAgICAgICByZXN1bHQuaG9zdCA9IHJlc3VsdC5ob3N0bmFtZSA9IGF1dGhJbkhvc3Quc2hpZnQoKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmVzdWx0LnNlYXJjaCA9IHJlbGF0aXZlLnNlYXJjaDtcbiAgICByZXN1bHQucXVlcnkgPSByZWxhdGl2ZS5xdWVyeTtcbiAgICAvL3RvIHN1cHBvcnQgaHR0cC5yZXF1ZXN0XG4gICAgaWYgKCF1dGlsLmlzTnVsbChyZXN1bHQucGF0aG5hbWUpIHx8ICF1dGlsLmlzTnVsbChyZXN1bHQuc2VhcmNoKSkge1xuICAgICAgcmVzdWx0LnBhdGggPSAocmVzdWx0LnBhdGhuYW1lID8gcmVzdWx0LnBhdGhuYW1lIDogJycpICtcbiAgICAgICAgICAgICAgICAgICAgKHJlc3VsdC5zZWFyY2ggPyByZXN1bHQuc2VhcmNoIDogJycpO1xuICAgIH1cbiAgICByZXN1bHQuaHJlZiA9IHJlc3VsdC5mb3JtYXQoKTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG5cbiAgaWYgKCFzcmNQYXRoLmxlbmd0aCkge1xuICAgIC8vIG5vIHBhdGggYXQgYWxsLiAgZWFzeS5cbiAgICAvLyB3ZSd2ZSBhbHJlYWR5IGhhbmRsZWQgdGhlIG90aGVyIHN0dWZmIGFib3ZlLlxuICAgIHJlc3VsdC5wYXRobmFtZSA9IG51bGw7XG4gICAgLy90byBzdXBwb3J0IGh0dHAucmVxdWVzdFxuICAgIGlmIChyZXN1bHQuc2VhcmNoKSB7XG4gICAgICByZXN1bHQucGF0aCA9ICcvJyArIHJlc3VsdC5zZWFyY2g7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlc3VsdC5wYXRoID0gbnVsbDtcbiAgICB9XG4gICAgcmVzdWx0LmhyZWYgPSByZXN1bHQuZm9ybWF0KCk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuXG4gIC8vIGlmIGEgdXJsIEVORHMgaW4gLiBvciAuLiwgdGhlbiBpdCBtdXN0IGdldCBhIHRyYWlsaW5nIHNsYXNoLlxuICAvLyBob3dldmVyLCBpZiBpdCBlbmRzIGluIGFueXRoaW5nIGVsc2Ugbm9uLXNsYXNoeSxcbiAgLy8gdGhlbiBpdCBtdXN0IE5PVCBnZXQgYSB0cmFpbGluZyBzbGFzaC5cbiAgdmFyIGxhc3QgPSBzcmNQYXRoLnNsaWNlKC0xKVswXTtcbiAgdmFyIGhhc1RyYWlsaW5nU2xhc2ggPSAoXG4gICAgICAocmVzdWx0Lmhvc3QgfHwgcmVsYXRpdmUuaG9zdCB8fCBzcmNQYXRoLmxlbmd0aCA+IDEpICYmXG4gICAgICAobGFzdCA9PT0gJy4nIHx8IGxhc3QgPT09ICcuLicpIHx8IGxhc3QgPT09ICcnKTtcblxuICAvLyBzdHJpcCBzaW5nbGUgZG90cywgcmVzb2x2ZSBkb3VibGUgZG90cyB0byBwYXJlbnQgZGlyXG4gIC8vIGlmIHRoZSBwYXRoIHRyaWVzIHRvIGdvIGFib3ZlIHRoZSByb290LCBgdXBgIGVuZHMgdXAgPiAwXG4gIHZhciB1cCA9IDA7XG4gIGZvciAodmFyIGkgPSBzcmNQYXRoLmxlbmd0aDsgaSA+PSAwOyBpLS0pIHtcbiAgICBsYXN0ID0gc3JjUGF0aFtpXTtcbiAgICBpZiAobGFzdCA9PT0gJy4nKSB7XG4gICAgICBzcmNQYXRoLnNwbGljZShpLCAxKTtcbiAgICB9IGVsc2UgaWYgKGxhc3QgPT09ICcuLicpIHtcbiAgICAgIHNyY1BhdGguc3BsaWNlKGksIDEpO1xuICAgICAgdXArKztcbiAgICB9IGVsc2UgaWYgKHVwKSB7XG4gICAgICBzcmNQYXRoLnNwbGljZShpLCAxKTtcbiAgICAgIHVwLS07XG4gICAgfVxuICB9XG5cbiAgLy8gaWYgdGhlIHBhdGggaXMgYWxsb3dlZCB0byBnbyBhYm92ZSB0aGUgcm9vdCwgcmVzdG9yZSBsZWFkaW5nIC4uc1xuICBpZiAoIW11c3RFbmRBYnMgJiYgIXJlbW92ZUFsbERvdHMpIHtcbiAgICBmb3IgKDsgdXAtLTsgdXApIHtcbiAgICAgIHNyY1BhdGgudW5zaGlmdCgnLi4nKTtcbiAgICB9XG4gIH1cblxuICBpZiAobXVzdEVuZEFicyAmJiBzcmNQYXRoWzBdICE9PSAnJyAmJlxuICAgICAgKCFzcmNQYXRoWzBdIHx8IHNyY1BhdGhbMF0uY2hhckF0KDApICE9PSAnLycpKSB7XG4gICAgc3JjUGF0aC51bnNoaWZ0KCcnKTtcbiAgfVxuXG4gIGlmIChoYXNUcmFpbGluZ1NsYXNoICYmIChzcmNQYXRoLmpvaW4oJy8nKS5zdWJzdHIoLTEpICE9PSAnLycpKSB7XG4gICAgc3JjUGF0aC5wdXNoKCcnKTtcbiAgfVxuXG4gIHZhciBpc0Fic29sdXRlID0gc3JjUGF0aFswXSA9PT0gJycgfHxcbiAgICAgIChzcmNQYXRoWzBdICYmIHNyY1BhdGhbMF0uY2hhckF0KDApID09PSAnLycpO1xuXG4gIC8vIHB1dCB0aGUgaG9zdCBiYWNrXG4gIGlmIChwc3ljaG90aWMpIHtcbiAgICByZXN1bHQuaG9zdG5hbWUgPSByZXN1bHQuaG9zdCA9IGlzQWJzb2x1dGUgPyAnJyA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmNQYXRoLmxlbmd0aCA/IHNyY1BhdGguc2hpZnQoKSA6ICcnO1xuICAgIC8vb2NjYXRpb25hbHkgdGhlIGF1dGggY2FuIGdldCBzdHVjayBvbmx5IGluIGhvc3RcbiAgICAvL3RoaXMgZXNwZWNpYWxseSBoYXBwZW5zIGluIGNhc2VzIGxpa2VcbiAgICAvL3VybC5yZXNvbHZlT2JqZWN0KCdtYWlsdG86bG9jYWwxQGRvbWFpbjEnLCAnbG9jYWwyQGRvbWFpbjInKVxuICAgIHZhciBhdXRoSW5Ib3N0ID0gcmVzdWx0Lmhvc3QgJiYgcmVzdWx0Lmhvc3QuaW5kZXhPZignQCcpID4gMCA/XG4gICAgICAgICAgICAgICAgICAgICByZXN1bHQuaG9zdC5zcGxpdCgnQCcpIDogZmFsc2U7XG4gICAgaWYgKGF1dGhJbkhvc3QpIHtcbiAgICAgIHJlc3VsdC5hdXRoID0gYXV0aEluSG9zdC5zaGlmdCgpO1xuICAgICAgcmVzdWx0Lmhvc3QgPSByZXN1bHQuaG9zdG5hbWUgPSBhdXRoSW5Ib3N0LnNoaWZ0KCk7XG4gICAgfVxuICB9XG5cbiAgbXVzdEVuZEFicyA9IG11c3RFbmRBYnMgfHwgKHJlc3VsdC5ob3N0ICYmIHNyY1BhdGgubGVuZ3RoKTtcblxuICBpZiAobXVzdEVuZEFicyAmJiAhaXNBYnNvbHV0ZSkge1xuICAgIHNyY1BhdGgudW5zaGlmdCgnJyk7XG4gIH1cblxuICBpZiAoIXNyY1BhdGgubGVuZ3RoKSB7XG4gICAgcmVzdWx0LnBhdGhuYW1lID0gbnVsbDtcbiAgICByZXN1bHQucGF0aCA9IG51bGw7XG4gIH0gZWxzZSB7XG4gICAgcmVzdWx0LnBhdGhuYW1lID0gc3JjUGF0aC5qb2luKCcvJyk7XG4gIH1cblxuICAvL3RvIHN1cHBvcnQgcmVxdWVzdC5odHRwXG4gIGlmICghdXRpbC5pc051bGwocmVzdWx0LnBhdGhuYW1lKSB8fCAhdXRpbC5pc051bGwocmVzdWx0LnNlYXJjaCkpIHtcbiAgICByZXN1bHQucGF0aCA9IChyZXN1bHQucGF0aG5hbWUgPyByZXN1bHQucGF0aG5hbWUgOiAnJykgK1xuICAgICAgICAgICAgICAgICAgKHJlc3VsdC5zZWFyY2ggPyByZXN1bHQuc2VhcmNoIDogJycpO1xuICB9XG4gIHJlc3VsdC5hdXRoID0gcmVsYXRpdmUuYXV0aCB8fCByZXN1bHQuYXV0aDtcbiAgcmVzdWx0LnNsYXNoZXMgPSByZXN1bHQuc2xhc2hlcyB8fCByZWxhdGl2ZS5zbGFzaGVzO1xuICByZXN1bHQuaHJlZiA9IHJlc3VsdC5mb3JtYXQoKTtcbiAgcmV0dXJuIHJlc3VsdDtcbn07XG5cblVybC5wcm90b3R5cGUucGFyc2VIb3N0ID0gZnVuY3Rpb24oKSB7XG4gIHZhciBob3N0ID0gdGhpcy5ob3N0O1xuICB2YXIgcG9ydCA9IHBvcnRQYXR0ZXJuLmV4ZWMoaG9zdCk7XG4gIGlmIChwb3J0KSB7XG4gICAgcG9ydCA9IHBvcnRbMF07XG4gICAgaWYgKHBvcnQgIT09ICc6Jykge1xuICAgICAgdGhpcy5wb3J0ID0gcG9ydC5zdWJzdHIoMSk7XG4gICAgfVxuICAgIGhvc3QgPSBob3N0LnN1YnN0cigwLCBob3N0Lmxlbmd0aCAtIHBvcnQubGVuZ3RoKTtcbiAgfVxuICBpZiAoaG9zdCkgdGhpcy5ob3N0bmFtZSA9IGhvc3Q7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgaXNTdHJpbmc6IGZ1bmN0aW9uKGFyZykge1xuICAgIHJldHVybiB0eXBlb2YoYXJnKSA9PT0gJ3N0cmluZyc7XG4gIH0sXG4gIGlzT2JqZWN0OiBmdW5jdGlvbihhcmcpIHtcbiAgICByZXR1cm4gdHlwZW9mKGFyZykgPT09ICdvYmplY3QnICYmIGFyZyAhPT0gbnVsbDtcbiAgfSxcbiAgaXNOdWxsOiBmdW5jdGlvbihhcmcpIHtcbiAgICByZXR1cm4gYXJnID09PSBudWxsO1xuICB9LFxuICBpc051bGxPclVuZGVmaW5lZDogZnVuY3Rpb24oYXJnKSB7XG4gICAgcmV0dXJuIGFyZyA9PSBudWxsO1xuICB9XG59O1xuIiwiLyoqXG4gKiBDb252ZXJ0IGFycmF5IG9mIDE2IGJ5dGUgdmFsdWVzIHRvIFVVSUQgc3RyaW5nIGZvcm1hdCBvZiB0aGUgZm9ybTpcbiAqIFhYWFhYWFhYLVhYWFgtWFhYWC1YWFhYLVhYWFhYWFhYWFhYWFxuICovXG52YXIgYnl0ZVRvSGV4ID0gW107XG5mb3IgKHZhciBpID0gMDsgaSA8IDI1NjsgKytpKSB7XG4gIGJ5dGVUb0hleFtpXSA9IChpICsgMHgxMDApLnRvU3RyaW5nKDE2KS5zdWJzdHIoMSk7XG59XG5cbmZ1bmN0aW9uIGJ5dGVzVG9VdWlkKGJ1Ziwgb2Zmc2V0KSB7XG4gIHZhciBpID0gb2Zmc2V0IHx8IDA7XG4gIHZhciBidGggPSBieXRlVG9IZXg7XG4gIC8vIGpvaW4gdXNlZCB0byBmaXggbWVtb3J5IGlzc3VlIGNhdXNlZCBieSBjb25jYXRlbmF0aW9uOiBodHRwczovL2J1Z3MuY2hyb21pdW0ub3JnL3AvdjgvaXNzdWVzL2RldGFpbD9pZD0zMTc1I2M0XG4gIHJldHVybiAoW2J0aFtidWZbaSsrXV0sIGJ0aFtidWZbaSsrXV0sIFxuXHRidGhbYnVmW2krK11dLCBidGhbYnVmW2krK11dLCAnLScsXG5cdGJ0aFtidWZbaSsrXV0sIGJ0aFtidWZbaSsrXV0sICctJyxcblx0YnRoW2J1ZltpKytdXSwgYnRoW2J1ZltpKytdXSwgJy0nLFxuXHRidGhbYnVmW2krK11dLCBidGhbYnVmW2krK11dLCAnLScsXG5cdGJ0aFtidWZbaSsrXV0sIGJ0aFtidWZbaSsrXV0sXG5cdGJ0aFtidWZbaSsrXV0sIGJ0aFtidWZbaSsrXV0sXG5cdGJ0aFtidWZbaSsrXV0sIGJ0aFtidWZbaSsrXV1dKS5qb2luKCcnKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBieXRlc1RvVXVpZDtcbiIsIi8vIFVuaXF1ZSBJRCBjcmVhdGlvbiByZXF1aXJlcyBhIGhpZ2ggcXVhbGl0eSByYW5kb20gIyBnZW5lcmF0b3IuICBJbiB0aGVcbi8vIGJyb3dzZXIgdGhpcyBpcyBhIGxpdHRsZSBjb21wbGljYXRlZCBkdWUgdG8gdW5rbm93biBxdWFsaXR5IG9mIE1hdGgucmFuZG9tKClcbi8vIGFuZCBpbmNvbnNpc3RlbnQgc3VwcG9ydCBmb3IgdGhlIGBjcnlwdG9gIEFQSS4gIFdlIGRvIHRoZSBiZXN0IHdlIGNhbiB2aWFcbi8vIGZlYXR1cmUtZGV0ZWN0aW9uXG5cbi8vIGdldFJhbmRvbVZhbHVlcyBuZWVkcyB0byBiZSBpbnZva2VkIGluIGEgY29udGV4dCB3aGVyZSBcInRoaXNcIiBpcyBhIENyeXB0b1xuLy8gaW1wbGVtZW50YXRpb24uIEFsc28sIGZpbmQgdGhlIGNvbXBsZXRlIGltcGxlbWVudGF0aW9uIG9mIGNyeXB0byBvbiBJRTExLlxudmFyIGdldFJhbmRvbVZhbHVlcyA9ICh0eXBlb2YoY3J5cHRvKSAhPSAndW5kZWZpbmVkJyAmJiBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzICYmIGNyeXB0by5nZXRSYW5kb21WYWx1ZXMuYmluZChjcnlwdG8pKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICh0eXBlb2YobXNDcnlwdG8pICE9ICd1bmRlZmluZWQnICYmIHR5cGVvZiB3aW5kb3cubXNDcnlwdG8uZ2V0UmFuZG9tVmFsdWVzID09ICdmdW5jdGlvbicgJiYgbXNDcnlwdG8uZ2V0UmFuZG9tVmFsdWVzLmJpbmQobXNDcnlwdG8pKTtcblxuaWYgKGdldFJhbmRvbVZhbHVlcykge1xuICAvLyBXSEFUV0cgY3J5cHRvIFJORyAtIGh0dHA6Ly93aWtpLndoYXR3Zy5vcmcvd2lraS9DcnlwdG9cbiAgdmFyIHJuZHM4ID0gbmV3IFVpbnQ4QXJyYXkoMTYpOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXVuZGVmXG5cbiAgbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiB3aGF0d2dSTkcoKSB7XG4gICAgZ2V0UmFuZG9tVmFsdWVzKHJuZHM4KTtcbiAgICByZXR1cm4gcm5kczg7XG4gIH07XG59IGVsc2Uge1xuICAvLyBNYXRoLnJhbmRvbSgpLWJhc2VkIChSTkcpXG4gIC8vXG4gIC8vIElmIGFsbCBlbHNlIGZhaWxzLCB1c2UgTWF0aC5yYW5kb20oKS4gIEl0J3MgZmFzdCwgYnV0IGlzIG9mIHVuc3BlY2lmaWVkXG4gIC8vIHF1YWxpdHkuXG4gIHZhciBybmRzID0gbmV3IEFycmF5KDE2KTtcblxuICBtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIG1hdGhSTkcoKSB7XG4gICAgZm9yICh2YXIgaSA9IDAsIHI7IGkgPCAxNjsgaSsrKSB7XG4gICAgICBpZiAoKGkgJiAweDAzKSA9PT0gMCkgciA9IE1hdGgucmFuZG9tKCkgKiAweDEwMDAwMDAwMDtcbiAgICAgIHJuZHNbaV0gPSByID4+PiAoKGkgJiAweDAzKSA8PCAzKSAmIDB4ZmY7XG4gICAgfVxuXG4gICAgcmV0dXJuIHJuZHM7XG4gIH07XG59XG4iLCIvLyBBZGFwdGVkIGZyb20gQ2hyaXMgVmVuZXNzJyBTSEExIGNvZGUgYXRcbi8vIGh0dHA6Ly93d3cubW92YWJsZS10eXBlLmNvLnVrL3NjcmlwdHMvc2hhMS5odG1sXG4ndXNlIHN0cmljdCc7XG5cbmZ1bmN0aW9uIGYocywgeCwgeSwgeikge1xuICBzd2l0Y2ggKHMpIHtcbiAgICBjYXNlIDA6IHJldHVybiAoeCAmIHkpIF4gKH54ICYgeik7XG4gICAgY2FzZSAxOiByZXR1cm4geCBeIHkgXiB6O1xuICAgIGNhc2UgMjogcmV0dXJuICh4ICYgeSkgXiAoeCAmIHopIF4gKHkgJiB6KTtcbiAgICBjYXNlIDM6IHJldHVybiB4IF4geSBeIHo7XG4gIH1cbn1cblxuZnVuY3Rpb24gUk9UTCh4LCBuKSB7XG4gIHJldHVybiAoeCA8PCBuKSB8ICh4Pj4+ICgzMiAtIG4pKTtcbn1cblxuZnVuY3Rpb24gc2hhMShieXRlcykge1xuICB2YXIgSyA9IFsweDVhODI3OTk5LCAweDZlZDllYmExLCAweDhmMWJiY2RjLCAweGNhNjJjMWQ2XTtcbiAgdmFyIEggPSBbMHg2NzQ1MjMwMSwgMHhlZmNkYWI4OSwgMHg5OGJhZGNmZSwgMHgxMDMyNTQ3NiwgMHhjM2QyZTFmMF07XG5cbiAgaWYgKHR5cGVvZihieXRlcykgPT0gJ3N0cmluZycpIHtcbiAgICB2YXIgbXNnID0gdW5lc2NhcGUoZW5jb2RlVVJJQ29tcG9uZW50KGJ5dGVzKSk7IC8vIFVURjggZXNjYXBlXG4gICAgYnl0ZXMgPSBuZXcgQXJyYXkobXNnLmxlbmd0aCk7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBtc2cubGVuZ3RoOyBpKyspIGJ5dGVzW2ldID0gbXNnLmNoYXJDb2RlQXQoaSk7XG4gIH1cblxuICBieXRlcy5wdXNoKDB4ODApO1xuXG4gIHZhciBsID0gYnl0ZXMubGVuZ3RoLzQgKyAyO1xuICB2YXIgTiA9IE1hdGguY2VpbChsLzE2KTtcbiAgdmFyIE0gPSBuZXcgQXJyYXkoTik7XG5cbiAgZm9yICh2YXIgaT0wOyBpPE47IGkrKykge1xuICAgIE1baV0gPSBuZXcgQXJyYXkoMTYpO1xuICAgIGZvciAodmFyIGo9MDsgajwxNjsgaisrKSB7XG4gICAgICBNW2ldW2pdID1cbiAgICAgICAgYnl0ZXNbaSAqIDY0ICsgaiAqIDRdIDw8IDI0IHxcbiAgICAgICAgYnl0ZXNbaSAqIDY0ICsgaiAqIDQgKyAxXSA8PCAxNiB8XG4gICAgICAgIGJ5dGVzW2kgKiA2NCArIGogKiA0ICsgMl0gPDwgOCB8XG4gICAgICAgIGJ5dGVzW2kgKiA2NCArIGogKiA0ICsgM107XG4gICAgfVxuICB9XG5cbiAgTVtOIC0gMV1bMTRdID0gKChieXRlcy5sZW5ndGggLSAxKSAqIDgpIC9cbiAgICBNYXRoLnBvdygyLCAzMik7IE1bTiAtIDFdWzE0XSA9IE1hdGguZmxvb3IoTVtOIC0gMV1bMTRdKTtcbiAgTVtOIC0gMV1bMTVdID0gKChieXRlcy5sZW5ndGggLSAxKSAqIDgpICYgMHhmZmZmZmZmZjtcblxuICBmb3IgKHZhciBpPTA7IGk8TjsgaSsrKSB7XG4gICAgdmFyIFcgPSBuZXcgQXJyYXkoODApO1xuXG4gICAgZm9yICh2YXIgdD0wOyB0PDE2OyB0KyspIFdbdF0gPSBNW2ldW3RdO1xuICAgIGZvciAodmFyIHQ9MTY7IHQ8ODA7IHQrKykge1xuICAgICAgV1t0XSA9IFJPVEwoV1t0IC0gM10gXiBXW3QgLSA4XSBeIFdbdCAtIDE0XSBeIFdbdCAtIDE2XSwgMSk7XG4gICAgfVxuXG4gICAgdmFyIGEgPSBIWzBdO1xuICAgIHZhciBiID0gSFsxXTtcbiAgICB2YXIgYyA9IEhbMl07XG4gICAgdmFyIGQgPSBIWzNdO1xuICAgIHZhciBlID0gSFs0XTtcblxuICAgIGZvciAodmFyIHQ9MDsgdDw4MDsgdCsrKSB7XG4gICAgICB2YXIgcyA9IE1hdGguZmxvb3IodC8yMCk7XG4gICAgICB2YXIgVCA9IFJPVEwoYSwgNSkgKyBmKHMsIGIsIGMsIGQpICsgZSArIEtbc10gKyBXW3RdID4+PiAwO1xuICAgICAgZSA9IGQ7XG4gICAgICBkID0gYztcbiAgICAgIGMgPSBST1RMKGIsIDMwKSA+Pj4gMDtcbiAgICAgIGIgPSBhO1xuICAgICAgYSA9IFQ7XG4gICAgfVxuXG4gICAgSFswXSA9IChIWzBdICsgYSkgPj4+IDA7XG4gICAgSFsxXSA9IChIWzFdICsgYikgPj4+IDA7XG4gICAgSFsyXSA9IChIWzJdICsgYykgPj4+IDA7XG4gICAgSFszXSA9IChIWzNdICsgZCkgPj4+IDA7XG4gICAgSFs0XSA9IChIWzRdICsgZSkgPj4+IDA7XG4gIH1cblxuICByZXR1cm4gW1xuICAgIEhbMF0gPj4gMjQgJiAweGZmLCBIWzBdID4+IDE2ICYgMHhmZiwgSFswXSA+PiA4ICYgMHhmZiwgSFswXSAmIDB4ZmYsXG4gICAgSFsxXSA+PiAyNCAmIDB4ZmYsIEhbMV0gPj4gMTYgJiAweGZmLCBIWzFdID4+IDggJiAweGZmLCBIWzFdICYgMHhmZixcbiAgICBIWzJdID4+IDI0ICYgMHhmZiwgSFsyXSA+PiAxNiAmIDB4ZmYsIEhbMl0gPj4gOCAmIDB4ZmYsIEhbMl0gJiAweGZmLFxuICAgIEhbM10gPj4gMjQgJiAweGZmLCBIWzNdID4+IDE2ICYgMHhmZiwgSFszXSA+PiA4ICYgMHhmZiwgSFszXSAmIDB4ZmYsXG4gICAgSFs0XSA+PiAyNCAmIDB4ZmYsIEhbNF0gPj4gMTYgJiAweGZmLCBIWzRdID4+IDggJiAweGZmLCBIWzRdICYgMHhmZlxuICBdO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHNoYTE7XG4iLCJ2YXIgYnl0ZXNUb1V1aWQgPSByZXF1aXJlKCcuL2J5dGVzVG9VdWlkJyk7XG5cbmZ1bmN0aW9uIHV1aWRUb0J5dGVzKHV1aWQpIHtcbiAgLy8gTm90ZTogV2UgYXNzdW1lIHdlJ3JlIGJlaW5nIHBhc3NlZCBhIHZhbGlkIHV1aWQgc3RyaW5nXG4gIHZhciBieXRlcyA9IFtdO1xuICB1dWlkLnJlcGxhY2UoL1thLWZBLUYwLTldezJ9L2csIGZ1bmN0aW9uKGhleCkge1xuICAgIGJ5dGVzLnB1c2gocGFyc2VJbnQoaGV4LCAxNikpO1xuICB9KTtcblxuICByZXR1cm4gYnl0ZXM7XG59XG5cbmZ1bmN0aW9uIHN0cmluZ1RvQnl0ZXMoc3RyKSB7XG4gIHN0ciA9IHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChzdHIpKTsgLy8gVVRGOCBlc2NhcGVcbiAgdmFyIGJ5dGVzID0gbmV3IEFycmF5KHN0ci5sZW5ndGgpO1xuICBmb3IgKHZhciBpID0gMDsgaSA8IHN0ci5sZW5ndGg7IGkrKykge1xuICAgIGJ5dGVzW2ldID0gc3RyLmNoYXJDb2RlQXQoaSk7XG4gIH1cbiAgcmV0dXJuIGJ5dGVzO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uKG5hbWUsIHZlcnNpb24sIGhhc2hmdW5jKSB7XG4gIHZhciBnZW5lcmF0ZVVVSUQgPSBmdW5jdGlvbih2YWx1ZSwgbmFtZXNwYWNlLCBidWYsIG9mZnNldCkge1xuICAgIHZhciBvZmYgPSBidWYgJiYgb2Zmc2V0IHx8IDA7XG5cbiAgICBpZiAodHlwZW9mKHZhbHVlKSA9PSAnc3RyaW5nJykgdmFsdWUgPSBzdHJpbmdUb0J5dGVzKHZhbHVlKTtcbiAgICBpZiAodHlwZW9mKG5hbWVzcGFjZSkgPT0gJ3N0cmluZycpIG5hbWVzcGFjZSA9IHV1aWRUb0J5dGVzKG5hbWVzcGFjZSk7XG5cbiAgICBpZiAoIUFycmF5LmlzQXJyYXkodmFsdWUpKSB0aHJvdyBUeXBlRXJyb3IoJ3ZhbHVlIG11c3QgYmUgYW4gYXJyYXkgb2YgYnl0ZXMnKTtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkobmFtZXNwYWNlKSB8fCBuYW1lc3BhY2UubGVuZ3RoICE9PSAxNikgdGhyb3cgVHlwZUVycm9yKCduYW1lc3BhY2UgbXVzdCBiZSB1dWlkIHN0cmluZyBvciBhbiBBcnJheSBvZiAxNiBieXRlIHZhbHVlcycpO1xuXG4gICAgLy8gUGVyIDQuM1xuICAgIHZhciBieXRlcyA9IGhhc2hmdW5jKG5hbWVzcGFjZS5jb25jYXQodmFsdWUpKTtcbiAgICBieXRlc1s2XSA9IChieXRlc1s2XSAmIDB4MGYpIHwgdmVyc2lvbjtcbiAgICBieXRlc1s4XSA9IChieXRlc1s4XSAmIDB4M2YpIHwgMHg4MDtcblxuICAgIGlmIChidWYpIHtcbiAgICAgIGZvciAodmFyIGlkeCA9IDA7IGlkeCA8IDE2OyArK2lkeCkge1xuICAgICAgICBidWZbb2ZmK2lkeF0gPSBieXRlc1tpZHhdO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBidWYgfHwgYnl0ZXNUb1V1aWQoYnl0ZXMpO1xuICB9O1xuXG4gIC8vIEZ1bmN0aW9uI25hbWUgaXMgbm90IHNldHRhYmxlIG9uIHNvbWUgcGxhdGZvcm1zICgjMjcwKVxuICB0cnkge1xuICAgIGdlbmVyYXRlVVVJRC5uYW1lID0gbmFtZTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gIH1cblxuICAvLyBQcmUtZGVmaW5lZCBuYW1lc3BhY2VzLCBwZXIgQXBwZW5kaXggQ1xuICBnZW5lcmF0ZVVVSUQuRE5TID0gJzZiYTdiODEwLTlkYWQtMTFkMS04MGI0LTAwYzA0ZmQ0MzBjOCc7XG4gIGdlbmVyYXRlVVVJRC5VUkwgPSAnNmJhN2I4MTEtOWRhZC0xMWQxLTgwYjQtMDBjMDRmZDQzMGM4JztcblxuICByZXR1cm4gZ2VuZXJhdGVVVUlEO1xufTtcbiIsInZhciBybmcgPSByZXF1aXJlKCcuL2xpYi9ybmcnKTtcbnZhciBieXRlc1RvVXVpZCA9IHJlcXVpcmUoJy4vbGliL2J5dGVzVG9VdWlkJyk7XG5cbmZ1bmN0aW9uIHY0KG9wdGlvbnMsIGJ1Ziwgb2Zmc2V0KSB7XG4gIHZhciBpID0gYnVmICYmIG9mZnNldCB8fCAwO1xuXG4gIGlmICh0eXBlb2Yob3B0aW9ucykgPT0gJ3N0cmluZycpIHtcbiAgICBidWYgPSBvcHRpb25zID09PSAnYmluYXJ5JyA/IG5ldyBBcnJheSgxNikgOiBudWxsO1xuICAgIG9wdGlvbnMgPSBudWxsO1xuICB9XG4gIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuXG4gIHZhciBybmRzID0gb3B0aW9ucy5yYW5kb20gfHwgKG9wdGlvbnMucm5nIHx8IHJuZykoKTtcblxuICAvLyBQZXIgNC40LCBzZXQgYml0cyBmb3IgdmVyc2lvbiBhbmQgYGNsb2NrX3NlcV9oaV9hbmRfcmVzZXJ2ZWRgXG4gIHJuZHNbNl0gPSAocm5kc1s2XSAmIDB4MGYpIHwgMHg0MDtcbiAgcm5kc1s4XSA9IChybmRzWzhdICYgMHgzZikgfCAweDgwO1xuXG4gIC8vIENvcHkgYnl0ZXMgdG8gYnVmZmVyLCBpZiBwcm92aWRlZFxuICBpZiAoYnVmKSB7XG4gICAgZm9yICh2YXIgaWkgPSAwOyBpaSA8IDE2OyArK2lpKSB7XG4gICAgICBidWZbaSArIGlpXSA9IHJuZHNbaWldO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBidWYgfHwgYnl0ZXNUb1V1aWQocm5kcyk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gdjQ7XG4iLCJ2YXIgdjM1ID0gcmVxdWlyZSgnLi9saWIvdjM1LmpzJyk7XG52YXIgc2hhMSA9IHJlcXVpcmUoJy4vbGliL3NoYTEnKTtcbm1vZHVsZS5leHBvcnRzID0gdjM1KCd2NScsIDB4NTAsIHNoYTEpO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5jb25zdCB2NCA9IHJlcXVpcmUoJ3V1aWQvdjQnKSxcbiAgICAgIHY1ID0gcmVxdWlyZSgndXVpZC92NScpO1xuXG5jb25zdCB1dWlkdjQgPSBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiB2NCgpO1xufTtcblxudXVpZHY0LnJlZ2V4ID0ge1xuICB2NDogL14oW2EtZjAtOV17OH0tW2EtZjAtOV17NH0tNFthLWYwLTldezN9LVthLWYwLTldezR9LVthLWYwLTldezEyfSl8KDB7OH0tMHs0fS0wezR9LTB7NH0tMHsxMn0pJC8sXG4gIHY1OiAvXihbYS1mMC05XXs4fS1bYS1mMC05XXs0fS01W2EtZjAtOV17M30tW2EtZjAtOV17NH0tW2EtZjAtOV17MTJ9KXwoMHs4fS0wezR9LTB7NH0tMHs0fS0wezEyfSkkL1xufTtcblxudXVpZHY0LmlzID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gIGlmICghdmFsdWUpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICByZXR1cm4gdXVpZHY0LnJlZ2V4LnY0LnRlc3QodmFsdWUpIHx8IHV1aWR2NC5yZWdleC52NS50ZXN0KHZhbHVlKTtcbn07XG5cbnV1aWR2NC5lbXB0eSA9IGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuICcwMDAwMDAwMC0wMDAwLTAwMDAtMDAwMC0wMDAwMDAwMDAwMDAnO1xufTtcblxudXVpZHY0LmZyb21TdHJpbmcgPSBmdW5jdGlvbiAodGV4dCkge1xuICBpZiAoIXRleHQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1RleHQgaXMgbWlzc2luZy4nKTtcbiAgfVxuXG4gIGNvbnN0IG5hbWVzcGFjZSA9ICdiYjVkMGZmYS05YTRjLTRkN2MtOGZjMi0wYTdkMjIyMGJhNDUnO1xuXG4gIGNvbnN0IHV1aWRGcm9tU3RyaW5nID0gdjUodGV4dCwgbmFtZXNwYWNlKTtcblxuICByZXR1cm4gdXVpZEZyb21TdHJpbmc7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IHV1aWR2NDtcbiIsIlwidXNlIHN0cmljdFwiO1xuLy8gQ29weXJpZ2h0IDIwMTggVGhlIE91dGxpbmUgQXV0aG9yc1xuLy9cbi8vIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4vLyB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4vLyBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbi8vXG4vLyAgICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuLy9cbi8vIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbi8vIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbi8vIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuLy8gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuLy8gbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG52YXIgX19yZWFkID0gKHRoaXMgJiYgdGhpcy5fX3JlYWQpIHx8IGZ1bmN0aW9uIChvLCBuKSB7XG4gICAgdmFyIG0gPSB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgb1tTeW1ib2wuaXRlcmF0b3JdO1xuICAgIGlmICghbSkgcmV0dXJuIG87XG4gICAgdmFyIGkgPSBtLmNhbGwobyksIHIsIGFyID0gW10sIGU7XG4gICAgdHJ5IHtcbiAgICAgICAgd2hpbGUgKChuID09PSB2b2lkIDAgfHwgbi0tID4gMCkgJiYgIShyID0gaS5uZXh0KCkpLmRvbmUpIGFyLnB1c2goci52YWx1ZSk7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikgeyBlID0geyBlcnJvcjogZXJyb3IgfTsgfVxuICAgIGZpbmFsbHkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgaWYgKHIgJiYgIXIuZG9uZSAmJiAobSA9IGlbXCJyZXR1cm5cIl0pKSBtLmNhbGwoaSk7XG4gICAgICAgIH1cbiAgICAgICAgZmluYWxseSB7IGlmIChlKSB0aHJvdyBlLmVycm9yOyB9XG4gICAgfVxuICAgIHJldHVybiBhcjtcbn07XG52YXIgX19zcHJlYWQgPSAodGhpcyAmJiB0aGlzLl9fc3ByZWFkKSB8fCBmdW5jdGlvbiAoKSB7XG4gICAgZm9yICh2YXIgYXIgPSBbXSwgaSA9IDA7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIGFyID0gYXIuY29uY2F0KF9fcmVhZChhcmd1bWVudHNbaV0pKTtcbiAgICByZXR1cm4gYXI7XG59O1xudmFyIF9fdmFsdWVzID0gKHRoaXMgJiYgdGhpcy5fX3ZhbHVlcykgfHwgZnVuY3Rpb24gKG8pIHtcbiAgICB2YXIgbSA9IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvW1N5bWJvbC5pdGVyYXRvcl0sIGkgPSAwO1xuICAgIGlmIChtKSByZXR1cm4gbS5jYWxsKG8pO1xuICAgIHJldHVybiB7XG4gICAgICAgIG5leHQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmIChvICYmIGkgPj0gby5sZW5ndGgpIG8gPSB2b2lkIDA7XG4gICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogbyAmJiBvW2krK10sIGRvbmU6ICFvIH07XG4gICAgICAgIH1cbiAgICB9O1xufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbnZhciBzaGFkb3dzb2Nrc19jb25maWdfMSA9IHJlcXVpcmUoXCJTaGFkb3dzb2Nrc0NvbmZpZy9zaGFkb3dzb2Nrc19jb25maWdcIik7XG52YXIgZXJyb3JzID0gcmVxdWlyZShcIi4uL21vZGVsL2Vycm9yc1wiKTtcbnZhciBldmVudHMgPSByZXF1aXJlKFwiLi4vbW9kZWwvZXZlbnRzXCIpO1xudmFyIHNldHRpbmdzXzEgPSByZXF1aXJlKFwiLi9zZXR0aW5nc1wiKTtcbi8vIElmIHMgaXMgYSBVUkwgd2hvc2UgZnJhZ21lbnQgY29udGFpbnMgYSBTaGFkb3dzb2NrcyBVUkwgdGhlbiByZXR1cm4gdGhhdCBTaGFkb3dzb2NrcyBVUkwsXG4vLyBvdGhlcndpc2UgcmV0dXJuIHMuXG5mdW5jdGlvbiB1bndyYXBJbnZpdGUocykge1xuICAgIHRyeSB7XG4gICAgICAgIHZhciB1cmwgPSBuZXcgVVJMKHMpO1xuICAgICAgICBpZiAodXJsLmhhc2gpIHtcbiAgICAgICAgICAgIHZhciBkZWNvZGVkRnJhZ21lbnQgPSBkZWNvZGVVUklDb21wb25lbnQodXJsLmhhc2gpO1xuICAgICAgICAgICAgLy8gU2VhcmNoIGluIHRoZSBmcmFnbWVudCBmb3Igc3M6Ly8gZm9yIHR3byByZWFzb25zOlxuICAgICAgICAgICAgLy8gIC0gVVJMLmhhc2ggaW5jbHVkZXMgdGhlIGxlYWRpbmcgIyAod2hhdCkuXG4gICAgICAgICAgICAvLyAgLSBXaGVuIGEgdXNlciBvcGVucyBpbnZpdGUuaHRtbCNFTkNPREVEU1NVUkwgaW4gdGhlaXIgYnJvd3NlciwgdGhlIHdlYnNpdGUgKGN1cnJlbnRseSlcbiAgICAgICAgICAgIC8vICAgIHJlZGlyZWN0cyB0byBpbnZpdGUuaHRtbCMvZW4vaW52aXRlL0VOQ09ERURTU1VSTC4gU2luY2UgY29weWluZyB0aGF0IHJlZGlyZWN0ZWQgVVJMXG4gICAgICAgICAgICAvLyAgICBzZWVtcyBsaWtlIGEgcmVhc29uYWJsZSB0aGluZyB0byBkbywgbGV0J3Mgc3VwcG9ydCB0aG9zZSBVUkxzIHRvby5cbiAgICAgICAgICAgIHZhciBwb3NzaWJsZVNoYWRvd3NvY2tzVXJsID0gZGVjb2RlZEZyYWdtZW50LnN1YnN0cmluZyhkZWNvZGVkRnJhZ21lbnQuaW5kZXhPZignc3M6Ly8nKSk7XG4gICAgICAgICAgICBpZiAobmV3IFVSTChwb3NzaWJsZVNoYWRvd3NvY2tzVXJsKS5wcm90b2NvbCA9PT0gJ3NzOicpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcG9zc2libGVTaGFkb3dzb2Nrc1VybDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICAvLyBTb21ldGhpbmcgd2Fzbid0IGEgVVJMLCBvciBpdCBjb3VsZG4ndCBiZSBkZWNvZGVkIC0gbm8gcHJvYmxlbSwgcGVvcGxlIHB1dCBhbGwga2luZHMgb2ZcbiAgICAgICAgLy8gY3JhenkgdGhpbmdzIGluIHRoZSBjbGlwYm9hcmQuXG4gICAgfVxuICAgIHJldHVybiBzO1xufVxuZXhwb3J0cy51bndyYXBJbnZpdGUgPSB1bndyYXBJbnZpdGU7XG52YXIgQXBwID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIEFwcChldmVudFF1ZXVlLCBzZXJ2ZXJSZXBvLCByb290RWwsIGRlYnVnTW9kZSwgdXJsSW50ZXJjZXB0b3IsIGNsaXBib2FyZCwgZXJyb3JSZXBvcnRlciwgc2V0dGluZ3MsIGVudmlyb25tZW50VmFycywgdXBkYXRlciwgcXVpdEFwcGxpY2F0aW9uLCBkb2N1bWVudCkge1xuICAgICAgICBpZiAoZG9jdW1lbnQgPT09IHZvaWQgMCkgeyBkb2N1bWVudCA9IHdpbmRvdy5kb2N1bWVudDsgfVxuICAgICAgICB0aGlzLmV2ZW50UXVldWUgPSBldmVudFF1ZXVlO1xuICAgICAgICB0aGlzLnNlcnZlclJlcG8gPSBzZXJ2ZXJSZXBvO1xuICAgICAgICB0aGlzLnJvb3RFbCA9IHJvb3RFbDtcbiAgICAgICAgdGhpcy5kZWJ1Z01vZGUgPSBkZWJ1Z01vZGU7XG4gICAgICAgIHRoaXMuY2xpcGJvYXJkID0gY2xpcGJvYXJkO1xuICAgICAgICB0aGlzLmVycm9yUmVwb3J0ZXIgPSBlcnJvclJlcG9ydGVyO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gICAgICAgIHRoaXMuZW52aXJvbm1lbnRWYXJzID0gZW52aXJvbm1lbnRWYXJzO1xuICAgICAgICB0aGlzLnVwZGF0ZXIgPSB1cGRhdGVyO1xuICAgICAgICB0aGlzLnF1aXRBcHBsaWNhdGlvbiA9IHF1aXRBcHBsaWNhdGlvbjtcbiAgICAgICAgdGhpcy5pZ25vcmVkQWNjZXNzS2V5cyA9IHt9O1xuICAgICAgICB0aGlzLnNlcnZlckxpc3RFbCA9IHJvb3RFbC4kLnNlcnZlcnNWaWV3LiQuc2VydmVyTGlzdDtcbiAgICAgICAgdGhpcy5mZWVkYmFja1ZpZXdFbCA9IHJvb3RFbC4kLmZlZWRiYWNrVmlldztcbiAgICAgICAgdGhpcy5zeW5jU2VydmVyc1RvVUkoKTtcbiAgICAgICAgdGhpcy5zeW5jQ29ubmVjdGl2aXR5U3RhdGVUb1NlcnZlckNhcmRzKCk7XG4gICAgICAgIHJvb3RFbC4kLmFib3V0Vmlldy52ZXJzaW9uID0gZW52aXJvbm1lbnRWYXJzLkFQUF9WRVJTSU9OO1xuICAgICAgICB0aGlzLmxvY2FsaXplID0gdGhpcy5yb290RWwubG9jYWxpemUuYmluZCh0aGlzLnJvb3RFbCk7XG4gICAgICAgIGlmICh1cmxJbnRlcmNlcHRvcikge1xuICAgICAgICAgICAgdGhpcy5yZWdpc3RlclVybEludGVyY2VwdGlvbkxpc3RlbmVyKHVybEludGVyY2VwdG9yKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2Fybignbm8gdXJsSW50ZXJjZXB0b3IsIHNzOi8vIHVybHMgd2lsbCBub3QgYmUgaW50ZXJjZXB0ZWQnKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmNsaXBib2FyZC5zZXRMaXN0ZW5lcih0aGlzLmhhbmRsZUNsaXBib2FyZFRleHQuYmluZCh0aGlzKSk7XG4gICAgICAgIHRoaXMudXBkYXRlci5zZXRMaXN0ZW5lcih0aGlzLnVwZGF0ZURvd25sb2FkZWQuYmluZCh0aGlzKSk7XG4gICAgICAgIC8vIFJlZ2lzdGVyIENvcmRvdmEgbW9iaWxlIGZvcmVncm91bmQgZXZlbnQgdG8gc3luYyBzZXJ2ZXIgY29ubmVjdGl2aXR5LlxuICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdyZXN1bWUnLCB0aGlzLnN5bmNDb25uZWN0aXZpdHlTdGF0ZVRvU2VydmVyQ2FyZHMuYmluZCh0aGlzKSk7XG4gICAgICAgIC8vIFJlZ2lzdGVyIGhhbmRsZXJzIGZvciBldmVudHMgZmlyZWQgYnkgUG9seW1lciBjb21wb25lbnRzLlxuICAgICAgICB0aGlzLnJvb3RFbC5hZGRFdmVudExpc3RlbmVyKCdQcm9tcHRBZGRTZXJ2ZXJSZXF1ZXN0ZWQnLCB0aGlzLnJlcXVlc3RQcm9tcHRBZGRTZXJ2ZXIuYmluZCh0aGlzKSk7XG4gICAgICAgIHRoaXMucm9vdEVsLmFkZEV2ZW50TGlzdGVuZXIoJ0FkZFNlcnZlckNvbmZpcm1hdGlvblJlcXVlc3RlZCcsIHRoaXMucmVxdWVzdEFkZFNlcnZlckNvbmZpcm1hdGlvbi5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGhpcy5yb290RWwuYWRkRXZlbnRMaXN0ZW5lcignQWRkU2VydmVyUmVxdWVzdGVkJywgdGhpcy5yZXF1ZXN0QWRkU2VydmVyLmJpbmQodGhpcykpO1xuICAgICAgICB0aGlzLnJvb3RFbC5hZGRFdmVudExpc3RlbmVyKCdJZ25vcmVTZXJ2ZXJSZXF1ZXN0ZWQnLCB0aGlzLnJlcXVlc3RJZ25vcmVTZXJ2ZXIuYmluZCh0aGlzKSk7XG4gICAgICAgIHRoaXMucm9vdEVsLmFkZEV2ZW50TGlzdGVuZXIoJ0Nvbm5lY3RQcmVzc2VkJywgdGhpcy5jb25uZWN0U2VydmVyLmJpbmQodGhpcykpO1xuICAgICAgICB0aGlzLnJvb3RFbC5hZGRFdmVudExpc3RlbmVyKCdEaXNjb25uZWN0UHJlc3NlZCcsIHRoaXMuZGlzY29ubmVjdFNlcnZlci5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGhpcy5yb290RWwuYWRkRXZlbnRMaXN0ZW5lcignRm9yZ2V0UHJlc3NlZCcsIHRoaXMuZm9yZ2V0U2VydmVyLmJpbmQodGhpcykpO1xuICAgICAgICB0aGlzLnJvb3RFbC5hZGRFdmVudExpc3RlbmVyKCdSZW5hbWVSZXF1ZXN0ZWQnLCB0aGlzLnJlbmFtZVNlcnZlci5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGhpcy5yb290RWwuYWRkRXZlbnRMaXN0ZW5lcignUXVpdFByZXNzZWQnLCB0aGlzLnF1aXRBcHBsaWNhdGlvbi5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGhpcy5yb290RWwuYWRkRXZlbnRMaXN0ZW5lcignQXV0b0Nvbm5lY3REaWFsb2dEaXNtaXNzZWQnLCB0aGlzLmF1dG9Db25uZWN0RGlhbG9nRGlzbWlzc2VkLmJpbmQodGhpcykpO1xuICAgICAgICB0aGlzLnJvb3RFbC5hZGRFdmVudExpc3RlbmVyKCdTaG93U2VydmVyUmVuYW1lJywgdGhpcy5yb290RWwuc2hvd1NlcnZlclJlbmFtZS5iaW5kKHRoaXMucm9vdEVsKSk7XG4gICAgICAgIHRoaXMuZmVlZGJhY2tWaWV3RWwuJC5zdWJtaXRCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcigndGFwJywgdGhpcy5zdWJtaXRGZWVkYmFjay5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGhpcy5yb290RWwuYWRkRXZlbnRMaXN0ZW5lcignUHJpdmFjeVRlcm1zQWNrZWQnLCB0aGlzLmFja1ByaXZhY3lUZXJtcy5iaW5kKHRoaXMpKTtcbiAgICAgICAgLy8gUmVnaXN0ZXIgaGFuZGxlcnMgZm9yIGV2ZW50cyBwdWJsaXNoZWQgdG8gb3VyIGV2ZW50IHF1ZXVlLlxuICAgICAgICB0aGlzLmV2ZW50UXVldWUuc3Vic2NyaWJlKGV2ZW50cy5TZXJ2ZXJBZGRlZCwgdGhpcy5zaG93U2VydmVyQWRkZWQuYmluZCh0aGlzKSk7XG4gICAgICAgIHRoaXMuZXZlbnRRdWV1ZS5zdWJzY3JpYmUoZXZlbnRzLlNlcnZlckZvcmdvdHRlbiwgdGhpcy5zaG93U2VydmVyRm9yZ290dGVuLmJpbmQodGhpcykpO1xuICAgICAgICB0aGlzLmV2ZW50UXVldWUuc3Vic2NyaWJlKGV2ZW50cy5TZXJ2ZXJSZW5hbWVkLCB0aGlzLnNob3dTZXJ2ZXJSZW5hbWVkLmJpbmQodGhpcykpO1xuICAgICAgICB0aGlzLmV2ZW50UXVldWUuc3Vic2NyaWJlKGV2ZW50cy5TZXJ2ZXJGb3JnZXRVbmRvbmUsIHRoaXMuc2hvd1NlcnZlckZvcmdldFVuZG9uZS5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGhpcy5ldmVudFF1ZXVlLnN1YnNjcmliZShldmVudHMuU2VydmVyQ29ubmVjdGVkLCB0aGlzLnNob3dTZXJ2ZXJDb25uZWN0ZWQuYmluZCh0aGlzKSk7XG4gICAgICAgIHRoaXMuZXZlbnRRdWV1ZS5zdWJzY3JpYmUoZXZlbnRzLlNlcnZlckRpc2Nvbm5lY3RlZCwgdGhpcy5zaG93U2VydmVyRGlzY29ubmVjdGVkLmJpbmQodGhpcykpO1xuICAgICAgICB0aGlzLmV2ZW50UXVldWUuc3Vic2NyaWJlKGV2ZW50cy5TZXJ2ZXJSZWNvbm5lY3RpbmcsIHRoaXMuc2hvd1NlcnZlclJlY29ubmVjdGluZy5iaW5kKHRoaXMpKTtcbiAgICAgICAgdGhpcy5ldmVudFF1ZXVlLnN0YXJ0UHVibGlzaGluZygpO1xuICAgICAgICBpZiAoIXRoaXMuYXJlUHJpdmFjeVRlcm1zQWNrZWQoKSkge1xuICAgICAgICAgICAgdGhpcy5kaXNwbGF5UHJpdmFjeVZpZXcoKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmRpc3BsYXlaZXJvU3RhdGVVaSgpO1xuICAgICAgICB0aGlzLnB1bGxDbGlwYm9hcmRUZXh0KCk7XG4gICAgfVxuICAgIEFwcC5wcm90b3R5cGUuc2hvd0xvY2FsaXplZEVycm9yID0gZnVuY3Rpb24gKGUsIHRvYXN0RHVyYXRpb24pIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgaWYgKHRvYXN0RHVyYXRpb24gPT09IHZvaWQgMCkgeyB0b2FzdER1cmF0aW9uID0gMTAwMDA7IH1cbiAgICAgICAgdmFyIG1lc3NhZ2VLZXk7XG4gICAgICAgIHZhciBtZXNzYWdlUGFyYW1zO1xuICAgICAgICB2YXIgYnV0dG9uS2V5O1xuICAgICAgICB2YXIgYnV0dG9uSGFuZGxlcjtcbiAgICAgICAgdmFyIGJ1dHRvbkxpbms7XG4gICAgICAgIGlmIChlIGluc3RhbmNlb2YgZXJyb3JzLlZwblBlcm1pc3Npb25Ob3RHcmFudGVkKSB7XG4gICAgICAgICAgICBtZXNzYWdlS2V5ID0gJ291dGxpbmUtcGx1Z2luLWVycm9yLXZwbi1wZXJtaXNzaW9uLW5vdC1ncmFudGVkJztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChlIGluc3RhbmNlb2YgZXJyb3JzLkludmFsaWRTZXJ2ZXJDcmVkZW50aWFscykge1xuICAgICAgICAgICAgbWVzc2FnZUtleSA9ICdvdXRsaW5lLXBsdWdpbi1lcnJvci1pbnZhbGlkLXNlcnZlci1jcmVkZW50aWFscyc7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoZSBpbnN0YW5jZW9mIGVycm9ycy5SZW1vdGVVZHBGb3J3YXJkaW5nRGlzYWJsZWQpIHtcbiAgICAgICAgICAgIG1lc3NhZ2VLZXkgPSAnb3V0bGluZS1wbHVnaW4tZXJyb3ItdWRwLWZvcndhcmRpbmctbm90LWVuYWJsZWQnO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBlcnJvcnMuU2VydmVyVW5yZWFjaGFibGUpIHtcbiAgICAgICAgICAgIG1lc3NhZ2VLZXkgPSAnb3V0bGluZS1wbHVnaW4tZXJyb3Itc2VydmVyLXVucmVhY2hhYmxlJztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChlIGluc3RhbmNlb2YgZXJyb3JzLkZlZWRiYWNrU3VibWlzc2lvbkVycm9yKSB7XG4gICAgICAgICAgICBtZXNzYWdlS2V5ID0gJ2Vycm9yLWZlZWRiYWNrLXN1Ym1pc3Npb24nO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBlcnJvcnMuU2VydmVyVXJsSW52YWxpZCkge1xuICAgICAgICAgICAgbWVzc2FnZUtleSA9ICdlcnJvci1pbnZhbGlkLWFjY2Vzcy1rZXknO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBlcnJvcnMuU2VydmVySW5jb21wYXRpYmxlKSB7XG4gICAgICAgICAgICBtZXNzYWdlS2V5ID0gJ2Vycm9yLXNlcnZlci1pbmNvbXBhdGlibGUnO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBlcnJvcnMuT3BlcmF0aW9uVGltZWRPdXQpIHtcbiAgICAgICAgICAgIG1lc3NhZ2VLZXkgPSAnZXJyb3ItdGltZW91dCc7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoZSBpbnN0YW5jZW9mIGVycm9ycy5TaGFkb3dzb2Nrc1N0YXJ0RmFpbHVyZSAmJiB0aGlzLmlzV2luZG93cygpKSB7XG4gICAgICAgICAgICAvLyBGYWxsIHRocm91Z2ggdG8gYGVycm9yLXVuZXhwZWN0ZWRgIGZvciBvdGhlciBwbGF0Zm9ybXMuXG4gICAgICAgICAgICBtZXNzYWdlS2V5ID0gJ291dGxpbmUtcGx1Z2luLWVycm9yLWFudGl2aXJ1cyc7XG4gICAgICAgICAgICBidXR0b25LZXkgPSAnZml4LXRoaXMnO1xuICAgICAgICAgICAgYnV0dG9uTGluayA9ICdodHRwczovL3MzLmFtYXpvbmF3cy5jb20vb3V0bGluZS12cG4vaW5kZXguaHRtbCMvZW4vc3VwcG9ydC9hbnRpdmlydXNCbG9jayc7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoZSBpbnN0YW5jZW9mIGVycm9ycy5Db25maWd1cmVTeXN0ZW1Qcm94eUZhaWx1cmUpIHtcbiAgICAgICAgICAgIG1lc3NhZ2VLZXkgPSAnb3V0bGluZS1wbHVnaW4tZXJyb3Itcm91dGluZy10YWJsZXMnO1xuICAgICAgICAgICAgYnV0dG9uS2V5ID0gJ2ZlZWRiYWNrLXBhZ2UtdGl0bGUnO1xuICAgICAgICAgICAgYnV0dG9uSGFuZGxlciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAvLyBUT0RPOiBEcm9wLWRvd24gaGFzIG5vIHNlbGVjdGVkIGl0ZW0sIHdoeSBub3Q/XG4gICAgICAgICAgICAgICAgX3RoaXMucm9vdEVsLmNoYW5nZVBhZ2UoJ2ZlZWRiYWNrJyk7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBlcnJvcnMuTm9BZG1pblBlcm1pc3Npb25zKSB7XG4gICAgICAgICAgICBtZXNzYWdlS2V5ID0gJ291dGxpbmUtcGx1Z2luLWVycm9yLWFkbWluLXBlcm1pc3Npb25zJztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChlIGluc3RhbmNlb2YgZXJyb3JzLlVuc3VwcG9ydGVkUm91dGluZ1RhYmxlKSB7XG4gICAgICAgICAgICBtZXNzYWdlS2V5ID0gJ291dGxpbmUtcGx1Z2luLWVycm9yLXVuc3VwcG9ydGVkLXJvdXRpbmctdGFibGUnO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBlcnJvcnMuU2VydmVyQWxyZWFkeUFkZGVkKSB7XG4gICAgICAgICAgICBtZXNzYWdlS2V5ID0gJ2Vycm9yLXNlcnZlci1hbHJlYWR5LWFkZGVkJztcbiAgICAgICAgICAgIG1lc3NhZ2VQYXJhbXMgPSBbJ3NlcnZlck5hbWUnLCBlLnNlcnZlci5uYW1lXTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChlIGluc3RhbmNlb2YgZXJyb3JzLlN5c3RlbUNvbmZpZ3VyYXRpb25FeGNlcHRpb24pIHtcbiAgICAgICAgICAgIG1lc3NhZ2VLZXkgPSAnb3V0bGluZS1wbHVnaW4tZXJyb3Itc3lzdGVtLWNvbmZpZ3VyYXRpb24nO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgbWVzc2FnZUtleSA9ICdlcnJvci11bmV4cGVjdGVkJztcbiAgICAgICAgfVxuICAgICAgICB2YXIgbWVzc2FnZSA9IG1lc3NhZ2VQYXJhbXMgPyB0aGlzLmxvY2FsaXplLmFwcGx5KHRoaXMsIF9fc3ByZWFkKFttZXNzYWdlS2V5XSwgbWVzc2FnZVBhcmFtcykpIDogdGhpcy5sb2NhbGl6ZShtZXNzYWdlS2V5KTtcbiAgICAgICAgLy8gRGVmZXIgYnkgNTAwbXMgc28gdGhhdCB0aGlzIHRvYXN0IGlzIHNob3duIGFmdGVyIGFueSB0b2FzdHMgdGhhdCBnZXQgc2hvd24gd2hlbiBhbnlcbiAgICAgICAgLy8gY3VycmVudGx5LWluLWZsaWdodCBkb21haW4gZXZlbnRzIGxhbmQgKGUuZy4gZmFrZSBzZXJ2ZXJzIGFkZGVkKS5cbiAgICAgICAgaWYgKHRoaXMucm9vdEVsICYmIHRoaXMucm9vdEVsLmFzeW5jKSB7XG4gICAgICAgICAgICB0aGlzLnJvb3RFbC5hc3luYyhmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgX3RoaXMucm9vdEVsLnNob3dUb2FzdChtZXNzYWdlLCB0b2FzdER1cmF0aW9uLCBidXR0b25LZXkgPyBfdGhpcy5sb2NhbGl6ZShidXR0b25LZXkpIDogdW5kZWZpbmVkLCBidXR0b25IYW5kbGVyLCBidXR0b25MaW5rKTtcbiAgICAgICAgICAgIH0sIDUwMCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIEFwcC5wcm90b3R5cGUucHVsbENsaXBib2FyZFRleHQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIHRoaXMuY2xpcGJvYXJkLmdldENvbnRlbnRzKCkudGhlbihmdW5jdGlvbiAodGV4dCkge1xuICAgICAgICAgICAgX3RoaXMuaGFuZGxlQ2xpcGJvYXJkVGV4dCh0ZXh0KTtcbiAgICAgICAgfSwgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignY2Fubm90IHJlYWQgY2xpcGJvYXJkLCBzeXN0ZW0gbWF5IGxhY2sgY2xpcGJvYXJkIHN1cHBvcnQnKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLnNob3dTZXJ2ZXJDb25uZWN0ZWQgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgY29uc29sZS5kZWJ1ZyhcInNlcnZlciBcIiArIGV2ZW50LnNlcnZlci5pZCArIFwiIGNvbm5lY3RlZFwiKTtcbiAgICAgICAgdmFyIGNhcmQgPSB0aGlzLnNlcnZlckxpc3RFbC5nZXRTZXJ2ZXJDYXJkKGV2ZW50LnNlcnZlci5pZCk7XG4gICAgICAgIGNhcmQuc3RhdGUgPSAnQ09OTkVDVEVEJztcbiAgICB9O1xuICAgIEFwcC5wcm90b3R5cGUuc2hvd1NlcnZlckRpc2Nvbm5lY3RlZCA9IGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgICBjb25zb2xlLmRlYnVnKFwic2VydmVyIFwiICsgZXZlbnQuc2VydmVyLmlkICsgXCIgZGlzY29ubmVjdGVkXCIpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgdGhpcy5zZXJ2ZXJMaXN0RWwuZ2V0U2VydmVyQ2FyZChldmVudC5zZXJ2ZXIuaWQpLnN0YXRlID0gJ0RJU0NPTk5FQ1RFRCc7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2Fybignc2VydmVyIGNhcmQgbm90IGZvdW5kIGFmdGVyIGRpc2Nvbm5lY3Rpb24gZXZlbnQsIGFzc3VtaW5nIGZvcmdvdHRlbicpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLnNob3dTZXJ2ZXJSZWNvbm5lY3RpbmcgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgY29uc29sZS5kZWJ1ZyhcInNlcnZlciBcIiArIGV2ZW50LnNlcnZlci5pZCArIFwiIHJlY29ubmVjdGluZ1wiKTtcbiAgICAgICAgdmFyIGNhcmQgPSB0aGlzLnNlcnZlckxpc3RFbC5nZXRTZXJ2ZXJDYXJkKGV2ZW50LnNlcnZlci5pZCk7XG4gICAgICAgIGNhcmQuc3RhdGUgPSAnUkVDT05ORUNUSU5HJztcbiAgICB9O1xuICAgIEFwcC5wcm90b3R5cGUuZGlzcGxheVplcm9TdGF0ZVVpID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAodGhpcy5yb290RWwuJC5zZXJ2ZXJzVmlldy5zaG91bGRTaG93WmVyb1N0YXRlKSB7XG4gICAgICAgICAgICB0aGlzLnJvb3RFbC4kLmFkZFNlcnZlclZpZXcub3BlbkFkZFNlcnZlclNoZWV0KCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIEFwcC5wcm90b3R5cGUuYXJlUHJpdmFjeVRlcm1zQWNrZWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAodGhpcy5lbnZpcm9ubWVudFZhcnMuQkVUQV9CVUlMRCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmdldChzZXR0aW5nc18xLlNldHRpbmdzS2V5LkJFVEFfQUNLKSA9PT0gJ3RydWUnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc2V0dGluZ3MuZ2V0KHNldHRpbmdzXzEuU2V0dGluZ3NLZXkuUFJJVkFDWV9BQ0spID09PSAndHJ1ZSc7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJjb3VsZCBub3QgcmVhZCBwcml2YWN5IGFja25vd2xlZGdlbWVudCBzZXR0aW5nLCBhc3N1bWluZyBub3QgYWNrbm93bGVkZ2VkXCIpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9O1xuICAgIEFwcC5wcm90b3R5cGUuZGlzcGxheVByaXZhY3lWaWV3ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLnJvb3RFbC4kLnNlcnZlcnNWaWV3LmhpZGRlbiA9IHRydWU7XG4gICAgICAgIHRoaXMucm9vdEVsLiQucHJpdmFjeVZpZXcuaXNCZXRhUmVsZWFzZSA9IHRoaXMuZW52aXJvbm1lbnRWYXJzLkJFVEFfQlVJTEQ7XG4gICAgICAgIHRoaXMucm9vdEVsLiQucHJpdmFjeVZpZXcuaGlkZGVuID0gZmFsc2U7XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLmFja1ByaXZhY3lUZXJtcyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5yb290RWwuJC5zZXJ2ZXJzVmlldy5oaWRkZW4gPSBmYWxzZTtcbiAgICAgICAgdGhpcy5yb290RWwuJC5wcml2YWN5Vmlldy5oaWRkZW4gPSB0cnVlO1xuICAgICAgICB0aGlzLnNldHRpbmdzLnNldCh0aGlzLmVudmlyb25tZW50VmFycy5CRVRBX0JVSUxEID8gc2V0dGluZ3NfMS5TZXR0aW5nc0tleS5CRVRBX0FDSyA6IHNldHRpbmdzXzEuU2V0dGluZ3NLZXkuUFJJVkFDWV9BQ0ssICd0cnVlJyk7XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLmhhbmRsZUNsaXBib2FyZFRleHQgPSBmdW5jdGlvbiAodGV4dCkge1xuICAgICAgICAvLyBTaG9ydGVuLCBzYW5pdGlzZS5cbiAgICAgICAgLy8gTm90ZSB0aGF0IHdlIGFsd2F5cyBjaGVjayB0aGUgdGV4dCwgZXZlbiBpZiB0aGUgY29udGVudHMgYXJlIHNhbWUgYXMgbGFzdCB0aW1lLCBiZWNhdXNlIHdlXG4gICAgICAgIC8vIGtlZXAgYW4gaW4tbWVtb3J5IGNhY2hlIG9mIHVzZXItaWdub3JlZCBhY2Nlc3Mga2V5cy5cbiAgICAgICAgdGV4dCA9IHRleHQuc3Vic3RyaW5nKDAsIDEwMDApLnRyaW0oKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHRoaXMuY29uZmlybUFkZFNlcnZlcih0ZXh0LCB0cnVlKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAvLyBEb24ndCBhbGVydCB0aGUgdXNlcjsgaGlnaCBmYWxzZSBwb3NpdGl2ZSByYXRlLlxuICAgICAgICB9XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLnVwZGF0ZURvd25sb2FkZWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRoaXMucm9vdEVsLnNob3dUb2FzdCh0aGlzLmxvY2FsaXplKCd1cGRhdGUtZG93bmxvYWRlZCcpLCA2MDAwMCk7XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLnJlcXVlc3RQcm9tcHRBZGRTZXJ2ZXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRoaXMucm9vdEVsLnByb21wdEFkZFNlcnZlcigpO1xuICAgIH07XG4gICAgLy8gQ2FjaGVzIGFuIGlnbm9yZWQgc2VydmVyIGFjY2VzcyBrZXkgc28gd2UgZG9uJ3QgcHJvbXB0IHRoZSB1c2VyIHRvIGFkZCBpdCBhZ2Fpbi5cbiAgICBBcHAucHJvdG90eXBlLnJlcXVlc3RJZ25vcmVTZXJ2ZXIgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgdmFyIGFjY2Vzc0tleSA9IGV2ZW50LmRldGFpbC5hY2Nlc3NLZXk7XG4gICAgICAgIHRoaXMuaWdub3JlZEFjY2Vzc0tleXNbYWNjZXNzS2V5XSA9IHRydWU7XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLnJlcXVlc3RBZGRTZXJ2ZXIgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHRoaXMuc2VydmVyUmVwby5hZGQoZXZlbnQuZGV0YWlsLnNlcnZlckNvbmZpZyk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgdGhpcy5jaGFuZ2VUb0RlZmF1bHRQYWdlKCk7XG4gICAgICAgICAgICB0aGlzLnNob3dMb2NhbGl6ZWRFcnJvcihlcnIpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLnJlcXVlc3RBZGRTZXJ2ZXJDb25maXJtYXRpb24gPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgdmFyIGFjY2Vzc0tleSA9IGV2ZW50LmRldGFpbC5hY2Nlc3NLZXk7XG4gICAgICAgIGNvbnNvbGUuZGVidWcoJ0dvdCBhZGQgc2VydmVyIGNvbmZpcm1hdGlvbiByZXF1ZXN0IGZyb20gVUknKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHRoaXMuY29uZmlybUFkZFNlcnZlcihhY2Nlc3NLZXkpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBjb25maXJtIGFkZCBzZXZlci4nLCBlcnIpO1xuICAgICAgICAgICAgdmFyIGFkZFNlcnZlclZpZXcgPSB0aGlzLnJvb3RFbC4kLmFkZFNlcnZlclZpZXc7XG4gICAgICAgICAgICBhZGRTZXJ2ZXJWaWV3LiQuYWNjZXNzS2V5SW5wdXQuaW52YWxpZCA9IHRydWU7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIEFwcC5wcm90b3R5cGUuY29uZmlybUFkZFNlcnZlciA9IGZ1bmN0aW9uIChhY2Nlc3NLZXksIGZyb21DbGlwYm9hcmQpIHtcbiAgICAgICAgaWYgKGZyb21DbGlwYm9hcmQgPT09IHZvaWQgMCkgeyBmcm9tQ2xpcGJvYXJkID0gZmFsc2U7IH1cbiAgICAgICAgdmFyIGFkZFNlcnZlclZpZXcgPSB0aGlzLnJvb3RFbC4kLmFkZFNlcnZlclZpZXc7XG4gICAgICAgIGFjY2Vzc0tleSA9IHVud3JhcEludml0ZShhY2Nlc3NLZXkpO1xuICAgICAgICBpZiAoZnJvbUNsaXBib2FyZCAmJiBhY2Nlc3NLZXkgaW4gdGhpcy5pZ25vcmVkQWNjZXNzS2V5cykge1xuICAgICAgICAgICAgcmV0dXJuIGNvbnNvbGUuZGVidWcoJ0lnbm9yaW5nIGFjY2VzcyBrZXknKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChmcm9tQ2xpcGJvYXJkICYmIGFkZFNlcnZlclZpZXcuaXNBZGRpbmdTZXJ2ZXIoKSkge1xuICAgICAgICAgICAgcmV0dXJuIGNvbnNvbGUuZGVidWcoJ0FscmVhZHkgYWRkaW5nIGEgc2VydmVyJyk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gRXhwZWN0IFNIQURPV1NPQ0tTX1VSSS5wYXJzZSB0byB0aHJvdyBvbiBpbnZhbGlkIGFjY2VzcyBrZXk7IHByb3BhZ2F0ZSBhbnkgZXhjZXB0aW9uLlxuICAgICAgICB2YXIgc2hhZG93c29ja3NDb25maWcgPSBudWxsO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgc2hhZG93c29ja3NDb25maWcgPSBzaGFkb3dzb2Nrc19jb25maWdfMS5TSEFET1dTT0NLU19VUkkucGFyc2UoYWNjZXNzS2V5KTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHZhciBtZXNzYWdlID0gISFlcnJvci5tZXNzYWdlID8gZXJyb3IubWVzc2FnZSA6ICdGYWlsZWQgdG8gcGFyc2UgYWNjZXNzIGtleSc7XG4gICAgICAgICAgICB0aHJvdyBuZXcgZXJyb3JzLlNlcnZlclVybEludmFsaWQobWVzc2FnZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNoYWRvd3NvY2tzQ29uZmlnLmhvc3QuaXNJUHY2KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgZXJyb3JzLlNlcnZlckluY29tcGF0aWJsZSgnT25seSBJUHY0IGFkZHJlc3NlcyBhcmUgY3VycmVudGx5IHN1cHBvcnRlZCcpO1xuICAgICAgICB9XG4gICAgICAgIHZhciBuYW1lID0gc2hhZG93c29ja3NDb25maWcuZXh0cmEub3V0bGluZSA/XG4gICAgICAgICAgICB0aGlzLmxvY2FsaXplKCdzZXJ2ZXItZGVmYXVsdC1uYW1lLW91dGxpbmUnKSA6XG4gICAgICAgICAgICBzaGFkb3dzb2Nrc0NvbmZpZy50YWcuZGF0YSA/IHNoYWRvd3NvY2tzQ29uZmlnLnRhZy5kYXRhIDpcbiAgICAgICAgICAgICAgICB0aGlzLmxvY2FsaXplKCdzZXJ2ZXItZGVmYXVsdC1uYW1lJyk7XG4gICAgICAgIHZhciBzZXJ2ZXJDb25maWcgPSB7XG4gICAgICAgICAgICBob3N0OiBzaGFkb3dzb2Nrc0NvbmZpZy5ob3N0LmRhdGEsXG4gICAgICAgICAgICBwb3J0OiBzaGFkb3dzb2Nrc0NvbmZpZy5wb3J0LmRhdGEsXG4gICAgICAgICAgICBtZXRob2Q6IHNoYWRvd3NvY2tzQ29uZmlnLm1ldGhvZC5kYXRhLFxuICAgICAgICAgICAgcGFzc3dvcmQ6IHNoYWRvd3NvY2tzQ29uZmlnLnBhc3N3b3JkLmRhdGEsXG4gICAgICAgICAgICBuYW1lOiBuYW1lLFxuICAgICAgICB9O1xuICAgICAgICBpZiAoIXRoaXMuc2VydmVyUmVwby5jb250YWluc1NlcnZlcihzZXJ2ZXJDb25maWcpKSB7XG4gICAgICAgICAgICAvLyBPbmx5IHByb21wdCB0aGUgdXNlciB0byBhZGQgbmV3IHNlcnZlcnMuXG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGFkZFNlcnZlclZpZXcub3BlbkFkZFNlcnZlckNvbmZpcm1hdGlvblNoZWV0KGFjY2Vzc0tleSwgc2VydmVyQ29uZmlnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gb3BlbiBhZGQgc2V2ZXIgY29uZmlybWF0aW9uIHNoZWV0OicsIGVyci5tZXNzYWdlKTtcbiAgICAgICAgICAgICAgICBpZiAoIWZyb21DbGlwYm9hcmQpXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2hvd0xvY2FsaXplZEVycm9yKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoIWZyb21DbGlwYm9hcmQpIHtcbiAgICAgICAgICAgIC8vIERpc3BsYXkgZXJyb3IgbWVzc2FnZSBpZiB0aGlzIGlzIG5vdCBhIGNsaXBib2FyZCBhZGQuXG4gICAgICAgICAgICBhZGRTZXJ2ZXJWaWV3LmNsb3NlKCk7XG4gICAgICAgICAgICB0aGlzLnNob3dMb2NhbGl6ZWRFcnJvcihuZXcgZXJyb3JzLlNlcnZlckFscmVhZHlBZGRlZCh0aGlzLnNlcnZlclJlcG8uY3JlYXRlU2VydmVyKCcnLCBzZXJ2ZXJDb25maWcsIHRoaXMuZXZlbnRRdWV1ZSkpKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgQXBwLnByb3RvdHlwZS5mb3JnZXRTZXJ2ZXIgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgdmFyIHNlcnZlcklkID0gZXZlbnQuZGV0YWlsLnNlcnZlcklkO1xuICAgICAgICB2YXIgc2VydmVyID0gdGhpcy5zZXJ2ZXJSZXBvLmdldEJ5SWQoc2VydmVySWQpO1xuICAgICAgICBpZiAoIXNlcnZlcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIk5vIHNlcnZlciB3aXRoIGlkIFwiICsgc2VydmVySWQpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc2hvd0xvY2FsaXplZEVycm9yKCk7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIG9uY2VOb3RSdW5uaW5nID0gc2VydmVyLmNoZWNrUnVubmluZygpLnRoZW4oZnVuY3Rpb24gKGlzUnVubmluZykge1xuICAgICAgICAgICAgcmV0dXJuIGlzUnVubmluZyA/IF90aGlzLmRpc2Nvbm5lY3RTZXJ2ZXIoZXZlbnQpIDogUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgICAgIH0pO1xuICAgICAgICBvbmNlTm90UnVubmluZy50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIF90aGlzLnNlcnZlclJlcG8uZm9yZ2V0KHNlcnZlcklkKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLnJlbmFtZVNlcnZlciA9IGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgICB2YXIgc2VydmVySWQgPSBldmVudC5kZXRhaWwuc2VydmVySWQ7XG4gICAgICAgIHZhciBuZXdOYW1lID0gZXZlbnQuZGV0YWlsLm5ld05hbWU7XG4gICAgICAgIHRoaXMuc2VydmVyUmVwby5yZW5hbWUoc2VydmVySWQsIG5ld05hbWUpO1xuICAgIH07XG4gICAgQXBwLnByb3RvdHlwZS5jb25uZWN0U2VydmVyID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIHZhciBzZXJ2ZXJJZCA9IGV2ZW50LmRldGFpbC5zZXJ2ZXJJZDtcbiAgICAgICAgaWYgKCFzZXJ2ZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiY29ubmVjdFNlcnZlciBldmVudCBoYWQgbm8gc2VydmVyIElEXCIpO1xuICAgICAgICB9XG4gICAgICAgIHZhciBzZXJ2ZXIgPSB0aGlzLmdldFNlcnZlckJ5U2VydmVySWQoc2VydmVySWQpO1xuICAgICAgICB2YXIgY2FyZCA9IHRoaXMuZ2V0Q2FyZEJ5U2VydmVySWQoc2VydmVySWQpO1xuICAgICAgICBjb25zb2xlLmxvZyhcImNvbm5lY3RpbmcgdG8gc2VydmVyIFwiICsgc2VydmVySWQpO1xuICAgICAgICBjYXJkLnN0YXRlID0gJ0NPTk5FQ1RJTkcnO1xuICAgICAgICBzZXJ2ZXIuY29ubmVjdCgpLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgY2FyZC5zdGF0ZSA9ICdDT05ORUNURUQnO1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJjb25uZWN0ZWQgdG8gc2VydmVyIFwiICsgc2VydmVySWQpO1xuICAgICAgICAgICAgX3RoaXMucm9vdEVsLnNob3dUb2FzdChfdGhpcy5sb2NhbGl6ZSgnc2VydmVyLWNvbm5lY3RlZCcsICdzZXJ2ZXJOYW1lJywgc2VydmVyLm5hbWUpKTtcbiAgICAgICAgICAgIF90aGlzLm1heWJlU2hvd0F1dG9Db25uZWN0RGlhbG9nKCk7XG4gICAgICAgIH0sIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICBjYXJkLnN0YXRlID0gJ0RJU0NPTk5FQ1RFRCc7XG4gICAgICAgICAgICBfdGhpcy5zaG93TG9jYWxpemVkRXJyb3IoZSk7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiY291bGQgbm90IGNvbm5lY3QgdG8gc2VydmVyIFwiICsgc2VydmVySWQgKyBcIjogXCIgKyBlLm5hbWUpO1xuICAgICAgICAgICAgaWYgKCEoZSBpbnN0YW5jZW9mIGVycm9ycy5SZWd1bGFyTmF0aXZlRXJyb3IpKSB7XG4gICAgICAgICAgICAgICAgX3RoaXMuZXJyb3JSZXBvcnRlci5yZXBvcnQoXCJjb25uZWN0aW9uIGZhaWx1cmU6IFwiICsgZS5uYW1lLCAnY29ubmVjdGlvbi1mYWlsdXJlJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgQXBwLnByb3RvdHlwZS5tYXliZVNob3dBdXRvQ29ubmVjdERpYWxvZyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGRpc21pc3NlZCA9IGZhbHNlO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgZGlzbWlzc2VkID0gdGhpcy5zZXR0aW5ncy5nZXQoc2V0dGluZ3NfMS5TZXR0aW5nc0tleS5BVVRPX0NPTk5FQ1RfRElBTE9HX0RJU01JU1NFRCkgPT09ICd0cnVlJztcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byByZWFkIGF1dG8tY29ubmVjdCBkaWFsb2cgc3RhdHVzLCBhc3N1bWluZyBub3QgZGlzbWlzc2VkOiBcIiArIGUpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZGlzbWlzc2VkKSB7XG4gICAgICAgICAgICB0aGlzLnJvb3RFbC4kLnNlcnZlcnNWaWV3LiQuYXV0b0Nvbm5lY3REaWFsb2cuc2hvdygpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLmF1dG9Db25uZWN0RGlhbG9nRGlzbWlzc2VkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLnNldHRpbmdzLnNldChzZXR0aW5nc18xLlNldHRpbmdzS2V5LkFVVE9fQ09OTkVDVF9ESUFMT0dfRElTTUlTU0VELCAndHJ1ZScpO1xuICAgIH07XG4gICAgQXBwLnByb3RvdHlwZS5kaXNjb25uZWN0U2VydmVyID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIHZhciBzZXJ2ZXJJZCA9IGV2ZW50LmRldGFpbC5zZXJ2ZXJJZDtcbiAgICAgICAgaWYgKCFzZXJ2ZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiZGlzY29ubmVjdFNlcnZlciBldmVudCBoYWQgbm8gc2VydmVyIElEXCIpO1xuICAgICAgICB9XG4gICAgICAgIHZhciBzZXJ2ZXIgPSB0aGlzLmdldFNlcnZlckJ5U2VydmVySWQoc2VydmVySWQpO1xuICAgICAgICB2YXIgY2FyZCA9IHRoaXMuZ2V0Q2FyZEJ5U2VydmVySWQoc2VydmVySWQpO1xuICAgICAgICBjb25zb2xlLmxvZyhcImRpc2Nvbm5lY3RpbmcgZnJvbSBzZXJ2ZXIgXCIgKyBzZXJ2ZXJJZCk7XG4gICAgICAgIGNhcmQuc3RhdGUgPSAnRElTQ09OTkVDVElORyc7XG4gICAgICAgIHNlcnZlci5kaXNjb25uZWN0KCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjYXJkLnN0YXRlID0gJ0RJU0NPTk5FQ1RFRCc7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImRpc2Nvbm5lY3RlZCBmcm9tIHNlcnZlciBcIiArIHNlcnZlcklkKTtcbiAgICAgICAgICAgIF90aGlzLnJvb3RFbC5zaG93VG9hc3QoX3RoaXMubG9jYWxpemUoJ3NlcnZlci1kaXNjb25uZWN0ZWQnLCAnc2VydmVyTmFtZScsIHNlcnZlci5uYW1lKSk7XG4gICAgICAgIH0sIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICBjYXJkLnN0YXRlID0gJ0NPTk5FQ1RFRCc7XG4gICAgICAgICAgICBfdGhpcy5zaG93TG9jYWxpemVkRXJyb3IoZSk7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oXCJjb3VsZCBub3QgZGlzY29ubmVjdCBmcm9tIHNlcnZlciBcIiArIHNlcnZlcklkICsgXCI6IFwiICsgZS5uYW1lKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLnN1Ym1pdEZlZWRiYWNrID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIHZhciBmb3JtRGF0YSA9IHRoaXMuZmVlZGJhY2tWaWV3RWwuZ2V0VmFsaWRhdGVkRm9ybURhdGEoKTtcbiAgICAgICAgaWYgKCFmb3JtRGF0YSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHZhciBmZWVkYmFjayA9IGZvcm1EYXRhLmZlZWRiYWNrLCBjYXRlZ29yeSA9IGZvcm1EYXRhLmNhdGVnb3J5LCBlbWFpbCA9IGZvcm1EYXRhLmVtYWlsO1xuICAgICAgICB0aGlzLnJvb3RFbC4kLmZlZWRiYWNrVmlldy5zdWJtaXR0aW5nID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5lcnJvclJlcG9ydGVyLnJlcG9ydChmZWVkYmFjaywgY2F0ZWdvcnksIGVtYWlsKVxuICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgX3RoaXMucm9vdEVsLiQuZmVlZGJhY2tWaWV3LnN1Ym1pdHRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgIF90aGlzLnJvb3RFbC4kLmZlZWRiYWNrVmlldy5yZXNldEZvcm0oKTtcbiAgICAgICAgICAgIF90aGlzLmNoYW5nZVRvRGVmYXVsdFBhZ2UoKTtcbiAgICAgICAgICAgIF90aGlzLnJvb3RFbC5zaG93VG9hc3QoX3RoaXMucm9vdEVsLmxvY2FsaXplKCdmZWVkYmFjay10aGFua3MnKSk7XG4gICAgICAgIH0sIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgIF90aGlzLnJvb3RFbC4kLmZlZWRiYWNrVmlldy5zdWJtaXR0aW5nID0gZmFsc2U7XG4gICAgICAgICAgICBfdGhpcy5zaG93TG9jYWxpemVkRXJyb3IobmV3IGVycm9ycy5GZWVkYmFja1N1Ym1pc3Npb25FcnJvcigpKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICAvLyBFdmVudFF1ZXVlIGV2ZW50IGhhbmRsZXJzOlxuICAgIEFwcC5wcm90b3R5cGUuc2hvd1NlcnZlckFkZGVkID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgIHZhciBzZXJ2ZXIgPSBldmVudC5zZXJ2ZXI7XG4gICAgICAgIGNvbnNvbGUuZGVidWcoJ1NlcnZlciBhZGRlZCcpO1xuICAgICAgICB0aGlzLnN5bmNTZXJ2ZXJzVG9VSSgpO1xuICAgICAgICB0aGlzLnN5bmNTZXJ2ZXJDb25uZWN0aXZpdHlTdGF0ZShzZXJ2ZXIpO1xuICAgICAgICB0aGlzLmNoYW5nZVRvRGVmYXVsdFBhZ2UoKTtcbiAgICAgICAgdGhpcy5yb290RWwuc2hvd1RvYXN0KHRoaXMubG9jYWxpemUoJ3NlcnZlci1hZGRlZCcsICdzZXJ2ZXJOYW1lJywgc2VydmVyLm5hbWUpKTtcbiAgICB9O1xuICAgIEFwcC5wcm90b3R5cGUuc2hvd1NlcnZlckZvcmdvdHRlbiA9IGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICB2YXIgc2VydmVyID0gZXZlbnQuc2VydmVyO1xuICAgICAgICBjb25zb2xlLmRlYnVnKCdTZXJ2ZXIgZm9yZ290dGVuJyk7XG4gICAgICAgIHRoaXMuc3luY1NlcnZlcnNUb1VJKCk7XG4gICAgICAgIHRoaXMucm9vdEVsLnNob3dUb2FzdCh0aGlzLmxvY2FsaXplKCdzZXJ2ZXItZm9yZ290dGVuJywgJ3NlcnZlck5hbWUnLCBzZXJ2ZXIubmFtZSksIDEwMDAwLCB0aGlzLmxvY2FsaXplKCd1bmRvLWJ1dHRvbi1sYWJlbCcpLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBfdGhpcy5zZXJ2ZXJSZXBvLnVuZG9Gb3JnZXQoc2VydmVyLmlkKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLnNob3dTZXJ2ZXJGb3JnZXRVbmRvbmUgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgdGhpcy5zeW5jU2VydmVyc1RvVUkoKTtcbiAgICAgICAgdmFyIHNlcnZlciA9IGV2ZW50LnNlcnZlcjtcbiAgICAgICAgdGhpcy5yb290RWwuc2hvd1RvYXN0KHRoaXMubG9jYWxpemUoJ3NlcnZlci1mb3Jnb3R0ZW4tdW5kbycsICdzZXJ2ZXJOYW1lJywgc2VydmVyLm5hbWUpKTtcbiAgICB9O1xuICAgIEFwcC5wcm90b3R5cGUuc2hvd1NlcnZlclJlbmFtZWQgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgdmFyIHNlcnZlciA9IGV2ZW50LnNlcnZlcjtcbiAgICAgICAgY29uc29sZS5kZWJ1ZygnU2VydmVyIHJlbmFtZWQnKTtcbiAgICAgICAgdGhpcy5zZXJ2ZXJMaXN0RWwuZ2V0U2VydmVyQ2FyZChzZXJ2ZXIuaWQpLnNlcnZlck5hbWUgPSBzZXJ2ZXIubmFtZTtcbiAgICAgICAgdGhpcy5yb290RWwuc2hvd1RvYXN0KHRoaXMubG9jYWxpemUoJ3NlcnZlci1yZW5hbWUtY29tcGxldGUnKSk7XG4gICAgfTtcbiAgICAvLyBIZWxwZXJzOlxuICAgIEFwcC5wcm90b3R5cGUuc3luY1NlcnZlcnNUb1VJID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLnJvb3RFbC5zZXJ2ZXJzID0gdGhpcy5zZXJ2ZXJSZXBvLmdldEFsbCgpO1xuICAgIH07XG4gICAgQXBwLnByb3RvdHlwZS5zeW5jQ29ubmVjdGl2aXR5U3RhdGVUb1NlcnZlckNhcmRzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgZV8xLCBfYTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGZvciAodmFyIF9iID0gX192YWx1ZXModGhpcy5zZXJ2ZXJSZXBvLmdldEFsbCgpKSwgX2MgPSBfYi5uZXh0KCk7ICFfYy5kb25lOyBfYyA9IF9iLm5leHQoKSkge1xuICAgICAgICAgICAgICAgIHZhciBzZXJ2ZXIgPSBfYy52YWx1ZTtcbiAgICAgICAgICAgICAgICB0aGlzLnN5bmNTZXJ2ZXJDb25uZWN0aXZpdHlTdGF0ZShzZXJ2ZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlXzFfMSkgeyBlXzEgPSB7IGVycm9yOiBlXzFfMSB9OyB9XG4gICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBpZiAoX2MgJiYgIV9jLmRvbmUgJiYgKF9hID0gX2IucmV0dXJuKSkgX2EuY2FsbChfYik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmaW5hbGx5IHsgaWYgKGVfMSkgdGhyb3cgZV8xLmVycm9yOyB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIEFwcC5wcm90b3R5cGUuc3luY1NlcnZlckNvbm5lY3Rpdml0eVN0YXRlID0gZnVuY3Rpb24gKHNlcnZlcikge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICBzZXJ2ZXIuY2hlY2tSdW5uaW5nKClcbiAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChpc1J1bm5pbmcpIHtcbiAgICAgICAgICAgIHZhciBjYXJkID0gX3RoaXMuc2VydmVyTGlzdEVsLmdldFNlcnZlckNhcmQoc2VydmVyLmlkKTtcbiAgICAgICAgICAgIGlmICghaXNSdW5uaW5nKSB7XG4gICAgICAgICAgICAgICAgY2FyZC5zdGF0ZSA9ICdESVNDT05ORUNURUQnO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHNlcnZlci5jaGVja1JlYWNoYWJsZSgpLnRoZW4oZnVuY3Rpb24gKGlzUmVhY2hhYmxlKSB7XG4gICAgICAgICAgICAgICAgaWYgKGlzUmVhY2hhYmxlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNhcmQuc3RhdGUgPSAnQ09OTkVDVEVEJztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiU2VydmVyIFwiICsgc2VydmVyLmlkICsgXCIgcmVjb25uZWN0aW5nXCIpO1xuICAgICAgICAgICAgICAgICAgICBjYXJkLnN0YXRlID0gJ1JFQ09OTkVDVElORyc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pXG4gICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBzeW5jIHNlcnZlciBjb25uZWN0aXZpdHkgc3RhdGUnLCBlKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLnJlZ2lzdGVyVXJsSW50ZXJjZXB0aW9uTGlzdGVuZXIgPSBmdW5jdGlvbiAodXJsSW50ZXJjZXB0b3IpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgdXJsSW50ZXJjZXB0b3IucmVnaXN0ZXJMaXN0ZW5lcihmdW5jdGlvbiAodXJsKSB7XG4gICAgICAgICAgICBpZiAoIXVybCB8fCAhdW53cmFwSW52aXRlKHVybCkuc3RhcnRzV2l0aCgnc3M6Ly8nKSkge1xuICAgICAgICAgICAgICAgIC8vIFRoaXMgY2hlY2sgaXMgbmVjZXNzYXJ5IHRvIGlnbm9yZSBlbXB0eSBhbmQgbWFsZm9ybWVkIGluc3RhbGwtcmVmZXJyZXIgVVJMcyBpbiBBbmRyb2lkXG4gICAgICAgICAgICAgICAgLy8gd2hpbGUgYWxsb3dpbmcgc3M6Ly8gYW5kIGludml0ZSBVUkxzLlxuICAgICAgICAgICAgICAgIC8vIFRPRE86IFN0b3AgcmVjZWl2aW5nIGluc3RhbGwgcmVmZXJyZXIgaW50ZW50cyBzbyB3ZSBjYW4gcmVtb3ZlIHRoaXMuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbnNvbGUuZGVidWcoXCJJZ25vcmluZyBpbnRlcmNlcHRlZCBub24tc2hhZG93c29ja3MgdXJsXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBfdGhpcy5jb25maXJtQWRkU2VydmVyKHVybCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgX3RoaXMuc2hvd0xvY2FsaXplZEVycm9ySW5EZWZhdWx0UGFnZShlcnIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIEFwcC5wcm90b3R5cGUuY2hhbmdlVG9EZWZhdWx0UGFnZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5yb290RWwuY2hhbmdlUGFnZSh0aGlzLnJvb3RFbC5ERUZBVUxUX1BBR0UpO1xuICAgIH07XG4gICAgLy8gUmV0dXJucyB0aGUgc2VydmVyIGhhdmluZyBzZXJ2ZXJJZCwgdGhyb3dzIGlmIHRoZSBzZXJ2ZXIgY2Fubm90IGJlIGZvdW5kLlxuICAgIEFwcC5wcm90b3R5cGUuZ2V0U2VydmVyQnlTZXJ2ZXJJZCA9IGZ1bmN0aW9uIChzZXJ2ZXJJZCkge1xuICAgICAgICB2YXIgc2VydmVyID0gdGhpcy5zZXJ2ZXJSZXBvLmdldEJ5SWQoc2VydmVySWQpO1xuICAgICAgICBpZiAoIXNlcnZlcikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiY291bGQgbm90IGZpbmQgc2VydmVyIHdpdGggSUQgXCIgKyBzZXJ2ZXJJZCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHNlcnZlcjtcbiAgICB9O1xuICAgIC8vIFJldHVybnMgdGhlIGNhcmQgYXNzb2NpYXRlZCB3aXRoIHNlcnZlcklkLCB0aHJvd3MgaWYgbm8gc3VjaCBjYXJkIGV4aXN0cy5cbiAgICAvLyBTZWUgc2VydmVyLWxpc3QuaHRtbC5cbiAgICBBcHAucHJvdG90eXBlLmdldENhcmRCeVNlcnZlcklkID0gZnVuY3Rpb24gKHNlcnZlcklkKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNlcnZlckxpc3RFbC5nZXRTZXJ2ZXJDYXJkKHNlcnZlcklkKTtcbiAgICB9O1xuICAgIEFwcC5wcm90b3R5cGUuc2hvd0xvY2FsaXplZEVycm9ySW5EZWZhdWx0UGFnZSA9IGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgdGhpcy5jaGFuZ2VUb0RlZmF1bHRQYWdlKCk7XG4gICAgICAgIHRoaXMuc2hvd0xvY2FsaXplZEVycm9yKGVycik7XG4gICAgfTtcbiAgICBBcHAucHJvdG90eXBlLmlzV2luZG93cyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuICEoJ2NvcmRvdmEnIGluIHdpbmRvdyk7XG4gICAgfTtcbiAgICByZXR1cm4gQXBwO1xufSgpKTtcbmV4cG9ydHMuQXBwID0gQXBwO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG4vLyBDb3B5cmlnaHQgMjAxOCBUaGUgT3V0bGluZSBBdXRob3JzXG4vL1xuLy8gTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbi8vIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbi8vIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuLy9cbi8vICAgICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4vL1xuLy8gVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuLy8gZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuLy8gV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4vLyBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4vLyBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbi8vIEdlbmVyaWMgY2xpcGJvYXJkLiBJbXBsZW1lbnRhdGlvbnMgc2hvdWxkIG9ubHkgaGF2ZSB0byBpbXBsZW1lbnQgZ2V0Q29udGVudHMoKS5cbnZhciBBYnN0cmFjdENsaXBib2FyZCA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBBYnN0cmFjdENsaXBib2FyZCgpIHtcbiAgICAgICAgdGhpcy5saXN0ZW5lciA9IG51bGw7XG4gICAgfVxuICAgIEFic3RyYWN0Q2xpcGJvYXJkLnByb3RvdHlwZS5nZXRDb250ZW50cyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcigndW5pbXBsZW1lbnRlZCBza2VsZXRvbiBtZXRob2QnKSk7XG4gICAgfTtcbiAgICBBYnN0cmFjdENsaXBib2FyZC5wcm90b3R5cGUuc2V0TGlzdGVuZXIgPSBmdW5jdGlvbiAobGlzdGVuZXIpIHtcbiAgICAgICAgdGhpcy5saXN0ZW5lciA9IGxpc3RlbmVyO1xuICAgIH07XG4gICAgQWJzdHJhY3RDbGlwYm9hcmQucHJvdG90eXBlLmVtaXRFdmVudCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKHRoaXMubGlzdGVuZXIpIHtcbiAgICAgICAgICAgIHRoaXMuZ2V0Q29udGVudHMoKS50aGVuKHRoaXMubGlzdGVuZXIpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICByZXR1cm4gQWJzdHJhY3RDbGlwYm9hcmQ7XG59KCkpO1xuZXhwb3J0cy5BYnN0cmFjdENsaXBib2FyZCA9IEFic3RyYWN0Q2xpcGJvYXJkO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG4vLyBDb3B5cmlnaHQgMjAxOCBUaGUgT3V0bGluZSBBdXRob3JzXG4vL1xuLy8gTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbi8vIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbi8vIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuLy9cbi8vICAgICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4vL1xuLy8gVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuLy8gZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuLy8gV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4vLyBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4vLyBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbnZhciBfX2V4dGVuZHMgPSAodGhpcyAmJiB0aGlzLl9fZXh0ZW5kcykgfHwgKGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgZXh0ZW5kU3RhdGljcyA9IGZ1bmN0aW9uIChkLCBiKSB7XG4gICAgICAgIGV4dGVuZFN0YXRpY3MgPSBPYmplY3Quc2V0UHJvdG90eXBlT2YgfHxcbiAgICAgICAgICAgICh7IF9fcHJvdG9fXzogW10gfSBpbnN0YW5jZW9mIEFycmF5ICYmIGZ1bmN0aW9uIChkLCBiKSB7IGQuX19wcm90b19fID0gYjsgfSkgfHxcbiAgICAgICAgICAgIGZ1bmN0aW9uIChkLCBiKSB7IGZvciAodmFyIHAgaW4gYikgaWYgKGIuaGFzT3duUHJvcGVydHkocCkpIGRbcF0gPSBiW3BdOyB9O1xuICAgICAgICByZXR1cm4gZXh0ZW5kU3RhdGljcyhkLCBiKTtcbiAgICB9XG4gICAgcmV0dXJuIGZ1bmN0aW9uIChkLCBiKSB7XG4gICAgICAgIGV4dGVuZFN0YXRpY3MoZCwgYik7XG4gICAgICAgIGZ1bmN0aW9uIF9fKCkgeyB0aGlzLmNvbnN0cnVjdG9yID0gZDsgfVxuICAgICAgICBkLnByb3RvdHlwZSA9IGIgPT09IG51bGwgPyBPYmplY3QuY3JlYXRlKGIpIDogKF9fLnByb3RvdHlwZSA9IGIucHJvdG90eXBlLCBuZXcgX18oKSk7XG4gICAgfTtcbn0pKCk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi90eXBlcy9hbWJpZW50L291dGxpbmVQbHVnaW4uZC50cycvPlxuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vdHlwZXMvYW1iaWVudC93ZWJpbnRlbnRzLmQudHMnLz5cbnZhciBSYXZlbiA9IHJlcXVpcmUoXCJyYXZlbi1qc1wiKTtcbnZhciBjbGlwYm9hcmRfMSA9IHJlcXVpcmUoXCIuL2NsaXBib2FyZFwiKTtcbnZhciBlcnJvcl9yZXBvcnRlcl8xID0gcmVxdWlyZShcIi4vZXJyb3JfcmVwb3J0ZXJcIik7XG52YXIgZmFrZV9jb25uZWN0aW9uXzEgPSByZXF1aXJlKFwiLi9mYWtlX2Nvbm5lY3Rpb25cIik7XG52YXIgbWFpbl8xID0gcmVxdWlyZShcIi4vbWFpblwiKTtcbnZhciBvdXRsaW5lX3NlcnZlcl8xID0gcmVxdWlyZShcIi4vb3V0bGluZV9zZXJ2ZXJcIik7XG52YXIgdXBkYXRlcl8xID0gcmVxdWlyZShcIi4vdXBkYXRlclwiKTtcbnZhciBpbnRlcmNlcHRvcnMgPSByZXF1aXJlKFwiLi91cmxfaW50ZXJjZXB0b3JcIik7XG4vLyBQdXNoZXMgYSBjbGlwYm9hcmQgZXZlbnQgd2hlbmV2ZXIgdGhlIGFwcCBpcyBicm91Z2h0IHRvIHRoZSBmb3JlZ3JvdW5kLlxudmFyIENvcmRvdmFDbGlwYm9hcmQgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKENvcmRvdmFDbGlwYm9hcmQsIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gQ29yZG92YUNsaXBib2FyZCgpIHtcbiAgICAgICAgdmFyIF90aGlzID0gX3N1cGVyLmNhbGwodGhpcykgfHwgdGhpcztcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigncmVzdW1lJywgX3RoaXMuZW1pdEV2ZW50LmJpbmQoX3RoaXMpKTtcbiAgICAgICAgcmV0dXJuIF90aGlzO1xuICAgIH1cbiAgICBDb3Jkb3ZhQ2xpcGJvYXJkLnByb3RvdHlwZS5nZXRDb250ZW50cyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgIGNvcmRvdmEucGx1Z2lucy5jbGlwYm9hcmQucGFzdGUocmVzb2x2ZSwgcmVqZWN0KTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICByZXR1cm4gQ29yZG92YUNsaXBib2FyZDtcbn0oY2xpcGJvYXJkXzEuQWJzdHJhY3RDbGlwYm9hcmQpKTtcbi8vIEFkZHMgcmVwb3J0cyBmcm9tIHRoZSAobmF0aXZlKSBDb3Jkb3ZhIHBsdWdpbi5cbnZhciBDb3Jkb3ZhRXJyb3JSZXBvcnRlciA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoQ29yZG92YUVycm9yUmVwb3J0ZXIsIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gQ29yZG92YUVycm9yUmVwb3J0ZXIoYXBwVmVyc2lvbiwgYXBwQnVpbGROdW1iZXIsIGRzbiwgbmF0aXZlRHNuKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IF9zdXBlci5jYWxsKHRoaXMsIGFwcFZlcnNpb24sIGRzbiwgeyAnYnVpbGQubnVtYmVyJzogYXBwQnVpbGROdW1iZXIgfSkgfHwgdGhpcztcbiAgICAgICAgY29yZG92YS5wbHVnaW5zLm91dGxpbmUubG9nLmluaXRpYWxpemUobmF0aXZlRHNuKS5jYXRjaChjb25zb2xlLmVycm9yKTtcbiAgICAgICAgcmV0dXJuIF90aGlzO1xuICAgIH1cbiAgICBDb3Jkb3ZhRXJyb3JSZXBvcnRlci5wcm90b3R5cGUucmVwb3J0ID0gZnVuY3Rpb24gKHVzZXJGZWVkYmFjaywgZmVlZGJhY2tDYXRlZ29yeSwgdXNlckVtYWlsKSB7XG4gICAgICAgIHJldHVybiBfc3VwZXIucHJvdG90eXBlLnJlcG9ydC5jYWxsKHRoaXMsIHVzZXJGZWVkYmFjaywgZmVlZGJhY2tDYXRlZ29yeSwgdXNlckVtYWlsKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiBjb3Jkb3ZhLnBsdWdpbnMub3V0bGluZS5sb2cuc2VuZChSYXZlbi5sYXN0RXZlbnRJZCgpKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICByZXR1cm4gQ29yZG92YUVycm9yUmVwb3J0ZXI7XG59KGVycm9yX3JlcG9ydGVyXzEuU2VudHJ5RXJyb3JSZXBvcnRlcikpO1xuZXhwb3J0cy5Db3Jkb3ZhRXJyb3JSZXBvcnRlciA9IENvcmRvdmFFcnJvclJlcG9ydGVyO1xuLy8gVGhpcyBjbGFzcyBzaG91bGQgb25seSBiZSBpbnN0YW50aWF0ZWQgYWZ0ZXIgQ29yZG92YSBmaXJlcyB0aGUgZGV2aWNlcmVhZHkgZXZlbnQuXG52YXIgQ29yZG92YVBsYXRmb3JtID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIENvcmRvdmFQbGF0Zm9ybSgpIHtcbiAgICB9XG4gICAgQ29yZG92YVBsYXRmb3JtLmlzQnJvd3NlciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIGRldmljZS5wbGF0Zm9ybSA9PT0gJ2Jyb3dzZXInO1xuICAgIH07XG4gICAgQ29yZG92YVBsYXRmb3JtLnByb3RvdHlwZS5oYXNEZXZpY2VTdXBwb3J0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gIUNvcmRvdmFQbGF0Zm9ybS5pc0Jyb3dzZXIoKTtcbiAgICB9O1xuICAgIENvcmRvdmFQbGF0Zm9ybS5wcm90b3R5cGUuZ2V0UGVyc2lzdGVudFNlcnZlckZhY3RvcnkgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoc2VydmVySWQsIGNvbmZpZywgZXZlbnRRdWV1ZSkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBvdXRsaW5lX3NlcnZlcl8xLk91dGxpbmVTZXJ2ZXIoc2VydmVySWQsIGNvbmZpZywgX3RoaXMuaGFzRGV2aWNlU3VwcG9ydCgpID8gbmV3IGNvcmRvdmEucGx1Z2lucy5vdXRsaW5lLkNvbm5lY3Rpb24oY29uZmlnLCBzZXJ2ZXJJZCkgOlxuICAgICAgICAgICAgICAgIG5ldyBmYWtlX2Nvbm5lY3Rpb25fMS5GYWtlT3V0bGluZUNvbm5lY3Rpb24oY29uZmlnLCBzZXJ2ZXJJZCksIGV2ZW50UXVldWUpO1xuICAgICAgICB9O1xuICAgIH07XG4gICAgQ29yZG92YVBsYXRmb3JtLnByb3RvdHlwZS5nZXRVcmxJbnRlcmNlcHRvciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKGRldmljZS5wbGF0Zm9ybSA9PT0gJ2lPUycgfHwgZGV2aWNlLnBsYXRmb3JtID09PSAnTWFjIE9TIFgnKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IGludGVyY2VwdG9ycy5BcHBsZVVybEludGVyY2VwdG9yKGFwcGxlTGF1bmNoVXJsKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChkZXZpY2UucGxhdGZvcm0gPT09ICdBbmRyb2lkJykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBpbnRlcmNlcHRvcnMuQW5kcm9pZFVybEludGVyY2VwdG9yKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc29sZS53YXJuKCdubyBpbnRlbnQgaW50ZXJjZXB0b3IgYXZhaWxhYmxlJyk7XG4gICAgICAgIHJldHVybiBuZXcgaW50ZXJjZXB0b3JzLlVybEludGVyY2VwdG9yKCk7XG4gICAgfTtcbiAgICBDb3Jkb3ZhUGxhdGZvcm0ucHJvdG90eXBlLmdldENsaXBib2FyZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBDb3Jkb3ZhQ2xpcGJvYXJkKCk7XG4gICAgfTtcbiAgICBDb3Jkb3ZhUGxhdGZvcm0ucHJvdG90eXBlLmdldEVycm9yUmVwb3J0ZXIgPSBmdW5jdGlvbiAoZW52KSB7XG4gICAgICAgIHJldHVybiB0aGlzLmhhc0RldmljZVN1cHBvcnQoKSA/XG4gICAgICAgICAgICBuZXcgQ29yZG92YUVycm9yUmVwb3J0ZXIoZW52LkFQUF9WRVJTSU9OLCBlbnYuQVBQX0JVSUxEX05VTUJFUiwgZW52LlNFTlRSWV9EU04sIGVudi5TRU5UUllfTkFUSVZFX0RTTikgOlxuICAgICAgICAgICAgbmV3IGVycm9yX3JlcG9ydGVyXzEuU2VudHJ5RXJyb3JSZXBvcnRlcihlbnYuQVBQX1ZFUlNJT04sIGVudi5TRU5UUllfRFNOLCB7fSk7XG4gICAgfTtcbiAgICBDb3Jkb3ZhUGxhdGZvcm0ucHJvdG90eXBlLmdldFVwZGF0ZXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBuZXcgdXBkYXRlcl8xLkFic3RyYWN0VXBkYXRlcigpO1xuICAgIH07XG4gICAgQ29yZG92YVBsYXRmb3JtLnByb3RvdHlwZS5xdWl0QXBwbGljYXRpb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8vIE9ubHkgdXNlZCBpbiBtYWNPUyBiZWNhdXNlIG1lbnUgYmFyIGFwcHMgcHJvdmlkZSBubyBhbHRlcm5hdGl2ZSB3YXkgb2YgcXVpdHRpbmcuXG4gICAgICAgIGNvcmRvdmEucGx1Z2lucy5vdXRsaW5lLnF1aXRBcHBsaWNhdGlvbigpO1xuICAgIH07XG4gICAgcmV0dXJuIENvcmRvdmFQbGF0Zm9ybTtcbn0oKSk7XG4vLyBodHRwczovL2NvcmRvdmEuYXBhY2hlLm9yZy9kb2NzL2VuL2xhdGVzdC9jb3Jkb3ZhL2V2ZW50cy9ldmVudHMuaHRtbCNkZXZpY2VyZWFkeVxudmFyIG9uY2VEZXZpY2VSZWFkeSA9IG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlKSB7XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignZGV2aWNlcmVhZHknLCByZXNvbHZlKTtcbn0pO1xuLy8gY29yZG92YS1baW9zfG9zeF0gY2FsbCBhIGdsb2JhbCBmdW5jdGlvbiB3aXRoIHRoaXMgc2lnbmF0dXJlIHdoZW4gYSBVUkwgaXNcbi8vIGludGVyY2VwdGVkLiBXZSBoYW5kbGUgVVJMIGludGVyY2VwdGlvbnMgd2l0aCBhbiBpbnRlbnQgaW50ZXJjZXB0b3I7IGhvd2V2ZXIsXG4vLyB3aGVuIHRoZSBhcHAgaXMgbGF1bmNoZWQgdmlhIFVSTCBvdXIgc3RhcnQgdXAgc2VxdWVuY2UgbWlzc2VzIHRoZSBjYWxsIGR1ZSB0b1xuLy8gYSByYWNlLiBEZWZpbmUgdGhlIGZ1bmN0aW9uIHRlbXBvcmFyaWx5IGhlcmUsIGFuZCBzZXQgYSBnbG9iYWwgdmFyaWFibGUuXG52YXIgYXBwbGVMYXVuY2hVcmw7XG53aW5kb3cuaGFuZGxlT3BlblVSTCA9IGZ1bmN0aW9uICh1cmwpIHtcbiAgICBhcHBsZUxhdW5jaFVybCA9IHVybDtcbn07XG5vbmNlRGV2aWNlUmVhZHkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgbWFpbl8xLm1haW4obmV3IENvcmRvdmFQbGF0Zm9ybSgpKTtcbn0pO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG4vLyBDb3B5cmlnaHQgMjAxOCBUaGUgT3V0bGluZSBBdXRob3JzXG4vL1xuLy8gTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbi8vIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbi8vIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuLy9cbi8vICAgICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4vL1xuLy8gVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuLy8gZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuLy8gV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4vLyBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4vLyBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbi8vIEtlZXAgdGhlc2UgaW4gc3luYyB3aXRoIHRoZSBFbnZpcm9ubWVudFZhcmlhYmxlcyBpbnRlcmZhY2UgYWJvdmUuXG52YXIgRU5WX0tFWVMgPSB7XG4gICAgQVBQX1ZFUlNJT046ICdBUFBfVkVSU0lPTicsXG4gICAgQVBQX0JVSUxEX05VTUJFUjogJ0FQUF9CVUlMRF9OVU1CRVInLFxuICAgIEJFVEFfQlVJTEQ6ICdCRVRBX0JVSUxEJyxcbiAgICBTRU5UUllfRFNOOiAnU0VOVFJZX0RTTicsXG4gICAgU0VOVFJZX05BVElWRV9EU046ICdTRU5UUllfTkFUSVZFX0RTTidcbn07XG5mdW5jdGlvbiB2YWxpZGF0ZUVudlZhcnMoanNvbikge1xuICAgIGZvciAodmFyIGtleSBpbiBFTlZfS0VZUykge1xuICAgICAgICBpZiAoIWpzb24uaGFzT3duUHJvcGVydHkoa2V5KSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTWlzc2luZyBlbnZpcm9ubWVudCB2YXJpYWJsZTogXCIgKyBrZXkpO1xuICAgICAgICB9XG4gICAgfVxufVxuLy8gQWNjb3JkaW5nIHRvIGh0dHA6Ly9jYW5pdXNlLmNvbS8jZmVhdD1mZXRjaCBmZXRjaCBkaWRuJ3QgaGl0IGlPUyBTYWZhcmlcbi8vIHVudGlsIHYxMC4zIHJlbGVhc2VkIDMvMjYvMTcsIHNvIHVzZSBYTUxIdHRwUmVxdWVzdCBpbnN0ZWFkLlxuZXhwb3J0cy5vbmNlRW52VmFycyA9IG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICB2YXIgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgeGhyLm9ubG9hZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHZhciBqc29uID0gSlNPTi5wYXJzZSh4aHIucmVzcG9uc2VUZXh0KTtcbiAgICAgICAgICAgIHZhbGlkYXRlRW52VmFycyhqc29uKTtcbiAgICAgICAgICAgIGNvbnNvbGUuZGVidWcoJ1Jlc29sdmluZyB3aXRoIGVudlZhcnM6JywganNvbik7XG4gICAgICAgICAgICByZXNvbHZlKGpzb24pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICB4aHIub3BlbignR0VUJywgJ2Vudmlyb25tZW50Lmpzb24nLCB0cnVlKTtcbiAgICB4aHIuc2VuZCgpO1xufSk7XG4iLCJcInVzZSBzdHJpY3RcIjtcbi8vIENvcHlyaWdodCAyMDE4IFRoZSBPdXRsaW5lIEF1dGhvcnNcbi8vXG4vLyBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuLy8geW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuLy8gWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4vL1xuLy8gICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbi8vXG4vLyBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4vLyBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4vLyBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbi8vIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbi8vIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xudmFyIFJhdmVuID0gcmVxdWlyZShcInJhdmVuLWpzXCIpO1xudmFyIFNlbnRyeUVycm9yUmVwb3J0ZXIgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gU2VudHJ5RXJyb3JSZXBvcnRlcihhcHBWZXJzaW9uLCBkc24sIHRhZ3MpIHtcbiAgICAgICAgUmF2ZW4uY29uZmlnKGRzbiwgeyByZWxlYXNlOiBhcHBWZXJzaW9uLCAndGFncyc6IHRhZ3MgfSkuaW5zdGFsbCgpO1xuICAgICAgICB0aGlzLnNldFVwVW5oYW5kbGVkUmVqZWN0aW9uTGlzdGVuZXIoKTtcbiAgICB9XG4gICAgU2VudHJ5RXJyb3JSZXBvcnRlci5wcm90b3R5cGUucmVwb3J0ID0gZnVuY3Rpb24gKHVzZXJGZWVkYmFjaywgZmVlZGJhY2tDYXRlZ29yeSwgdXNlckVtYWlsKSB7XG4gICAgICAgIFJhdmVuLnNldFVzZXJDb250ZXh0KHsgZW1haWw6IHVzZXJFbWFpbCB8fCAnJyB9KTtcbiAgICAgICAgUmF2ZW4uY2FwdHVyZU1lc3NhZ2UodXNlckZlZWRiYWNrLCB7IHRhZ3M6IHsgY2F0ZWdvcnk6IGZlZWRiYWNrQ2F0ZWdvcnkgfSB9KTtcbiAgICAgICAgUmF2ZW4uc2V0VXNlckNvbnRleHQoKTsgLy8gUmVzZXQgdGhlIHVzZXIgY29udGV4dCwgZG9uJ3QgY2FjaGUgdGhlIGVtYWlsXG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9O1xuICAgIFNlbnRyeUVycm9yUmVwb3J0ZXIucHJvdG90eXBlLnNldFVwVW5oYW5kbGVkUmVqZWN0aW9uTGlzdGVuZXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8vIENocm9tZSBpcyB0aGUgb25seSBicm93c2VyIHRoYXQgc3VwcG9ydHMgdGhlIHVuaGFuZGxlZHJlamVjdGlvbiBldmVudC5cbiAgICAgICAgLy8gVGhpcyBpcyBmaW5lIGZvciBBbmRyb2lkLCBidXQgd2lsbCBub3Qgd29yayBpbiBpT1MuXG4gICAgICAgIHZhciB1bmhhbmRsZWRSZWplY3Rpb24gPSAndW5oYW5kbGVkcmVqZWN0aW9uJztcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIodW5oYW5kbGVkUmVqZWN0aW9uLCBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICAgIHZhciByZWFzb24gPSBldmVudC5yZWFzb247XG4gICAgICAgICAgICB2YXIgbXNnID0gcmVhc29uLnN0YWNrID8gcmVhc29uLnN0YWNrIDogcmVhc29uO1xuICAgICAgICAgICAgUmF2ZW4uY2FwdHVyZUJyZWFkY3J1bWIoeyBtZXNzYWdlOiBtc2csIGNhdGVnb3J5OiB1bmhhbmRsZWRSZWplY3Rpb24gfSk7XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgcmV0dXJuIFNlbnRyeUVycm9yUmVwb3J0ZXI7XG59KCkpO1xuZXhwb3J0cy5TZW50cnlFcnJvclJlcG9ydGVyID0gU2VudHJ5RXJyb3JSZXBvcnRlcjtcbiIsIlwidXNlIHN0cmljdFwiO1xuLy8gQ29weXJpZ2h0IDIwMTggVGhlIE91dGxpbmUgQXV0aG9yc1xuLy9cbi8vIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4vLyB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4vLyBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbi8vXG4vLyAgICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuLy9cbi8vIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbi8vIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbi8vIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuLy8gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuLy8gbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi90eXBlcy9hbWJpZW50L291dGxpbmVQbHVnaW4uZC50cycvPlxudmFyIGVycm9ycyA9IHJlcXVpcmUoXCIuLi9tb2RlbC9lcnJvcnNcIik7XG4vLyBOb3RlIHRoYXQgYmVjYXVzZSB0aGlzIGltcGxlbWVudGF0aW9uIGRvZXMgbm90IGVtaXQgZGlzY29ubmVjdGlvbiBldmVudHMsIFwic3dpdGNoaW5nXCIgYmV0d2VlblxuLy8gc2VydmVycyBpbiB0aGUgc2VydmVyIGxpc3Qgd2lsbCBub3Qgd29yayBhcyBleHBlY3RlZC5cbnZhciBGYWtlT3V0bGluZUNvbm5lY3Rpb24gPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gRmFrZU91dGxpbmVDb25uZWN0aW9uKGNvbmZpZywgaWQpIHtcbiAgICAgICAgdGhpcy5jb25maWcgPSBjb25maWc7XG4gICAgICAgIHRoaXMuaWQgPSBpZDtcbiAgICAgICAgdGhpcy5ydW5uaW5nID0gZmFsc2U7XG4gICAgfVxuICAgIEZha2VPdXRsaW5lQ29ubmVjdGlvbi5wcm90b3R5cGUucGxheUJyb2tlbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY29uZmlnLm5hbWUgJiYgdGhpcy5jb25maWcubmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKCdicm9rZW4nKTtcbiAgICB9O1xuICAgIEZha2VPdXRsaW5lQ29ubmVjdGlvbi5wcm90b3R5cGUucGxheVVucmVhY2hhYmxlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gISh0aGlzLmNvbmZpZy5uYW1lICYmIHRoaXMuY29uZmlnLm5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygndW5yZWFjaGFibGUnKSk7XG4gICAgfTtcbiAgICBGYWtlT3V0bGluZUNvbm5lY3Rpb24ucHJvdG90eXBlLnN0YXJ0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAodGhpcy5ydW5uaW5nKSB7XG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLnBsYXlVbnJlYWNoYWJsZSgpKSB7XG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IGVycm9ycy5PdXRsaW5lUGx1Z2luRXJyb3IoNSAvKiBTRVJWRVJfVU5SRUFDSEFCTEUgKi8pKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0aGlzLnBsYXlCcm9rZW4oKSkge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBlcnJvcnMuT3V0bGluZVBsdWdpbkVycm9yKDggLyogU0hBRE9XU09DS1NfU1RBUlRfRkFJTFVSRSAqLykpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5ydW5uaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgRmFrZU91dGxpbmVDb25uZWN0aW9uLnByb3RvdHlwZS5zdG9wID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAoIXRoaXMucnVubmluZykge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMucnVubmluZyA9IGZhbHNlO1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgfTtcbiAgICBGYWtlT3V0bGluZUNvbm5lY3Rpb24ucHJvdG90eXBlLmlzUnVubmluZyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh0aGlzLnJ1bm5pbmcpO1xuICAgIH07XG4gICAgRmFrZU91dGxpbmVDb25uZWN0aW9uLnByb3RvdHlwZS5pc1JlYWNoYWJsZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSghdGhpcy5wbGF5VW5yZWFjaGFibGUoKSk7XG4gICAgfTtcbiAgICBGYWtlT3V0bGluZUNvbm5lY3Rpb24ucHJvdG90eXBlLm9uU3RhdHVzQ2hhbmdlID0gZnVuY3Rpb24gKGxpc3RlbmVyKSB7XG4gICAgICAgIC8vIE5PT1BcbiAgICB9O1xuICAgIHJldHVybiBGYWtlT3V0bGluZUNvbm5lY3Rpb247XG59KCkpO1xuZXhwb3J0cy5GYWtlT3V0bGluZUNvbm5lY3Rpb24gPSBGYWtlT3V0bGluZUNvbm5lY3Rpb247XG4iLCJcInVzZSBzdHJpY3RcIjtcbi8vIENvcHlyaWdodCAyMDE4IFRoZSBPdXRsaW5lIEF1dGhvcnNcbi8vXG4vLyBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuLy8geW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuLy8gWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4vL1xuLy8gICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbi8vXG4vLyBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4vLyBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4vLyBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbi8vIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbi8vIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxudmFyIF9fcmVhZCA9ICh0aGlzICYmIHRoaXMuX19yZWFkKSB8fCBmdW5jdGlvbiAobywgbikge1xuICAgIHZhciBtID0gdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIG9bU3ltYm9sLml0ZXJhdG9yXTtcbiAgICBpZiAoIW0pIHJldHVybiBvO1xuICAgIHZhciBpID0gbS5jYWxsKG8pLCByLCBhciA9IFtdLCBlO1xuICAgIHRyeSB7XG4gICAgICAgIHdoaWxlICgobiA9PT0gdm9pZCAwIHx8IG4tLSA+IDApICYmICEociA9IGkubmV4dCgpKS5kb25lKSBhci5wdXNoKHIudmFsdWUpO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHsgZSA9IHsgZXJyb3I6IGVycm9yIH07IH1cbiAgICBmaW5hbGx5IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmIChyICYmICFyLmRvbmUgJiYgKG0gPSBpW1wicmV0dXJuXCJdKSkgbS5jYWxsKGkpO1xuICAgICAgICB9XG4gICAgICAgIGZpbmFsbHkgeyBpZiAoZSkgdGhyb3cgZS5lcnJvcjsgfVxuICAgIH1cbiAgICByZXR1cm4gYXI7XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xudmFyIHVybCA9IHJlcXVpcmUoXCJ1cmxcIik7XG52YXIgZXZlbnRzXzEgPSByZXF1aXJlKFwiLi4vbW9kZWwvZXZlbnRzXCIpO1xudmFyIGFwcF8xID0gcmVxdWlyZShcIi4vYXBwXCIpO1xudmFyIGVudmlyb25tZW50XzEgPSByZXF1aXJlKFwiLi9lbnZpcm9ubWVudFwiKTtcbnZhciBwZXJzaXN0ZW50X3NlcnZlcl8xID0gcmVxdWlyZShcIi4vcGVyc2lzdGVudF9zZXJ2ZXJcIik7XG52YXIgc2V0dGluZ3NfMSA9IHJlcXVpcmUoXCIuL3NldHRpbmdzXCIpO1xuLy8gVXNlZCB0byBkZXRlcm1pbmUgd2hldGhlciB0byB1c2UgUG9seW1lciBmdW5jdGlvbmFsaXR5IG9uIGFwcCBpbml0aWFsaXphdGlvbiBmYWlsdXJlLlxudmFyIHdlYkNvbXBvbmVudHNBcmVSZWFkeSA9IGZhbHNlO1xuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignV2ViQ29tcG9uZW50c1JlYWR5JywgZnVuY3Rpb24gKCkge1xuICAgIGNvbnNvbGUuZGVidWcoJ3JlY2VpdmVkIFdlYkNvbXBvbmVudHNSZWFkeSBldmVudCcpO1xuICAgIHdlYkNvbXBvbmVudHNBcmVSZWFkeSA9IHRydWU7XG59KTtcbi8vIFVzZWQgdG8gZGVsYXkgbG9hZGluZyB0aGUgYXBwIHVudGlsICh0cmFuc2xhdGlvbikgcmVzb3VyY2VzIGhhdmUgYmVlbiBsb2FkZWQuIFRoaXMgY2FuIGhhcHBlbiBhXG4vLyBsaXR0bGUgbGF0ZXIgdGhhbiBXZWJDb21wb25lbnRzUmVhZHkuXG52YXIgb25jZVBvbHltZXJJc1JlYWR5ID0gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUpIHtcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdhcHAtbG9jYWxpemUtcmVzb3VyY2VzLWxvYWRlZCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgY29uc29sZS5kZWJ1ZygncmVjZWl2ZWQgYXBwLWxvY2FsaXplLXJlc291cmNlcy1sb2FkZWQgZXZlbnQnKTtcbiAgICAgICAgcmVzb2x2ZSgpO1xuICAgIH0pO1xufSk7XG4vLyBIZWxwZXJzXG4vLyBEbyBub3QgY2FsbCB1bnRpbCBXZWJDb21wb25lbnRzUmVhZHkgaGFzIGZpcmVkIVxuZnVuY3Rpb24gZ2V0Um9vdEVsKCkge1xuICAgIHJldHVybiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdhcHAtcm9vdCcpO1xufVxuZnVuY3Rpb24gY3JlYXRlU2VydmVyUmVwbyhldmVudFF1ZXVlLCBzdG9yYWdlLCBkZXZpY2VTdXBwb3J0LCBjb25uZWN0aW9uVHlwZSkge1xuICAgIHZhciByZXBvID0gbmV3IHBlcnNpc3RlbnRfc2VydmVyXzEuUGVyc2lzdGVudFNlcnZlclJlcG9zaXRvcnkoY29ubmVjdGlvblR5cGUsIGV2ZW50UXVldWUsIHN0b3JhZ2UpO1xuICAgIGlmICghZGV2aWNlU3VwcG9ydCkge1xuICAgICAgICBjb25zb2xlLmRlYnVnKCdEZXRlY3RlZCBkZXZlbG9wbWVudCBlbnZpcm9ubWVudCwgdXNpbmcgZmFrZSBzZXJ2ZXJzLicpO1xuICAgICAgICBpZiAocmVwby5nZXRBbGwoKS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHJlcG8uYWRkKHsgbmFtZTogJ0Zha2UgV29ya2luZyBTZXJ2ZXInLCBob3N0OiAnMTI3LjAuMC4xJywgcG9ydDogMTIzIH0pO1xuICAgICAgICAgICAgcmVwby5hZGQoeyBuYW1lOiAnRmFrZSBCcm9rZW4gU2VydmVyJywgaG9zdDogJzE5Mi4wLjIuMScsIHBvcnQ6IDEyMyB9KTtcbiAgICAgICAgICAgIHJlcG8uYWRkKHsgbmFtZTogJ0Zha2UgVW5yZWFjaGFibGUgU2VydmVyJywgaG9zdDogJzEwLjAuMC4yNCcsIHBvcnQ6IDEyMyB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcmVwbztcbn1cbmZ1bmN0aW9uIG1haW4ocGxhdGZvcm0pIHtcbiAgICByZXR1cm4gUHJvbWlzZS5hbGwoW2Vudmlyb25tZW50XzEub25jZUVudlZhcnMsIG9uY2VQb2x5bWVySXNSZWFkeV0pXG4gICAgICAgIC50aGVuKGZ1bmN0aW9uIChfYSkge1xuICAgICAgICB2YXIgX2IgPSBfX3JlYWQoX2EsIDEpLCBlbnZpcm9ubWVudFZhcnMgPSBfYlswXTtcbiAgICAgICAgY29uc29sZS5kZWJ1ZygncnVubmluZyBtYWluKCkgZnVuY3Rpb24nKTtcbiAgICAgICAgdmFyIHF1ZXJ5UGFyYW1zID0gdXJsLnBhcnNlKGRvY3VtZW50LlVSTCwgdHJ1ZSkucXVlcnk7XG4gICAgICAgIHZhciBkZWJ1Z01vZGUgPSBxdWVyeVBhcmFtcy5kZWJ1ZyA9PT0gJ3RydWUnO1xuICAgICAgICB2YXIgZXZlbnRRdWV1ZSA9IG5ldyBldmVudHNfMS5FdmVudFF1ZXVlKCk7XG4gICAgICAgIHZhciBzZXJ2ZXJSZXBvID0gY3JlYXRlU2VydmVyUmVwbyhldmVudFF1ZXVlLCB3aW5kb3cubG9jYWxTdG9yYWdlLCBwbGF0Zm9ybS5oYXNEZXZpY2VTdXBwb3J0KCksIHBsYXRmb3JtLmdldFBlcnNpc3RlbnRTZXJ2ZXJGYWN0b3J5KCkpO1xuICAgICAgICB2YXIgc2V0dGluZ3MgPSBuZXcgc2V0dGluZ3NfMS5TZXR0aW5ncygpO1xuICAgICAgICB2YXIgYXBwID0gbmV3IGFwcF8xLkFwcChldmVudFF1ZXVlLCBzZXJ2ZXJSZXBvLCBnZXRSb290RWwoKSwgZGVidWdNb2RlLCBwbGF0Zm9ybS5nZXRVcmxJbnRlcmNlcHRvcigpLCBwbGF0Zm9ybS5nZXRDbGlwYm9hcmQoKSwgcGxhdGZvcm0uZ2V0RXJyb3JSZXBvcnRlcihlbnZpcm9ubWVudFZhcnMpLCBzZXR0aW5ncywgZW52aXJvbm1lbnRWYXJzLCBwbGF0Zm9ybS5nZXRVcGRhdGVyKCksIHBsYXRmb3JtLnF1aXRBcHBsaWNhdGlvbik7XG4gICAgfSwgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgb25VbmV4cGVjdGVkRXJyb3IoZSk7XG4gICAgICAgIHRocm93IGU7XG4gICAgfSk7XG59XG5leHBvcnRzLm1haW4gPSBtYWluO1xuZnVuY3Rpb24gb25VbmV4cGVjdGVkRXJyb3IoZXJyb3IpIHtcbiAgICB2YXIgcm9vdEVsID0gZ2V0Um9vdEVsKCk7XG4gICAgaWYgKHdlYkNvbXBvbmVudHNBcmVSZWFkeSAmJiByb290RWwgJiYgcm9vdEVsLmxvY2FsaXplKSB7XG4gICAgICAgIHZhciBsb2NhbGl6ZSA9IHJvb3RFbC5sb2NhbGl6ZS5iaW5kKHJvb3RFbCk7XG4gICAgICAgIHJvb3RFbC5zaG93VG9hc3QobG9jYWxpemUoJ2Vycm9yLXVuZXhwZWN0ZWQnKSwgMTIwMDAwKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIFNvbWV0aGluZyB3ZW50IHRlcnJpYmx5IHdyb25nIChpLmUuIFBvbHltZXIgZmFpbGVkIHRvIGluaXRpYWxpemUpLiBQcm92aWRlIHNvbWUgbWVzc2FnaW5nIHRvXG4gICAgICAgIC8vIHRoZSB1c2VyLCBldmVuIGlmIHdlIGFyZSBub3QgYWJsZSB0byBkaXNwbGF5IGl0IGluIGEgdG9hc3Qgb3IgbG9jYWxpemUgaXQuXG4gICAgICAgIC8vIFRPRE86IHByb3ZpZGUgYW4gaGVscCBlbWFpbCBvbmNlIHdlIGhhdmUgYSBkb21haW4uXG4gICAgICAgIGFsZXJ0KFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZC5cIik7XG4gICAgfVxuICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xufVxuLy8gUmV0dXJucyBQb2x5bWVyJ3MgbG9jYWxpemF0aW9uIGZ1bmN0aW9uLiBNdXN0IGJlIGNhbGxlZCBhZnRlciBXZWJDb21wb25lbnRzUmVhZHkgaGFzIGZpcmVkLlxuZnVuY3Rpb24gZ2V0TG9jYWxpemF0aW9uRnVuY3Rpb24oKSB7XG4gICAgdmFyIHJvb3RFbCA9IGdldFJvb3RFbCgpO1xuICAgIGlmICghcm9vdEVsKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gcm9vdEVsLmxvY2FsaXplO1xufVxuZXhwb3J0cy5nZXRMb2NhbGl6YXRpb25GdW5jdGlvbiA9IGdldExvY2FsaXphdGlvbkZ1bmN0aW9uO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG4vLyBDb3B5cmlnaHQgMjAxOCBUaGUgT3V0bGluZSBBdXRob3JzXG4vL1xuLy8gTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbi8vIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbi8vIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuLy9cbi8vICAgICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4vL1xuLy8gVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuLy8gZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuLy8gV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4vLyBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4vLyBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uL3R5cGVzL2FtYmllbnQvb3V0bGluZVBsdWdpbi5kLnRzJy8+XG52YXIgZXJyb3JzID0gcmVxdWlyZShcIi4uL21vZGVsL2Vycm9yc1wiKTtcbnZhciBldmVudHMgPSByZXF1aXJlKFwiLi4vbW9kZWwvZXZlbnRzXCIpO1xudmFyIE91dGxpbmVTZXJ2ZXIgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gT3V0bGluZVNlcnZlcihpZCwgY29uZmlnLCBjb25uZWN0aW9uLCBldmVudFF1ZXVlKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIHRoaXMuaWQgPSBpZDtcbiAgICAgICAgdGhpcy5jb25maWcgPSBjb25maWc7XG4gICAgICAgIHRoaXMuY29ubmVjdGlvbiA9IGNvbm5lY3Rpb247XG4gICAgICAgIHRoaXMuZXZlbnRRdWV1ZSA9IGV2ZW50UXVldWU7XG4gICAgICAgIHRoaXMuY29ubmVjdGlvbi5vblN0YXR1c0NoYW5nZShmdW5jdGlvbiAoc3RhdHVzKSB7XG4gICAgICAgICAgICB2YXIgc3RhdHVzRXZlbnQ7XG4gICAgICAgICAgICBzd2l0Y2ggKHN0YXR1cykge1xuICAgICAgICAgICAgICAgIGNhc2UgMCAvKiBDT05ORUNURUQgKi86XG4gICAgICAgICAgICAgICAgICAgIHN0YXR1c0V2ZW50ID0gbmV3IGV2ZW50cy5TZXJ2ZXJDb25uZWN0ZWQoX3RoaXMpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIDEgLyogRElTQ09OTkVDVEVEICovOlxuICAgICAgICAgICAgICAgICAgICBzdGF0dXNFdmVudCA9IG5ldyBldmVudHMuU2VydmVyRGlzY29ubmVjdGVkKF90aGlzKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAyIC8qIFJFQ09OTkVDVElORyAqLzpcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzRXZlbnQgPSBuZXcgZXZlbnRzLlNlcnZlclJlY29ubmVjdGluZyhfdGhpcyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihcIlJlY2VpdmVkIHVua25vd24gY29ubmVjdGlvbiBzdGF0dXMgXCIgKyBzdGF0dXMpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBldmVudFF1ZXVlLmVucXVldWUoc3RhdHVzRXZlbnQpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KE91dGxpbmVTZXJ2ZXIucHJvdG90eXBlLCBcIm5hbWVcIiwge1xuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbmZpZy5uYW1lIHx8IHRoaXMuY29uZmlnLmhvc3QgfHwgJyc7XG4gICAgICAgIH0sXG4gICAgICAgIHNldDogZnVuY3Rpb24gKG5ld05hbWUpIHtcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLm5hbWUgPSBuZXdOYW1lO1xuICAgICAgICB9LFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoT3V0bGluZVNlcnZlci5wcm90b3R5cGUsIFwiaG9zdFwiLCB7XG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uZmlnLmhvc3Q7XG4gICAgICAgIH0sXG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIE91dGxpbmVTZXJ2ZXIucHJvdG90eXBlLmNvbm5lY3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmNvbm5lY3Rpb24uc3RhcnQoKS5jYXRjaChmdW5jdGlvbiAoZSkge1xuICAgICAgICAgICAgLy8gZSBvcmlnaW5hdGVzIGluIFwibmF0aXZlXCIgY29kZTogZWl0aGVyIENvcmRvdmEgb3IgRWxlY3Ryb24ncyBtYWluIHByb2Nlc3MuXG4gICAgICAgICAgICAvLyBCZWNhdXNlIG9mIHRoaXMsIHdlIGNhbm5vdCBhc3N1bWUgXCJpbnN0YW5jZW9mIE91dGxpbmVQbHVnaW5FcnJvclwiIHdpbGwgd29yay5cbiAgICAgICAgICAgIGlmIChlLmVycm9yQ29kZSkge1xuICAgICAgICAgICAgICAgIHRocm93IGVycm9ycy5mcm9tRXJyb3JDb2RlKGUuZXJyb3JDb2RlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgT3V0bGluZVNlcnZlci5wcm90b3R5cGUuZGlzY29ubmVjdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY29ubmVjdGlvbi5zdG9wKCkuY2F0Y2goZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgIC8vIFRPRE86IE5vbmUgb2YgdGhlIHBsdWdpbnMgY3VycmVudGx5IHJldHVybiBhbiBFcnJvckNvZGUgb24gZGlzY29ubmVjdGlvbi5cbiAgICAgICAgICAgIHRocm93IG5ldyBlcnJvcnMuUmVndWxhck5hdGl2ZUVycm9yKCk7XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgT3V0bGluZVNlcnZlci5wcm90b3R5cGUuY2hlY2tSdW5uaW5nID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5jb25uZWN0aW9uLmlzUnVubmluZygpO1xuICAgIH07XG4gICAgT3V0bGluZVNlcnZlci5wcm90b3R5cGUuY2hlY2tSZWFjaGFibGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmNvbm5lY3Rpb24uaXNSZWFjaGFibGUoKTtcbiAgICB9O1xuICAgIHJldHVybiBPdXRsaW5lU2VydmVyO1xufSgpKTtcbmV4cG9ydHMuT3V0bGluZVNlcnZlciA9IE91dGxpbmVTZXJ2ZXI7XG4iLCJcInVzZSBzdHJpY3RcIjtcbi8vIENvcHlyaWdodCAyMDE4IFRoZSBPdXRsaW5lIEF1dGhvcnNcbi8vXG4vLyBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuLy8geW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuLy8gWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4vL1xuLy8gICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbi8vXG4vLyBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4vLyBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4vLyBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbi8vIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbi8vIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxudmFyIF9fdmFsdWVzID0gKHRoaXMgJiYgdGhpcy5fX3ZhbHVlcykgfHwgZnVuY3Rpb24gKG8pIHtcbiAgICB2YXIgbSA9IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvW1N5bWJvbC5pdGVyYXRvcl0sIGkgPSAwO1xuICAgIGlmIChtKSByZXR1cm4gbS5jYWxsKG8pO1xuICAgIHJldHVybiB7XG4gICAgICAgIG5leHQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmIChvICYmIGkgPj0gby5sZW5ndGgpIG8gPSB2b2lkIDA7XG4gICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogbyAmJiBvW2krK10sIGRvbmU6ICFvIH07XG4gICAgICAgIH1cbiAgICB9O1xufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbnZhciB1dWlkdjQgPSByZXF1aXJlKFwidXVpZHY0XCIpO1xudmFyIGVycm9yc18xID0gcmVxdWlyZShcIi4uL21vZGVsL2Vycm9yc1wiKTtcbnZhciBldmVudHMgPSByZXF1aXJlKFwiLi4vbW9kZWwvZXZlbnRzXCIpO1xuLy8gTWFpbnRhaW5zIGEgcGVyc2lzdGVkIHNldCBvZiBzZXJ2ZXJzIGFuZCBsaWFpc2VzIHdpdGggdGhlIGNvcmUuXG52YXIgUGVyc2lzdGVudFNlcnZlclJlcG9zaXRvcnkgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gUGVyc2lzdGVudFNlcnZlclJlcG9zaXRvcnkoY3JlYXRlU2VydmVyLCBldmVudFF1ZXVlLCBzdG9yYWdlKSB7XG4gICAgICAgIHRoaXMuY3JlYXRlU2VydmVyID0gY3JlYXRlU2VydmVyO1xuICAgICAgICB0aGlzLmV2ZW50UXVldWUgPSBldmVudFF1ZXVlO1xuICAgICAgICB0aGlzLnN0b3JhZ2UgPSBzdG9yYWdlO1xuICAgICAgICB0aGlzLmxhc3RGb3Jnb3R0ZW5TZXJ2ZXIgPSBudWxsO1xuICAgICAgICB0aGlzLmxvYWRTZXJ2ZXJzKCk7XG4gICAgfVxuICAgIFBlcnNpc3RlbnRTZXJ2ZXJSZXBvc2l0b3J5LnByb3RvdHlwZS5nZXRBbGwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBBcnJheS5mcm9tKHRoaXMuc2VydmVyQnlJZC52YWx1ZXMoKSk7XG4gICAgfTtcbiAgICBQZXJzaXN0ZW50U2VydmVyUmVwb3NpdG9yeS5wcm90b3R5cGUuZ2V0QnlJZCA9IGZ1bmN0aW9uIChzZXJ2ZXJJZCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXJ2ZXJCeUlkLmdldChzZXJ2ZXJJZCk7XG4gICAgfTtcbiAgICBQZXJzaXN0ZW50U2VydmVyUmVwb3NpdG9yeS5wcm90b3R5cGUuYWRkID0gZnVuY3Rpb24gKHNlcnZlckNvbmZpZykge1xuICAgICAgICB2YXIgYWxyZWFkeUFkZGVkU2VydmVyID0gdGhpcy5zZXJ2ZXJGcm9tQ29uZmlnKHNlcnZlckNvbmZpZyk7XG4gICAgICAgIGlmIChhbHJlYWR5QWRkZWRTZXJ2ZXIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBlcnJvcnNfMS5TZXJ2ZXJBbHJlYWR5QWRkZWQoYWxyZWFkeUFkZGVkU2VydmVyKTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgc2VydmVyID0gdGhpcy5jcmVhdGVTZXJ2ZXIodXVpZHY0KCksIHNlcnZlckNvbmZpZywgdGhpcy5ldmVudFF1ZXVlKTtcbiAgICAgICAgdGhpcy5zZXJ2ZXJCeUlkLnNldChzZXJ2ZXIuaWQsIHNlcnZlcik7XG4gICAgICAgIHRoaXMuc3RvcmVTZXJ2ZXJzKCk7XG4gICAgICAgIHRoaXMuZXZlbnRRdWV1ZS5lbnF1ZXVlKG5ldyBldmVudHMuU2VydmVyQWRkZWQoc2VydmVyKSk7XG4gICAgfTtcbiAgICBQZXJzaXN0ZW50U2VydmVyUmVwb3NpdG9yeS5wcm90b3R5cGUucmVuYW1lID0gZnVuY3Rpb24gKHNlcnZlcklkLCBuZXdOYW1lKSB7XG4gICAgICAgIHZhciBzZXJ2ZXIgPSB0aGlzLnNlcnZlckJ5SWQuZ2V0KHNlcnZlcklkKTtcbiAgICAgICAgaWYgKCFzZXJ2ZXIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcIkNhbm5vdCByZW5hbWUgbm9uZXhpc3RlbnQgc2VydmVyIFwiICsgc2VydmVySWQpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHNlcnZlci5uYW1lID0gbmV3TmFtZTtcbiAgICAgICAgdGhpcy5zdG9yZVNlcnZlcnMoKTtcbiAgICAgICAgdGhpcy5ldmVudFF1ZXVlLmVucXVldWUobmV3IGV2ZW50cy5TZXJ2ZXJSZW5hbWVkKHNlcnZlcikpO1xuICAgIH07XG4gICAgUGVyc2lzdGVudFNlcnZlclJlcG9zaXRvcnkucHJvdG90eXBlLmZvcmdldCA9IGZ1bmN0aW9uIChzZXJ2ZXJJZCkge1xuICAgICAgICB2YXIgc2VydmVyID0gdGhpcy5zZXJ2ZXJCeUlkLmdldChzZXJ2ZXJJZCk7XG4gICAgICAgIGlmICghc2VydmVyKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oXCJDYW5ub3QgcmVtb3ZlIG5vbmV4aXN0ZW50IHNlcnZlciBcIiArIHNlcnZlcklkKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNlcnZlckJ5SWQuZGVsZXRlKHNlcnZlcklkKTtcbiAgICAgICAgdGhpcy5sYXN0Rm9yZ290dGVuU2VydmVyID0gc2VydmVyO1xuICAgICAgICB0aGlzLnN0b3JlU2VydmVycygpO1xuICAgICAgICB0aGlzLmV2ZW50UXVldWUuZW5xdWV1ZShuZXcgZXZlbnRzLlNlcnZlckZvcmdvdHRlbihzZXJ2ZXIpKTtcbiAgICB9O1xuICAgIFBlcnNpc3RlbnRTZXJ2ZXJSZXBvc2l0b3J5LnByb3RvdHlwZS51bmRvRm9yZ2V0ID0gZnVuY3Rpb24gKHNlcnZlcklkKSB7XG4gICAgICAgIGlmICghdGhpcy5sYXN0Rm9yZ290dGVuU2VydmVyKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ05vIGZvcmdvdHRlbiBzZXJ2ZXIgdG8gdW5mb3JnZXQnKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0aGlzLmxhc3RGb3Jnb3R0ZW5TZXJ2ZXIuaWQgIT09IHNlcnZlcklkKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ2lkIG9mIGZvcmdvdHRlbiBzZXJ2ZXInLCB0aGlzLmxhc3RGb3Jnb3R0ZW5TZXJ2ZXIsICdkb2VzIG5vdCBtYXRjaCcsIHNlcnZlcklkKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNlcnZlckJ5SWQuc2V0KHRoaXMubGFzdEZvcmdvdHRlblNlcnZlci5pZCwgdGhpcy5sYXN0Rm9yZ290dGVuU2VydmVyKTtcbiAgICAgICAgdGhpcy5zdG9yZVNlcnZlcnMoKTtcbiAgICAgICAgdGhpcy5ldmVudFF1ZXVlLmVucXVldWUobmV3IGV2ZW50cy5TZXJ2ZXJGb3JnZXRVbmRvbmUodGhpcy5sYXN0Rm9yZ290dGVuU2VydmVyKSk7XG4gICAgICAgIHRoaXMubGFzdEZvcmdvdHRlblNlcnZlciA9IG51bGw7XG4gICAgfTtcbiAgICBQZXJzaXN0ZW50U2VydmVyUmVwb3NpdG9yeS5wcm90b3R5cGUuY29udGFpbnNTZXJ2ZXIgPSBmdW5jdGlvbiAoY29uZmlnKSB7XG4gICAgICAgIHJldHVybiAhIXRoaXMuc2VydmVyRnJvbUNvbmZpZyhjb25maWcpO1xuICAgIH07XG4gICAgUGVyc2lzdGVudFNlcnZlclJlcG9zaXRvcnkucHJvdG90eXBlLnNlcnZlckZyb21Db25maWcgPSBmdW5jdGlvbiAoY29uZmlnKSB7XG4gICAgICAgIHZhciBlXzEsIF9hO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgZm9yICh2YXIgX2IgPSBfX3ZhbHVlcyh0aGlzLmdldEFsbCgpKSwgX2MgPSBfYi5uZXh0KCk7ICFfYy5kb25lOyBfYyA9IF9iLm5leHQoKSkge1xuICAgICAgICAgICAgICAgIHZhciBzZXJ2ZXIgPSBfYy52YWx1ZTtcbiAgICAgICAgICAgICAgICBpZiAoY29uZmlnc01hdGNoKHNlcnZlci5jb25maWcsIGNvbmZpZykpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHNlcnZlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVfMV8xKSB7IGVfMSA9IHsgZXJyb3I6IGVfMV8xIH07IH1cbiAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGlmIChfYyAmJiAhX2MuZG9uZSAmJiAoX2EgPSBfYi5yZXR1cm4pKSBfYS5jYWxsKF9iKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZpbmFsbHkgeyBpZiAoZV8xKSB0aHJvdyBlXzEuZXJyb3I7IH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgUGVyc2lzdGVudFNlcnZlclJlcG9zaXRvcnkucHJvdG90eXBlLnN0b3JlU2VydmVycyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGVfMiwgX2E7XG4gICAgICAgIHZhciBjb25maWdCeUlkID0ge307XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBmb3IgKHZhciBfYiA9IF9fdmFsdWVzKHRoaXMuc2VydmVyQnlJZC52YWx1ZXMoKSksIF9jID0gX2IubmV4dCgpOyAhX2MuZG9uZTsgX2MgPSBfYi5uZXh0KCkpIHtcbiAgICAgICAgICAgICAgICB2YXIgc2VydmVyID0gX2MudmFsdWU7XG4gICAgICAgICAgICAgICAgY29uZmlnQnlJZFtzZXJ2ZXIuaWRdID0gc2VydmVyLmNvbmZpZztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZV8yXzEpIHsgZV8yID0geyBlcnJvcjogZV8yXzEgfTsgfVxuICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgaWYgKF9jICYmICFfYy5kb25lICYmIChfYSA9IF9iLnJldHVybikpIF9hLmNhbGwoX2IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZmluYWxseSB7IGlmIChlXzIpIHRocm93IGVfMi5lcnJvcjsgfVxuICAgICAgICB9XG4gICAgICAgIHZhciBqc29uID0gSlNPTi5zdHJpbmdpZnkoY29uZmlnQnlJZCk7XG4gICAgICAgIHRoaXMuc3RvcmFnZS5zZXRJdGVtKFBlcnNpc3RlbnRTZXJ2ZXJSZXBvc2l0b3J5LlNFUlZFUlNfU1RPUkFHRV9LRVksIGpzb24pO1xuICAgIH07XG4gICAgLy8gTG9hZHMgc2VydmVycyBmcm9tIHN0b3JhZ2UsXG4gICAgLy8gcmFpc2luZyBhbiBlcnJvciBpZiB0aGVyZSBpcyBhbnkgcHJvYmxlbSBsb2FkaW5nLlxuICAgIFBlcnNpc3RlbnRTZXJ2ZXJSZXBvc2l0b3J5LnByb3RvdHlwZS5sb2FkU2VydmVycyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5zZXJ2ZXJCeUlkID0gbmV3IE1hcCgpO1xuICAgICAgICB2YXIgc2VydmVyc0pzb24gPSB0aGlzLnN0b3JhZ2UuZ2V0SXRlbShQZXJzaXN0ZW50U2VydmVyUmVwb3NpdG9yeS5TRVJWRVJTX1NUT1JBR0VfS0VZKTtcbiAgICAgICAgaWYgKCFzZXJ2ZXJzSnNvbikge1xuICAgICAgICAgICAgY29uc29sZS5kZWJ1ZyhcIm5vIHNlcnZlcnMgZm91bmQgaW4gc3RvcmFnZVwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB2YXIgY29uZmlnQnlJZCA9IHt9O1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uZmlnQnlJZCA9IEpTT04ucGFyc2Uoc2VydmVyc0pzb24pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJjb3VsZCBub3QgcGFyc2Ugc2F2ZWQgc2VydmVyczogXCIgKyBlLm1lc3NhZ2UpO1xuICAgICAgICB9XG4gICAgICAgIGZvciAodmFyIHNlcnZlcklkIGluIGNvbmZpZ0J5SWQpIHtcbiAgICAgICAgICAgIGlmIChjb25maWdCeUlkLmhhc093blByb3BlcnR5KHNlcnZlcklkKSkge1xuICAgICAgICAgICAgICAgIHZhciBjb25maWcgPSBjb25maWdCeUlkW3NlcnZlcklkXTtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgc2VydmVyID0gdGhpcy5jcmVhdGVTZXJ2ZXIoc2VydmVySWQsIGNvbmZpZywgdGhpcy5ldmVudFF1ZXVlKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXJ2ZXJCeUlkLnNldChzZXJ2ZXJJZCwgc2VydmVyKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gRG9uJ3QgcHJvcGFnYXRlIHNvIG90aGVyIHN0b3JlZCBzZXJ2ZXJzIGNhbiBiZSBjcmVhdGVkLlxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgLy8gTmFtZSBieSB3aGljaCBzZXJ2ZXJzIGFyZSBzYXZlZCB0byBzdG9yYWdlLlxuICAgIFBlcnNpc3RlbnRTZXJ2ZXJSZXBvc2l0b3J5LlNFUlZFUlNfU1RPUkFHRV9LRVkgPSAnc2VydmVycyc7XG4gICAgcmV0dXJuIFBlcnNpc3RlbnRTZXJ2ZXJSZXBvc2l0b3J5O1xufSgpKTtcbmV4cG9ydHMuUGVyc2lzdGVudFNlcnZlclJlcG9zaXRvcnkgPSBQZXJzaXN0ZW50U2VydmVyUmVwb3NpdG9yeTtcbmZ1bmN0aW9uIGNvbmZpZ3NNYXRjaChsZWZ0LCByaWdodCkge1xuICAgIHJldHVybiBsZWZ0Lmhvc3QgPT09IHJpZ2h0Lmhvc3QgJiYgbGVmdC5wb3J0ID09PSByaWdodC5wb3J0ICYmIGxlZnQubWV0aG9kID09PSByaWdodC5tZXRob2QgJiZcbiAgICAgICAgbGVmdC5wYXNzd29yZCA9PT0gcmlnaHQucGFzc3dvcmQ7XG59XG4iLCJcInVzZSBzdHJpY3RcIjtcbi8vIENvcHlyaWdodCAyMDE4IFRoZSBPdXRsaW5lIEF1dGhvcnNcbi8vXG4vLyBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuLy8geW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuLy8gWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4vL1xuLy8gICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbi8vXG4vLyBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4vLyBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4vLyBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbi8vIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbi8vIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxudmFyIF9fdmFsdWVzID0gKHRoaXMgJiYgdGhpcy5fX3ZhbHVlcykgfHwgZnVuY3Rpb24gKG8pIHtcbiAgICB2YXIgbSA9IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvW1N5bWJvbC5pdGVyYXRvcl0sIGkgPSAwO1xuICAgIGlmIChtKSByZXR1cm4gbS5jYWxsKG8pO1xuICAgIHJldHVybiB7XG4gICAgICAgIG5leHQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmIChvICYmIGkgPj0gby5sZW5ndGgpIG8gPSB2b2lkIDA7XG4gICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogbyAmJiBvW2krK10sIGRvbmU6ICFvIH07XG4gICAgICAgIH1cbiAgICB9O1xufTtcbnZhciBfX3JlYWQgPSAodGhpcyAmJiB0aGlzLl9fcmVhZCkgfHwgZnVuY3Rpb24gKG8sIG4pIHtcbiAgICB2YXIgbSA9IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvW1N5bWJvbC5pdGVyYXRvcl07XG4gICAgaWYgKCFtKSByZXR1cm4gbztcbiAgICB2YXIgaSA9IG0uY2FsbChvKSwgciwgYXIgPSBbXSwgZTtcbiAgICB0cnkge1xuICAgICAgICB3aGlsZSAoKG4gPT09IHZvaWQgMCB8fCBuLS0gPiAwKSAmJiAhKHIgPSBpLm5leHQoKSkuZG9uZSkgYXIucHVzaChyLnZhbHVlKTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7IGUgPSB7IGVycm9yOiBlcnJvciB9OyB9XG4gICAgZmluYWxseSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAociAmJiAhci5kb25lICYmIChtID0gaVtcInJldHVyblwiXSkpIG0uY2FsbChpKTtcbiAgICAgICAgfVxuICAgICAgICBmaW5hbGx5IHsgaWYgKGUpIHRocm93IGUuZXJyb3I7IH1cbiAgICB9XG4gICAgcmV0dXJuIGFyO1xufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbi8vIFNldHRpbmcga2V5cyBzdXBwb3J0ZWQgYnkgdGhlIGBTZXR0aW5nc2AgY2xhc3MuXG52YXIgU2V0dGluZ3NLZXk7XG4oZnVuY3Rpb24gKFNldHRpbmdzS2V5KSB7XG4gICAgU2V0dGluZ3NLZXlbXCJWUE5fV0FSTklOR19ESVNNSVNTRURcIl0gPSBcInZwbi13YXJuaW5nLWRpc21pc3NlZFwiO1xuICAgIFNldHRpbmdzS2V5W1wiQVVUT19DT05ORUNUX0RJQUxPR19ESVNNSVNTRURcIl0gPSBcImF1dG8tY29ubmVjdC1kaWFsb2ctZGlzbWlzc2VkXCI7XG4gICAgU2V0dGluZ3NLZXlbXCJQUklWQUNZX0FDS1wiXSA9IFwicHJpdmFjeS1hY2tcIjtcbiAgICBTZXR0aW5nc0tleVtcIkJFVEFfQUNLXCJdID0gXCJiZXRhLWFja1wiO1xufSkoU2V0dGluZ3NLZXkgPSBleHBvcnRzLlNldHRpbmdzS2V5IHx8IChleHBvcnRzLlNldHRpbmdzS2V5ID0ge30pKTtcbi8vIFBlcnNpc3RlbnQgc3RvcmFnZSBmb3IgdXNlciBzZXR0aW5ncyB0aGF0IHN1cHBvcnRzIGEgbGltaXRlZCBzZXQgb2Yga2V5cy5cbnZhciBTZXR0aW5ncyA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBTZXR0aW5ncyhzdG9yYWdlLCB2YWxpZEtleXMpIHtcbiAgICAgICAgaWYgKHN0b3JhZ2UgPT09IHZvaWQgMCkgeyBzdG9yYWdlID0gd2luZG93LmxvY2FsU3RvcmFnZTsgfVxuICAgICAgICBpZiAodmFsaWRLZXlzID09PSB2b2lkIDApIHsgdmFsaWRLZXlzID0gT2JqZWN0LnZhbHVlcyhTZXR0aW5nc0tleSk7IH1cbiAgICAgICAgdGhpcy5zdG9yYWdlID0gc3RvcmFnZTtcbiAgICAgICAgdGhpcy52YWxpZEtleXMgPSB2YWxpZEtleXM7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MgPSBuZXcgTWFwKCk7XG4gICAgICAgIHRoaXMubG9hZFNldHRpbmdzKCk7XG4gICAgfVxuICAgIFNldHRpbmdzLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiAoa2V5KSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNldHRpbmdzLmdldChrZXkpO1xuICAgIH07XG4gICAgU2V0dGluZ3MucHJvdG90eXBlLnNldCA9IGZ1bmN0aW9uIChrZXksIHZhbHVlKSB7XG4gICAgICAgIGlmICghdGhpcy5pc1ZhbGlkU2V0dGluZyhrZXkpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3Qgc2V0IGludmFsaWQga2V5IFwiICsga2V5KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNldHRpbmdzLnNldChrZXksIHZhbHVlKTtcbiAgICAgICAgdGhpcy5zdG9yZVNldHRpbmdzKCk7XG4gICAgfTtcbiAgICBTZXR0aW5ncy5wcm90b3R5cGUucmVtb3ZlID0gZnVuY3Rpb24gKGtleSkge1xuICAgICAgICB0aGlzLnNldHRpbmdzLmRlbGV0ZShrZXkpO1xuICAgICAgICB0aGlzLnN0b3JlU2V0dGluZ3MoKTtcbiAgICB9O1xuICAgIFNldHRpbmdzLnByb3RvdHlwZS5pc1ZhbGlkU2V0dGluZyA9IGZ1bmN0aW9uIChrZXkpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudmFsaWRLZXlzLmluY2x1ZGVzKGtleSk7XG4gICAgfTtcbiAgICBTZXR0aW5ncy5wcm90b3R5cGUubG9hZFNldHRpbmdzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgc2V0dGluZ3NKc29uID0gdGhpcy5zdG9yYWdlLmdldEl0ZW0oU2V0dGluZ3MuU1RPUkFHRV9LRVkpO1xuICAgICAgICBpZiAoIXNldHRpbmdzSnNvbikge1xuICAgICAgICAgICAgY29uc29sZS5kZWJ1ZyhcIk5vIHNldHRpbmdzIGZvdW5kIGluIHN0b3JhZ2VcIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHN0b3JhZ2VTZXR0aW5ncyA9IEpTT04ucGFyc2Uoc2V0dGluZ3NKc29uKTtcbiAgICAgICAgZm9yICh2YXIga2V5IGluIHN0b3JhZ2VTZXR0aW5ncykge1xuICAgICAgICAgICAgaWYgKHN0b3JhZ2VTZXR0aW5ncy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXR0aW5ncy5zZXQoa2V5LCBzdG9yYWdlU2V0dGluZ3Nba2V5XSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIFNldHRpbmdzLnByb3RvdHlwZS5zdG9yZVNldHRpbmdzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgZV8xLCBfYTtcbiAgICAgICAgdmFyIHN0b3JhZ2VTZXR0aW5ncyA9IHt9O1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgZm9yICh2YXIgX2IgPSBfX3ZhbHVlcyh0aGlzLnNldHRpbmdzKSwgX2MgPSBfYi5uZXh0KCk7ICFfYy5kb25lOyBfYyA9IF9iLm5leHQoKSkge1xuICAgICAgICAgICAgICAgIHZhciBfZCA9IF9fcmVhZChfYy52YWx1ZSwgMiksIGtleSA9IF9kWzBdLCB2YWx1ZSA9IF9kWzFdO1xuICAgICAgICAgICAgICAgIHN0b3JhZ2VTZXR0aW5nc1trZXldID0gdmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVfMV8xKSB7IGVfMSA9IHsgZXJyb3I6IGVfMV8xIH07IH1cbiAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGlmIChfYyAmJiAhX2MuZG9uZSAmJiAoX2EgPSBfYi5yZXR1cm4pKSBfYS5jYWxsKF9iKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZpbmFsbHkgeyBpZiAoZV8xKSB0aHJvdyBlXzEuZXJyb3I7IH1cbiAgICAgICAgfVxuICAgICAgICB2YXIgc3RvcmFnZVNldHRpbmdzSnNvbiA9IEpTT04uc3RyaW5naWZ5KHN0b3JhZ2VTZXR0aW5ncyk7XG4gICAgICAgIHRoaXMuc3RvcmFnZS5zZXRJdGVtKFNldHRpbmdzLlNUT1JBR0VfS0VZLCBzdG9yYWdlU2V0dGluZ3NKc29uKTtcbiAgICB9O1xuICAgIFNldHRpbmdzLlNUT1JBR0VfS0VZID0gJ3NldHRpbmdzJztcbiAgICByZXR1cm4gU2V0dGluZ3M7XG59KCkpO1xuZXhwb3J0cy5TZXR0aW5ncyA9IFNldHRpbmdzO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG4vLyBDb3B5cmlnaHQgMjAxOCBUaGUgT3V0bGluZSBBdXRob3JzXG4vL1xuLy8gTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbi8vIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbi8vIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuLy9cbi8vICAgICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4vL1xuLy8gVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuLy8gZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuLy8gV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4vLyBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4vLyBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbnZhciBBYnN0cmFjdFVwZGF0ZXIgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gQWJzdHJhY3RVcGRhdGVyKCkge1xuICAgICAgICB0aGlzLmxpc3RlbmVyID0gbnVsbDtcbiAgICB9XG4gICAgQWJzdHJhY3RVcGRhdGVyLnByb3RvdHlwZS5zZXRMaXN0ZW5lciA9IGZ1bmN0aW9uIChsaXN0ZW5lcikge1xuICAgICAgICB0aGlzLmxpc3RlbmVyID0gbGlzdGVuZXI7XG4gICAgfTtcbiAgICBBYnN0cmFjdFVwZGF0ZXIucHJvdG90eXBlLmVtaXRFdmVudCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKHRoaXMubGlzdGVuZXIpIHtcbiAgICAgICAgICAgIHRoaXMubGlzdGVuZXIoKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIEFic3RyYWN0VXBkYXRlcjtcbn0oKSk7XG5leHBvcnRzLkFic3RyYWN0VXBkYXRlciA9IEFic3RyYWN0VXBkYXRlcjtcbiIsIlwidXNlIHN0cmljdFwiO1xuLy8gQ29weXJpZ2h0IDIwMTggVGhlIE91dGxpbmUgQXV0aG9yc1xuLy9cbi8vIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4vLyB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4vLyBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbi8vXG4vLyAgICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuLy9cbi8vIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbi8vIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbi8vIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuLy8gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuLy8gbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG52YXIgX19leHRlbmRzID0gKHRoaXMgJiYgdGhpcy5fX2V4dGVuZHMpIHx8IChmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGV4dGVuZFN0YXRpY3MgPSBmdW5jdGlvbiAoZCwgYikge1xuICAgICAgICBleHRlbmRTdGF0aWNzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8XG4gICAgICAgICAgICAoeyBfX3Byb3RvX186IFtdIH0gaW5zdGFuY2VvZiBBcnJheSAmJiBmdW5jdGlvbiAoZCwgYikgeyBkLl9fcHJvdG9fXyA9IGI7IH0pIHx8XG4gICAgICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChiLmhhc093blByb3BlcnR5KHApKSBkW3BdID0gYltwXTsgfTtcbiAgICAgICAgcmV0dXJuIGV4dGVuZFN0YXRpY3MoZCwgYik7XG4gICAgfVxuICAgIHJldHVybiBmdW5jdGlvbiAoZCwgYikge1xuICAgICAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xuICAgICAgICBmdW5jdGlvbiBfXygpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGQ7IH1cbiAgICAgICAgZC5wcm90b3R5cGUgPSBiID09PSBudWxsID8gT2JqZWN0LmNyZWF0ZShiKSA6IChfXy5wcm90b3R5cGUgPSBiLnByb3RvdHlwZSwgbmV3IF9fKCkpO1xuICAgIH07XG59KSgpO1xudmFyIF9fdmFsdWVzID0gKHRoaXMgJiYgdGhpcy5fX3ZhbHVlcykgfHwgZnVuY3Rpb24gKG8pIHtcbiAgICB2YXIgbSA9IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvW1N5bWJvbC5pdGVyYXRvcl0sIGkgPSAwO1xuICAgIGlmIChtKSByZXR1cm4gbS5jYWxsKG8pO1xuICAgIHJldHVybiB7XG4gICAgICAgIG5leHQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmIChvICYmIGkgPj0gby5sZW5ndGgpIG8gPSB2b2lkIDA7XG4gICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogbyAmJiBvW2krK10sIGRvbmU6ICFvIH07XG4gICAgICAgIH1cbiAgICB9O1xufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uL3R5cGVzL2FtYmllbnQvd2ViaW50ZW50cy5kLnRzJy8+XG52YXIgVXJsSW50ZXJjZXB0b3IgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gVXJsSW50ZXJjZXB0b3IoKSB7XG4gICAgICAgIHRoaXMubGlzdGVuZXJzID0gW107XG4gICAgfVxuICAgIFVybEludGVyY2VwdG9yLnByb3RvdHlwZS5yZWdpc3Rlckxpc3RlbmVyID0gZnVuY3Rpb24gKGxpc3RlbmVyKSB7XG4gICAgICAgIHRoaXMubGlzdGVuZXJzLnB1c2gobGlzdGVuZXIpO1xuICAgICAgICBpZiAodGhpcy5sYXVuY2hVcmwpIHtcbiAgICAgICAgICAgIGxpc3RlbmVyKHRoaXMubGF1bmNoVXJsKTtcbiAgICAgICAgICAgIHRoaXMubGF1bmNoVXJsID0gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBVcmxJbnRlcmNlcHRvci5wcm90b3R5cGUuZXhlY3V0ZUxpc3RlbmVycyA9IGZ1bmN0aW9uICh1cmwpIHtcbiAgICAgICAgdmFyIGVfMSwgX2E7XG4gICAgICAgIGlmICghdXJsKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLmxpc3RlbmVycy5sZW5ndGgpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdubyBsaXN0ZW5lcnMgaGF2ZSBiZWVuIGFkZGVkLCBkZWxheWluZyBpbnRlbnQgZmlyaW5nJyk7XG4gICAgICAgICAgICB0aGlzLmxhdW5jaFVybCA9IHVybDtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgZm9yICh2YXIgX2IgPSBfX3ZhbHVlcyh0aGlzLmxpc3RlbmVycyksIF9jID0gX2IubmV4dCgpOyAhX2MuZG9uZTsgX2MgPSBfYi5uZXh0KCkpIHtcbiAgICAgICAgICAgICAgICB2YXIgbGlzdGVuZXIgPSBfYy52YWx1ZTtcbiAgICAgICAgICAgICAgICBsaXN0ZW5lcih1cmwpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlXzFfMSkgeyBlXzEgPSB7IGVycm9yOiBlXzFfMSB9OyB9XG4gICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBpZiAoX2MgJiYgIV9jLmRvbmUgJiYgKF9hID0gX2IucmV0dXJuKSkgX2EuY2FsbChfYik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmaW5hbGx5IHsgaWYgKGVfMSkgdGhyb3cgZV8xLmVycm9yOyB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiBVcmxJbnRlcmNlcHRvcjtcbn0oKSk7XG5leHBvcnRzLlVybEludGVyY2VwdG9yID0gVXJsSW50ZXJjZXB0b3I7XG52YXIgQW5kcm9pZFVybEludGVyY2VwdG9yID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhBbmRyb2lkVXJsSW50ZXJjZXB0b3IsIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gQW5kcm9pZFVybEludGVyY2VwdG9yKCkge1xuICAgICAgICB2YXIgX3RoaXMgPSBfc3VwZXIuY2FsbCh0aGlzKSB8fCB0aGlzO1xuICAgICAgICB3aW5kb3cud2ViaW50ZW50LmdldFVyaShmdW5jdGlvbiAobGF1bmNoVXJsKSB7XG4gICAgICAgICAgICB3aW5kb3cud2ViaW50ZW50Lm9uTmV3SW50ZW50KF90aGlzLmV4ZWN1dGVMaXN0ZW5lcnMuYmluZChfdGhpcykpO1xuICAgICAgICAgICAgX3RoaXMuZXhlY3V0ZUxpc3RlbmVycyhsYXVuY2hVcmwpO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIF90aGlzO1xuICAgIH1cbiAgICByZXR1cm4gQW5kcm9pZFVybEludGVyY2VwdG9yO1xufShVcmxJbnRlcmNlcHRvcikpO1xuZXhwb3J0cy5BbmRyb2lkVXJsSW50ZXJjZXB0b3IgPSBBbmRyb2lkVXJsSW50ZXJjZXB0b3I7XG52YXIgQXBwbGVVcmxJbnRlcmNlcHRvciA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoQXBwbGVVcmxJbnRlcmNlcHRvciwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBBcHBsZVVybEludGVyY2VwdG9yKGxhdW5jaFVybCkge1xuICAgICAgICB2YXIgX3RoaXMgPSBfc3VwZXIuY2FsbCh0aGlzKSB8fCB0aGlzO1xuICAgICAgICAvLyBjb3Jkb3ZhLVtpb3N8b3N4XSBjYWxsIGEgZ2xvYmFsIGZ1bmN0aW9uIHdpdGggdGhpcyBzaWduYXR1cmUgd2hlbiBhIFVSTCBpcyBpbnRlcmNlcHRlZC5cbiAgICAgICAgLy8gV2UgZGVmaW5lIGl0IGluIHxjb3Jkb3ZhX21haW58LCByZWRlZmluZSBpdCB0byB1c2UgdGhpcyBpbnRlcmNlcHRvci5cbiAgICAgICAgd2luZG93LmhhbmRsZU9wZW5VUkwgPSBmdW5jdGlvbiAodXJsKSB7XG4gICAgICAgICAgICBfdGhpcy5leGVjdXRlTGlzdGVuZXJzKHVybCk7XG4gICAgICAgIH07XG4gICAgICAgIGlmIChsYXVuY2hVcmwpIHtcbiAgICAgICAgICAgIF90aGlzLmV4ZWN1dGVMaXN0ZW5lcnMobGF1bmNoVXJsKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gX3RoaXM7XG4gICAgfVxuICAgIHJldHVybiBBcHBsZVVybEludGVyY2VwdG9yO1xufShVcmxJbnRlcmNlcHRvcikpO1xuZXhwb3J0cy5BcHBsZVVybEludGVyY2VwdG9yID0gQXBwbGVVcmxJbnRlcmNlcHRvcjtcbiIsIlwidXNlIHN0cmljdFwiO1xuLy8gQ29weXJpZ2h0IDIwMTggVGhlIE91dGxpbmUgQXV0aG9yc1xuLy9cbi8vIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4vLyB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4vLyBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbi8vXG4vLyAgICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuLy9cbi8vIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbi8vIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbi8vIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuLy8gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuLy8gbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG52YXIgX19leHRlbmRzID0gKHRoaXMgJiYgdGhpcy5fX2V4dGVuZHMpIHx8IChmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGV4dGVuZFN0YXRpY3MgPSBmdW5jdGlvbiAoZCwgYikge1xuICAgICAgICBleHRlbmRTdGF0aWNzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8XG4gICAgICAgICAgICAoeyBfX3Byb3RvX186IFtdIH0gaW5zdGFuY2VvZiBBcnJheSAmJiBmdW5jdGlvbiAoZCwgYikgeyBkLl9fcHJvdG9fXyA9IGI7IH0pIHx8XG4gICAgICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChiLmhhc093blByb3BlcnR5KHApKSBkW3BdID0gYltwXTsgfTtcbiAgICAgICAgcmV0dXJuIGV4dGVuZFN0YXRpY3MoZCwgYik7XG4gICAgfVxuICAgIHJldHVybiBmdW5jdGlvbiAoZCwgYikge1xuICAgICAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xuICAgICAgICBmdW5jdGlvbiBfXygpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGQ7IH1cbiAgICAgICAgZC5wcm90b3R5cGUgPSBiID09PSBudWxsID8gT2JqZWN0LmNyZWF0ZShiKSA6IChfXy5wcm90b3R5cGUgPSBiLnByb3RvdHlwZSwgbmV3IF9fKCkpO1xuICAgIH07XG59KSgpO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xudmFyIE91dGxpbmVFcnJvciA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoT3V0bGluZUVycm9yLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIE91dGxpbmVFcnJvcihtZXNzYWdlKSB7XG4gICAgICAgIHZhciBfbmV3VGFyZ2V0ID0gdGhpcy5jb25zdHJ1Y3RvcjtcbiAgICAgICAgdmFyIF90aGlzID0gXG4gICAgICAgIC8vIHJlZjpcbiAgICAgICAgLy8gaHR0cHM6Ly93d3cudHlwZXNjcmlwdGxhbmcub3JnL2RvY3MvaGFuZGJvb2svcmVsZWFzZS1ub3Rlcy90eXBlc2NyaXB0LTItMi5odG1sI3N1cHBvcnQtZm9yLW5ld3RhcmdldFxuICAgICAgICBfc3VwZXIuY2FsbCh0aGlzLCBtZXNzYWdlKSB8fCB0aGlzO1xuICAgICAgICBPYmplY3Quc2V0UHJvdG90eXBlT2YoX3RoaXMsIF9uZXdUYXJnZXQucHJvdG90eXBlKTsgLy8gcmVzdG9yZSBwcm90b3R5cGUgY2hhaW5cbiAgICAgICAgX3RoaXMubmFtZSA9IF9uZXdUYXJnZXQubmFtZTtcbiAgICAgICAgcmV0dXJuIF90aGlzO1xuICAgIH1cbiAgICByZXR1cm4gT3V0bGluZUVycm9yO1xufShFcnJvcikpO1xuZXhwb3J0cy5PdXRsaW5lRXJyb3IgPSBPdXRsaW5lRXJyb3I7XG52YXIgU2VydmVyQWxyZWFkeUFkZGVkID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhTZXJ2ZXJBbHJlYWR5QWRkZWQsIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gU2VydmVyQWxyZWFkeUFkZGVkKHNlcnZlcikge1xuICAgICAgICB2YXIgX3RoaXMgPSBfc3VwZXIuY2FsbCh0aGlzKSB8fCB0aGlzO1xuICAgICAgICBfdGhpcy5zZXJ2ZXIgPSBzZXJ2ZXI7XG4gICAgICAgIHJldHVybiBfdGhpcztcbiAgICB9XG4gICAgcmV0dXJuIFNlcnZlckFscmVhZHlBZGRlZDtcbn0oT3V0bGluZUVycm9yKSk7XG5leHBvcnRzLlNlcnZlckFscmVhZHlBZGRlZCA9IFNlcnZlckFscmVhZHlBZGRlZDtcbnZhciBTZXJ2ZXJJbmNvbXBhdGlibGUgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKFNlcnZlckluY29tcGF0aWJsZSwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBTZXJ2ZXJJbmNvbXBhdGlibGUobWVzc2FnZSkge1xuICAgICAgICByZXR1cm4gX3N1cGVyLmNhbGwodGhpcywgbWVzc2FnZSkgfHwgdGhpcztcbiAgICB9XG4gICAgcmV0dXJuIFNlcnZlckluY29tcGF0aWJsZTtcbn0oT3V0bGluZUVycm9yKSk7XG5leHBvcnRzLlNlcnZlckluY29tcGF0aWJsZSA9IFNlcnZlckluY29tcGF0aWJsZTtcbnZhciBTZXJ2ZXJVcmxJbnZhbGlkID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhTZXJ2ZXJVcmxJbnZhbGlkLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIFNlcnZlclVybEludmFsaWQobWVzc2FnZSkge1xuICAgICAgICByZXR1cm4gX3N1cGVyLmNhbGwodGhpcywgbWVzc2FnZSkgfHwgdGhpcztcbiAgICB9XG4gICAgcmV0dXJuIFNlcnZlclVybEludmFsaWQ7XG59KE91dGxpbmVFcnJvcikpO1xuZXhwb3J0cy5TZXJ2ZXJVcmxJbnZhbGlkID0gU2VydmVyVXJsSW52YWxpZDtcbnZhciBPcGVyYXRpb25UaW1lZE91dCA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoT3BlcmF0aW9uVGltZWRPdXQsIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gT3BlcmF0aW9uVGltZWRPdXQodGltZW91dE1zLCBvcGVyYXRpb25OYW1lKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IF9zdXBlci5jYWxsKHRoaXMpIHx8IHRoaXM7XG4gICAgICAgIF90aGlzLnRpbWVvdXRNcyA9IHRpbWVvdXRNcztcbiAgICAgICAgX3RoaXMub3BlcmF0aW9uTmFtZSA9IG9wZXJhdGlvbk5hbWU7XG4gICAgICAgIHJldHVybiBfdGhpcztcbiAgICB9XG4gICAgcmV0dXJuIE9wZXJhdGlvblRpbWVkT3V0O1xufShPdXRsaW5lRXJyb3IpKTtcbmV4cG9ydHMuT3BlcmF0aW9uVGltZWRPdXQgPSBPcGVyYXRpb25UaW1lZE91dDtcbnZhciBGZWVkYmFja1N1Ym1pc3Npb25FcnJvciA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoRmVlZGJhY2tTdWJtaXNzaW9uRXJyb3IsIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gRmVlZGJhY2tTdWJtaXNzaW9uRXJyb3IoKSB7XG4gICAgICAgIHJldHVybiBfc3VwZXIuY2FsbCh0aGlzKSB8fCB0aGlzO1xuICAgIH1cbiAgICByZXR1cm4gRmVlZGJhY2tTdWJtaXNzaW9uRXJyb3I7XG59KE91dGxpbmVFcnJvcikpO1xuZXhwb3J0cy5GZWVkYmFja1N1Ym1pc3Npb25FcnJvciA9IEZlZWRiYWNrU3VibWlzc2lvbkVycm9yO1xuLy8gRXJyb3IgdGhyb3duIGJ5IFwibmF0aXZlXCIgY29kZS5cbi8vXG4vLyBNdXN0IGJlIGtlcHQgaW4gc3luYyB3aXRoIGl0cyBDb3Jkb3ZhIGRvcHBlbGdhbmdlcjpcbi8vICAgY29yZG92YS1wbHVnaW4tb3V0bGluZS9vdXRsaW5lUGx1Z2luLmpzXG4vL1xuLy8gVE9ETzogUmVuYW1lIHRoaXMgY2xhc3MsIFwicGx1Z2luXCIgaXMgYSBwb29yIG5hbWUgc2luY2UgdGhlIEVsZWN0cm9uIGFwcHMgZG8gbm90IGhhdmUgcGx1Z2lucy5cbnZhciBPdXRsaW5lUGx1Z2luRXJyb3IgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKE91dGxpbmVQbHVnaW5FcnJvciwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBPdXRsaW5lUGx1Z2luRXJyb3IoZXJyb3JDb2RlKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IF9zdXBlci5jYWxsKHRoaXMpIHx8IHRoaXM7XG4gICAgICAgIF90aGlzLmVycm9yQ29kZSA9IGVycm9yQ29kZTtcbiAgICAgICAgcmV0dXJuIF90aGlzO1xuICAgIH1cbiAgICByZXR1cm4gT3V0bGluZVBsdWdpbkVycm9yO1xufShPdXRsaW5lRXJyb3IpKTtcbmV4cG9ydHMuT3V0bGluZVBsdWdpbkVycm9yID0gT3V0bGluZVBsdWdpbkVycm9yO1xuLy8gTWFya2VyIGNsYXNzIGZvciBlcnJvcnMgb3JpZ2luYXRpbmcgaW4gbmF0aXZlIGNvZGUuXG4vLyBCaWZ1cmNhdGVzIGludG8gdHdvIHN1YmNsYXNzZXM6XG4vLyAgLSBcImV4cGVjdGVkXCIgZXJyb3JzIG9yaWdpbmF0aW5nIGluIG5hdGl2ZSBjb2RlLCBlLmcuIGluY29ycmVjdCBwYXNzd29yZFxuLy8gIC0gXCJ1bmV4cGVjdGVkXCIgZXJyb3JzIG9yaWdpbmF0aW5nIGluIG5hdGl2ZSBjb2RlLCBlLmcuIHVuaGFuZGxlZCByb3V0aW5nIHRhYmxlXG52YXIgTmF0aXZlRXJyb3IgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKE5hdGl2ZUVycm9yLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIE5hdGl2ZUVycm9yKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBOYXRpdmVFcnJvcjtcbn0oT3V0bGluZUVycm9yKSk7XG5leHBvcnRzLk5hdGl2ZUVycm9yID0gTmF0aXZlRXJyb3I7XG52YXIgUmVndWxhck5hdGl2ZUVycm9yID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhSZWd1bGFyTmF0aXZlRXJyb3IsIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gUmVndWxhck5hdGl2ZUVycm9yKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBSZWd1bGFyTmF0aXZlRXJyb3I7XG59KE5hdGl2ZUVycm9yKSk7XG5leHBvcnRzLlJlZ3VsYXJOYXRpdmVFcnJvciA9IFJlZ3VsYXJOYXRpdmVFcnJvcjtcbnZhciBSZWRGbGFnTmF0aXZlRXJyb3IgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKFJlZEZsYWdOYXRpdmVFcnJvciwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBSZWRGbGFnTmF0aXZlRXJyb3IoKSB7XG4gICAgICAgIHJldHVybiBfc3VwZXIgIT09IG51bGwgJiYgX3N1cGVyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cykgfHwgdGhpcztcbiAgICB9XG4gICAgcmV0dXJuIFJlZEZsYWdOYXRpdmVFcnJvcjtcbn0oTmF0aXZlRXJyb3IpKTtcbmV4cG9ydHMuUmVkRmxhZ05hdGl2ZUVycm9yID0gUmVkRmxhZ05hdGl2ZUVycm9yO1xuLy8vLy8vXG4vLyBcIkV4cGVjdGVkXCIgZXJyb3JzLlxuLy8vLy8vXG52YXIgVW5leHBlY3RlZFBsdWdpbkVycm9yID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhVbmV4cGVjdGVkUGx1Z2luRXJyb3IsIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gVW5leHBlY3RlZFBsdWdpbkVycm9yKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBVbmV4cGVjdGVkUGx1Z2luRXJyb3I7XG59KFJlZ3VsYXJOYXRpdmVFcnJvcikpO1xuZXhwb3J0cy5VbmV4cGVjdGVkUGx1Z2luRXJyb3IgPSBVbmV4cGVjdGVkUGx1Z2luRXJyb3I7XG52YXIgVnBuUGVybWlzc2lvbk5vdEdyYW50ZWQgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKFZwblBlcm1pc3Npb25Ob3RHcmFudGVkLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIFZwblBlcm1pc3Npb25Ob3RHcmFudGVkKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBWcG5QZXJtaXNzaW9uTm90R3JhbnRlZDtcbn0oUmVndWxhck5hdGl2ZUVycm9yKSk7XG5leHBvcnRzLlZwblBlcm1pc3Npb25Ob3RHcmFudGVkID0gVnBuUGVybWlzc2lvbk5vdEdyYW50ZWQ7XG52YXIgSW52YWxpZFNlcnZlckNyZWRlbnRpYWxzID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhJbnZhbGlkU2VydmVyQ3JlZGVudGlhbHMsIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gSW52YWxpZFNlcnZlckNyZWRlbnRpYWxzKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBJbnZhbGlkU2VydmVyQ3JlZGVudGlhbHM7XG59KFJlZ3VsYXJOYXRpdmVFcnJvcikpO1xuZXhwb3J0cy5JbnZhbGlkU2VydmVyQ3JlZGVudGlhbHMgPSBJbnZhbGlkU2VydmVyQ3JlZGVudGlhbHM7XG52YXIgUmVtb3RlVWRwRm9yd2FyZGluZ0Rpc2FibGVkID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhSZW1vdGVVZHBGb3J3YXJkaW5nRGlzYWJsZWQsIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gUmVtb3RlVWRwRm9yd2FyZGluZ0Rpc2FibGVkKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBSZW1vdGVVZHBGb3J3YXJkaW5nRGlzYWJsZWQ7XG59KFJlZ3VsYXJOYXRpdmVFcnJvcikpO1xuZXhwb3J0cy5SZW1vdGVVZHBGb3J3YXJkaW5nRGlzYWJsZWQgPSBSZW1vdGVVZHBGb3J3YXJkaW5nRGlzYWJsZWQ7XG52YXIgU2VydmVyVW5yZWFjaGFibGUgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKFNlcnZlclVucmVhY2hhYmxlLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIFNlcnZlclVucmVhY2hhYmxlKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBTZXJ2ZXJVbnJlYWNoYWJsZTtcbn0oUmVndWxhck5hdGl2ZUVycm9yKSk7XG5leHBvcnRzLlNlcnZlclVucmVhY2hhYmxlID0gU2VydmVyVW5yZWFjaGFibGU7XG52YXIgSWxsZWdhbFNlcnZlckNvbmZpZ3VyYXRpb24gPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKElsbGVnYWxTZXJ2ZXJDb25maWd1cmF0aW9uLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIElsbGVnYWxTZXJ2ZXJDb25maWd1cmF0aW9uKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBJbGxlZ2FsU2VydmVyQ29uZmlndXJhdGlvbjtcbn0oUmVndWxhck5hdGl2ZUVycm9yKSk7XG5leHBvcnRzLklsbGVnYWxTZXJ2ZXJDb25maWd1cmF0aW9uID0gSWxsZWdhbFNlcnZlckNvbmZpZ3VyYXRpb247XG52YXIgTm9BZG1pblBlcm1pc3Npb25zID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhOb0FkbWluUGVybWlzc2lvbnMsIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gTm9BZG1pblBlcm1pc3Npb25zKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBOb0FkbWluUGVybWlzc2lvbnM7XG59KFJlZ3VsYXJOYXRpdmVFcnJvcikpO1xuZXhwb3J0cy5Ob0FkbWluUGVybWlzc2lvbnMgPSBOb0FkbWluUGVybWlzc2lvbnM7XG52YXIgU3lzdGVtQ29uZmlndXJhdGlvbkV4Y2VwdGlvbiA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoU3lzdGVtQ29uZmlndXJhdGlvbkV4Y2VwdGlvbiwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBTeXN0ZW1Db25maWd1cmF0aW9uRXhjZXB0aW9uKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBTeXN0ZW1Db25maWd1cmF0aW9uRXhjZXB0aW9uO1xufShSZWd1bGFyTmF0aXZlRXJyb3IpKTtcbmV4cG9ydHMuU3lzdGVtQ29uZmlndXJhdGlvbkV4Y2VwdGlvbiA9IFN5c3RlbUNvbmZpZ3VyYXRpb25FeGNlcHRpb247XG4vLy8vLy9cbi8vIE5vdywgXCJ1bmV4cGVjdGVkXCIgZXJyb3JzLlxuLy8gVXNlIHRoZXNlIHNwYXJpbmdseSBiZWNhdXNlIGVhY2ggb2NjdXJyZW5jZSB0cmlnZ2VycyBhIFNlbnRyeSByZXBvcnQuXG4vLy8vLy9cbi8vIFdpbmRvd3MuXG52YXIgU2hhZG93c29ja3NTdGFydEZhaWx1cmUgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKFNoYWRvd3NvY2tzU3RhcnRGYWlsdXJlLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIFNoYWRvd3NvY2tzU3RhcnRGYWlsdXJlKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBTaGFkb3dzb2Nrc1N0YXJ0RmFpbHVyZTtcbn0oUmVkRmxhZ05hdGl2ZUVycm9yKSk7XG5leHBvcnRzLlNoYWRvd3NvY2tzU3RhcnRGYWlsdXJlID0gU2hhZG93c29ja3NTdGFydEZhaWx1cmU7XG52YXIgQ29uZmlndXJlU3lzdGVtUHJveHlGYWlsdXJlID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhDb25maWd1cmVTeXN0ZW1Qcm94eUZhaWx1cmUsIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gQ29uZmlndXJlU3lzdGVtUHJveHlGYWlsdXJlKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBDb25maWd1cmVTeXN0ZW1Qcm94eUZhaWx1cmU7XG59KFJlZEZsYWdOYXRpdmVFcnJvcikpO1xuZXhwb3J0cy5Db25maWd1cmVTeXN0ZW1Qcm94eUZhaWx1cmUgPSBDb25maWd1cmVTeXN0ZW1Qcm94eUZhaWx1cmU7XG52YXIgVW5zdXBwb3J0ZWRSb3V0aW5nVGFibGUgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKFVuc3VwcG9ydGVkUm91dGluZ1RhYmxlLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIFVuc3VwcG9ydGVkUm91dGluZ1RhYmxlKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIHJldHVybiBVbnN1cHBvcnRlZFJvdXRpbmdUYWJsZTtcbn0oUmVkRmxhZ05hdGl2ZUVycm9yKSk7XG5leHBvcnRzLlVuc3VwcG9ydGVkUm91dGluZ1RhYmxlID0gVW5zdXBwb3J0ZWRSb3V0aW5nVGFibGU7XG4vLyBVc2VkIG9uIEFuZHJvaWQgYW5kIEFwcGxlIHRvIGluZGljYXRlIHRoYXQgdGhlIHBsdWdpbiBmYWlsZWQgdG8gZXN0YWJsaXNoIHRoZSBWUE4gdHVubmVsLlxudmFyIFZwblN0YXJ0RmFpbHVyZSA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoVnBuU3RhcnRGYWlsdXJlLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIFZwblN0YXJ0RmFpbHVyZSgpIHtcbiAgICAgICAgcmV0dXJuIF9zdXBlciAhPT0gbnVsbCAmJiBfc3VwZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKSB8fCB0aGlzO1xuICAgIH1cbiAgICByZXR1cm4gVnBuU3RhcnRGYWlsdXJlO1xufShSZWRGbGFnTmF0aXZlRXJyb3IpKTtcbmV4cG9ydHMuVnBuU3RhcnRGYWlsdXJlID0gVnBuU3RhcnRGYWlsdXJlO1xuLy8gQ29udmVydHMgYW4gRXJyb3JDb2RlIC0gb3JpZ2luYXRpbmcgaW4gXCJuYXRpdmVcIiBjb2RlIC0gdG8gYW4gaW5zdGFuY2Ugb2YgdGhlIHJlbGV2YW50XG4vLyBPdXRsaW5lRXJyb3Igc3ViY2xhc3MuXG4vLyBUaHJvd3MgaWYgdGhlIGVycm9yIGNvZGUgaXMgbm90IG9uZSBkZWZpbmVkIGluIEVycm9yQ29kZSBvciBpcyBFcnJvckNvZGUuTk9fRVJST1IuXG5mdW5jdGlvbiBmcm9tRXJyb3JDb2RlKGVycm9yQ29kZSkge1xuICAgIHN3aXRjaCAoZXJyb3JDb2RlKSB7XG4gICAgICAgIGNhc2UgMSAvKiBVTkVYUEVDVEVEICovOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBVbmV4cGVjdGVkUGx1Z2luRXJyb3IoKTtcbiAgICAgICAgY2FzZSAyIC8qIFZQTl9QRVJNSVNTSU9OX05PVF9HUkFOVEVEICovOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBWcG5QZXJtaXNzaW9uTm90R3JhbnRlZCgpO1xuICAgICAgICBjYXNlIDMgLyogSU5WQUxJRF9TRVJWRVJfQ1JFREVOVElBTFMgKi86XG4gICAgICAgICAgICByZXR1cm4gbmV3IEludmFsaWRTZXJ2ZXJDcmVkZW50aWFscygpO1xuICAgICAgICBjYXNlIDQgLyogVURQX1JFTEFZX05PVF9FTkFCTEVEICovOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBSZW1vdGVVZHBGb3J3YXJkaW5nRGlzYWJsZWQoKTtcbiAgICAgICAgY2FzZSA1IC8qIFNFUlZFUl9VTlJFQUNIQUJMRSAqLzpcbiAgICAgICAgICAgIHJldHVybiBuZXcgU2VydmVyVW5yZWFjaGFibGUoKTtcbiAgICAgICAgY2FzZSA2IC8qIFZQTl9TVEFSVF9GQUlMVVJFICovOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBWcG5TdGFydEZhaWx1cmUoKTtcbiAgICAgICAgY2FzZSA3IC8qIElMTEVHQUxfU0VSVkVSX0NPTkZJR1VSQVRJT04gKi86XG4gICAgICAgICAgICByZXR1cm4gbmV3IElsbGVnYWxTZXJ2ZXJDb25maWd1cmF0aW9uKCk7XG4gICAgICAgIGNhc2UgOCAvKiBTSEFET1dTT0NLU19TVEFSVF9GQUlMVVJFICovOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBTaGFkb3dzb2Nrc1N0YXJ0RmFpbHVyZSgpO1xuICAgICAgICBjYXNlIDkgLyogQ09ORklHVVJFX1NZU1RFTV9QUk9YWV9GQUlMVVJFICovOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBDb25maWd1cmVTeXN0ZW1Qcm94eUZhaWx1cmUoKTtcbiAgICAgICAgY2FzZSAxMCAvKiBOT19BRE1JTl9QRVJNSVNTSU9OUyAqLzpcbiAgICAgICAgICAgIHJldHVybiBuZXcgTm9BZG1pblBlcm1pc3Npb25zKCk7XG4gICAgICAgIGNhc2UgMTEgLyogVU5TVVBQT1JURURfUk9VVElOR19UQUJMRSAqLzpcbiAgICAgICAgICAgIHJldHVybiBuZXcgVW5zdXBwb3J0ZWRSb3V0aW5nVGFibGUoKTtcbiAgICAgICAgY2FzZSAxMiAvKiBTWVNURU1fTUlTQ09ORklHVVJFRCAqLzpcbiAgICAgICAgICAgIHJldHVybiBuZXcgU3lzdGVtQ29uZmlndXJhdGlvbkV4Y2VwdGlvbigpO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwidW5rbm93biBFcnJvckNvZGUgXCIgKyBlcnJvckNvZGUpO1xuICAgIH1cbn1cbmV4cG9ydHMuZnJvbUVycm9yQ29kZSA9IGZyb21FcnJvckNvZGU7XG4vLyBDb252ZXJ0cyBhIE5hdGl2ZUVycm9yIHRvIGFuIEVycm9yQ29kZS5cbi8vIFRocm93cyBpZiB0aGUgZXJyb3IgaXMgbm90IGEgc3ViY2xhc3Mgb2YgTmF0aXZlRXJyb3IuXG5mdW5jdGlvbiB0b0Vycm9yQ29kZShlKSB7XG4gICAgaWYgKGUgaW5zdGFuY2VvZiBVbmV4cGVjdGVkUGx1Z2luRXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIDEgLyogVU5FWFBFQ1RFRCAqLztcbiAgICB9XG4gICAgZWxzZSBpZiAoZSBpbnN0YW5jZW9mIFZwblBlcm1pc3Npb25Ob3RHcmFudGVkKSB7XG4gICAgICAgIHJldHVybiAyIC8qIFZQTl9QRVJNSVNTSU9OX05PVF9HUkFOVEVEICovO1xuICAgIH1cbiAgICBlbHNlIGlmIChlIGluc3RhbmNlb2YgSW52YWxpZFNlcnZlckNyZWRlbnRpYWxzKSB7XG4gICAgICAgIHJldHVybiAzIC8qIElOVkFMSURfU0VSVkVSX0NSRURFTlRJQUxTICovO1xuICAgIH1cbiAgICBlbHNlIGlmIChlIGluc3RhbmNlb2YgUmVtb3RlVWRwRm9yd2FyZGluZ0Rpc2FibGVkKSB7XG4gICAgICAgIHJldHVybiA0IC8qIFVEUF9SRUxBWV9OT1RfRU5BQkxFRCAqLztcbiAgICB9XG4gICAgZWxzZSBpZiAoZSBpbnN0YW5jZW9mIFNlcnZlclVucmVhY2hhYmxlKSB7XG4gICAgICAgIHJldHVybiA1IC8qIFNFUlZFUl9VTlJFQUNIQUJMRSAqLztcbiAgICB9XG4gICAgZWxzZSBpZiAoZSBpbnN0YW5jZW9mIFZwblN0YXJ0RmFpbHVyZSkge1xuICAgICAgICByZXR1cm4gNiAvKiBWUE5fU1RBUlRfRkFJTFVSRSAqLztcbiAgICB9XG4gICAgZWxzZSBpZiAoZSBpbnN0YW5jZW9mIElsbGVnYWxTZXJ2ZXJDb25maWd1cmF0aW9uKSB7XG4gICAgICAgIHJldHVybiA3IC8qIElMTEVHQUxfU0VSVkVSX0NPTkZJR1VSQVRJT04gKi87XG4gICAgfVxuICAgIGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBTaGFkb3dzb2Nrc1N0YXJ0RmFpbHVyZSkge1xuICAgICAgICByZXR1cm4gOCAvKiBTSEFET1dTT0NLU19TVEFSVF9GQUlMVVJFICovO1xuICAgIH1cbiAgICBlbHNlIGlmIChlIGluc3RhbmNlb2YgQ29uZmlndXJlU3lzdGVtUHJveHlGYWlsdXJlKSB7XG4gICAgICAgIHJldHVybiA5IC8qIENPTkZJR1VSRV9TWVNURU1fUFJPWFlfRkFJTFVSRSAqLztcbiAgICB9XG4gICAgZWxzZSBpZiAoZSBpbnN0YW5jZW9mIFVuc3VwcG9ydGVkUm91dGluZ1RhYmxlKSB7XG4gICAgICAgIHJldHVybiAxMSAvKiBVTlNVUFBPUlRFRF9ST1VUSU5HX1RBQkxFICovO1xuICAgIH1cbiAgICBlbHNlIGlmIChlIGluc3RhbmNlb2YgTm9BZG1pblBlcm1pc3Npb25zKSB7XG4gICAgICAgIHJldHVybiAxMCAvKiBOT19BRE1JTl9QRVJNSVNTSU9OUyAqLztcbiAgICB9XG4gICAgZWxzZSBpZiAoZSBpbnN0YW5jZW9mIFN5c3RlbUNvbmZpZ3VyYXRpb25FeGNlcHRpb24pIHtcbiAgICAgICAgcmV0dXJuIDEyIC8qIFNZU1RFTV9NSVNDT05GSUdVUkVEICovO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJ1bmtub3duIE5hdGl2ZUVycm9yIFwiICsgZS5uYW1lKTtcbn1cbmV4cG9ydHMudG9FcnJvckNvZGUgPSB0b0Vycm9yQ29kZTtcbiIsIlwidXNlIHN0cmljdFwiO1xuLy8gQ29weXJpZ2h0IDIwMTggVGhlIE91dGxpbmUgQXV0aG9yc1xuLy9cbi8vIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4vLyB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4vLyBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbi8vXG4vLyAgICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuLy9cbi8vIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbi8vIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbi8vIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuLy8gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuLy8gbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG52YXIgX192YWx1ZXMgPSAodGhpcyAmJiB0aGlzLl9fdmFsdWVzKSB8fCBmdW5jdGlvbiAobykge1xuICAgIHZhciBtID0gdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIG9bU3ltYm9sLml0ZXJhdG9yXSwgaSA9IDA7XG4gICAgaWYgKG0pIHJldHVybiBtLmNhbGwobyk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbmV4dDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKG8gJiYgaSA+PSBvLmxlbmd0aCkgbyA9IHZvaWQgMDtcbiAgICAgICAgICAgIHJldHVybiB7IHZhbHVlOiBvICYmIG9baSsrXSwgZG9uZTogIW8gfTtcbiAgICAgICAgfVxuICAgIH07XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xudmFyIFNlcnZlckFkZGVkID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFNlcnZlckFkZGVkKHNlcnZlcikge1xuICAgICAgICB0aGlzLnNlcnZlciA9IHNlcnZlcjtcbiAgICB9XG4gICAgcmV0dXJuIFNlcnZlckFkZGVkO1xufSgpKTtcbmV4cG9ydHMuU2VydmVyQWRkZWQgPSBTZXJ2ZXJBZGRlZDtcbnZhciBTZXJ2ZXJBbHJlYWR5QWRkZWQgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gU2VydmVyQWxyZWFkeUFkZGVkKHNlcnZlcikge1xuICAgICAgICB0aGlzLnNlcnZlciA9IHNlcnZlcjtcbiAgICB9XG4gICAgcmV0dXJuIFNlcnZlckFscmVhZHlBZGRlZDtcbn0oKSk7XG5leHBvcnRzLlNlcnZlckFscmVhZHlBZGRlZCA9IFNlcnZlckFscmVhZHlBZGRlZDtcbnZhciBTZXJ2ZXJGb3Jnb3R0ZW4gPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gU2VydmVyRm9yZ290dGVuKHNlcnZlcikge1xuICAgICAgICB0aGlzLnNlcnZlciA9IHNlcnZlcjtcbiAgICB9XG4gICAgcmV0dXJuIFNlcnZlckZvcmdvdHRlbjtcbn0oKSk7XG5leHBvcnRzLlNlcnZlckZvcmdvdHRlbiA9IFNlcnZlckZvcmdvdHRlbjtcbnZhciBTZXJ2ZXJGb3JnZXRVbmRvbmUgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gU2VydmVyRm9yZ2V0VW5kb25lKHNlcnZlcikge1xuICAgICAgICB0aGlzLnNlcnZlciA9IHNlcnZlcjtcbiAgICB9XG4gICAgcmV0dXJuIFNlcnZlckZvcmdldFVuZG9uZTtcbn0oKSk7XG5leHBvcnRzLlNlcnZlckZvcmdldFVuZG9uZSA9IFNlcnZlckZvcmdldFVuZG9uZTtcbnZhciBTZXJ2ZXJSZW5hbWVkID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFNlcnZlclJlbmFtZWQoc2VydmVyKSB7XG4gICAgICAgIHRoaXMuc2VydmVyID0gc2VydmVyO1xuICAgIH1cbiAgICByZXR1cm4gU2VydmVyUmVuYW1lZDtcbn0oKSk7XG5leHBvcnRzLlNlcnZlclJlbmFtZWQgPSBTZXJ2ZXJSZW5hbWVkO1xudmFyIFNlcnZlclVybEludmFsaWQgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gU2VydmVyVXJsSW52YWxpZChzZXJ2ZXJVcmwpIHtcbiAgICAgICAgdGhpcy5zZXJ2ZXJVcmwgPSBzZXJ2ZXJVcmw7XG4gICAgfVxuICAgIHJldHVybiBTZXJ2ZXJVcmxJbnZhbGlkO1xufSgpKTtcbmV4cG9ydHMuU2VydmVyVXJsSW52YWxpZCA9IFNlcnZlclVybEludmFsaWQ7XG52YXIgU2VydmVyQ29ubmVjdGVkID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFNlcnZlckNvbm5lY3RlZChzZXJ2ZXIpIHtcbiAgICAgICAgdGhpcy5zZXJ2ZXIgPSBzZXJ2ZXI7XG4gICAgfVxuICAgIHJldHVybiBTZXJ2ZXJDb25uZWN0ZWQ7XG59KCkpO1xuZXhwb3J0cy5TZXJ2ZXJDb25uZWN0ZWQgPSBTZXJ2ZXJDb25uZWN0ZWQ7XG52YXIgU2VydmVyRGlzY29ubmVjdGVkID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFNlcnZlckRpc2Nvbm5lY3RlZChzZXJ2ZXIpIHtcbiAgICAgICAgdGhpcy5zZXJ2ZXIgPSBzZXJ2ZXI7XG4gICAgfVxuICAgIHJldHVybiBTZXJ2ZXJEaXNjb25uZWN0ZWQ7XG59KCkpO1xuZXhwb3J0cy5TZXJ2ZXJEaXNjb25uZWN0ZWQgPSBTZXJ2ZXJEaXNjb25uZWN0ZWQ7XG52YXIgU2VydmVyUmVjb25uZWN0aW5nID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFNlcnZlclJlY29ubmVjdGluZyhzZXJ2ZXIpIHtcbiAgICAgICAgdGhpcy5zZXJ2ZXIgPSBzZXJ2ZXI7XG4gICAgfVxuICAgIHJldHVybiBTZXJ2ZXJSZWNvbm5lY3Rpbmc7XG59KCkpO1xuZXhwb3J0cy5TZXJ2ZXJSZWNvbm5lY3RpbmcgPSBTZXJ2ZXJSZWNvbm5lY3Rpbmc7XG4vLyBTaW1wbGUgcHVibGlzaGVyLXN1YnNjcmliZXIgcXVldWUuXG52YXIgRXZlbnRRdWV1ZSA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBFdmVudFF1ZXVlKCkge1xuICAgICAgICB0aGlzLnF1ZXVlZEV2ZW50cyA9IFtdO1xuICAgICAgICB0aGlzLmxpc3RlbmVyc0J5RXZlbnRUeXBlID0gbmV3IE1hcCgpO1xuICAgICAgICB0aGlzLmlzU3RhcnRlZCA9IGZhbHNlO1xuICAgICAgICB0aGlzLmlzUHVibGlzaGluZyA9IGZhbHNlO1xuICAgIH1cbiAgICBFdmVudFF1ZXVlLnByb3RvdHlwZS5zdGFydFB1Ymxpc2hpbmcgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRoaXMuaXNTdGFydGVkID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5wdWJsaXNoUXVldWVkRXZlbnRzKCk7XG4gICAgfTtcbiAgICAvLyBSZWdpc3RlcnMgYSBsaXN0ZW5lciBmb3IgZXZlbnRzIG9mIHRoZSB0eXBlIG9mIHRoZSBnaXZlbiBjb25zdHJ1Y3Rvci5cbiAgICBFdmVudFF1ZXVlLnByb3RvdHlwZS5zdWJzY3JpYmUgPSBmdW5jdGlvbiAoZXZlbnRUeXBlLCBsaXN0ZW5lcikge1xuICAgICAgICB2YXIgbGlzdGVuZXJzID0gdGhpcy5saXN0ZW5lcnNCeUV2ZW50VHlwZS5nZXQoZXZlbnRUeXBlKTtcbiAgICAgICAgaWYgKCFsaXN0ZW5lcnMpIHtcbiAgICAgICAgICAgIGxpc3RlbmVycyA9IFtdO1xuICAgICAgICAgICAgdGhpcy5saXN0ZW5lcnNCeUV2ZW50VHlwZS5zZXQoZXZlbnRUeXBlLCBsaXN0ZW5lcnMpO1xuICAgICAgICB9XG4gICAgICAgIGxpc3RlbmVycy5wdXNoKGxpc3RlbmVyKTtcbiAgICB9O1xuICAgIC8vIEVucXVldWVzIHRoZSBnaXZlbiBldmVudCBmb3IgcHVibGlzaGluZyBhbmQgcHVibGlzaGVzIGFsbCBxdWV1ZWQgZXZlbnRzIGlmXG4gICAgLy8gcHVibGlzaGluZyBpcyBub3QgYWxyZWFkeSBoYXBwZW5pbmcuXG4gICAgLy9cbiAgICAvLyBUaGUgZW5xdWV1ZSBtZXRob2QgaXMgcmVlbnRyYW50OiBpdCBtYXkgYmUgY2FsbGVkIGJ5IGFuIGV2ZW50IGxpc3RlbmVyXG4gICAgLy8gZHVyaW5nIHRoZSBwdWJsaXNoaW5nIG9mIHRoZSBldmVudHMuIEluIHRoYXQgY2FzZSB0aGUgbWV0aG9kIGFkZHMgdGhlIGV2ZW50XG4gICAgLy8gdG8gdGhlIGVuZCBvZiB0aGUgcXVldWUgYW5kIHJldHVybnMgaW1tZWRpYXRlbHkuXG4gICAgLy9cbiAgICAvLyBUaGlzIGd1YXJhbnRlZXMgdGhhdCBldmVudHMgYXJlIHB1Ymxpc2hlZCBhbmQgaGFuZGxlZCBpbiB0aGUgb3JkZXIgdGhhdFxuICAgIC8vIHRoZXkgYXJlIHF1ZXVlZC5cbiAgICAvL1xuICAgIC8vIFRoZXJlJ3Mgbm8gZ3VhcmFudGVlIHRoYXQgdGhlIHN1YnNjcmliZXJzIGZvciB0aGUgZXZlbnQgaGF2ZSBiZWVuIGNhbGxlZCBieVxuICAgIC8vIHRoZSB0aW1lIHRoaXMgZnVuY3Rpb24gcmV0dXJucy5cbiAgICBFdmVudFF1ZXVlLnByb3RvdHlwZS5lbnF1ZXVlID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgIHRoaXMucXVldWVkRXZlbnRzLnB1c2goZXZlbnQpO1xuICAgICAgICBpZiAodGhpcy5pc1N0YXJ0ZWQpIHtcbiAgICAgICAgICAgIHRoaXMucHVibGlzaFF1ZXVlZEV2ZW50cygpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvLyBUcmlnZ2VycyB0aGUgc3Vic2NyaWJlcnMgZm9yIGFsbCB0aGUgZW5xdWV1ZWQgZXZlbnRzLlxuICAgIEV2ZW50UXVldWUucHJvdG90eXBlLnB1Ymxpc2hRdWV1ZWRFdmVudHMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBlXzEsIF9hO1xuICAgICAgICBpZiAodGhpcy5pc1B1Ymxpc2hpbmcpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIHRoaXMuaXNQdWJsaXNoaW5nID0gdHJ1ZTtcbiAgICAgICAgd2hpbGUgKHRoaXMucXVldWVkRXZlbnRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHZhciBldmVudF8xID0gdGhpcy5xdWV1ZWRFdmVudHMuc2hpZnQoKTtcbiAgICAgICAgICAgIHZhciBsaXN0ZW5lcnMgPSB0aGlzLmxpc3RlbmVyc0J5RXZlbnRUeXBlLmdldChldmVudF8xLmNvbnN0cnVjdG9yKTtcbiAgICAgICAgICAgIGlmICghbGlzdGVuZXJzKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdEcm9wcGluZyBldmVudCB3aXRoIG5vIGxpc3RlbmVyczonLCBldmVudF8xKTtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgbGlzdGVuZXJzXzEgPSBfX3ZhbHVlcyhsaXN0ZW5lcnMpLCBsaXN0ZW5lcnNfMV8xID0gbGlzdGVuZXJzXzEubmV4dCgpOyAhbGlzdGVuZXJzXzFfMS5kb25lOyBsaXN0ZW5lcnNfMV8xID0gbGlzdGVuZXJzXzEubmV4dCgpKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBsaXN0ZW5lciA9IGxpc3RlbmVyc18xXzEudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIGxpc3RlbmVyKGV2ZW50XzEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlXzFfMSkgeyBlXzEgPSB7IGVycm9yOiBlXzFfMSB9OyB9XG4gICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBpZiAobGlzdGVuZXJzXzFfMSAmJiAhbGlzdGVuZXJzXzFfMS5kb25lICYmIChfYSA9IGxpc3RlbmVyc18xLnJldHVybikpIF9hLmNhbGwobGlzdGVuZXJzXzEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmaW5hbGx5IHsgaWYgKGVfMSkgdGhyb3cgZV8xLmVycm9yOyB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5pc1B1Ymxpc2hpbmcgPSBmYWxzZTtcbiAgICB9O1xuICAgIHJldHVybiBFdmVudFF1ZXVlO1xufSgpKTtcbmV4cG9ydHMuRXZlbnRRdWV1ZSA9IEV2ZW50UXVldWU7XG4iXX0=
